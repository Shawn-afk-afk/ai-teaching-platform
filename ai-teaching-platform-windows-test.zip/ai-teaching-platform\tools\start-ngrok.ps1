param([switch]$CheckOnly)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $projectRoot
$tunnelProcess = $null
$oldPublicOrigin = $env:PUBLIC_ORIGIN
$launchExit = 0
try {
    $ngrokExecutable = Join-Path $projectRoot 'ngrok.exe'
    if (-not (Test-Path -LiteralPath $ngrokExecutable)) {
        $ngrokExecutable = Join-Path $projectRoot 'tools\ngrok\ngrok.exe'
    }
    if (-not (Test-Path -LiteralPath $ngrokExecutable)) {
        $ngrokCommand = Get-Command ngrok.exe -ErrorAction SilentlyContinue
        if (-not $ngrokCommand) { throw 'ngrok.exe not found. Download it from https://ngrok.com/download/windows and place it beside start-ngrok.bat.' }
        $ngrokExecutable = $ngrokCommand.Source
    }
    & $ngrokExecutable version
    if ($LASTEXITCODE -ne 0) { throw 'ngrok version check failed.' }
    $configDirectory = Join-Path $projectRoot 'data\ngrok'
    $configFile = Join-Path $configDirectory 'ngrok.yml'
    if ($CheckOnly) {
        Write-Host ('Executable: ' + $ngrokExecutable)
        Write-Host ('Config exists: ' + (Test-Path -LiteralPath $configFile))
        Write-Host 'Check complete. No tunnel or website was started.'
    } else {
        if (-not (Test-Path -LiteralPath $configFile)) {
            Write-Host 'First-time setup (run these commands in PowerShell inside this project):' -ForegroundColor Yellow
            Write-Host '  New-Item -ItemType Directory -Force -Path .\data\ngrok | Out-Null'
            Write-Host '  .\ngrok.exe config add-authtoken YOUR_TOKEN --config .\data\ngrok\ngrok.yml'
            throw 'Configure your own ngrok token first, then double-click start-ngrok.bat again. Do not share your token.'
        }
        & $ngrokExecutable config check --config $configFile
        if ($LASTEXITCODE -ne 0) { throw 'ngrok configuration is invalid. See the message above.' }
        foreach ($port in @(4180,4040)) {
            $listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,$port)
            try { $listener.Start() } catch { throw ('Port ' + $port + ' is busy. Save your work and press Ctrl+C in the old website/ngrok window, then retry. No existing process was stopped.') } finally { $listener.Stop() }
        }
        $stdout = Join-Path $configDirectory 'agent.stdout.log'
        $stderr = Join-Path $configDirectory 'agent.stderr.log'
        # These arguments are fixed; only a quoted local config path is variable.
        $agentArguments = 'http http://127.0.0.1:4180 --inspect=false --config "' + $configFile + '"'
        $tunnelProcess = Start-Process -FilePath $ngrokExecutable -ArgumentList $agentArguments -WorkingDirectory $projectRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
        Write-Host 'Connecting ngrok (up to 40 seconds)...'
        $publicUrl = $null
        $deadline = [DateTime]::UtcNow.AddSeconds(40)
        while ([DateTime]::UtcNow -lt $deadline) {
            if ($tunnelProcess.HasExited) { throw ('ngrok exited. Read data\ngrok\agent.stderr.log for the ngrok error. Exit code: ' + $tunnelProcess.ExitCode) }
            try {
                $info = Invoke-RestMethod -Uri 'http://127.0.0.1:4040/api/tunnels' -TimeoutSec 2
                $candidate = $info.tunnels | Where-Object { $_.public_url -like 'https://*' -and $_.config.addr -in @('http://127.0.0.1:4180','127.0.0.1:4180') } | Select-Object -First 1
                if ($candidate) { $publicUrl = ([Uri]$candidate.public_url).GetLeftPart([UriPartial]::Authority); break }
            } catch { }
            Start-Sleep -Milliseconds 500
        }
        if (-not $publicUrl) { throw 'No HTTPS tunnel found. Check your network, account token, ngrok account limits and data\ngrok\agent.stderr.log. The ngrok local API must listen on 127.0.0.1:4040.' }
        $env:PUBLIC_ORIGIN = $publicUrl
        Set-Content -LiteralPath (Join-Path $configDirectory 'public-url.txt') -Value $publicUrl -Encoding UTF8
        Write-Host ''
        Write-Host ('PUBLIC URL: ' + $publicUrl) -ForegroundColor Green
        Write-Host 'Share this HTTPS URL with testers. Log in with existing teacher credentials or student invitation codes.'
        Write-Host 'Keep this window and Ollama running. Save work before Ctrl+C. Closing this launcher stops its tunnel.'
        Write-Host 'The URL is also saved in data\ngrok\public-url.txt.'
        Write-Host ''
        & (Join-Path $projectRoot 'start-p7.ps1')
        if ($LASTEXITCODE -ne 0) { throw ('Website exited with code ' + $LASTEXITCODE) }
    }
} catch {
    Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
    $launchExit = 1
} finally {
    $env:PUBLIC_ORIGIN = $oldPublicOrigin
    if ($null -ne $tunnelProcess -and -not $tunnelProcess.HasExited) { Stop-Process -Id $tunnelProcess.Id -ErrorAction SilentlyContinue }
}
exit $launchExit
