import {el,button,field} from './content-editor.js';
import {SESSION_LABELS} from '../domain/session.js';
import {EXTRA_TYPES} from '../domain/extended-questions.js';
import {studentExtra,renderRichBlock} from './expanded-content.js';
export function updateStudentSession(root,session,unknown=false,location='本機'){
  const state=root.querySelector('#learner-session');if(!state)return;state.textContent=unknown?'stale · 無法取得課堂狀態，暫時禁止修改。':session?`${location}課堂：${SESSION_LABELS[session.state]} · ${session.state==='active'?'可作答':'唯讀；未保存輸入仍保留，不會自動提交'}`:'自主學習';
  const locked=unknown||Boolean(session&&session.state!=='active');for(const node of root.querySelectorAll('#learner-questions,#save-answers,#submit-attempt'))node.disabled=locked||root.dataset.editable!=='true';const begin=root.querySelector('#begin-attempt');if(begin)begin.disabled=locked;
}
const date=value=>new Date(value).toLocaleString('zh-TW');
// This renderer receives only AssessmentService's allowlisted learner envelope.
export function renderStudentWork(root,view,{begin,save,submit,changed,selectAttempt,upload},selectedId){
  root.replaceChildren();const {content,assignment}=view;root.append(el('p','',{id:'learner-session',role:'status'}));
  root.append(el('h3',assignment.title),el('p',`${content.title} · 固定版本 v${view.resourceVersionNo}`),el('p',`開放：${assignment.opensAt?date(assignment.opensAt):'立即'} · 截止：${assignment.closesAt?date(assignment.closesAt):'不限時'} · 最多 ${assignment.maxAttempts} 次`));
  const current=view.attempts.find(a=>a.id===selectedId)??view.attempts.find(a=>a.status==='in_progress'&&!a.invalidatedAt)??view.attempts.at(-1);
  if(view.attempts.length){const chooser=field('查看作答紀錄',current.id,selectAttempt,{options:view.attempts.map(a=>[a.id,`第 ${a.attemptNo} 次 · ${{in_progress:'作答中',submitted:'已提交',closed:'已關閉'}[a.status]}`])});chooser.querySelector('select').id='learner-attempt';root.append(chooser);}
  const inProgress=current?.status==='in_progress'&&!current.invalidatedAt;
  root.dataset.editable=String(Boolean(inProgress&&!view.archived));
  if(!view.attempts.some(a=>a.status==='in_progress'&&!a.invalidatedAt)&&view.attempts.length<assignment.maxAttempts&&!view.archived){const start=button(current?'開始另一次作答':'開始作答',begin);start.id='begin-attempt';root.append(start);}
  if(!current){root.append(el('p','尚未開始。開始後可暫存並離開，再回到此頁恢復。'));updateStudentSession(root,view.session);return;}
  root.append(el('p',`第 ${current.attemptNo} 次 · ${current.invalidatedAt?'已失效，不列入報告':inProgress?'作答中，尚未提交':`已提交：${date(current.submittedAt)}`}`,{id:'attempt-status'}));
  const responses=view.responses.filter(r=>r.attemptId===current.id),answers=Object.fromEntries(responses.map(r=>[r.questionId,r.answer]));
  const questions=el('fieldset','',{id:'learner-questions'});questions.disabled=!inProgress||view.archived;
  for(const block of content.blocks){
    if(block.type!=='questionSet'){questions.append(['vocabularyList','organizer'].includes(block.type)?renderRichBlock(block):el(block.type==='heading'?'h4':'p',block.data.text,{class:'preview-block'}));continue;}
    for(const id of block.data.questionIds){const q=content.questions.find(q=>q.id===id),card=el('div','',{class:'edit-card','data-answer-id':id});card.append(el('h4',q.prompt),el('small',`配分 ${q.maxScore}`));
      const update=value=>{answers[id]=value;changed();};
      if(EXTRA_TYPES.includes(q.type))studentExtra(card,q,answers[id],update,{files:view.files??[],upload:upload?(question,file,ids)=>upload(current,question,file,ids):undefined});
      else if(q.type==='shortAnswer')card.append(field('你的回答',answers[id]??'',update,{type:'textarea'}));
      else{const opts=[['','尚未作答'],...(q.type==='trueFalse'?[['true','是'],['false','否']]:q.options.map(o=>[o.id,o.text]))];card.append(field('你的選擇',answers[id]===null?'':String(answers[id]),v=>update(v===''?null:q.type==='trueFalse'?v==='true':v),{options:opts}));}
      if(q.hints.length){const hints=el('details');hints.append(el('summary','查看提示'),...q.hints.map(h=>el('p',h)));card.append(hints);}questions.append(card);
    }
  }
  root.append(questions);
  if(inProgress&&!view.archived){const actions=el('div','',{class:'actions'}),saveButton=button('暫存作答',()=>save(current,answers)),submitButton=button('確認提交',()=>{if(confirm('提交後不可修改本次作答。空白客觀題計 0 分，簡答等待教師批改。確定提交嗎？'))submit(current,answers);});saveButton.id='save-answers';submitButton.id='submit-attempt';actions.append(saveButton,submitButton);root.append(actions,el('p','修改後請按「暫存作答」。提交也會一併保存目前輸入。'));}
  const release=view.released[current.id]??{},result=el('div','',{id:'learner-results'});result.append(el('h4','教師發布結果'));
  if(release.score){const s=release.score.data;result.append(el('p',`得分 ${s.score}／已評配分 ${s.scoredMax}；總配分 ${s.totalMax} · ${s.scoreComplete?'評分完整':'尚有待批改題目'}（發布於 ${date(release.score.publishedAt)}）`));for(const q of s.questions)result.append(el('p',`${content.questions.find(x=>x.id===q.questionId).prompt}：${q.score===null?'待批改':q.score+'／'+q.maxScore}`));}else result.append(el('p','分數尚未發布。'));
  if(release.answers){result.append(el('h5','已發布答案／規準'));for(const a of release.answers.data){const q=content.questions.find(q=>q.id===a.questionId);result.append(el('p',`${q.prompt}：${q.type==='singleChoice'?q.options.find(o=>o.id===a.answer)?.text:q.type==='trueFalse'?a.answer?'是':'否':a.display??a.rubric}`));}}else result.append(el('p','答案尚未發布。'));
  result.append(el('p',release.feedback?`教師回饋：${release.feedback.data.body}`:'回饋尚未發布。'));root.append(result);
  updateStudentSession(root,view.session);
}
