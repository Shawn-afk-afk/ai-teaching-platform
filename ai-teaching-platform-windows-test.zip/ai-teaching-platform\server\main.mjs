import {mkdir} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {createApp} from './app.mjs';
import {OllamaAI} from './ai/ollama-ai.mjs';
const dbPath=resolve(process.env.L1_DB??'data/l1.sqlite');await mkdir(dirname(dbPath),{recursive:true});
const app=createApp({dbPath,publicOrigin:process.env.PUBLIC_ORIGIN||undefined,...(process.env.AI_PROVIDER==='ollama'?{ai:new OllamaAI()}:{})});const origin=await app.listen(Number(process.env.PORT??4180));console.log(`L1: ${origin} · AI=${process.env.AI_PROVIDER==='ollama'?'gemma4:12b':'mock'}`);
if(process.env.PUBLIC_ORIGIN)console.log(`Public origin: ${process.env.PUBLIC_ORIGIN}`);
if(app.store.teacherCount()===0)console.log(`首次教師設定碼（只供本機初始化）：${app.setupToken}`);
let stopping=false;async function stop(){if(stopping)return;stopping=true;await app.close();process.exit(0);}process.on('SIGINT',stop);process.on('SIGTERM',stop);
