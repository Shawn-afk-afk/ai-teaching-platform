import {AppError} from '../contracts/errors.js';
import {effective_scores,validate_layout} from './rules.js';
import {EXTRA_TYPES,normalizeExtra} from './extended-questions.js';
export const DEMO_LEARNERS=Object.freeze([{id:'demo-learner-a',name:'示範學生 A'},{id:'demo-learner-b',name:'示範學生 B'}]);
export function learnersFor(project){return project.learners??DEMO_LEARNERS;}
export function reject(message,code='VALIDATION_FAILED'){throw new AppError(code,message);}
export function normalizeAnswers(version,answers){
  if(!answers||typeof answers!=='object'||Array.isArray(answers))reject('作答內容必須是題目與答案的對應。');
  validate_layout(version);
  if(Object.keys(answers).some(id=>!version.questions.some(q=>q.id===id)))reject('作答包含不屬於指派版本的題目。');
  return Object.fromEntries(version.questions.map(q=>{
    const value=Object.hasOwn(answers,q.id)?answers[q.id]:null;
    if(value===null||value==='')return [q.id,null];
    if(EXTRA_TYPES.includes(q.type)){try{return [q.id,normalizeExtra(q,value)];}catch(e){reject(e.message);}}
    if(q.type==='singleChoice'&&!q.options.some(o=>o.id===value))reject('單選答案不是有效選項。');
    if(q.type==='trueFalse'&&typeof value!=='boolean')reject('是非題答案必須為是或否。');
    if(q.type==='shortAnswer'&&(typeof value!=='string'||value.length>20000))reject('簡答必須是文字且不超過 20,000 字元。');
    return [q.id,value];
  }));
}
export function attemptResult(project,attempt){
  const allocation=project.allocations.find(a=>a.id===attempt.allocationId),version=project.versions.find(v=>v.id===allocation?.resourceVersionId);
  if(!version)reject('找不到指派的固定版本。');
  const responses=project.responses.filter(r=>r.attemptId===attempt.id);
  if(responses.length!==version.questions.length||new Set(responses.map(r=>r.questionId)).size!==responses.length)reject('作答題目遺漏或重複。');
  const history=project.scoreRevisions.filter(s=>responses.some(r=>r.id===s.responseId));
  for(const r of responses){const q=version.questions.find(q=>q.id===r.questionId);if(!q)reject('作答題目不屬於指派版本。');for(const s of history.filter(s=>s.responseId===r.id))if(!Number.isFinite(s.score)||s.score<0||s.score>q.maxScore||s.maxScore!==q.maxScore)reject('評分與指派版本配分不符。');}
  const effective=effective_scores(history);
  const questions=version.questions.map(q=>{const r=responses.find(r=>r.questionId===q.id),s=effective[r.id];return {questionId:q.id,responseId:r.id,score:s?.score??null,maxScore:q.maxScore,origin:s?.origin??null,scoreRevisionId:s?.id??null};});
  const graded=questions.filter(q=>q.score!==null);
  return {questions,score:graded.reduce((n,q)=>n+q.score,0),scoredMax:graded.reduce((n,q)=>n+q.maxScore,0),totalMax:questions.reduce((n,q)=>n+q.maxScore,0),scoreComplete:graded.length===questions.length,gradingStatus:graded.length===questions.length?'complete':graded.length?'partial':'not_started'};
}
