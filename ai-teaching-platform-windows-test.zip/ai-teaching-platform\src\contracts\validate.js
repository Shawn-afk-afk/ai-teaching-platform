import * as compiled from './validators.js';
import * as extended from './validators-v3.js';
import {AppError} from './errors.js';
export function validateContract(name, value) {
  const validator = (value?.schemaVersion==='3.0.0'?extended:compiled)[name.replaceAll('-','_')];
  if (!validator) throw new AppError('SCHEMA_VERSION_UNSUPPORTED','不支援的資料契約。');
  if (!validator(value)) throw new AppError('VALIDATION_FAILED',`資料不符合 Contract ${value?.schemaVersion??'2.0.0'}。`,{
    details:validator.errors.map(({instancePath,keyword,message})=>({path:instancePath,keyword,message}))});
  return value;
}
