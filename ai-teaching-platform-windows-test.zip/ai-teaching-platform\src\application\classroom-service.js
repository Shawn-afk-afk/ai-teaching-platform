import {AssessmentService} from './assessment-service.js';
import {sessionFor,publicSession} from '../domain/session.js';
import {reject} from '../domain/assessment.js';
import {buildReport,reportCSV} from '../domain/report.js';
export class ClassroomService extends AssessmentService {
  async transition(projectId,expected,assignmentId,action,{sessionSequence}={}){
    const {p,actor}=await this.context(projectId,'teacher');if(p.status==='archived')reject('封存專案不能控制課堂。');
    const session=sessionFor(p,assignmentId),allowed={lobby:{start:'active',end:'ended'},active:{pause:'paused',end:'ended'},paused:{resume:'active',end:'ended'},ended:{}};
    // Independent student saves must not invalidate an unchanged classroom state.
    // L0 callers retain whole-project CAS; L1 controls send the observed sequence.
    if(sessionSequence===undefined?p.revision!==expected:!Number.isInteger(sessionSequence)||session?.sequence!==sessionSequence)reject('課堂狀態已更新，請重新取得快照。','VERSION_CONFLICT');
    const state=session&&allowed[session.state]?.[action];if(!state)reject('目前狀態不能執行這個課堂操作。','INVALID_TRANSITION');
    session.state=state;session.sequence++;session.updatedAt=this.clock();p.sessionEvents??=[];
    p.sessionEvents.push({eventId:crypto.randomUUID(),eventType:'session.changed',aggregateId:session.id,sequence:session.sequence,occurredAt:session.updatedAt,payload:{state},actorId:actor.actorId});p.sessionEvents=p.sessionEvents.slice(-100);
    return this.repository.save(p,p.revision);
  }
  async snapshot(projectId,assignmentId){const {p}=await this.context(projectId,'teacher');const session=sessionFor(p,assignmentId);return {projectRevision:p.revision,readAt:this.clock(),session:publicSession(session),events:(p.sessionEvents??[]).filter(e=>e.aggregateId===session?.id).map(({eventId,eventType,aggregateId,sequence,occurredAt,payload})=>({eventId,eventType,aggregateId,sequence,occurredAt,payload})),report:buildReport(p,assignmentId)};}
  async exportCSV(projectId,assignmentId){const {p}=await this.context(projectId,'teacher');return reportCSV(buildReport(p,assignmentId),p);}
}
