var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// node_modules/.pnpm/ajv@8.17.1/node_modules/ajv/dist/runtime/ucs2length.js
var require_ucs2length = __commonJS({
  "node_modules/.pnpm/ajv@8.17.1/node_modules/ajv/dist/runtime/ucs2length.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function ucs2length(str) {
      const len = str.length;
      let length = 0;
      let pos = 0;
      let value;
      while (pos < len) {
        length++;
        value = str.charCodeAt(pos++);
        if (value >= 55296 && value <= 56319 && pos < len) {
          value = str.charCodeAt(pos);
          if ((value & 64512) === 56320)
            pos++;
        }
      }
      return length;
    }
    exports.default = ucs2length;
    ucs2length.code = 'require("ajv/dist/runtime/ucs2length").default';
  }
});

// node_modules/.pnpm/fast-deep-equal@3.1.3/node_modules/fast-deep-equal/index.js
var require_fast_deep_equal = __commonJS({
  "node_modules/.pnpm/fast-deep-equal@3.1.3/node_modules/fast-deep-equal/index.js"(exports, module) {
    "use strict";
    module.exports = function equal(a, b) {
      if (a === b) return true;
      if (a && b && typeof a == "object" && typeof b == "object") {
        if (a.constructor !== b.constructor) return false;
        var length, i, keys;
        if (Array.isArray(a)) {
          length = a.length;
          if (length != b.length) return false;
          for (i = length; i-- !== 0; )
            if (!equal(a[i], b[i])) return false;
          return true;
        }
        if (a.constructor === RegExp) return a.source === b.source && a.flags === b.flags;
        if (a.valueOf !== Object.prototype.valueOf) return a.valueOf() === b.valueOf();
        if (a.toString !== Object.prototype.toString) return a.toString() === b.toString();
        keys = Object.keys(a);
        length = keys.length;
        if (length !== Object.keys(b).length) return false;
        for (i = length; i-- !== 0; )
          if (!Object.prototype.hasOwnProperty.call(b, keys[i])) return false;
        for (i = length; i-- !== 0; ) {
          var key = keys[i];
          if (!equal(a[key], b[key])) return false;
        }
        return true;
      }
      return a !== a && b !== b;
    };
  }
});

// node_modules/.pnpm/ajv@8.17.1/node_modules/ajv/dist/runtime/equal.js
var require_equal = __commonJS({
  "node_modules/.pnpm/ajv@8.17.1/node_modules/ajv/dist/runtime/equal.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var equal = require_fast_deep_equal();
    equal.code = 'require("ajv/dist/runtime/equal").default';
    exports.default = equal;
  }
});

// node_modules/.pnpm/ajv-formats@3.0.1_ajv@8.17.1/node_modules/ajv-formats/dist/formats.js
var require_formats = __commonJS({
  "node_modules/.pnpm/ajv-formats@3.0.1_ajv@8.17.1/node_modules/ajv-formats/dist/formats.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.formatNames = exports.fastFormats = exports.fullFormats = void 0;
    function fmtDef(validate, compare) {
      return { validate, compare };
    }
    exports.fullFormats = {
      // date: http://tools.ietf.org/html/rfc3339#section-5.6
      date: fmtDef(date, compareDate),
      // date-time: http://tools.ietf.org/html/rfc3339#section-5.6
      time: fmtDef(getTime(true), compareTime),
      "date-time": fmtDef(getDateTime(true), compareDateTime),
      "iso-time": fmtDef(getTime(), compareIsoTime),
      "iso-date-time": fmtDef(getDateTime(), compareIsoDateTime),
      // duration: https://tools.ietf.org/html/rfc3339#appendix-A
      duration: /^P(?!$)((\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+S)?)?|(\d+W)?)$/,
      uri,
      "uri-reference": /^(?:[a-z][a-z0-9+\-.]*:)?(?:\/?\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:(?:[0-9a-f]{1,4}:){6}|::(?:[0-9a-f]{1,4}:){5}|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}|(?:(?:[0-9a-f]{1,4}:){0,1}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::)(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?))|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)|[Vv][0-9a-f]+\.[a-z0-9\-._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)|(?:[a-z0-9\-._~!$&'"()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*)?(?:\?(?:[a-z0-9\-._~!$&'"()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[a-z0-9\-._~!$&'"()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i,
      // uri-template: https://tools.ietf.org/html/rfc6570
      "uri-template": /^(?:(?:[^\x00-\x20"'<>%\\^`{|}]|%[0-9a-f]{2})|\{[+#./;?&=,!@|]?(?:[a-z0-9_]|%[0-9a-f]{2})+(?::[1-9][0-9]{0,3}|\*)?(?:,(?:[a-z0-9_]|%[0-9a-f]{2})+(?::[1-9][0-9]{0,3}|\*)?)*\})*$/i,
      // For the source: https://gist.github.com/dperini/729294
      // For test cases: https://mathiasbynens.be/demo/url-regex
      url: /^(?:https?|ftp):\/\/(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z0-9\u{00a1}-\u{ffff}]+-)*[a-z0-9\u{00a1}-\u{ffff}]+)(?:\.(?:[a-z0-9\u{00a1}-\u{ffff}]+-)*[a-z0-9\u{00a1}-\u{ffff}]+)*(?:\.(?:[a-z\u{00a1}-\u{ffff}]{2,})))(?::\d{2,5})?(?:\/[^\s]*)?$/iu,
      email: /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i,
      hostname: /^(?=.{1,253}\.?$)[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[-0-9a-z]{0,61}[0-9a-z])?)*\.?$/i,
      // optimized https://www.safaribooksonline.com/library/view/regular-expressions-cookbook/9780596802837/ch07s16.html
      ipv4: /^(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/,
      ipv6: /^((([0-9a-f]{1,4}:){7}([0-9a-f]{1,4}|:))|(([0-9a-f]{1,4}:){6}(:[0-9a-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){5}(((:[0-9a-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){4}(((:[0-9a-f]{1,4}){1,3})|((:[0-9a-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){3}(((:[0-9a-f]{1,4}){1,4})|((:[0-9a-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){2}(((:[0-9a-f]{1,4}){1,5})|((:[0-9a-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){1}(((:[0-9a-f]{1,4}){1,6})|((:[0-9a-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9a-f]{1,4}){1,7})|((:[0-9a-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))$/i,
      regex,
      // uuid: http://tools.ietf.org/html/rfc4122
      uuid: /^(?:urn:uuid:)?[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i,
      // JSON-pointer: https://tools.ietf.org/html/rfc6901
      // uri fragment: https://tools.ietf.org/html/rfc3986#appendix-A
      "json-pointer": /^(?:\/(?:[^~/]|~0|~1)*)*$/,
      "json-pointer-uri-fragment": /^#(?:\/(?:[a-z0-9_\-.!$&'()*+,;:=@]|%[0-9a-f]{2}|~0|~1)*)*$/i,
      // relative JSON-pointer: http://tools.ietf.org/html/draft-luff-relative-json-pointer-00
      "relative-json-pointer": /^(?:0|[1-9][0-9]*)(?:#|(?:\/(?:[^~/]|~0|~1)*)*)$/,
      // the following formats are used by the openapi specification: https://spec.openapis.org/oas/v3.0.0#data-types
      // byte: https://github.com/miguelmota/is-base64
      byte,
      // signed 32 bit integer
      int32: { type: "number", validate: validateInt32 },
      // signed 64 bit integer
      int64: { type: "number", validate: validateInt64 },
      // C-type float
      float: { type: "number", validate: validateNumber },
      // C-type double
      double: { type: "number", validate: validateNumber },
      // hint to the UI to hide input strings
      password: true,
      // unchecked string payload
      binary: true
    };
    exports.fastFormats = {
      ...exports.fullFormats,
      date: fmtDef(/^\d\d\d\d-[0-1]\d-[0-3]\d$/, compareDate),
      time: fmtDef(/^(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)$/i, compareTime),
      "date-time": fmtDef(/^\d\d\d\d-[0-1]\d-[0-3]\dt(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)$/i, compareDateTime),
      "iso-time": fmtDef(/^(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)?$/i, compareIsoTime),
      "iso-date-time": fmtDef(/^\d\d\d\d-[0-1]\d-[0-3]\d[t\s](?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)?$/i, compareIsoDateTime),
      // uri: https://github.com/mafintosh/is-my-json-valid/blob/master/formats.js
      uri: /^(?:[a-z][a-z0-9+\-.]*:)(?:\/?\/)?[^\s]*$/i,
      "uri-reference": /^(?:(?:[a-z][a-z0-9+\-.]*:)?\/?\/)?(?:[^\\\s#][^\s#]*)?(?:#[^\\\s]*)?$/i,
      // email (sources from jsen validator):
      // http://stackoverflow.com/questions/201323/using-a-regular-expression-to-validate-an-email-address#answer-8829363
      // http://www.w3.org/TR/html5/forms.html#valid-e-mail-address (search for 'wilful violation')
      email: /^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*$/i
    };
    exports.formatNames = Object.keys(exports.fullFormats);
    function isLeapYear(year) {
      return year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
    }
    var DATE = /^(\d\d\d\d)-(\d\d)-(\d\d)$/;
    var DAYS = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    function date(str) {
      const matches = DATE.exec(str);
      if (!matches)
        return false;
      const year = +matches[1];
      const month = +matches[2];
      const day = +matches[3];
      return month >= 1 && month <= 12 && day >= 1 && day <= (month === 2 && isLeapYear(year) ? 29 : DAYS[month]);
    }
    function compareDate(d1, d2) {
      if (!(d1 && d2))
        return void 0;
      if (d1 > d2)
        return 1;
      if (d1 < d2)
        return -1;
      return 0;
    }
    var TIME = /^(\d\d):(\d\d):(\d\d(?:\.\d+)?)(z|([+-])(\d\d)(?::?(\d\d))?)?$/i;
    function getTime(strictTimeZone) {
      return function time(str) {
        const matches = TIME.exec(str);
        if (!matches)
          return false;
        const hr = +matches[1];
        const min = +matches[2];
        const sec = +matches[3];
        const tz = matches[4];
        const tzSign = matches[5] === "-" ? -1 : 1;
        const tzH = +(matches[6] || 0);
        const tzM = +(matches[7] || 0);
        if (tzH > 23 || tzM > 59 || strictTimeZone && !tz)
          return false;
        if (hr <= 23 && min <= 59 && sec < 60)
          return true;
        const utcMin = min - tzM * tzSign;
        const utcHr = hr - tzH * tzSign - (utcMin < 0 ? 1 : 0);
        return (utcHr === 23 || utcHr === -1) && (utcMin === 59 || utcMin === -1) && sec < 61;
      };
    }
    function compareTime(s1, s2) {
      if (!(s1 && s2))
        return void 0;
      const t1 = (/* @__PURE__ */ new Date("2020-01-01T" + s1)).valueOf();
      const t2 = (/* @__PURE__ */ new Date("2020-01-01T" + s2)).valueOf();
      if (!(t1 && t2))
        return void 0;
      return t1 - t2;
    }
    function compareIsoTime(t1, t2) {
      if (!(t1 && t2))
        return void 0;
      const a1 = TIME.exec(t1);
      const a2 = TIME.exec(t2);
      if (!(a1 && a2))
        return void 0;
      t1 = a1[1] + a1[2] + a1[3];
      t2 = a2[1] + a2[2] + a2[3];
      if (t1 > t2)
        return 1;
      if (t1 < t2)
        return -1;
      return 0;
    }
    var DATE_TIME_SEPARATOR = /t|\s/i;
    function getDateTime(strictTimeZone) {
      const time = getTime(strictTimeZone);
      return function date_time(str) {
        const dateTime = str.split(DATE_TIME_SEPARATOR);
        return dateTime.length === 2 && date(dateTime[0]) && time(dateTime[1]);
      };
    }
    function compareDateTime(dt1, dt2) {
      if (!(dt1 && dt2))
        return void 0;
      const d1 = new Date(dt1).valueOf();
      const d2 = new Date(dt2).valueOf();
      if (!(d1 && d2))
        return void 0;
      return d1 - d2;
    }
    function compareIsoDateTime(dt1, dt2) {
      if (!(dt1 && dt2))
        return void 0;
      const [d1, t1] = dt1.split(DATE_TIME_SEPARATOR);
      const [d2, t2] = dt2.split(DATE_TIME_SEPARATOR);
      const res = compareDate(d1, d2);
      if (res === void 0)
        return void 0;
      return res || compareTime(t1, t2);
    }
    var NOT_URI_FRAGMENT = /\/|:/;
    var URI = /^(?:[a-z][a-z0-9+\-.]*:)(?:\/?\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:(?:[0-9a-f]{1,4}:){6}|::(?:[0-9a-f]{1,4}:){5}|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}|(?:(?:[0-9a-f]{1,4}:){0,1}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::)(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?))|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)|[Vv][0-9a-f]+\.[a-z0-9\-._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)|(?:[a-z0-9\-._~!$&'()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)(?:\?(?:[a-z0-9\-._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[a-z0-9\-._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i;
    function uri(str) {
      return NOT_URI_FRAGMENT.test(str) && URI.test(str);
    }
    var BYTE = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/gm;
    function byte(str) {
      BYTE.lastIndex = 0;
      return BYTE.test(str);
    }
    var MIN_INT32 = -(2 ** 31);
    var MAX_INT32 = 2 ** 31 - 1;
    function validateInt32(value) {
      return Number.isInteger(value) && value <= MAX_INT32 && value >= MIN_INT32;
    }
    function validateInt64(value) {
      return Number.isInteger(value);
    }
    function validateNumber() {
      return true;
    }
    var Z_ANCHOR = /[^\\]\\Z/;
    function regex(str) {
      if (Z_ANCHOR.test(str))
        return false;
      try {
        new RegExp(str);
        return true;
      } catch (e) {
        return false;
      }
    }
  }
});

// <stdin>
var generate_request = validate20;
var schema31 = { "type": "object", "properties": { "schemaVersion": { "const": "3.0.0" }, "requestId": { "type": "string", "minLength": 1 }, "task": { "const": "generateResources" }, "inputMode": { "enum": ["source", "topic"] }, "projectId": { "type": "string", "minLength": 1 }, "topicDescription": { "type": "string", "minLength": 1 }, "sourceChunks": { "type": "array", "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "text": { "type": "string", "minLength": 1 }, "locator": { "type": "object", "properties": { "kind": { "enum": ["page", "paragraph", "section"] }, "index": { "type": "integer", "minimum": 1 } }, "required": ["kind", "index"], "additionalProperties": false } }, "required": ["id", "sourceId", "sourceRevision", "text", "locator"], "additionalProperties": false } }, "objectives": { "type": "array", "minItems": 1, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "description": { "type": "string", "minLength": 1 } }, "required": ["id", "description"], "additionalProperties": false } }, "profile": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "language": { "type": "string", "minLength": 1 }, "readingLoad": { "type": "object", "properties": { "teacherLabel": { "type": "string", "minLength": 1 }, "sentenceGuidance": { "type": "string", "minLength": 1 }, "vocabularySupport": { "type": "boolean" } }, "required": ["teacherLabel", "sentenceGuidance", "vocabularySupport"], "additionalProperties": false }, "cognitiveChallenge": { "type": "string", "minLength": 1 }, "scaffolds": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "supportTier": { "type": ["string", "null"] } }, "required": ["id", "language", "readingLoad", "cognitiveChallenge", "scaffolds", "supportTier"], "additionalProperties": false }, "outputSpec": { "type": "object", "properties": { "resourceType": { "enum": ["handout", "reading", "comprehension", "quiz", "vocabulary", "stations", "exitTicket", "organizer", "tieredPractice"] }, "title": { "type": "string", "minLength": 1 }, "questionTypes": { "type": "array", "uniqueItems": true, "items": { "enum": ["singleChoice", "trueFalse", "shortAnswer", "multipleChoice", "fillBlank", "matching", "ordering", "upload"] } }, "questionCount": { "type": "integer", "minimum": 0, "maximum": 100 } }, "required": ["resourceType", "title", "questionTypes", "questionCount"], "additionalProperties": false } }, "required": ["schemaVersion", "requestId", "task", "inputMode", "projectId", "topicDescription", "sourceChunks", "objectives", "profile", "outputSpec"], "additionalProperties": false, "allOf": [{ "if": { "properties": { "inputMode": { "const": "source" } } }, "then": { "properties": { "sourceChunks": { "minItems": 1 } } } }], "$schema": "https://json-schema.org/draft/2020-12/schema", "title": "generate-request" };
var func1 = Object.prototype.hasOwnProperty;
var func2 = require_ucs2length().default;
var func0 = require_equal().default;
function validate20(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate20.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs2 = errors;
  let valid1 = true;
  const _errs3 = errors;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.inputMode !== void 0) {
      if ("source" !== data.inputMode) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors++;
      }
    }
  }
  var _valid0 = _errs3 === errors;
  errors = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.sourceChunks !== void 0) {
        let data1 = data.sourceChunks;
        if (Array.isArray(data1)) {
          if (data1.length < 1) {
            const err1 = { instancePath: instancePath + "/sourceChunks", schemaPath: "#/allOf/0/then/properties/sourceChunks/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
            if (vErrors === null) {
              vErrors = [err1];
            } else {
              vErrors.push(err1);
            }
            errors++;
          }
        }
      }
    }
    var _valid0 = _errs5 === errors;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.sourceChunks = true;
      props0.inputMode = true;
    }
  }
  if (!valid1) {
    const err2 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err2];
    } else {
      vErrors.push(err2);
    }
    errors++;
  }
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.schemaVersion === void 0) {
      const err3 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "schemaVersion" }, message: "must have required property 'schemaVersion'" };
      if (vErrors === null) {
        vErrors = [err3];
      } else {
        vErrors.push(err3);
      }
      errors++;
    }
    if (data.requestId === void 0) {
      const err4 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "requestId" }, message: "must have required property 'requestId'" };
      if (vErrors === null) {
        vErrors = [err4];
      } else {
        vErrors.push(err4);
      }
      errors++;
    }
    if (data.task === void 0) {
      const err5 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "task" }, message: "must have required property 'task'" };
      if (vErrors === null) {
        vErrors = [err5];
      } else {
        vErrors.push(err5);
      }
      errors++;
    }
    if (data.inputMode === void 0) {
      const err6 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "inputMode" }, message: "must have required property 'inputMode'" };
      if (vErrors === null) {
        vErrors = [err6];
      } else {
        vErrors.push(err6);
      }
      errors++;
    }
    if (data.projectId === void 0) {
      const err7 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "projectId" }, message: "must have required property 'projectId'" };
      if (vErrors === null) {
        vErrors = [err7];
      } else {
        vErrors.push(err7);
      }
      errors++;
    }
    if (data.topicDescription === void 0) {
      const err8 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "topicDescription" }, message: "must have required property 'topicDescription'" };
      if (vErrors === null) {
        vErrors = [err8];
      } else {
        vErrors.push(err8);
      }
      errors++;
    }
    if (data.sourceChunks === void 0) {
      const err9 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "sourceChunks" }, message: "must have required property 'sourceChunks'" };
      if (vErrors === null) {
        vErrors = [err9];
      } else {
        vErrors.push(err9);
      }
      errors++;
    }
    if (data.objectives === void 0) {
      const err10 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "objectives" }, message: "must have required property 'objectives'" };
      if (vErrors === null) {
        vErrors = [err10];
      } else {
        vErrors.push(err10);
      }
      errors++;
    }
    if (data.profile === void 0) {
      const err11 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "profile" }, message: "must have required property 'profile'" };
      if (vErrors === null) {
        vErrors = [err11];
      } else {
        vErrors.push(err11);
      }
      errors++;
    }
    if (data.outputSpec === void 0) {
      const err12 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "outputSpec" }, message: "must have required property 'outputSpec'" };
      if (vErrors === null) {
        vErrors = [err12];
      } else {
        vErrors.push(err12);
      }
      errors++;
    }
    for (const key0 in data) {
      if (!func1.call(schema31.properties, key0)) {
        const err13 = { instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" };
        if (vErrors === null) {
          vErrors = [err13];
        } else {
          vErrors.push(err13);
        }
        errors++;
      }
    }
    if (data.schemaVersion !== void 0) {
      if ("3.0.0" !== data.schemaVersion) {
        const err14 = { instancePath: instancePath + "/schemaVersion", schemaPath: "#/properties/schemaVersion/const", keyword: "const", params: { allowedValue: "3.0.0" }, message: "must be equal to constant" };
        if (vErrors === null) {
          vErrors = [err14];
        } else {
          vErrors.push(err14);
        }
        errors++;
      }
    }
    if (data.requestId !== void 0) {
      let data3 = data.requestId;
      if (typeof data3 === "string") {
        if (func2(data3) < 1) {
          const err15 = { instancePath: instancePath + "/requestId", schemaPath: "#/properties/requestId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err15];
          } else {
            vErrors.push(err15);
          }
          errors++;
        }
      } else {
        const err16 = { instancePath: instancePath + "/requestId", schemaPath: "#/properties/requestId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err16];
        } else {
          vErrors.push(err16);
        }
        errors++;
      }
    }
    if (data.task !== void 0) {
      if ("generateResources" !== data.task) {
        const err17 = { instancePath: instancePath + "/task", schemaPath: "#/properties/task/const", keyword: "const", params: { allowedValue: "generateResources" }, message: "must be equal to constant" };
        if (vErrors === null) {
          vErrors = [err17];
        } else {
          vErrors.push(err17);
        }
        errors++;
      }
    }
    if (data.inputMode !== void 0) {
      let data5 = data.inputMode;
      if (!(data5 === "source" || data5 === "topic")) {
        const err18 = { instancePath: instancePath + "/inputMode", schemaPath: "#/properties/inputMode/enum", keyword: "enum", params: { allowedValues: schema31.properties.inputMode.enum }, message: "must be equal to one of the allowed values" };
        if (vErrors === null) {
          vErrors = [err18];
        } else {
          vErrors.push(err18);
        }
        errors++;
      }
    }
    if (data.projectId !== void 0) {
      let data6 = data.projectId;
      if (typeof data6 === "string") {
        if (func2(data6) < 1) {
          const err19 = { instancePath: instancePath + "/projectId", schemaPath: "#/properties/projectId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err19];
          } else {
            vErrors.push(err19);
          }
          errors++;
        }
      } else {
        const err20 = { instancePath: instancePath + "/projectId", schemaPath: "#/properties/projectId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err20];
        } else {
          vErrors.push(err20);
        }
        errors++;
      }
    }
    if (data.topicDescription !== void 0) {
      let data7 = data.topicDescription;
      if (typeof data7 === "string") {
        if (func2(data7) < 1) {
          const err21 = { instancePath: instancePath + "/topicDescription", schemaPath: "#/properties/topicDescription/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err21];
          } else {
            vErrors.push(err21);
          }
          errors++;
        }
      } else {
        const err22 = { instancePath: instancePath + "/topicDescription", schemaPath: "#/properties/topicDescription/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err22];
        } else {
          vErrors.push(err22);
        }
        errors++;
      }
    }
    if (data.sourceChunks !== void 0) {
      let data8 = data.sourceChunks;
      if (Array.isArray(data8)) {
        const len0 = data8.length;
        for (let i0 = 0; i0 < len0; i0++) {
          let data9 = data8[i0];
          if (data9 && typeof data9 == "object" && !Array.isArray(data9)) {
            if (data9.id === void 0) {
              const err23 = { instancePath: instancePath + "/sourceChunks/" + i0, schemaPath: "#/properties/sourceChunks/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
              if (vErrors === null) {
                vErrors = [err23];
              } else {
                vErrors.push(err23);
              }
              errors++;
            }
            if (data9.sourceId === void 0) {
              const err24 = { instancePath: instancePath + "/sourceChunks/" + i0, schemaPath: "#/properties/sourceChunks/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
              if (vErrors === null) {
                vErrors = [err24];
              } else {
                vErrors.push(err24);
              }
              errors++;
            }
            if (data9.sourceRevision === void 0) {
              const err25 = { instancePath: instancePath + "/sourceChunks/" + i0, schemaPath: "#/properties/sourceChunks/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
              if (vErrors === null) {
                vErrors = [err25];
              } else {
                vErrors.push(err25);
              }
              errors++;
            }
            if (data9.text === void 0) {
              const err26 = { instancePath: instancePath + "/sourceChunks/" + i0, schemaPath: "#/properties/sourceChunks/items/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
              if (vErrors === null) {
                vErrors = [err26];
              } else {
                vErrors.push(err26);
              }
              errors++;
            }
            if (data9.locator === void 0) {
              const err27 = { instancePath: instancePath + "/sourceChunks/" + i0, schemaPath: "#/properties/sourceChunks/items/required", keyword: "required", params: { missingProperty: "locator" }, message: "must have required property 'locator'" };
              if (vErrors === null) {
                vErrors = [err27];
              } else {
                vErrors.push(err27);
              }
              errors++;
            }
            for (const key1 in data9) {
              if (!(key1 === "id" || key1 === "sourceId" || key1 === "sourceRevision" || key1 === "text" || key1 === "locator")) {
                const err28 = { instancePath: instancePath + "/sourceChunks/" + i0, schemaPath: "#/properties/sourceChunks/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" };
                if (vErrors === null) {
                  vErrors = [err28];
                } else {
                  vErrors.push(err28);
                }
                errors++;
              }
            }
            if (data9.id !== void 0) {
              let data10 = data9.id;
              if (typeof data10 === "string") {
                if (func2(data10) < 1) {
                  const err29 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/id", schemaPath: "#/properties/sourceChunks/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err29];
                  } else {
                    vErrors.push(err29);
                  }
                  errors++;
                }
              } else {
                const err30 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/id", schemaPath: "#/properties/sourceChunks/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err30];
                } else {
                  vErrors.push(err30);
                }
                errors++;
              }
            }
            if (data9.sourceId !== void 0) {
              let data11 = data9.sourceId;
              if (typeof data11 === "string") {
                if (func2(data11) < 1) {
                  const err31 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/sourceId", schemaPath: "#/properties/sourceChunks/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err31];
                  } else {
                    vErrors.push(err31);
                  }
                  errors++;
                }
              } else {
                const err32 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/sourceId", schemaPath: "#/properties/sourceChunks/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err32];
                } else {
                  vErrors.push(err32);
                }
                errors++;
              }
            }
            if (data9.sourceRevision !== void 0) {
              let data12 = data9.sourceRevision;
              if (!(typeof data12 == "number" && (!(data12 % 1) && !isNaN(data12)))) {
                const err33 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/sourceRevision", schemaPath: "#/properties/sourceChunks/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                if (vErrors === null) {
                  vErrors = [err33];
                } else {
                  vErrors.push(err33);
                }
                errors++;
              }
              if (typeof data12 == "number") {
                if (data12 < 1 || isNaN(data12)) {
                  const err34 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/sourceRevision", schemaPath: "#/properties/sourceChunks/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                  if (vErrors === null) {
                    vErrors = [err34];
                  } else {
                    vErrors.push(err34);
                  }
                  errors++;
                }
              }
            }
            if (data9.text !== void 0) {
              let data13 = data9.text;
              if (typeof data13 === "string") {
                if (func2(data13) < 1) {
                  const err35 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/text", schemaPath: "#/properties/sourceChunks/items/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err35];
                  } else {
                    vErrors.push(err35);
                  }
                  errors++;
                }
              } else {
                const err36 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/text", schemaPath: "#/properties/sourceChunks/items/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err36];
                } else {
                  vErrors.push(err36);
                }
                errors++;
              }
            }
            if (data9.locator !== void 0) {
              let data14 = data9.locator;
              if (data14 && typeof data14 == "object" && !Array.isArray(data14)) {
                if (data14.kind === void 0) {
                  const err37 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/locator", schemaPath: "#/properties/sourceChunks/items/properties/locator/required", keyword: "required", params: { missingProperty: "kind" }, message: "must have required property 'kind'" };
                  if (vErrors === null) {
                    vErrors = [err37];
                  } else {
                    vErrors.push(err37);
                  }
                  errors++;
                }
                if (data14.index === void 0) {
                  const err38 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/locator", schemaPath: "#/properties/sourceChunks/items/properties/locator/required", keyword: "required", params: { missingProperty: "index" }, message: "must have required property 'index'" };
                  if (vErrors === null) {
                    vErrors = [err38];
                  } else {
                    vErrors.push(err38);
                  }
                  errors++;
                }
                for (const key2 in data14) {
                  if (!(key2 === "kind" || key2 === "index")) {
                    const err39 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/locator", schemaPath: "#/properties/sourceChunks/items/properties/locator/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" };
                    if (vErrors === null) {
                      vErrors = [err39];
                    } else {
                      vErrors.push(err39);
                    }
                    errors++;
                  }
                }
                if (data14.kind !== void 0) {
                  let data15 = data14.kind;
                  if (!(data15 === "page" || data15 === "paragraph" || data15 === "section")) {
                    const err40 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/locator/kind", schemaPath: "#/properties/sourceChunks/items/properties/locator/properties/kind/enum", keyword: "enum", params: { allowedValues: schema31.properties.sourceChunks.items.properties.locator.properties.kind.enum }, message: "must be equal to one of the allowed values" };
                    if (vErrors === null) {
                      vErrors = [err40];
                    } else {
                      vErrors.push(err40);
                    }
                    errors++;
                  }
                }
                if (data14.index !== void 0) {
                  let data16 = data14.index;
                  if (!(typeof data16 == "number" && (!(data16 % 1) && !isNaN(data16)))) {
                    const err41 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/locator/index", schemaPath: "#/properties/sourceChunks/items/properties/locator/properties/index/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                    if (vErrors === null) {
                      vErrors = [err41];
                    } else {
                      vErrors.push(err41);
                    }
                    errors++;
                  }
                  if (typeof data16 == "number") {
                    if (data16 < 1 || isNaN(data16)) {
                      const err42 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/locator/index", schemaPath: "#/properties/sourceChunks/items/properties/locator/properties/index/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                      if (vErrors === null) {
                        vErrors = [err42];
                      } else {
                        vErrors.push(err42);
                      }
                      errors++;
                    }
                  }
                }
              } else {
                const err43 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/locator", schemaPath: "#/properties/sourceChunks/items/properties/locator/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                if (vErrors === null) {
                  vErrors = [err43];
                } else {
                  vErrors.push(err43);
                }
                errors++;
              }
            }
          } else {
            const err44 = { instancePath: instancePath + "/sourceChunks/" + i0, schemaPath: "#/properties/sourceChunks/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
            if (vErrors === null) {
              vErrors = [err44];
            } else {
              vErrors.push(err44);
            }
            errors++;
          }
        }
      } else {
        const err45 = { instancePath: instancePath + "/sourceChunks", schemaPath: "#/properties/sourceChunks/type", keyword: "type", params: { type: "array" }, message: "must be array" };
        if (vErrors === null) {
          vErrors = [err45];
        } else {
          vErrors.push(err45);
        }
        errors++;
      }
    }
    if (data.objectives !== void 0) {
      let data17 = data.objectives;
      if (Array.isArray(data17)) {
        if (data17.length < 1) {
          const err46 = { instancePath: instancePath + "/objectives", schemaPath: "#/properties/objectives/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
          if (vErrors === null) {
            vErrors = [err46];
          } else {
            vErrors.push(err46);
          }
          errors++;
        }
        const len1 = data17.length;
        for (let i1 = 0; i1 < len1; i1++) {
          let data18 = data17[i1];
          if (data18 && typeof data18 == "object" && !Array.isArray(data18)) {
            if (data18.id === void 0) {
              const err47 = { instancePath: instancePath + "/objectives/" + i1, schemaPath: "#/properties/objectives/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
              if (vErrors === null) {
                vErrors = [err47];
              } else {
                vErrors.push(err47);
              }
              errors++;
            }
            if (data18.description === void 0) {
              const err48 = { instancePath: instancePath + "/objectives/" + i1, schemaPath: "#/properties/objectives/items/required", keyword: "required", params: { missingProperty: "description" }, message: "must have required property 'description'" };
              if (vErrors === null) {
                vErrors = [err48];
              } else {
                vErrors.push(err48);
              }
              errors++;
            }
            for (const key3 in data18) {
              if (!(key3 === "id" || key3 === "description")) {
                const err49 = { instancePath: instancePath + "/objectives/" + i1, schemaPath: "#/properties/objectives/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" };
                if (vErrors === null) {
                  vErrors = [err49];
                } else {
                  vErrors.push(err49);
                }
                errors++;
              }
            }
            if (data18.id !== void 0) {
              let data19 = data18.id;
              if (typeof data19 === "string") {
                if (func2(data19) < 1) {
                  const err50 = { instancePath: instancePath + "/objectives/" + i1 + "/id", schemaPath: "#/properties/objectives/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err50];
                  } else {
                    vErrors.push(err50);
                  }
                  errors++;
                }
              } else {
                const err51 = { instancePath: instancePath + "/objectives/" + i1 + "/id", schemaPath: "#/properties/objectives/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err51];
                } else {
                  vErrors.push(err51);
                }
                errors++;
              }
            }
            if (data18.description !== void 0) {
              let data20 = data18.description;
              if (typeof data20 === "string") {
                if (func2(data20) < 1) {
                  const err52 = { instancePath: instancePath + "/objectives/" + i1 + "/description", schemaPath: "#/properties/objectives/items/properties/description/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err52];
                  } else {
                    vErrors.push(err52);
                  }
                  errors++;
                }
              } else {
                const err53 = { instancePath: instancePath + "/objectives/" + i1 + "/description", schemaPath: "#/properties/objectives/items/properties/description/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err53];
                } else {
                  vErrors.push(err53);
                }
                errors++;
              }
            }
          } else {
            const err54 = { instancePath: instancePath + "/objectives/" + i1, schemaPath: "#/properties/objectives/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
            if (vErrors === null) {
              vErrors = [err54];
            } else {
              vErrors.push(err54);
            }
            errors++;
          }
        }
      } else {
        const err55 = { instancePath: instancePath + "/objectives", schemaPath: "#/properties/objectives/type", keyword: "type", params: { type: "array" }, message: "must be array" };
        if (vErrors === null) {
          vErrors = [err55];
        } else {
          vErrors.push(err55);
        }
        errors++;
      }
    }
    if (data.profile !== void 0) {
      let data21 = data.profile;
      if (data21 && typeof data21 == "object" && !Array.isArray(data21)) {
        if (data21.id === void 0) {
          const err56 = { instancePath: instancePath + "/profile", schemaPath: "#/properties/profile/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
          if (vErrors === null) {
            vErrors = [err56];
          } else {
            vErrors.push(err56);
          }
          errors++;
        }
        if (data21.language === void 0) {
          const err57 = { instancePath: instancePath + "/profile", schemaPath: "#/properties/profile/required", keyword: "required", params: { missingProperty: "language" }, message: "must have required property 'language'" };
          if (vErrors === null) {
            vErrors = [err57];
          } else {
            vErrors.push(err57);
          }
          errors++;
        }
        if (data21.readingLoad === void 0) {
          const err58 = { instancePath: instancePath + "/profile", schemaPath: "#/properties/profile/required", keyword: "required", params: { missingProperty: "readingLoad" }, message: "must have required property 'readingLoad'" };
          if (vErrors === null) {
            vErrors = [err58];
          } else {
            vErrors.push(err58);
          }
          errors++;
        }
        if (data21.cognitiveChallenge === void 0) {
          const err59 = { instancePath: instancePath + "/profile", schemaPath: "#/properties/profile/required", keyword: "required", params: { missingProperty: "cognitiveChallenge" }, message: "must have required property 'cognitiveChallenge'" };
          if (vErrors === null) {
            vErrors = [err59];
          } else {
            vErrors.push(err59);
          }
          errors++;
        }
        if (data21.scaffolds === void 0) {
          const err60 = { instancePath: instancePath + "/profile", schemaPath: "#/properties/profile/required", keyword: "required", params: { missingProperty: "scaffolds" }, message: "must have required property 'scaffolds'" };
          if (vErrors === null) {
            vErrors = [err60];
          } else {
            vErrors.push(err60);
          }
          errors++;
        }
        if (data21.supportTier === void 0) {
          const err61 = { instancePath: instancePath + "/profile", schemaPath: "#/properties/profile/required", keyword: "required", params: { missingProperty: "supportTier" }, message: "must have required property 'supportTier'" };
          if (vErrors === null) {
            vErrors = [err61];
          } else {
            vErrors.push(err61);
          }
          errors++;
        }
        for (const key4 in data21) {
          if (!(key4 === "id" || key4 === "language" || key4 === "readingLoad" || key4 === "cognitiveChallenge" || key4 === "scaffolds" || key4 === "supportTier")) {
            const err62 = { instancePath: instancePath + "/profile", schemaPath: "#/properties/profile/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key4 }, message: "must NOT have additional properties" };
            if (vErrors === null) {
              vErrors = [err62];
            } else {
              vErrors.push(err62);
            }
            errors++;
          }
        }
        if (data21.id !== void 0) {
          let data22 = data21.id;
          if (typeof data22 === "string") {
            if (func2(data22) < 1) {
              const err63 = { instancePath: instancePath + "/profile/id", schemaPath: "#/properties/profile/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
              if (vErrors === null) {
                vErrors = [err63];
              } else {
                vErrors.push(err63);
              }
              errors++;
            }
          } else {
            const err64 = { instancePath: instancePath + "/profile/id", schemaPath: "#/properties/profile/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
            if (vErrors === null) {
              vErrors = [err64];
            } else {
              vErrors.push(err64);
            }
            errors++;
          }
        }
        if (data21.language !== void 0) {
          let data23 = data21.language;
          if (typeof data23 === "string") {
            if (func2(data23) < 1) {
              const err65 = { instancePath: instancePath + "/profile/language", schemaPath: "#/properties/profile/properties/language/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
              if (vErrors === null) {
                vErrors = [err65];
              } else {
                vErrors.push(err65);
              }
              errors++;
            }
          } else {
            const err66 = { instancePath: instancePath + "/profile/language", schemaPath: "#/properties/profile/properties/language/type", keyword: "type", params: { type: "string" }, message: "must be string" };
            if (vErrors === null) {
              vErrors = [err66];
            } else {
              vErrors.push(err66);
            }
            errors++;
          }
        }
        if (data21.readingLoad !== void 0) {
          let data24 = data21.readingLoad;
          if (data24 && typeof data24 == "object" && !Array.isArray(data24)) {
            if (data24.teacherLabel === void 0) {
              const err67 = { instancePath: instancePath + "/profile/readingLoad", schemaPath: "#/properties/profile/properties/readingLoad/required", keyword: "required", params: { missingProperty: "teacherLabel" }, message: "must have required property 'teacherLabel'" };
              if (vErrors === null) {
                vErrors = [err67];
              } else {
                vErrors.push(err67);
              }
              errors++;
            }
            if (data24.sentenceGuidance === void 0) {
              const err68 = { instancePath: instancePath + "/profile/readingLoad", schemaPath: "#/properties/profile/properties/readingLoad/required", keyword: "required", params: { missingProperty: "sentenceGuidance" }, message: "must have required property 'sentenceGuidance'" };
              if (vErrors === null) {
                vErrors = [err68];
              } else {
                vErrors.push(err68);
              }
              errors++;
            }
            if (data24.vocabularySupport === void 0) {
              const err69 = { instancePath: instancePath + "/profile/readingLoad", schemaPath: "#/properties/profile/properties/readingLoad/required", keyword: "required", params: { missingProperty: "vocabularySupport" }, message: "must have required property 'vocabularySupport'" };
              if (vErrors === null) {
                vErrors = [err69];
              } else {
                vErrors.push(err69);
              }
              errors++;
            }
            for (const key5 in data24) {
              if (!(key5 === "teacherLabel" || key5 === "sentenceGuidance" || key5 === "vocabularySupport")) {
                const err70 = { instancePath: instancePath + "/profile/readingLoad", schemaPath: "#/properties/profile/properties/readingLoad/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key5 }, message: "must NOT have additional properties" };
                if (vErrors === null) {
                  vErrors = [err70];
                } else {
                  vErrors.push(err70);
                }
                errors++;
              }
            }
            if (data24.teacherLabel !== void 0) {
              let data25 = data24.teacherLabel;
              if (typeof data25 === "string") {
                if (func2(data25) < 1) {
                  const err71 = { instancePath: instancePath + "/profile/readingLoad/teacherLabel", schemaPath: "#/properties/profile/properties/readingLoad/properties/teacherLabel/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err71];
                  } else {
                    vErrors.push(err71);
                  }
                  errors++;
                }
              } else {
                const err72 = { instancePath: instancePath + "/profile/readingLoad/teacherLabel", schemaPath: "#/properties/profile/properties/readingLoad/properties/teacherLabel/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err72];
                } else {
                  vErrors.push(err72);
                }
                errors++;
              }
            }
            if (data24.sentenceGuidance !== void 0) {
              let data26 = data24.sentenceGuidance;
              if (typeof data26 === "string") {
                if (func2(data26) < 1) {
                  const err73 = { instancePath: instancePath + "/profile/readingLoad/sentenceGuidance", schemaPath: "#/properties/profile/properties/readingLoad/properties/sentenceGuidance/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err73];
                  } else {
                    vErrors.push(err73);
                  }
                  errors++;
                }
              } else {
                const err74 = { instancePath: instancePath + "/profile/readingLoad/sentenceGuidance", schemaPath: "#/properties/profile/properties/readingLoad/properties/sentenceGuidance/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err74];
                } else {
                  vErrors.push(err74);
                }
                errors++;
              }
            }
            if (data24.vocabularySupport !== void 0) {
              if (typeof data24.vocabularySupport !== "boolean") {
                const err75 = { instancePath: instancePath + "/profile/readingLoad/vocabularySupport", schemaPath: "#/properties/profile/properties/readingLoad/properties/vocabularySupport/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" };
                if (vErrors === null) {
                  vErrors = [err75];
                } else {
                  vErrors.push(err75);
                }
                errors++;
              }
            }
          } else {
            const err76 = { instancePath: instancePath + "/profile/readingLoad", schemaPath: "#/properties/profile/properties/readingLoad/type", keyword: "type", params: { type: "object" }, message: "must be object" };
            if (vErrors === null) {
              vErrors = [err76];
            } else {
              vErrors.push(err76);
            }
            errors++;
          }
        }
        if (data21.cognitiveChallenge !== void 0) {
          let data28 = data21.cognitiveChallenge;
          if (typeof data28 === "string") {
            if (func2(data28) < 1) {
              const err77 = { instancePath: instancePath + "/profile/cognitiveChallenge", schemaPath: "#/properties/profile/properties/cognitiveChallenge/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
              if (vErrors === null) {
                vErrors = [err77];
              } else {
                vErrors.push(err77);
              }
              errors++;
            }
          } else {
            const err78 = { instancePath: instancePath + "/profile/cognitiveChallenge", schemaPath: "#/properties/profile/properties/cognitiveChallenge/type", keyword: "type", params: { type: "string" }, message: "must be string" };
            if (vErrors === null) {
              vErrors = [err78];
            } else {
              vErrors.push(err78);
            }
            errors++;
          }
        }
        if (data21.scaffolds !== void 0) {
          let data29 = data21.scaffolds;
          if (Array.isArray(data29)) {
            const len2 = data29.length;
            for (let i2 = 0; i2 < len2; i2++) {
              let data30 = data29[i2];
              if (typeof data30 === "string") {
                if (func2(data30) < 1) {
                  const err79 = { instancePath: instancePath + "/profile/scaffolds/" + i2, schemaPath: "#/properties/profile/properties/scaffolds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err79];
                  } else {
                    vErrors.push(err79);
                  }
                  errors++;
                }
              } else {
                const err80 = { instancePath: instancePath + "/profile/scaffolds/" + i2, schemaPath: "#/properties/profile/properties/scaffolds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err80];
                } else {
                  vErrors.push(err80);
                }
                errors++;
              }
            }
          } else {
            const err81 = { instancePath: instancePath + "/profile/scaffolds", schemaPath: "#/properties/profile/properties/scaffolds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
            if (vErrors === null) {
              vErrors = [err81];
            } else {
              vErrors.push(err81);
            }
            errors++;
          }
        }
        if (data21.supportTier !== void 0) {
          let data31 = data21.supportTier;
          if (typeof data31 !== "string" && data31 !== null) {
            const err82 = { instancePath: instancePath + "/profile/supportTier", schemaPath: "#/properties/profile/properties/supportTier/type", keyword: "type", params: { type: schema31.properties.profile.properties.supportTier.type }, message: "must be string,null" };
            if (vErrors === null) {
              vErrors = [err82];
            } else {
              vErrors.push(err82);
            }
            errors++;
          }
        }
      } else {
        const err83 = { instancePath: instancePath + "/profile", schemaPath: "#/properties/profile/type", keyword: "type", params: { type: "object" }, message: "must be object" };
        if (vErrors === null) {
          vErrors = [err83];
        } else {
          vErrors.push(err83);
        }
        errors++;
      }
    }
    if (data.outputSpec !== void 0) {
      let data32 = data.outputSpec;
      if (data32 && typeof data32 == "object" && !Array.isArray(data32)) {
        if (data32.resourceType === void 0) {
          const err84 = { instancePath: instancePath + "/outputSpec", schemaPath: "#/properties/outputSpec/required", keyword: "required", params: { missingProperty: "resourceType" }, message: "must have required property 'resourceType'" };
          if (vErrors === null) {
            vErrors = [err84];
          } else {
            vErrors.push(err84);
          }
          errors++;
        }
        if (data32.title === void 0) {
          const err85 = { instancePath: instancePath + "/outputSpec", schemaPath: "#/properties/outputSpec/required", keyword: "required", params: { missingProperty: "title" }, message: "must have required property 'title'" };
          if (vErrors === null) {
            vErrors = [err85];
          } else {
            vErrors.push(err85);
          }
          errors++;
        }
        if (data32.questionTypes === void 0) {
          const err86 = { instancePath: instancePath + "/outputSpec", schemaPath: "#/properties/outputSpec/required", keyword: "required", params: { missingProperty: "questionTypes" }, message: "must have required property 'questionTypes'" };
          if (vErrors === null) {
            vErrors = [err86];
          } else {
            vErrors.push(err86);
          }
          errors++;
        }
        if (data32.questionCount === void 0) {
          const err87 = { instancePath: instancePath + "/outputSpec", schemaPath: "#/properties/outputSpec/required", keyword: "required", params: { missingProperty: "questionCount" }, message: "must have required property 'questionCount'" };
          if (vErrors === null) {
            vErrors = [err87];
          } else {
            vErrors.push(err87);
          }
          errors++;
        }
        for (const key6 in data32) {
          if (!(key6 === "resourceType" || key6 === "title" || key6 === "questionTypes" || key6 === "questionCount")) {
            const err88 = { instancePath: instancePath + "/outputSpec", schemaPath: "#/properties/outputSpec/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key6 }, message: "must NOT have additional properties" };
            if (vErrors === null) {
              vErrors = [err88];
            } else {
              vErrors.push(err88);
            }
            errors++;
          }
        }
        if (data32.resourceType !== void 0) {
          let data33 = data32.resourceType;
          if (!(data33 === "handout" || data33 === "reading" || data33 === "comprehension" || data33 === "quiz" || data33 === "vocabulary" || data33 === "stations" || data33 === "exitTicket" || data33 === "organizer" || data33 === "tieredPractice")) {
            const err89 = { instancePath: instancePath + "/outputSpec/resourceType", schemaPath: "#/properties/outputSpec/properties/resourceType/enum", keyword: "enum", params: { allowedValues: schema31.properties.outputSpec.properties.resourceType.enum }, message: "must be equal to one of the allowed values" };
            if (vErrors === null) {
              vErrors = [err89];
            } else {
              vErrors.push(err89);
            }
            errors++;
          }
        }
        if (data32.title !== void 0) {
          let data34 = data32.title;
          if (typeof data34 === "string") {
            if (func2(data34) < 1) {
              const err90 = { instancePath: instancePath + "/outputSpec/title", schemaPath: "#/properties/outputSpec/properties/title/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
              if (vErrors === null) {
                vErrors = [err90];
              } else {
                vErrors.push(err90);
              }
              errors++;
            }
          } else {
            const err91 = { instancePath: instancePath + "/outputSpec/title", schemaPath: "#/properties/outputSpec/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" };
            if (vErrors === null) {
              vErrors = [err91];
            } else {
              vErrors.push(err91);
            }
            errors++;
          }
        }
        if (data32.questionTypes !== void 0) {
          let data35 = data32.questionTypes;
          if (Array.isArray(data35)) {
            const len3 = data35.length;
            for (let i3 = 0; i3 < len3; i3++) {
              let data36 = data35[i3];
              if (!(data36 === "singleChoice" || data36 === "trueFalse" || data36 === "shortAnswer" || data36 === "multipleChoice" || data36 === "fillBlank" || data36 === "matching" || data36 === "ordering" || data36 === "upload")) {
                const err92 = { instancePath: instancePath + "/outputSpec/questionTypes/" + i3, schemaPath: "#/properties/outputSpec/properties/questionTypes/items/enum", keyword: "enum", params: { allowedValues: schema31.properties.outputSpec.properties.questionTypes.items.enum }, message: "must be equal to one of the allowed values" };
                if (vErrors === null) {
                  vErrors = [err92];
                } else {
                  vErrors.push(err92);
                }
                errors++;
              }
            }
            let i4 = data35.length;
            let j0;
            if (i4 > 1) {
              outer0: for (; i4--; ) {
                for (j0 = i4; j0--; ) {
                  if (func0(data35[i4], data35[j0])) {
                    const err93 = { instancePath: instancePath + "/outputSpec/questionTypes", schemaPath: "#/properties/outputSpec/properties/questionTypes/uniqueItems", keyword: "uniqueItems", params: { i: i4, j: j0 }, message: "must NOT have duplicate items (items ## " + j0 + " and " + i4 + " are identical)" };
                    if (vErrors === null) {
                      vErrors = [err93];
                    } else {
                      vErrors.push(err93);
                    }
                    errors++;
                    break outer0;
                  }
                }
              }
            }
          } else {
            const err94 = { instancePath: instancePath + "/outputSpec/questionTypes", schemaPath: "#/properties/outputSpec/properties/questionTypes/type", keyword: "type", params: { type: "array" }, message: "must be array" };
            if (vErrors === null) {
              vErrors = [err94];
            } else {
              vErrors.push(err94);
            }
            errors++;
          }
        }
        if (data32.questionCount !== void 0) {
          let data37 = data32.questionCount;
          if (!(typeof data37 == "number" && (!(data37 % 1) && !isNaN(data37)))) {
            const err95 = { instancePath: instancePath + "/outputSpec/questionCount", schemaPath: "#/properties/outputSpec/properties/questionCount/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
            if (vErrors === null) {
              vErrors = [err95];
            } else {
              vErrors.push(err95);
            }
            errors++;
          }
          if (typeof data37 == "number") {
            if (data37 > 100 || isNaN(data37)) {
              const err96 = { instancePath: instancePath + "/outputSpec/questionCount", schemaPath: "#/properties/outputSpec/properties/questionCount/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
              if (vErrors === null) {
                vErrors = [err96];
              } else {
                vErrors.push(err96);
              }
              errors++;
            }
            if (data37 < 0 || isNaN(data37)) {
              const err97 = { instancePath: instancePath + "/outputSpec/questionCount", schemaPath: "#/properties/outputSpec/properties/questionCount/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
              if (vErrors === null) {
                vErrors = [err97];
              } else {
                vErrors.push(err97);
              }
              errors++;
            }
          }
        }
      } else {
        const err98 = { instancePath: instancePath + "/outputSpec", schemaPath: "#/properties/outputSpec/type", keyword: "type", params: { type: "object" }, message: "must be object" };
        if (vErrors === null) {
          vErrors = [err98];
        } else {
          vErrors.push(err98);
        }
        errors++;
      }
    }
  } else {
    const err99 = { instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" };
    if (vErrors === null) {
      vErrors = [err99];
    } else {
      vErrors.push(err99);
    }
    errors++;
  }
  validate20.errors = vErrors;
  return errors === 0;
}
validate20.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var generate_result = validate21;
var schema32 = { "type": "object", "properties": { "schemaVersion": { "const": "3.0.0" }, "requestId": { "type": "string", "minLength": 1 }, "jobId": { "type": "string", "minLength": 1 }, "state": { "const": "succeeded" }, "origin": { "enum": ["mock", "model"] }, "providerInfo": { "type": "object", "properties": { "provider": { "type": "string", "minLength": 1 }, "modelId": { "type": ["string", "null"] } }, "required": ["provider", "modelId"], "additionalProperties": false }, "generatedAt": { "type": "string", "format": "date-time" }, "resources": { "type": "array", "minItems": 1, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "resourceId": { "type": "string", "minLength": 1 }, "resourceType": { "enum": ["handout", "reading", "comprehension", "quiz", "vocabulary", "stations", "exitTicket", "organizer", "tieredPractice"] }, "title": { "type": "string", "minLength": 1 }, "profileId": { "type": "string", "minLength": 1 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "blocks": { "type": "array", "items": { "oneOf": [{ "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "type": { "enum": ["heading", "paragraph"] }, "data": { "type": "object", "properties": { "text": { "type": "string", "minLength": 1 } }, "required": ["text"], "additionalProperties": false }, "visibility": { "enum": ["student", "teacher", "both"] }, "sourceRefs": { "type": "array", "items": { "type": "object", "properties": { "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "chunkId": { "type": "string", "minLength": 1 } }, "required": ["sourceId", "sourceRevision", "chunkId"], "additionalProperties": false } } }, "required": ["id", "type", "data", "visibility", "sourceRefs"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "type": { "const": "teacherNote" }, "data": { "type": "object", "properties": { "text": { "type": "string", "minLength": 1 } }, "required": ["text"], "additionalProperties": false }, "visibility": { "const": "teacher" }, "sourceRefs": { "type": "array", "items": { "type": "object", "properties": { "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "chunkId": { "type": "string", "minLength": 1 } }, "required": ["sourceId", "sourceRevision", "chunkId"], "additionalProperties": false } } }, "required": ["id", "type", "data", "visibility", "sourceRefs"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "type": { "const": "questionSet" }, "data": { "type": "object", "properties": { "questionIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true } }, "required": ["questionIds"], "additionalProperties": false }, "visibility": { "enum": ["student", "both"] }, "sourceRefs": { "type": "array", "items": { "type": "object", "properties": { "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "chunkId": { "type": "string", "minLength": 1 } }, "required": ["sourceId", "sourceRevision", "chunkId"], "additionalProperties": false } } }, "required": ["id", "type", "data", "visibility", "sourceRefs"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "type": { "const": "vocabularyList" }, "data": { "type": "object", "properties": { "entries": { "type": "array", "minItems": 1, "maxItems": 30, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "term": { "type": "string", "minLength": 1 }, "definition": { "type": "string", "minLength": 1 }, "example": { "type": "string" } }, "required": ["id", "term", "definition", "example"], "additionalProperties": false } } }, "required": ["entries"], "additionalProperties": false }, "visibility": { "enum": ["student", "teacher", "both"] }, "sourceRefs": { "type": "array", "items": { "type": "object", "properties": { "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "chunkId": { "type": "string", "minLength": 1 } }, "required": ["sourceId", "sourceRevision", "chunkId"], "additionalProperties": false } } }, "required": ["id", "type", "data", "visibility", "sourceRefs"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "type": { "const": "organizer" }, "data": { "type": "object", "properties": { "title": { "type": "string", "minLength": 1 }, "nodes": { "type": "array", "minItems": 1, "maxItems": 30, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "label": { "type": "string", "minLength": 1 } }, "required": ["id", "label"], "additionalProperties": false } }, "edges": { "type": "array", "maxItems": 100, "items": { "type": "object", "properties": { "from": { "type": "string", "minLength": 1 }, "to": { "type": "string", "minLength": 1 }, "label": { "type": "string" } }, "required": ["from", "to", "label"], "additionalProperties": false } } }, "required": ["title", "nodes", "edges"], "additionalProperties": false }, "visibility": { "enum": ["student", "teacher", "both"] }, "sourceRefs": { "type": "array", "items": { "type": "object", "properties": { "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "chunkId": { "type": "string", "minLength": 1 } }, "required": ["sourceId", "sourceRevision", "chunkId"], "additionalProperties": false } } }, "required": ["id", "type", "data", "visibility", "sourceRefs"], "additionalProperties": false }] } }, "questions": { "type": "array", "items": { "oneOf": [{ "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "sourceRefs": { "type": "array", "items": { "type": "object", "properties": { "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "chunkId": { "type": "string", "minLength": 1 } }, "required": ["sourceId", "sourceRevision", "chunkId"], "additionalProperties": false } }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "singleChoice" }, "options": { "type": "array", "minItems": 2, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "text": { "type": "string", "minLength": 1 } }, "required": ["id", "text"], "additionalProperties": false } }, "answerKey": { "type": "string", "minLength": 1 }, "scoring": { "const": "exactMatch" } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "sourceRefs", "hints", "type", "options", "answerKey", "scoring"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "sourceRefs": { "type": "array", "items": { "type": "object", "properties": { "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "chunkId": { "type": "string", "minLength": 1 } }, "required": ["sourceId", "sourceRevision", "chunkId"], "additionalProperties": false } }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "trueFalse" }, "answerKey": { "type": "boolean" }, "scoring": { "const": "exactMatch" } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "sourceRefs", "hints", "type", "answerKey", "scoring"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "sourceRefs": { "type": "array", "items": { "type": "object", "properties": { "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "chunkId": { "type": "string", "minLength": 1 } }, "required": ["sourceId", "sourceRevision", "chunkId"], "additionalProperties": false } }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "shortAnswer" }, "rubric": { "type": "string", "minLength": 1 }, "scoring": { "const": "manual" } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "sourceRefs", "hints", "type", "rubric", "scoring"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "sourceRefs": { "type": "array", "items": { "type": "object", "properties": { "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "chunkId": { "type": "string", "minLength": 1 } }, "required": ["sourceId", "sourceRevision", "chunkId"], "additionalProperties": false } }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "multipleChoice" }, "options": { "type": "array", "minItems": 2, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "text": { "type": "string", "minLength": 1 } }, "required": ["id", "text"], "additionalProperties": false } }, "answerKey": { "type": "array", "minItems": 1, "maxItems": 30, "items": { "type": "string", "minLength": 1 } }, "scoring": { "const": "exactMatch" } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "sourceRefs", "hints", "type", "options", "answerKey", "scoring"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "sourceRefs": { "type": "array", "items": { "type": "object", "properties": { "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "chunkId": { "type": "string", "minLength": 1 } }, "required": ["sourceId", "sourceRevision", "chunkId"], "additionalProperties": false } }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "fillBlank" }, "blanks": { "type": "array", "minItems": 1, "maxItems": 30, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "label": { "type": "string", "minLength": 1 }, "answers": { "type": "array", "minItems": 1, "maxItems": 30, "items": { "type": "string", "minLength": 1 } } }, "required": ["id", "label", "answers"], "additionalProperties": false } }, "scoring": { "const": "partial" } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "sourceRefs", "hints", "type", "blanks", "scoring"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "sourceRefs": { "type": "array", "items": { "type": "object", "properties": { "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "chunkId": { "type": "string", "minLength": 1 } }, "required": ["sourceId", "sourceRevision", "chunkId"], "additionalProperties": false } }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "matching" }, "left": { "type": "array", "minItems": 1, "maxItems": 30, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "text": { "type": "string", "minLength": 1 } }, "required": ["id", "text"], "additionalProperties": false } }, "right": { "type": "array", "minItems": 1, "maxItems": 30, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "text": { "type": "string", "minLength": 1 } }, "required": ["id", "text"], "additionalProperties": false } }, "answerKey": { "type": "object", "additionalProperties": { "type": "string", "minLength": 1 }, "minProperties": 1 }, "scoring": { "const": "partial" } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "sourceRefs", "hints", "type", "left", "right", "answerKey", "scoring"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "sourceRefs": { "type": "array", "items": { "type": "object", "properties": { "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "chunkId": { "type": "string", "minLength": 1 } }, "required": ["sourceId", "sourceRevision", "chunkId"], "additionalProperties": false } }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "ordering" }, "items": { "type": "array", "minItems": 1, "maxItems": 30, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "text": { "type": "string", "minLength": 1 } }, "required": ["id", "text"], "additionalProperties": false } }, "answerKey": { "type": "array", "minItems": 1, "maxItems": 30, "items": { "type": "string", "minLength": 1 } }, "scoring": { "const": "exactMatch" } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "sourceRefs", "hints", "type", "items", "answerKey", "scoring"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "sourceRefs": { "type": "array", "items": { "type": "object", "properties": { "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "chunkId": { "type": "string", "minLength": 1 } }, "required": ["sourceId", "sourceRevision", "chunkId"], "additionalProperties": false } }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "upload" }, "rubric": { "type": "string", "minLength": 1 }, "scoring": { "const": "manual" } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "sourceRefs", "hints", "type", "rubric", "scoring"], "additionalProperties": false }] } } }, "required": ["id", "resourceId", "resourceType", "title", "profileId", "objectiveIds", "blocks", "questions"], "additionalProperties": false } }, "warnings": { "type": "array", "items": { "type": "string", "minLength": 1 } } }, "required": ["schemaVersion", "requestId", "jobId", "state", "origin", "providerInfo", "generatedAt", "resources", "warnings"], "additionalProperties": false, "$schema": "https://json-schema.org/draft/2020-12/schema", "title": "generate-result" };
var formats0 = require_formats().fullFormats["date-time"];
function validate21(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate21.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.schemaVersion === void 0) {
      const err0 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "schemaVersion" }, message: "must have required property 'schemaVersion'" };
      if (vErrors === null) {
        vErrors = [err0];
      } else {
        vErrors.push(err0);
      }
      errors++;
    }
    if (data.requestId === void 0) {
      const err1 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "requestId" }, message: "must have required property 'requestId'" };
      if (vErrors === null) {
        vErrors = [err1];
      } else {
        vErrors.push(err1);
      }
      errors++;
    }
    if (data.jobId === void 0) {
      const err2 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "jobId" }, message: "must have required property 'jobId'" };
      if (vErrors === null) {
        vErrors = [err2];
      } else {
        vErrors.push(err2);
      }
      errors++;
    }
    if (data.state === void 0) {
      const err3 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "state" }, message: "must have required property 'state'" };
      if (vErrors === null) {
        vErrors = [err3];
      } else {
        vErrors.push(err3);
      }
      errors++;
    }
    if (data.origin === void 0) {
      const err4 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "origin" }, message: "must have required property 'origin'" };
      if (vErrors === null) {
        vErrors = [err4];
      } else {
        vErrors.push(err4);
      }
      errors++;
    }
    if (data.providerInfo === void 0) {
      const err5 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "providerInfo" }, message: "must have required property 'providerInfo'" };
      if (vErrors === null) {
        vErrors = [err5];
      } else {
        vErrors.push(err5);
      }
      errors++;
    }
    if (data.generatedAt === void 0) {
      const err6 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "generatedAt" }, message: "must have required property 'generatedAt'" };
      if (vErrors === null) {
        vErrors = [err6];
      } else {
        vErrors.push(err6);
      }
      errors++;
    }
    if (data.resources === void 0) {
      const err7 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "resources" }, message: "must have required property 'resources'" };
      if (vErrors === null) {
        vErrors = [err7];
      } else {
        vErrors.push(err7);
      }
      errors++;
    }
    if (data.warnings === void 0) {
      const err8 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "warnings" }, message: "must have required property 'warnings'" };
      if (vErrors === null) {
        vErrors = [err8];
      } else {
        vErrors.push(err8);
      }
      errors++;
    }
    for (const key0 in data) {
      if (!func1.call(schema32.properties, key0)) {
        const err9 = { instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" };
        if (vErrors === null) {
          vErrors = [err9];
        } else {
          vErrors.push(err9);
        }
        errors++;
      }
    }
    if (data.schemaVersion !== void 0) {
      if ("3.0.0" !== data.schemaVersion) {
        const err10 = { instancePath: instancePath + "/schemaVersion", schemaPath: "#/properties/schemaVersion/const", keyword: "const", params: { allowedValue: "3.0.0" }, message: "must be equal to constant" };
        if (vErrors === null) {
          vErrors = [err10];
        } else {
          vErrors.push(err10);
        }
        errors++;
      }
    }
    if (data.requestId !== void 0) {
      let data1 = data.requestId;
      if (typeof data1 === "string") {
        if (func2(data1) < 1) {
          const err11 = { instancePath: instancePath + "/requestId", schemaPath: "#/properties/requestId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err11];
          } else {
            vErrors.push(err11);
          }
          errors++;
        }
      } else {
        const err12 = { instancePath: instancePath + "/requestId", schemaPath: "#/properties/requestId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err12];
        } else {
          vErrors.push(err12);
        }
        errors++;
      }
    }
    if (data.jobId !== void 0) {
      let data2 = data.jobId;
      if (typeof data2 === "string") {
        if (func2(data2) < 1) {
          const err13 = { instancePath: instancePath + "/jobId", schemaPath: "#/properties/jobId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err13];
          } else {
            vErrors.push(err13);
          }
          errors++;
        }
      } else {
        const err14 = { instancePath: instancePath + "/jobId", schemaPath: "#/properties/jobId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err14];
        } else {
          vErrors.push(err14);
        }
        errors++;
      }
    }
    if (data.state !== void 0) {
      if ("succeeded" !== data.state) {
        const err15 = { instancePath: instancePath + "/state", schemaPath: "#/properties/state/const", keyword: "const", params: { allowedValue: "succeeded" }, message: "must be equal to constant" };
        if (vErrors === null) {
          vErrors = [err15];
        } else {
          vErrors.push(err15);
        }
        errors++;
      }
    }
    if (data.origin !== void 0) {
      let data4 = data.origin;
      if (!(data4 === "mock" || data4 === "model")) {
        const err16 = { instancePath: instancePath + "/origin", schemaPath: "#/properties/origin/enum", keyword: "enum", params: { allowedValues: schema32.properties.origin.enum }, message: "must be equal to one of the allowed values" };
        if (vErrors === null) {
          vErrors = [err16];
        } else {
          vErrors.push(err16);
        }
        errors++;
      }
    }
    if (data.providerInfo !== void 0) {
      let data5 = data.providerInfo;
      if (data5 && typeof data5 == "object" && !Array.isArray(data5)) {
        if (data5.provider === void 0) {
          const err17 = { instancePath: instancePath + "/providerInfo", schemaPath: "#/properties/providerInfo/required", keyword: "required", params: { missingProperty: "provider" }, message: "must have required property 'provider'" };
          if (vErrors === null) {
            vErrors = [err17];
          } else {
            vErrors.push(err17);
          }
          errors++;
        }
        if (data5.modelId === void 0) {
          const err18 = { instancePath: instancePath + "/providerInfo", schemaPath: "#/properties/providerInfo/required", keyword: "required", params: { missingProperty: "modelId" }, message: "must have required property 'modelId'" };
          if (vErrors === null) {
            vErrors = [err18];
          } else {
            vErrors.push(err18);
          }
          errors++;
        }
        for (const key1 in data5) {
          if (!(key1 === "provider" || key1 === "modelId")) {
            const err19 = { instancePath: instancePath + "/providerInfo", schemaPath: "#/properties/providerInfo/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" };
            if (vErrors === null) {
              vErrors = [err19];
            } else {
              vErrors.push(err19);
            }
            errors++;
          }
        }
        if (data5.provider !== void 0) {
          let data6 = data5.provider;
          if (typeof data6 === "string") {
            if (func2(data6) < 1) {
              const err20 = { instancePath: instancePath + "/providerInfo/provider", schemaPath: "#/properties/providerInfo/properties/provider/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
              if (vErrors === null) {
                vErrors = [err20];
              } else {
                vErrors.push(err20);
              }
              errors++;
            }
          } else {
            const err21 = { instancePath: instancePath + "/providerInfo/provider", schemaPath: "#/properties/providerInfo/properties/provider/type", keyword: "type", params: { type: "string" }, message: "must be string" };
            if (vErrors === null) {
              vErrors = [err21];
            } else {
              vErrors.push(err21);
            }
            errors++;
          }
        }
        if (data5.modelId !== void 0) {
          let data7 = data5.modelId;
          if (typeof data7 !== "string" && data7 !== null) {
            const err22 = { instancePath: instancePath + "/providerInfo/modelId", schemaPath: "#/properties/providerInfo/properties/modelId/type", keyword: "type", params: { type: schema32.properties.providerInfo.properties.modelId.type }, message: "must be string,null" };
            if (vErrors === null) {
              vErrors = [err22];
            } else {
              vErrors.push(err22);
            }
            errors++;
          }
        }
      } else {
        const err23 = { instancePath: instancePath + "/providerInfo", schemaPath: "#/properties/providerInfo/type", keyword: "type", params: { type: "object" }, message: "must be object" };
        if (vErrors === null) {
          vErrors = [err23];
        } else {
          vErrors.push(err23);
        }
        errors++;
      }
    }
    if (data.generatedAt !== void 0) {
      let data8 = data.generatedAt;
      if (typeof data8 === "string") {
        if (!formats0.validate(data8)) {
          const err24 = { instancePath: instancePath + "/generatedAt", schemaPath: "#/properties/generatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
          if (vErrors === null) {
            vErrors = [err24];
          } else {
            vErrors.push(err24);
          }
          errors++;
        }
      } else {
        const err25 = { instancePath: instancePath + "/generatedAt", schemaPath: "#/properties/generatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err25];
        } else {
          vErrors.push(err25);
        }
        errors++;
      }
    }
    if (data.resources !== void 0) {
      let data9 = data.resources;
      if (Array.isArray(data9)) {
        if (data9.length < 1) {
          const err26 = { instancePath: instancePath + "/resources", schemaPath: "#/properties/resources/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
          if (vErrors === null) {
            vErrors = [err26];
          } else {
            vErrors.push(err26);
          }
          errors++;
        }
        const len0 = data9.length;
        for (let i0 = 0; i0 < len0; i0++) {
          let data10 = data9[i0];
          if (data10 && typeof data10 == "object" && !Array.isArray(data10)) {
            if (data10.id === void 0) {
              const err27 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
              if (vErrors === null) {
                vErrors = [err27];
              } else {
                vErrors.push(err27);
              }
              errors++;
            }
            if (data10.resourceId === void 0) {
              const err28 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/required", keyword: "required", params: { missingProperty: "resourceId" }, message: "must have required property 'resourceId'" };
              if (vErrors === null) {
                vErrors = [err28];
              } else {
                vErrors.push(err28);
              }
              errors++;
            }
            if (data10.resourceType === void 0) {
              const err29 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/required", keyword: "required", params: { missingProperty: "resourceType" }, message: "must have required property 'resourceType'" };
              if (vErrors === null) {
                vErrors = [err29];
              } else {
                vErrors.push(err29);
              }
              errors++;
            }
            if (data10.title === void 0) {
              const err30 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/required", keyword: "required", params: { missingProperty: "title" }, message: "must have required property 'title'" };
              if (vErrors === null) {
                vErrors = [err30];
              } else {
                vErrors.push(err30);
              }
              errors++;
            }
            if (data10.profileId === void 0) {
              const err31 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/required", keyword: "required", params: { missingProperty: "profileId" }, message: "must have required property 'profileId'" };
              if (vErrors === null) {
                vErrors = [err31];
              } else {
                vErrors.push(err31);
              }
              errors++;
            }
            if (data10.objectiveIds === void 0) {
              const err32 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
              if (vErrors === null) {
                vErrors = [err32];
              } else {
                vErrors.push(err32);
              }
              errors++;
            }
            if (data10.blocks === void 0) {
              const err33 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/required", keyword: "required", params: { missingProperty: "blocks" }, message: "must have required property 'blocks'" };
              if (vErrors === null) {
                vErrors = [err33];
              } else {
                vErrors.push(err33);
              }
              errors++;
            }
            if (data10.questions === void 0) {
              const err34 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/required", keyword: "required", params: { missingProperty: "questions" }, message: "must have required property 'questions'" };
              if (vErrors === null) {
                vErrors = [err34];
              } else {
                vErrors.push(err34);
              }
              errors++;
            }
            for (const key2 in data10) {
              if (!(key2 === "id" || key2 === "resourceId" || key2 === "resourceType" || key2 === "title" || key2 === "profileId" || key2 === "objectiveIds" || key2 === "blocks" || key2 === "questions")) {
                const err35 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" };
                if (vErrors === null) {
                  vErrors = [err35];
                } else {
                  vErrors.push(err35);
                }
                errors++;
              }
            }
            if (data10.id !== void 0) {
              let data11 = data10.id;
              if (typeof data11 === "string") {
                if (func2(data11) < 1) {
                  const err36 = { instancePath: instancePath + "/resources/" + i0 + "/id", schemaPath: "#/properties/resources/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err36];
                  } else {
                    vErrors.push(err36);
                  }
                  errors++;
                }
              } else {
                const err37 = { instancePath: instancePath + "/resources/" + i0 + "/id", schemaPath: "#/properties/resources/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err37];
                } else {
                  vErrors.push(err37);
                }
                errors++;
              }
            }
            if (data10.resourceId !== void 0) {
              let data12 = data10.resourceId;
              if (typeof data12 === "string") {
                if (func2(data12) < 1) {
                  const err38 = { instancePath: instancePath + "/resources/" + i0 + "/resourceId", schemaPath: "#/properties/resources/items/properties/resourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err38];
                  } else {
                    vErrors.push(err38);
                  }
                  errors++;
                }
              } else {
                const err39 = { instancePath: instancePath + "/resources/" + i0 + "/resourceId", schemaPath: "#/properties/resources/items/properties/resourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err39];
                } else {
                  vErrors.push(err39);
                }
                errors++;
              }
            }
            if (data10.resourceType !== void 0) {
              let data13 = data10.resourceType;
              if (!(data13 === "handout" || data13 === "reading" || data13 === "comprehension" || data13 === "quiz" || data13 === "vocabulary" || data13 === "stations" || data13 === "exitTicket" || data13 === "organizer" || data13 === "tieredPractice")) {
                const err40 = { instancePath: instancePath + "/resources/" + i0 + "/resourceType", schemaPath: "#/properties/resources/items/properties/resourceType/enum", keyword: "enum", params: { allowedValues: schema32.properties.resources.items.properties.resourceType.enum }, message: "must be equal to one of the allowed values" };
                if (vErrors === null) {
                  vErrors = [err40];
                } else {
                  vErrors.push(err40);
                }
                errors++;
              }
            }
            if (data10.title !== void 0) {
              let data14 = data10.title;
              if (typeof data14 === "string") {
                if (func2(data14) < 1) {
                  const err41 = { instancePath: instancePath + "/resources/" + i0 + "/title", schemaPath: "#/properties/resources/items/properties/title/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err41];
                  } else {
                    vErrors.push(err41);
                  }
                  errors++;
                }
              } else {
                const err42 = { instancePath: instancePath + "/resources/" + i0 + "/title", schemaPath: "#/properties/resources/items/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err42];
                } else {
                  vErrors.push(err42);
                }
                errors++;
              }
            }
            if (data10.profileId !== void 0) {
              let data15 = data10.profileId;
              if (typeof data15 === "string") {
                if (func2(data15) < 1) {
                  const err43 = { instancePath: instancePath + "/resources/" + i0 + "/profileId", schemaPath: "#/properties/resources/items/properties/profileId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err43];
                  } else {
                    vErrors.push(err43);
                  }
                  errors++;
                }
              } else {
                const err44 = { instancePath: instancePath + "/resources/" + i0 + "/profileId", schemaPath: "#/properties/resources/items/properties/profileId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err44];
                } else {
                  vErrors.push(err44);
                }
                errors++;
              }
            }
            if (data10.objectiveIds !== void 0) {
              let data16 = data10.objectiveIds;
              if (Array.isArray(data16)) {
                if (data16.length < 1) {
                  const err45 = { instancePath: instancePath + "/resources/" + i0 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                  if (vErrors === null) {
                    vErrors = [err45];
                  } else {
                    vErrors.push(err45);
                  }
                  errors++;
                }
                const len1 = data16.length;
                for (let i1 = 0; i1 < len1; i1++) {
                  let data17 = data16[i1];
                  if (typeof data17 === "string") {
                    if (func2(data17) < 1) {
                      const err46 = { instancePath: instancePath + "/resources/" + i0 + "/objectiveIds/" + i1, schemaPath: "#/properties/resources/items/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err46];
                      } else {
                        vErrors.push(err46);
                      }
                      errors++;
                    }
                  } else {
                    const err47 = { instancePath: instancePath + "/resources/" + i0 + "/objectiveIds/" + i1, schemaPath: "#/properties/resources/items/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err47];
                    } else {
                      vErrors.push(err47);
                    }
                    errors++;
                  }
                }
                let i2 = data16.length;
                let j0;
                if (i2 > 1) {
                  const indices0 = {};
                  for (; i2--; ) {
                    let item0 = data16[i2];
                    if (typeof item0 !== "string") {
                      continue;
                    }
                    if (typeof indices0[item0] == "number") {
                      j0 = indices0[item0];
                      const err48 = { instancePath: instancePath + "/resources/" + i0 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i2, j: j0 }, message: "must NOT have duplicate items (items ## " + j0 + " and " + i2 + " are identical)" };
                      if (vErrors === null) {
                        vErrors = [err48];
                      } else {
                        vErrors.push(err48);
                      }
                      errors++;
                      break;
                    }
                    indices0[item0] = i2;
                  }
                }
              } else {
                const err49 = { instancePath: instancePath + "/resources/" + i0 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                if (vErrors === null) {
                  vErrors = [err49];
                } else {
                  vErrors.push(err49);
                }
                errors++;
              }
            }
            if (data10.blocks !== void 0) {
              let data18 = data10.blocks;
              if (Array.isArray(data18)) {
                const len2 = data18.length;
                for (let i3 = 0; i3 < len2; i3++) {
                  let data19 = data18[i3];
                  const _errs39 = errors;
                  let valid10 = false;
                  let passing0 = null;
                  const _errs40 = errors;
                  if (data19 && typeof data19 == "object" && !Array.isArray(data19)) {
                    if (data19.id === void 0) {
                      const err50 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                      if (vErrors === null) {
                        vErrors = [err50];
                      } else {
                        vErrors.push(err50);
                      }
                      errors++;
                    }
                    if (data19.type === void 0) {
                      const err51 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                      if (vErrors === null) {
                        vErrors = [err51];
                      } else {
                        vErrors.push(err51);
                      }
                      errors++;
                    }
                    if (data19.data === void 0) {
                      const err52 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/required", keyword: "required", params: { missingProperty: "data" }, message: "must have required property 'data'" };
                      if (vErrors === null) {
                        vErrors = [err52];
                      } else {
                        vErrors.push(err52);
                      }
                      errors++;
                    }
                    if (data19.visibility === void 0) {
                      const err53 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/required", keyword: "required", params: { missingProperty: "visibility" }, message: "must have required property 'visibility'" };
                      if (vErrors === null) {
                        vErrors = [err53];
                      } else {
                        vErrors.push(err53);
                      }
                      errors++;
                    }
                    if (data19.sourceRefs === void 0) {
                      const err54 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/required", keyword: "required", params: { missingProperty: "sourceRefs" }, message: "must have required property 'sourceRefs'" };
                      if (vErrors === null) {
                        vErrors = [err54];
                      } else {
                        vErrors.push(err54);
                      }
                      errors++;
                    }
                    for (const key3 in data19) {
                      if (!(key3 === "id" || key3 === "type" || key3 === "data" || key3 === "visibility" || key3 === "sourceRefs")) {
                        const err55 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" };
                        if (vErrors === null) {
                          vErrors = [err55];
                        } else {
                          vErrors.push(err55);
                        }
                        errors++;
                      }
                    }
                    if (data19.id !== void 0) {
                      let data20 = data19.id;
                      if (typeof data20 === "string") {
                        if (func2(data20) < 1) {
                          const err56 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err56];
                          } else {
                            vErrors.push(err56);
                          }
                          errors++;
                        }
                      } else {
                        const err57 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err57];
                        } else {
                          vErrors.push(err57);
                        }
                        errors++;
                      }
                    }
                    if (data19.type !== void 0) {
                      let data21 = data19.type;
                      if (!(data21 === "heading" || data21 === "paragraph")) {
                        const err58 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/type", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/type/enum", keyword: "enum", params: { allowedValues: schema32.properties.resources.items.properties.blocks.items.oneOf[0].properties.type.enum }, message: "must be equal to one of the allowed values" };
                        if (vErrors === null) {
                          vErrors = [err58];
                        } else {
                          vErrors.push(err58);
                        }
                        errors++;
                      }
                    }
                    if (data19.data !== void 0) {
                      let data22 = data19.data;
                      if (data22 && typeof data22 == "object" && !Array.isArray(data22)) {
                        if (data22.text === void 0) {
                          const err59 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/data/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
                          if (vErrors === null) {
                            vErrors = [err59];
                          } else {
                            vErrors.push(err59);
                          }
                          errors++;
                        }
                        for (const key4 in data22) {
                          if (!(key4 === "text")) {
                            const err60 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/data/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key4 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err60];
                            } else {
                              vErrors.push(err60);
                            }
                            errors++;
                          }
                        }
                        if (data22.text !== void 0) {
                          let data23 = data22.text;
                          if (typeof data23 === "string") {
                            if (func2(data23) < 1) {
                              const err61 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/text", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/data/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err61];
                              } else {
                                vErrors.push(err61);
                              }
                              errors++;
                            }
                          } else {
                            const err62 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/text", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/data/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err62];
                            } else {
                              vErrors.push(err62);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err63 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/data/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                        if (vErrors === null) {
                          vErrors = [err63];
                        } else {
                          vErrors.push(err63);
                        }
                        errors++;
                      }
                    }
                    if (data19.visibility !== void 0) {
                      let data24 = data19.visibility;
                      if (!(data24 === "student" || data24 === "teacher" || data24 === "both")) {
                        const err64 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/visibility", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/visibility/enum", keyword: "enum", params: { allowedValues: schema32.properties.resources.items.properties.blocks.items.oneOf[0].properties.visibility.enum }, message: "must be equal to one of the allowed values" };
                        if (vErrors === null) {
                          vErrors = [err64];
                        } else {
                          vErrors.push(err64);
                        }
                        errors++;
                      }
                    }
                    if (data19.sourceRefs !== void 0) {
                      let data25 = data19.sourceRefs;
                      if (Array.isArray(data25)) {
                        const len3 = data25.length;
                        for (let i4 = 0; i4 < len3; i4++) {
                          let data26 = data25[i4];
                          if (data26 && typeof data26 == "object" && !Array.isArray(data26)) {
                            if (data26.sourceId === void 0) {
                              const err65 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
                              if (vErrors === null) {
                                vErrors = [err65];
                              } else {
                                vErrors.push(err65);
                              }
                              errors++;
                            }
                            if (data26.sourceRevision === void 0) {
                              const err66 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
                              if (vErrors === null) {
                                vErrors = [err66];
                              } else {
                                vErrors.push(err66);
                              }
                              errors++;
                            }
                            if (data26.chunkId === void 0) {
                              const err67 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "chunkId" }, message: "must have required property 'chunkId'" };
                              if (vErrors === null) {
                                vErrors = [err67];
                              } else {
                                vErrors.push(err67);
                              }
                              errors++;
                            }
                            for (const key5 in data26) {
                              if (!(key5 === "sourceId" || key5 === "sourceRevision" || key5 === "chunkId")) {
                                const err68 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key5 }, message: "must NOT have additional properties" };
                                if (vErrors === null) {
                                  vErrors = [err68];
                                } else {
                                  vErrors.push(err68);
                                }
                                errors++;
                              }
                            }
                            if (data26.sourceId !== void 0) {
                              let data27 = data26.sourceId;
                              if (typeof data27 === "string") {
                                if (func2(data27) < 1) {
                                  const err69 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4 + "/sourceId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err69];
                                  } else {
                                    vErrors.push(err69);
                                  }
                                  errors++;
                                }
                              } else {
                                const err70 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4 + "/sourceId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err70];
                                } else {
                                  vErrors.push(err70);
                                }
                                errors++;
                              }
                            }
                            if (data26.sourceRevision !== void 0) {
                              let data28 = data26.sourceRevision;
                              if (!(typeof data28 == "number" && (!(data28 % 1) && !isNaN(data28)))) {
                                const err71 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                if (vErrors === null) {
                                  vErrors = [err71];
                                } else {
                                  vErrors.push(err71);
                                }
                                errors++;
                              }
                              if (typeof data28 == "number") {
                                if (data28 < 1 || isNaN(data28)) {
                                  const err72 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                                  if (vErrors === null) {
                                    vErrors = [err72];
                                  } else {
                                    vErrors.push(err72);
                                  }
                                  errors++;
                                }
                              }
                            }
                            if (data26.chunkId !== void 0) {
                              let data29 = data26.chunkId;
                              if (typeof data29 === "string") {
                                if (func2(data29) < 1) {
                                  const err73 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4 + "/chunkId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/properties/chunkId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err73];
                                  } else {
                                    vErrors.push(err73);
                                  }
                                  errors++;
                                }
                              } else {
                                const err74 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4 + "/chunkId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/properties/chunkId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err74];
                                } else {
                                  vErrors.push(err74);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err75 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                            if (vErrors === null) {
                              vErrors = [err75];
                            } else {
                              vErrors.push(err75);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err76 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err76];
                        } else {
                          vErrors.push(err76);
                        }
                        errors++;
                      }
                    }
                  } else {
                    const err77 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                    if (vErrors === null) {
                      vErrors = [err77];
                    } else {
                      vErrors.push(err77);
                    }
                    errors++;
                  }
                  var _valid0 = _errs40 === errors;
                  if (_valid0) {
                    valid10 = true;
                    passing0 = 0;
                    var props0 = true;
                  }
                  const _errs63 = errors;
                  if (data19 && typeof data19 == "object" && !Array.isArray(data19)) {
                    if (data19.id === void 0) {
                      const err78 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                      if (vErrors === null) {
                        vErrors = [err78];
                      } else {
                        vErrors.push(err78);
                      }
                      errors++;
                    }
                    if (data19.type === void 0) {
                      const err79 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                      if (vErrors === null) {
                        vErrors = [err79];
                      } else {
                        vErrors.push(err79);
                      }
                      errors++;
                    }
                    if (data19.data === void 0) {
                      const err80 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/required", keyword: "required", params: { missingProperty: "data" }, message: "must have required property 'data'" };
                      if (vErrors === null) {
                        vErrors = [err80];
                      } else {
                        vErrors.push(err80);
                      }
                      errors++;
                    }
                    if (data19.visibility === void 0) {
                      const err81 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/required", keyword: "required", params: { missingProperty: "visibility" }, message: "must have required property 'visibility'" };
                      if (vErrors === null) {
                        vErrors = [err81];
                      } else {
                        vErrors.push(err81);
                      }
                      errors++;
                    }
                    if (data19.sourceRefs === void 0) {
                      const err82 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/required", keyword: "required", params: { missingProperty: "sourceRefs" }, message: "must have required property 'sourceRefs'" };
                      if (vErrors === null) {
                        vErrors = [err82];
                      } else {
                        vErrors.push(err82);
                      }
                      errors++;
                    }
                    for (const key6 in data19) {
                      if (!(key6 === "id" || key6 === "type" || key6 === "data" || key6 === "visibility" || key6 === "sourceRefs")) {
                        const err83 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key6 }, message: "must NOT have additional properties" };
                        if (vErrors === null) {
                          vErrors = [err83];
                        } else {
                          vErrors.push(err83);
                        }
                        errors++;
                      }
                    }
                    if (data19.id !== void 0) {
                      let data30 = data19.id;
                      if (typeof data30 === "string") {
                        if (func2(data30) < 1) {
                          const err84 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err84];
                          } else {
                            vErrors.push(err84);
                          }
                          errors++;
                        }
                      } else {
                        const err85 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err85];
                        } else {
                          vErrors.push(err85);
                        }
                        errors++;
                      }
                    }
                    if (data19.type !== void 0) {
                      if ("teacherNote" !== data19.type) {
                        const err86 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/type", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/type/const", keyword: "const", params: { allowedValue: "teacherNote" }, message: "must be equal to constant" };
                        if (vErrors === null) {
                          vErrors = [err86];
                        } else {
                          vErrors.push(err86);
                        }
                        errors++;
                      }
                    }
                    if (data19.data !== void 0) {
                      let data32 = data19.data;
                      if (data32 && typeof data32 == "object" && !Array.isArray(data32)) {
                        if (data32.text === void 0) {
                          const err87 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/data/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
                          if (vErrors === null) {
                            vErrors = [err87];
                          } else {
                            vErrors.push(err87);
                          }
                          errors++;
                        }
                        for (const key7 in data32) {
                          if (!(key7 === "text")) {
                            const err88 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/data/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key7 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err88];
                            } else {
                              vErrors.push(err88);
                            }
                            errors++;
                          }
                        }
                        if (data32.text !== void 0) {
                          let data33 = data32.text;
                          if (typeof data33 === "string") {
                            if (func2(data33) < 1) {
                              const err89 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/text", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/data/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err89];
                              } else {
                                vErrors.push(err89);
                              }
                              errors++;
                            }
                          } else {
                            const err90 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/text", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/data/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err90];
                            } else {
                              vErrors.push(err90);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err91 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/data/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                        if (vErrors === null) {
                          vErrors = [err91];
                        } else {
                          vErrors.push(err91);
                        }
                        errors++;
                      }
                    }
                    if (data19.visibility !== void 0) {
                      if ("teacher" !== data19.visibility) {
                        const err92 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/visibility", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/visibility/const", keyword: "const", params: { allowedValue: "teacher" }, message: "must be equal to constant" };
                        if (vErrors === null) {
                          vErrors = [err92];
                        } else {
                          vErrors.push(err92);
                        }
                        errors++;
                      }
                    }
                    if (data19.sourceRefs !== void 0) {
                      let data35 = data19.sourceRefs;
                      if (Array.isArray(data35)) {
                        const len4 = data35.length;
                        for (let i5 = 0; i5 < len4; i5++) {
                          let data36 = data35[i5];
                          if (data36 && typeof data36 == "object" && !Array.isArray(data36)) {
                            if (data36.sourceId === void 0) {
                              const err93 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
                              if (vErrors === null) {
                                vErrors = [err93];
                              } else {
                                vErrors.push(err93);
                              }
                              errors++;
                            }
                            if (data36.sourceRevision === void 0) {
                              const err94 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
                              if (vErrors === null) {
                                vErrors = [err94];
                              } else {
                                vErrors.push(err94);
                              }
                              errors++;
                            }
                            if (data36.chunkId === void 0) {
                              const err95 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "chunkId" }, message: "must have required property 'chunkId'" };
                              if (vErrors === null) {
                                vErrors = [err95];
                              } else {
                                vErrors.push(err95);
                              }
                              errors++;
                            }
                            for (const key8 in data36) {
                              if (!(key8 === "sourceId" || key8 === "sourceRevision" || key8 === "chunkId")) {
                                const err96 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key8 }, message: "must NOT have additional properties" };
                                if (vErrors === null) {
                                  vErrors = [err96];
                                } else {
                                  vErrors.push(err96);
                                }
                                errors++;
                              }
                            }
                            if (data36.sourceId !== void 0) {
                              let data37 = data36.sourceId;
                              if (typeof data37 === "string") {
                                if (func2(data37) < 1) {
                                  const err97 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5 + "/sourceId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err97];
                                  } else {
                                    vErrors.push(err97);
                                  }
                                  errors++;
                                }
                              } else {
                                const err98 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5 + "/sourceId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err98];
                                } else {
                                  vErrors.push(err98);
                                }
                                errors++;
                              }
                            }
                            if (data36.sourceRevision !== void 0) {
                              let data38 = data36.sourceRevision;
                              if (!(typeof data38 == "number" && (!(data38 % 1) && !isNaN(data38)))) {
                                const err99 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                if (vErrors === null) {
                                  vErrors = [err99];
                                } else {
                                  vErrors.push(err99);
                                }
                                errors++;
                              }
                              if (typeof data38 == "number") {
                                if (data38 < 1 || isNaN(data38)) {
                                  const err100 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                                  if (vErrors === null) {
                                    vErrors = [err100];
                                  } else {
                                    vErrors.push(err100);
                                  }
                                  errors++;
                                }
                              }
                            }
                            if (data36.chunkId !== void 0) {
                              let data39 = data36.chunkId;
                              if (typeof data39 === "string") {
                                if (func2(data39) < 1) {
                                  const err101 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5 + "/chunkId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/properties/chunkId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err101];
                                  } else {
                                    vErrors.push(err101);
                                  }
                                  errors++;
                                }
                              } else {
                                const err102 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5 + "/chunkId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/properties/chunkId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err102];
                                } else {
                                  vErrors.push(err102);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err103 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                            if (vErrors === null) {
                              vErrors = [err103];
                            } else {
                              vErrors.push(err103);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err104 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err104];
                        } else {
                          vErrors.push(err104);
                        }
                        errors++;
                      }
                    }
                  } else {
                    const err105 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                    if (vErrors === null) {
                      vErrors = [err105];
                    } else {
                      vErrors.push(err105);
                    }
                    errors++;
                  }
                  var _valid0 = _errs63 === errors;
                  if (_valid0 && valid10) {
                    valid10 = false;
                    passing0 = [passing0, 1];
                  } else {
                    if (_valid0) {
                      valid10 = true;
                      passing0 = 1;
                      if (props0 !== true) {
                        props0 = true;
                      }
                    }
                    const _errs86 = errors;
                    if (data19 && typeof data19 == "object" && !Array.isArray(data19)) {
                      if (data19.id === void 0) {
                        const err106 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                        if (vErrors === null) {
                          vErrors = [err106];
                        } else {
                          vErrors.push(err106);
                        }
                        errors++;
                      }
                      if (data19.type === void 0) {
                        const err107 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                        if (vErrors === null) {
                          vErrors = [err107];
                        } else {
                          vErrors.push(err107);
                        }
                        errors++;
                      }
                      if (data19.data === void 0) {
                        const err108 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/required", keyword: "required", params: { missingProperty: "data" }, message: "must have required property 'data'" };
                        if (vErrors === null) {
                          vErrors = [err108];
                        } else {
                          vErrors.push(err108);
                        }
                        errors++;
                      }
                      if (data19.visibility === void 0) {
                        const err109 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/required", keyword: "required", params: { missingProperty: "visibility" }, message: "must have required property 'visibility'" };
                        if (vErrors === null) {
                          vErrors = [err109];
                        } else {
                          vErrors.push(err109);
                        }
                        errors++;
                      }
                      if (data19.sourceRefs === void 0) {
                        const err110 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/required", keyword: "required", params: { missingProperty: "sourceRefs" }, message: "must have required property 'sourceRefs'" };
                        if (vErrors === null) {
                          vErrors = [err110];
                        } else {
                          vErrors.push(err110);
                        }
                        errors++;
                      }
                      for (const key9 in data19) {
                        if (!(key9 === "id" || key9 === "type" || key9 === "data" || key9 === "visibility" || key9 === "sourceRefs")) {
                          const err111 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key9 }, message: "must NOT have additional properties" };
                          if (vErrors === null) {
                            vErrors = [err111];
                          } else {
                            vErrors.push(err111);
                          }
                          errors++;
                        }
                      }
                      if (data19.id !== void 0) {
                        let data40 = data19.id;
                        if (typeof data40 === "string") {
                          if (func2(data40) < 1) {
                            const err112 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                            if (vErrors === null) {
                              vErrors = [err112];
                            } else {
                              vErrors.push(err112);
                            }
                            errors++;
                          }
                        } else {
                          const err113 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                          if (vErrors === null) {
                            vErrors = [err113];
                          } else {
                            vErrors.push(err113);
                          }
                          errors++;
                        }
                      }
                      if (data19.type !== void 0) {
                        if ("questionSet" !== data19.type) {
                          const err114 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/type", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/type/const", keyword: "const", params: { allowedValue: "questionSet" }, message: "must be equal to constant" };
                          if (vErrors === null) {
                            vErrors = [err114];
                          } else {
                            vErrors.push(err114);
                          }
                          errors++;
                        }
                      }
                      if (data19.data !== void 0) {
                        let data42 = data19.data;
                        if (data42 && typeof data42 == "object" && !Array.isArray(data42)) {
                          if (data42.questionIds === void 0) {
                            const err115 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/data/required", keyword: "required", params: { missingProperty: "questionIds" }, message: "must have required property 'questionIds'" };
                            if (vErrors === null) {
                              vErrors = [err115];
                            } else {
                              vErrors.push(err115);
                            }
                            errors++;
                          }
                          for (const key10 in data42) {
                            if (!(key10 === "questionIds")) {
                              const err116 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/data/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key10 }, message: "must NOT have additional properties" };
                              if (vErrors === null) {
                                vErrors = [err116];
                              } else {
                                vErrors.push(err116);
                              }
                              errors++;
                            }
                          }
                          if (data42.questionIds !== void 0) {
                            let data43 = data42.questionIds;
                            if (Array.isArray(data43)) {
                              if (data43.length < 1) {
                                const err117 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/questionIds", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/data/properties/questionIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                                if (vErrors === null) {
                                  vErrors = [err117];
                                } else {
                                  vErrors.push(err117);
                                }
                                errors++;
                              }
                              const len5 = data43.length;
                              for (let i6 = 0; i6 < len5; i6++) {
                                let data44 = data43[i6];
                                if (typeof data44 === "string") {
                                  if (func2(data44) < 1) {
                                    const err118 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/questionIds/" + i6, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/data/properties/questionIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err118];
                                    } else {
                                      vErrors.push(err118);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err119 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/questionIds/" + i6, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/data/properties/questionIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err119];
                                  } else {
                                    vErrors.push(err119);
                                  }
                                  errors++;
                                }
                              }
                              let i7 = data43.length;
                              let j1;
                              if (i7 > 1) {
                                const indices1 = {};
                                for (; i7--; ) {
                                  let item1 = data43[i7];
                                  if (typeof item1 !== "string") {
                                    continue;
                                  }
                                  if (typeof indices1[item1] == "number") {
                                    j1 = indices1[item1];
                                    const err120 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/questionIds", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/data/properties/questionIds/uniqueItems", keyword: "uniqueItems", params: { i: i7, j: j1 }, message: "must NOT have duplicate items (items ## " + j1 + " and " + i7 + " are identical)" };
                                    if (vErrors === null) {
                                      vErrors = [err120];
                                    } else {
                                      vErrors.push(err120);
                                    }
                                    errors++;
                                    break;
                                  }
                                  indices1[item1] = i7;
                                }
                              }
                            } else {
                              const err121 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/questionIds", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/data/properties/questionIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                              if (vErrors === null) {
                                vErrors = [err121];
                              } else {
                                vErrors.push(err121);
                              }
                              errors++;
                            }
                          }
                        } else {
                          const err122 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/data/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                          if (vErrors === null) {
                            vErrors = [err122];
                          } else {
                            vErrors.push(err122);
                          }
                          errors++;
                        }
                      }
                      if (data19.visibility !== void 0) {
                        let data45 = data19.visibility;
                        if (!(data45 === "student" || data45 === "both")) {
                          const err123 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/visibility", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/visibility/enum", keyword: "enum", params: { allowedValues: schema32.properties.resources.items.properties.blocks.items.oneOf[2].properties.visibility.enum }, message: "must be equal to one of the allowed values" };
                          if (vErrors === null) {
                            vErrors = [err123];
                          } else {
                            vErrors.push(err123);
                          }
                          errors++;
                        }
                      }
                      if (data19.sourceRefs !== void 0) {
                        let data46 = data19.sourceRefs;
                        if (Array.isArray(data46)) {
                          const len6 = data46.length;
                          for (let i8 = 0; i8 < len6; i8++) {
                            let data47 = data46[i8];
                            if (data47 && typeof data47 == "object" && !Array.isArray(data47)) {
                              if (data47.sourceId === void 0) {
                                const err124 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
                                if (vErrors === null) {
                                  vErrors = [err124];
                                } else {
                                  vErrors.push(err124);
                                }
                                errors++;
                              }
                              if (data47.sourceRevision === void 0) {
                                const err125 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
                                if (vErrors === null) {
                                  vErrors = [err125];
                                } else {
                                  vErrors.push(err125);
                                }
                                errors++;
                              }
                              if (data47.chunkId === void 0) {
                                const err126 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "chunkId" }, message: "must have required property 'chunkId'" };
                                if (vErrors === null) {
                                  vErrors = [err126];
                                } else {
                                  vErrors.push(err126);
                                }
                                errors++;
                              }
                              for (const key11 in data47) {
                                if (!(key11 === "sourceId" || key11 === "sourceRevision" || key11 === "chunkId")) {
                                  const err127 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key11 }, message: "must NOT have additional properties" };
                                  if (vErrors === null) {
                                    vErrors = [err127];
                                  } else {
                                    vErrors.push(err127);
                                  }
                                  errors++;
                                }
                              }
                              if (data47.sourceId !== void 0) {
                                let data48 = data47.sourceId;
                                if (typeof data48 === "string") {
                                  if (func2(data48) < 1) {
                                    const err128 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8 + "/sourceId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err128];
                                    } else {
                                      vErrors.push(err128);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err129 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8 + "/sourceId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err129];
                                  } else {
                                    vErrors.push(err129);
                                  }
                                  errors++;
                                }
                              }
                              if (data47.sourceRevision !== void 0) {
                                let data49 = data47.sourceRevision;
                                if (!(typeof data49 == "number" && (!(data49 % 1) && !isNaN(data49)))) {
                                  const err130 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                  if (vErrors === null) {
                                    vErrors = [err130];
                                  } else {
                                    vErrors.push(err130);
                                  }
                                  errors++;
                                }
                                if (typeof data49 == "number") {
                                  if (data49 < 1 || isNaN(data49)) {
                                    const err131 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                                    if (vErrors === null) {
                                      vErrors = [err131];
                                    } else {
                                      vErrors.push(err131);
                                    }
                                    errors++;
                                  }
                                }
                              }
                              if (data47.chunkId !== void 0) {
                                let data50 = data47.chunkId;
                                if (typeof data50 === "string") {
                                  if (func2(data50) < 1) {
                                    const err132 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8 + "/chunkId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/properties/chunkId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err132];
                                    } else {
                                      vErrors.push(err132);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err133 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8 + "/chunkId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/properties/chunkId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err133];
                                  } else {
                                    vErrors.push(err133);
                                  }
                                  errors++;
                                }
                              }
                            } else {
                              const err134 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                              if (vErrors === null) {
                                vErrors = [err134];
                              } else {
                                vErrors.push(err134);
                              }
                              errors++;
                            }
                          }
                        } else {
                          const err135 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                          if (vErrors === null) {
                            vErrors = [err135];
                          } else {
                            vErrors.push(err135);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err136 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err136];
                      } else {
                        vErrors.push(err136);
                      }
                      errors++;
                    }
                    var _valid0 = _errs86 === errors;
                    if (_valid0 && valid10) {
                      valid10 = false;
                      passing0 = [passing0, 2];
                    } else {
                      if (_valid0) {
                        valid10 = true;
                        passing0 = 2;
                        if (props0 !== true) {
                          props0 = true;
                        }
                      }
                      const _errs111 = errors;
                      if (data19 && typeof data19 == "object" && !Array.isArray(data19)) {
                        if (data19.id === void 0) {
                          const err137 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                          if (vErrors === null) {
                            vErrors = [err137];
                          } else {
                            vErrors.push(err137);
                          }
                          errors++;
                        }
                        if (data19.type === void 0) {
                          const err138 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                          if (vErrors === null) {
                            vErrors = [err138];
                          } else {
                            vErrors.push(err138);
                          }
                          errors++;
                        }
                        if (data19.data === void 0) {
                          const err139 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/required", keyword: "required", params: { missingProperty: "data" }, message: "must have required property 'data'" };
                          if (vErrors === null) {
                            vErrors = [err139];
                          } else {
                            vErrors.push(err139);
                          }
                          errors++;
                        }
                        if (data19.visibility === void 0) {
                          const err140 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/required", keyword: "required", params: { missingProperty: "visibility" }, message: "must have required property 'visibility'" };
                          if (vErrors === null) {
                            vErrors = [err140];
                          } else {
                            vErrors.push(err140);
                          }
                          errors++;
                        }
                        if (data19.sourceRefs === void 0) {
                          const err141 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/required", keyword: "required", params: { missingProperty: "sourceRefs" }, message: "must have required property 'sourceRefs'" };
                          if (vErrors === null) {
                            vErrors = [err141];
                          } else {
                            vErrors.push(err141);
                          }
                          errors++;
                        }
                        for (const key12 in data19) {
                          if (!(key12 === "id" || key12 === "type" || key12 === "data" || key12 === "visibility" || key12 === "sourceRefs")) {
                            const err142 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key12 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err142];
                            } else {
                              vErrors.push(err142);
                            }
                            errors++;
                          }
                        }
                        if (data19.id !== void 0) {
                          let data51 = data19.id;
                          if (typeof data51 === "string") {
                            if (func2(data51) < 1) {
                              const err143 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err143];
                              } else {
                                vErrors.push(err143);
                              }
                              errors++;
                            }
                          } else {
                            const err144 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err144];
                            } else {
                              vErrors.push(err144);
                            }
                            errors++;
                          }
                        }
                        if (data19.type !== void 0) {
                          if ("vocabularyList" !== data19.type) {
                            const err145 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/type", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/type/const", keyword: "const", params: { allowedValue: "vocabularyList" }, message: "must be equal to constant" };
                            if (vErrors === null) {
                              vErrors = [err145];
                            } else {
                              vErrors.push(err145);
                            }
                            errors++;
                          }
                        }
                        if (data19.data !== void 0) {
                          let data53 = data19.data;
                          if (data53 && typeof data53 == "object" && !Array.isArray(data53)) {
                            if (data53.entries === void 0) {
                              const err146 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/data/required", keyword: "required", params: { missingProperty: "entries" }, message: "must have required property 'entries'" };
                              if (vErrors === null) {
                                vErrors = [err146];
                              } else {
                                vErrors.push(err146);
                              }
                              errors++;
                            }
                            for (const key13 in data53) {
                              if (!(key13 === "entries")) {
                                const err147 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/data/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key13 }, message: "must NOT have additional properties" };
                                if (vErrors === null) {
                                  vErrors = [err147];
                                } else {
                                  vErrors.push(err147);
                                }
                                errors++;
                              }
                            }
                            if (data53.entries !== void 0) {
                              let data54 = data53.entries;
                              if (Array.isArray(data54)) {
                                if (data54.length > 30) {
                                  const err148 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/entries", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/data/properties/entries/maxItems", keyword: "maxItems", params: { limit: 30 }, message: "must NOT have more than 30 items" };
                                  if (vErrors === null) {
                                    vErrors = [err148];
                                  } else {
                                    vErrors.push(err148);
                                  }
                                  errors++;
                                }
                                if (data54.length < 1) {
                                  const err149 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/entries", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/data/properties/entries/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                                  if (vErrors === null) {
                                    vErrors = [err149];
                                  } else {
                                    vErrors.push(err149);
                                  }
                                  errors++;
                                }
                                const len7 = data54.length;
                                for (let i9 = 0; i9 < len7; i9++) {
                                  let data55 = data54[i9];
                                  if (data55 && typeof data55 == "object" && !Array.isArray(data55)) {
                                    if (data55.id === void 0) {
                                      const err150 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/entries/" + i9, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/data/properties/entries/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                                      if (vErrors === null) {
                                        vErrors = [err150];
                                      } else {
                                        vErrors.push(err150);
                                      }
                                      errors++;
                                    }
                                    if (data55.term === void 0) {
                                      const err151 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/entries/" + i9, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/data/properties/entries/items/required", keyword: "required", params: { missingProperty: "term" }, message: "must have required property 'term'" };
                                      if (vErrors === null) {
                                        vErrors = [err151];
                                      } else {
                                        vErrors.push(err151);
                                      }
                                      errors++;
                                    }
                                    if (data55.definition === void 0) {
                                      const err152 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/entries/" + i9, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/data/properties/entries/items/required", keyword: "required", params: { missingProperty: "definition" }, message: "must have required property 'definition'" };
                                      if (vErrors === null) {
                                        vErrors = [err152];
                                      } else {
                                        vErrors.push(err152);
                                      }
                                      errors++;
                                    }
                                    if (data55.example === void 0) {
                                      const err153 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/entries/" + i9, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/data/properties/entries/items/required", keyword: "required", params: { missingProperty: "example" }, message: "must have required property 'example'" };
                                      if (vErrors === null) {
                                        vErrors = [err153];
                                      } else {
                                        vErrors.push(err153);
                                      }
                                      errors++;
                                    }
                                    for (const key14 in data55) {
                                      if (!(key14 === "id" || key14 === "term" || key14 === "definition" || key14 === "example")) {
                                        const err154 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/entries/" + i9, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/data/properties/entries/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key14 }, message: "must NOT have additional properties" };
                                        if (vErrors === null) {
                                          vErrors = [err154];
                                        } else {
                                          vErrors.push(err154);
                                        }
                                        errors++;
                                      }
                                    }
                                    if (data55.id !== void 0) {
                                      let data56 = data55.id;
                                      if (typeof data56 === "string") {
                                        if (func2(data56) < 1) {
                                          const err155 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/entries/" + i9 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/data/properties/entries/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err155];
                                          } else {
                                            vErrors.push(err155);
                                          }
                                          errors++;
                                        }
                                      } else {
                                        const err156 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/entries/" + i9 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/data/properties/entries/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err156];
                                        } else {
                                          vErrors.push(err156);
                                        }
                                        errors++;
                                      }
                                    }
                                    if (data55.term !== void 0) {
                                      let data57 = data55.term;
                                      if (typeof data57 === "string") {
                                        if (func2(data57) < 1) {
                                          const err157 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/entries/" + i9 + "/term", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/data/properties/entries/items/properties/term/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err157];
                                          } else {
                                            vErrors.push(err157);
                                          }
                                          errors++;
                                        }
                                      } else {
                                        const err158 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/entries/" + i9 + "/term", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/data/properties/entries/items/properties/term/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err158];
                                        } else {
                                          vErrors.push(err158);
                                        }
                                        errors++;
                                      }
                                    }
                                    if (data55.definition !== void 0) {
                                      let data58 = data55.definition;
                                      if (typeof data58 === "string") {
                                        if (func2(data58) < 1) {
                                          const err159 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/entries/" + i9 + "/definition", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/data/properties/entries/items/properties/definition/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err159];
                                          } else {
                                            vErrors.push(err159);
                                          }
                                          errors++;
                                        }
                                      } else {
                                        const err160 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/entries/" + i9 + "/definition", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/data/properties/entries/items/properties/definition/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err160];
                                        } else {
                                          vErrors.push(err160);
                                        }
                                        errors++;
                                      }
                                    }
                                    if (data55.example !== void 0) {
                                      if (typeof data55.example !== "string") {
                                        const err161 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/entries/" + i9 + "/example", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/data/properties/entries/items/properties/example/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err161];
                                        } else {
                                          vErrors.push(err161);
                                        }
                                        errors++;
                                      }
                                    }
                                  } else {
                                    const err162 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/entries/" + i9, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/data/properties/entries/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                    if (vErrors === null) {
                                      vErrors = [err162];
                                    } else {
                                      vErrors.push(err162);
                                    }
                                    errors++;
                                  }
                                }
                              } else {
                                const err163 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/entries", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/data/properties/entries/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                if (vErrors === null) {
                                  vErrors = [err163];
                                } else {
                                  vErrors.push(err163);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err164 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/data/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                            if (vErrors === null) {
                              vErrors = [err164];
                            } else {
                              vErrors.push(err164);
                            }
                            errors++;
                          }
                        }
                        if (data19.visibility !== void 0) {
                          let data60 = data19.visibility;
                          if (!(data60 === "student" || data60 === "teacher" || data60 === "both")) {
                            const err165 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/visibility", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/visibility/enum", keyword: "enum", params: { allowedValues: schema32.properties.resources.items.properties.blocks.items.oneOf[3].properties.visibility.enum }, message: "must be equal to one of the allowed values" };
                            if (vErrors === null) {
                              vErrors = [err165];
                            } else {
                              vErrors.push(err165);
                            }
                            errors++;
                          }
                        }
                        if (data19.sourceRefs !== void 0) {
                          let data61 = data19.sourceRefs;
                          if (Array.isArray(data61)) {
                            const len8 = data61.length;
                            for (let i10 = 0; i10 < len8; i10++) {
                              let data62 = data61[i10];
                              if (data62 && typeof data62 == "object" && !Array.isArray(data62)) {
                                if (data62.sourceId === void 0) {
                                  const err166 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i10, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
                                  if (vErrors === null) {
                                    vErrors = [err166];
                                  } else {
                                    vErrors.push(err166);
                                  }
                                  errors++;
                                }
                                if (data62.sourceRevision === void 0) {
                                  const err167 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i10, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
                                  if (vErrors === null) {
                                    vErrors = [err167];
                                  } else {
                                    vErrors.push(err167);
                                  }
                                  errors++;
                                }
                                if (data62.chunkId === void 0) {
                                  const err168 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i10, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "chunkId" }, message: "must have required property 'chunkId'" };
                                  if (vErrors === null) {
                                    vErrors = [err168];
                                  } else {
                                    vErrors.push(err168);
                                  }
                                  errors++;
                                }
                                for (const key15 in data62) {
                                  if (!(key15 === "sourceId" || key15 === "sourceRevision" || key15 === "chunkId")) {
                                    const err169 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i10, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/sourceRefs/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key15 }, message: "must NOT have additional properties" };
                                    if (vErrors === null) {
                                      vErrors = [err169];
                                    } else {
                                      vErrors.push(err169);
                                    }
                                    errors++;
                                  }
                                }
                                if (data62.sourceId !== void 0) {
                                  let data63 = data62.sourceId;
                                  if (typeof data63 === "string") {
                                    if (func2(data63) < 1) {
                                      const err170 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i10 + "/sourceId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/sourceRefs/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err170];
                                      } else {
                                        vErrors.push(err170);
                                      }
                                      errors++;
                                    }
                                  } else {
                                    const err171 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i10 + "/sourceId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/sourceRefs/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err171];
                                    } else {
                                      vErrors.push(err171);
                                    }
                                    errors++;
                                  }
                                }
                                if (data62.sourceRevision !== void 0) {
                                  let data64 = data62.sourceRevision;
                                  if (!(typeof data64 == "number" && (!(data64 % 1) && !isNaN(data64)))) {
                                    const err172 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i10 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/sourceRefs/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                    if (vErrors === null) {
                                      vErrors = [err172];
                                    } else {
                                      vErrors.push(err172);
                                    }
                                    errors++;
                                  }
                                  if (typeof data64 == "number") {
                                    if (data64 < 1 || isNaN(data64)) {
                                      const err173 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i10 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/sourceRefs/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                                      if (vErrors === null) {
                                        vErrors = [err173];
                                      } else {
                                        vErrors.push(err173);
                                      }
                                      errors++;
                                    }
                                  }
                                }
                                if (data62.chunkId !== void 0) {
                                  let data65 = data62.chunkId;
                                  if (typeof data65 === "string") {
                                    if (func2(data65) < 1) {
                                      const err174 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i10 + "/chunkId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/sourceRefs/items/properties/chunkId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err174];
                                      } else {
                                        vErrors.push(err174);
                                      }
                                      errors++;
                                    }
                                  } else {
                                    const err175 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i10 + "/chunkId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/sourceRefs/items/properties/chunkId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err175];
                                    } else {
                                      vErrors.push(err175);
                                    }
                                    errors++;
                                  }
                                }
                              } else {
                                const err176 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i10, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/sourceRefs/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                if (vErrors === null) {
                                  vErrors = [err176];
                                } else {
                                  vErrors.push(err176);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err177 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/properties/sourceRefs/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                            if (vErrors === null) {
                              vErrors = [err177];
                            } else {
                              vErrors.push(err177);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err178 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/3/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                        if (vErrors === null) {
                          vErrors = [err178];
                        } else {
                          vErrors.push(err178);
                        }
                        errors++;
                      }
                      var _valid0 = _errs111 === errors;
                      if (_valid0 && valid10) {
                        valid10 = false;
                        passing0 = [passing0, 3];
                      } else {
                        if (_valid0) {
                          valid10 = true;
                          passing0 = 3;
                          if (props0 !== true) {
                            props0 = true;
                          }
                        }
                        const _errs145 = errors;
                        if (data19 && typeof data19 == "object" && !Array.isArray(data19)) {
                          if (data19.id === void 0) {
                            const err179 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                            if (vErrors === null) {
                              vErrors = [err179];
                            } else {
                              vErrors.push(err179);
                            }
                            errors++;
                          }
                          if (data19.type === void 0) {
                            const err180 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                            if (vErrors === null) {
                              vErrors = [err180];
                            } else {
                              vErrors.push(err180);
                            }
                            errors++;
                          }
                          if (data19.data === void 0) {
                            const err181 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/required", keyword: "required", params: { missingProperty: "data" }, message: "must have required property 'data'" };
                            if (vErrors === null) {
                              vErrors = [err181];
                            } else {
                              vErrors.push(err181);
                            }
                            errors++;
                          }
                          if (data19.visibility === void 0) {
                            const err182 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/required", keyword: "required", params: { missingProperty: "visibility" }, message: "must have required property 'visibility'" };
                            if (vErrors === null) {
                              vErrors = [err182];
                            } else {
                              vErrors.push(err182);
                            }
                            errors++;
                          }
                          if (data19.sourceRefs === void 0) {
                            const err183 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/required", keyword: "required", params: { missingProperty: "sourceRefs" }, message: "must have required property 'sourceRefs'" };
                            if (vErrors === null) {
                              vErrors = [err183];
                            } else {
                              vErrors.push(err183);
                            }
                            errors++;
                          }
                          for (const key16 in data19) {
                            if (!(key16 === "id" || key16 === "type" || key16 === "data" || key16 === "visibility" || key16 === "sourceRefs")) {
                              const err184 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key16 }, message: "must NOT have additional properties" };
                              if (vErrors === null) {
                                vErrors = [err184];
                              } else {
                                vErrors.push(err184);
                              }
                              errors++;
                            }
                          }
                          if (data19.id !== void 0) {
                            let data66 = data19.id;
                            if (typeof data66 === "string") {
                              if (func2(data66) < 1) {
                                const err185 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                if (vErrors === null) {
                                  vErrors = [err185];
                                } else {
                                  vErrors.push(err185);
                                }
                                errors++;
                              }
                            } else {
                              const err186 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err186];
                              } else {
                                vErrors.push(err186);
                              }
                              errors++;
                            }
                          }
                          if (data19.type !== void 0) {
                            if ("organizer" !== data19.type) {
                              const err187 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/type", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/type/const", keyword: "const", params: { allowedValue: "organizer" }, message: "must be equal to constant" };
                              if (vErrors === null) {
                                vErrors = [err187];
                              } else {
                                vErrors.push(err187);
                              }
                              errors++;
                            }
                          }
                          if (data19.data !== void 0) {
                            let data68 = data19.data;
                            if (data68 && typeof data68 == "object" && !Array.isArray(data68)) {
                              if (data68.title === void 0) {
                                const err188 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/required", keyword: "required", params: { missingProperty: "title" }, message: "must have required property 'title'" };
                                if (vErrors === null) {
                                  vErrors = [err188];
                                } else {
                                  vErrors.push(err188);
                                }
                                errors++;
                              }
                              if (data68.nodes === void 0) {
                                const err189 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/required", keyword: "required", params: { missingProperty: "nodes" }, message: "must have required property 'nodes'" };
                                if (vErrors === null) {
                                  vErrors = [err189];
                                } else {
                                  vErrors.push(err189);
                                }
                                errors++;
                              }
                              if (data68.edges === void 0) {
                                const err190 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/required", keyword: "required", params: { missingProperty: "edges" }, message: "must have required property 'edges'" };
                                if (vErrors === null) {
                                  vErrors = [err190];
                                } else {
                                  vErrors.push(err190);
                                }
                                errors++;
                              }
                              for (const key17 in data68) {
                                if (!(key17 === "title" || key17 === "nodes" || key17 === "edges")) {
                                  const err191 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key17 }, message: "must NOT have additional properties" };
                                  if (vErrors === null) {
                                    vErrors = [err191];
                                  } else {
                                    vErrors.push(err191);
                                  }
                                  errors++;
                                }
                              }
                              if (data68.title !== void 0) {
                                let data69 = data68.title;
                                if (typeof data69 === "string") {
                                  if (func2(data69) < 1) {
                                    const err192 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/title", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/title/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err192];
                                    } else {
                                      vErrors.push(err192);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err193 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/title", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err193];
                                  } else {
                                    vErrors.push(err193);
                                  }
                                  errors++;
                                }
                              }
                              if (data68.nodes !== void 0) {
                                let data70 = data68.nodes;
                                if (Array.isArray(data70)) {
                                  if (data70.length > 30) {
                                    const err194 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/nodes", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/nodes/maxItems", keyword: "maxItems", params: { limit: 30 }, message: "must NOT have more than 30 items" };
                                    if (vErrors === null) {
                                      vErrors = [err194];
                                    } else {
                                      vErrors.push(err194);
                                    }
                                    errors++;
                                  }
                                  if (data70.length < 1) {
                                    const err195 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/nodes", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/nodes/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                                    if (vErrors === null) {
                                      vErrors = [err195];
                                    } else {
                                      vErrors.push(err195);
                                    }
                                    errors++;
                                  }
                                  const len9 = data70.length;
                                  for (let i11 = 0; i11 < len9; i11++) {
                                    let data71 = data70[i11];
                                    if (data71 && typeof data71 == "object" && !Array.isArray(data71)) {
                                      if (data71.id === void 0) {
                                        const err196 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/nodes/" + i11, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/nodes/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                                        if (vErrors === null) {
                                          vErrors = [err196];
                                        } else {
                                          vErrors.push(err196);
                                        }
                                        errors++;
                                      }
                                      if (data71.label === void 0) {
                                        const err197 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/nodes/" + i11, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/nodes/items/required", keyword: "required", params: { missingProperty: "label" }, message: "must have required property 'label'" };
                                        if (vErrors === null) {
                                          vErrors = [err197];
                                        } else {
                                          vErrors.push(err197);
                                        }
                                        errors++;
                                      }
                                      for (const key18 in data71) {
                                        if (!(key18 === "id" || key18 === "label")) {
                                          const err198 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/nodes/" + i11, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/nodes/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key18 }, message: "must NOT have additional properties" };
                                          if (vErrors === null) {
                                            vErrors = [err198];
                                          } else {
                                            vErrors.push(err198);
                                          }
                                          errors++;
                                        }
                                      }
                                      if (data71.id !== void 0) {
                                        let data72 = data71.id;
                                        if (typeof data72 === "string") {
                                          if (func2(data72) < 1) {
                                            const err199 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/nodes/" + i11 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/nodes/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                            if (vErrors === null) {
                                              vErrors = [err199];
                                            } else {
                                              vErrors.push(err199);
                                            }
                                            errors++;
                                          }
                                        } else {
                                          const err200 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/nodes/" + i11 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/nodes/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                          if (vErrors === null) {
                                            vErrors = [err200];
                                          } else {
                                            vErrors.push(err200);
                                          }
                                          errors++;
                                        }
                                      }
                                      if (data71.label !== void 0) {
                                        let data73 = data71.label;
                                        if (typeof data73 === "string") {
                                          if (func2(data73) < 1) {
                                            const err201 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/nodes/" + i11 + "/label", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/nodes/items/properties/label/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                            if (vErrors === null) {
                                              vErrors = [err201];
                                            } else {
                                              vErrors.push(err201);
                                            }
                                            errors++;
                                          }
                                        } else {
                                          const err202 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/nodes/" + i11 + "/label", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/nodes/items/properties/label/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                          if (vErrors === null) {
                                            vErrors = [err202];
                                          } else {
                                            vErrors.push(err202);
                                          }
                                          errors++;
                                        }
                                      }
                                    } else {
                                      const err203 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/nodes/" + i11, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/nodes/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                      if (vErrors === null) {
                                        vErrors = [err203];
                                      } else {
                                        vErrors.push(err203);
                                      }
                                      errors++;
                                    }
                                  }
                                } else {
                                  const err204 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/nodes", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/nodes/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                  if (vErrors === null) {
                                    vErrors = [err204];
                                  } else {
                                    vErrors.push(err204);
                                  }
                                  errors++;
                                }
                              }
                              if (data68.edges !== void 0) {
                                let data74 = data68.edges;
                                if (Array.isArray(data74)) {
                                  if (data74.length > 100) {
                                    const err205 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/edges", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/edges/maxItems", keyword: "maxItems", params: { limit: 100 }, message: "must NOT have more than 100 items" };
                                    if (vErrors === null) {
                                      vErrors = [err205];
                                    } else {
                                      vErrors.push(err205);
                                    }
                                    errors++;
                                  }
                                  const len10 = data74.length;
                                  for (let i12 = 0; i12 < len10; i12++) {
                                    let data75 = data74[i12];
                                    if (data75 && typeof data75 == "object" && !Array.isArray(data75)) {
                                      if (data75.from === void 0) {
                                        const err206 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/edges/" + i12, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/edges/items/required", keyword: "required", params: { missingProperty: "from" }, message: "must have required property 'from'" };
                                        if (vErrors === null) {
                                          vErrors = [err206];
                                        } else {
                                          vErrors.push(err206);
                                        }
                                        errors++;
                                      }
                                      if (data75.to === void 0) {
                                        const err207 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/edges/" + i12, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/edges/items/required", keyword: "required", params: { missingProperty: "to" }, message: "must have required property 'to'" };
                                        if (vErrors === null) {
                                          vErrors = [err207];
                                        } else {
                                          vErrors.push(err207);
                                        }
                                        errors++;
                                      }
                                      if (data75.label === void 0) {
                                        const err208 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/edges/" + i12, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/edges/items/required", keyword: "required", params: { missingProperty: "label" }, message: "must have required property 'label'" };
                                        if (vErrors === null) {
                                          vErrors = [err208];
                                        } else {
                                          vErrors.push(err208);
                                        }
                                        errors++;
                                      }
                                      for (const key19 in data75) {
                                        if (!(key19 === "from" || key19 === "to" || key19 === "label")) {
                                          const err209 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/edges/" + i12, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/edges/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key19 }, message: "must NOT have additional properties" };
                                          if (vErrors === null) {
                                            vErrors = [err209];
                                          } else {
                                            vErrors.push(err209);
                                          }
                                          errors++;
                                        }
                                      }
                                      if (data75.from !== void 0) {
                                        let data76 = data75.from;
                                        if (typeof data76 === "string") {
                                          if (func2(data76) < 1) {
                                            const err210 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/edges/" + i12 + "/from", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/edges/items/properties/from/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                            if (vErrors === null) {
                                              vErrors = [err210];
                                            } else {
                                              vErrors.push(err210);
                                            }
                                            errors++;
                                          }
                                        } else {
                                          const err211 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/edges/" + i12 + "/from", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/edges/items/properties/from/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                          if (vErrors === null) {
                                            vErrors = [err211];
                                          } else {
                                            vErrors.push(err211);
                                          }
                                          errors++;
                                        }
                                      }
                                      if (data75.to !== void 0) {
                                        let data77 = data75.to;
                                        if (typeof data77 === "string") {
                                          if (func2(data77) < 1) {
                                            const err212 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/edges/" + i12 + "/to", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/edges/items/properties/to/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                            if (vErrors === null) {
                                              vErrors = [err212];
                                            } else {
                                              vErrors.push(err212);
                                            }
                                            errors++;
                                          }
                                        } else {
                                          const err213 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/edges/" + i12 + "/to", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/edges/items/properties/to/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                          if (vErrors === null) {
                                            vErrors = [err213];
                                          } else {
                                            vErrors.push(err213);
                                          }
                                          errors++;
                                        }
                                      }
                                      if (data75.label !== void 0) {
                                        if (typeof data75.label !== "string") {
                                          const err214 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/edges/" + i12 + "/label", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/edges/items/properties/label/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                          if (vErrors === null) {
                                            vErrors = [err214];
                                          } else {
                                            vErrors.push(err214);
                                          }
                                          errors++;
                                        }
                                      }
                                    } else {
                                      const err215 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/edges/" + i12, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/edges/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                      if (vErrors === null) {
                                        vErrors = [err215];
                                      } else {
                                        vErrors.push(err215);
                                      }
                                      errors++;
                                    }
                                  }
                                } else {
                                  const err216 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/edges", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/properties/edges/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                  if (vErrors === null) {
                                    vErrors = [err216];
                                  } else {
                                    vErrors.push(err216);
                                  }
                                  errors++;
                                }
                              }
                            } else {
                              const err217 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/data/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                              if (vErrors === null) {
                                vErrors = [err217];
                              } else {
                                vErrors.push(err217);
                              }
                              errors++;
                            }
                          }
                          if (data19.visibility !== void 0) {
                            let data79 = data19.visibility;
                            if (!(data79 === "student" || data79 === "teacher" || data79 === "both")) {
                              const err218 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/visibility", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/visibility/enum", keyword: "enum", params: { allowedValues: schema32.properties.resources.items.properties.blocks.items.oneOf[4].properties.visibility.enum }, message: "must be equal to one of the allowed values" };
                              if (vErrors === null) {
                                vErrors = [err218];
                              } else {
                                vErrors.push(err218);
                              }
                              errors++;
                            }
                          }
                          if (data19.sourceRefs !== void 0) {
                            let data80 = data19.sourceRefs;
                            if (Array.isArray(data80)) {
                              const len11 = data80.length;
                              for (let i13 = 0; i13 < len11; i13++) {
                                let data81 = data80[i13];
                                if (data81 && typeof data81 == "object" && !Array.isArray(data81)) {
                                  if (data81.sourceId === void 0) {
                                    const err219 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i13, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
                                    if (vErrors === null) {
                                      vErrors = [err219];
                                    } else {
                                      vErrors.push(err219);
                                    }
                                    errors++;
                                  }
                                  if (data81.sourceRevision === void 0) {
                                    const err220 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i13, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
                                    if (vErrors === null) {
                                      vErrors = [err220];
                                    } else {
                                      vErrors.push(err220);
                                    }
                                    errors++;
                                  }
                                  if (data81.chunkId === void 0) {
                                    const err221 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i13, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "chunkId" }, message: "must have required property 'chunkId'" };
                                    if (vErrors === null) {
                                      vErrors = [err221];
                                    } else {
                                      vErrors.push(err221);
                                    }
                                    errors++;
                                  }
                                  for (const key20 in data81) {
                                    if (!(key20 === "sourceId" || key20 === "sourceRevision" || key20 === "chunkId")) {
                                      const err222 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i13, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/sourceRefs/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key20 }, message: "must NOT have additional properties" };
                                      if (vErrors === null) {
                                        vErrors = [err222];
                                      } else {
                                        vErrors.push(err222);
                                      }
                                      errors++;
                                    }
                                  }
                                  if (data81.sourceId !== void 0) {
                                    let data82 = data81.sourceId;
                                    if (typeof data82 === "string") {
                                      if (func2(data82) < 1) {
                                        const err223 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i13 + "/sourceId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/sourceRefs/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err223];
                                        } else {
                                          vErrors.push(err223);
                                        }
                                        errors++;
                                      }
                                    } else {
                                      const err224 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i13 + "/sourceId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/sourceRefs/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                      if (vErrors === null) {
                                        vErrors = [err224];
                                      } else {
                                        vErrors.push(err224);
                                      }
                                      errors++;
                                    }
                                  }
                                  if (data81.sourceRevision !== void 0) {
                                    let data83 = data81.sourceRevision;
                                    if (!(typeof data83 == "number" && (!(data83 % 1) && !isNaN(data83)))) {
                                      const err225 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i13 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/sourceRefs/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                      if (vErrors === null) {
                                        vErrors = [err225];
                                      } else {
                                        vErrors.push(err225);
                                      }
                                      errors++;
                                    }
                                    if (typeof data83 == "number") {
                                      if (data83 < 1 || isNaN(data83)) {
                                        const err226 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i13 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/sourceRefs/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                                        if (vErrors === null) {
                                          vErrors = [err226];
                                        } else {
                                          vErrors.push(err226);
                                        }
                                        errors++;
                                      }
                                    }
                                  }
                                  if (data81.chunkId !== void 0) {
                                    let data84 = data81.chunkId;
                                    if (typeof data84 === "string") {
                                      if (func2(data84) < 1) {
                                        const err227 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i13 + "/chunkId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/sourceRefs/items/properties/chunkId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err227];
                                        } else {
                                          vErrors.push(err227);
                                        }
                                        errors++;
                                      }
                                    } else {
                                      const err228 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i13 + "/chunkId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/sourceRefs/items/properties/chunkId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                      if (vErrors === null) {
                                        vErrors = [err228];
                                      } else {
                                        vErrors.push(err228);
                                      }
                                      errors++;
                                    }
                                  }
                                } else {
                                  const err229 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i13, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/sourceRefs/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                  if (vErrors === null) {
                                    vErrors = [err229];
                                  } else {
                                    vErrors.push(err229);
                                  }
                                  errors++;
                                }
                              }
                            } else {
                              const err230 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/properties/sourceRefs/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                              if (vErrors === null) {
                                vErrors = [err230];
                              } else {
                                vErrors.push(err230);
                              }
                              errors++;
                            }
                          }
                        } else {
                          const err231 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/4/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                          if (vErrors === null) {
                            vErrors = [err231];
                          } else {
                            vErrors.push(err231);
                          }
                          errors++;
                        }
                        var _valid0 = _errs145 === errors;
                        if (_valid0 && valid10) {
                          valid10 = false;
                          passing0 = [passing0, 4];
                        } else {
                          if (_valid0) {
                            valid10 = true;
                            passing0 = 4;
                            if (props0 !== true) {
                              props0 = true;
                            }
                          }
                        }
                      }
                    }
                  }
                  if (!valid10) {
                    const err232 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf", keyword: "oneOf", params: { passingSchemas: passing0 }, message: "must match exactly one schema in oneOf" };
                    if (vErrors === null) {
                      vErrors = [err232];
                    } else {
                      vErrors.push(err232);
                    }
                    errors++;
                  } else {
                    errors = _errs39;
                    if (vErrors !== null) {
                      if (_errs39) {
                        vErrors.length = _errs39;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                }
              } else {
                const err233 = { instancePath: instancePath + "/resources/" + i0 + "/blocks", schemaPath: "#/properties/resources/items/properties/blocks/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                if (vErrors === null) {
                  vErrors = [err233];
                } else {
                  vErrors.push(err233);
                }
                errors++;
              }
            }
            if (data10.questions !== void 0) {
              let data85 = data10.questions;
              if (Array.isArray(data85)) {
                const len12 = data85.length;
                for (let i14 = 0; i14 < len12; i14++) {
                  let data86 = data85[i14];
                  const _errs191 = errors;
                  let valid50 = false;
                  let passing1 = null;
                  const _errs192 = errors;
                  if (data86 && typeof data86 == "object" && !Array.isArray(data86)) {
                    if (data86.id === void 0) {
                      const err234 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                      if (vErrors === null) {
                        vErrors = [err234];
                      } else {
                        vErrors.push(err234);
                      }
                      errors++;
                    }
                    if (data86.prompt === void 0) {
                      const err235 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
                      if (vErrors === null) {
                        vErrors = [err235];
                      } else {
                        vErrors.push(err235);
                      }
                      errors++;
                    }
                    if (data86.maxScore === void 0) {
                      const err236 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
                      if (vErrors === null) {
                        vErrors = [err236];
                      } else {
                        vErrors.push(err236);
                      }
                      errors++;
                    }
                    if (data86.objectiveIds === void 0) {
                      const err237 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
                      if (vErrors === null) {
                        vErrors = [err237];
                      } else {
                        vErrors.push(err237);
                      }
                      errors++;
                    }
                    if (data86.sourceRefs === void 0) {
                      const err238 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "sourceRefs" }, message: "must have required property 'sourceRefs'" };
                      if (vErrors === null) {
                        vErrors = [err238];
                      } else {
                        vErrors.push(err238);
                      }
                      errors++;
                    }
                    if (data86.hints === void 0) {
                      const err239 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
                      if (vErrors === null) {
                        vErrors = [err239];
                      } else {
                        vErrors.push(err239);
                      }
                      errors++;
                    }
                    if (data86.type === void 0) {
                      const err240 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                      if (vErrors === null) {
                        vErrors = [err240];
                      } else {
                        vErrors.push(err240);
                      }
                      errors++;
                    }
                    if (data86.options === void 0) {
                      const err241 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "options" }, message: "must have required property 'options'" };
                      if (vErrors === null) {
                        vErrors = [err241];
                      } else {
                        vErrors.push(err241);
                      }
                      errors++;
                    }
                    if (data86.answerKey === void 0) {
                      const err242 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "answerKey" }, message: "must have required property 'answerKey'" };
                      if (vErrors === null) {
                        vErrors = [err242];
                      } else {
                        vErrors.push(err242);
                      }
                      errors++;
                    }
                    if (data86.scoring === void 0) {
                      const err243 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "scoring" }, message: "must have required property 'scoring'" };
                      if (vErrors === null) {
                        vErrors = [err243];
                      } else {
                        vErrors.push(err243);
                      }
                      errors++;
                    }
                    for (const key21 in data86) {
                      if (!func1.call(schema32.properties.resources.items.properties.questions.items.oneOf[0].properties, key21)) {
                        const err244 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key21 }, message: "must NOT have additional properties" };
                        if (vErrors === null) {
                          vErrors = [err244];
                        } else {
                          vErrors.push(err244);
                        }
                        errors++;
                      }
                    }
                    if (data86.id !== void 0) {
                      let data87 = data86.id;
                      if (typeof data87 === "string") {
                        if (func2(data87) < 1) {
                          const err245 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err245];
                          } else {
                            vErrors.push(err245);
                          }
                          errors++;
                        }
                      } else {
                        const err246 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err246];
                        } else {
                          vErrors.push(err246);
                        }
                        errors++;
                      }
                    }
                    if (data86.prompt !== void 0) {
                      let data88 = data86.prompt;
                      if (typeof data88 === "string") {
                        if (func2(data88) < 1) {
                          const err247 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err247];
                          } else {
                            vErrors.push(err247);
                          }
                          errors++;
                        }
                      } else {
                        const err248 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err248];
                        } else {
                          vErrors.push(err248);
                        }
                        errors++;
                      }
                    }
                    if (data86.maxScore !== void 0) {
                      let data89 = data86.maxScore;
                      if (typeof data89 == "number") {
                        if (data89 <= 0 || isNaN(data89)) {
                          const err249 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                          if (vErrors === null) {
                            vErrors = [err249];
                          } else {
                            vErrors.push(err249);
                          }
                          errors++;
                        }
                      } else {
                        const err250 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                        if (vErrors === null) {
                          vErrors = [err250];
                        } else {
                          vErrors.push(err250);
                        }
                        errors++;
                      }
                    }
                    if (data86.objectiveIds !== void 0) {
                      let data90 = data86.objectiveIds;
                      if (Array.isArray(data90)) {
                        if (data90.length < 1) {
                          const err251 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                          if (vErrors === null) {
                            vErrors = [err251];
                          } else {
                            vErrors.push(err251);
                          }
                          errors++;
                        }
                        const len13 = data90.length;
                        for (let i15 = 0; i15 < len13; i15++) {
                          let data91 = data90[i15];
                          if (typeof data91 === "string") {
                            if (func2(data91) < 1) {
                              const err252 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds/" + i15, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err252];
                              } else {
                                vErrors.push(err252);
                              }
                              errors++;
                            }
                          } else {
                            const err253 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds/" + i15, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err253];
                            } else {
                              vErrors.push(err253);
                            }
                            errors++;
                          }
                        }
                        let i16 = data90.length;
                        let j2;
                        if (i16 > 1) {
                          const indices2 = {};
                          for (; i16--; ) {
                            let item2 = data90[i16];
                            if (typeof item2 !== "string") {
                              continue;
                            }
                            if (typeof indices2[item2] == "number") {
                              j2 = indices2[item2];
                              const err254 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i16, j: j2 }, message: "must NOT have duplicate items (items ## " + j2 + " and " + i16 + " are identical)" };
                              if (vErrors === null) {
                                vErrors = [err254];
                              } else {
                                vErrors.push(err254);
                              }
                              errors++;
                              break;
                            }
                            indices2[item2] = i16;
                          }
                        }
                      } else {
                        const err255 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err255];
                        } else {
                          vErrors.push(err255);
                        }
                        errors++;
                      }
                    }
                    if (data86.sourceRefs !== void 0) {
                      let data92 = data86.sourceRefs;
                      if (Array.isArray(data92)) {
                        const len14 = data92.length;
                        for (let i17 = 0; i17 < len14; i17++) {
                          let data93 = data92[i17];
                          if (data93 && typeof data93 == "object" && !Array.isArray(data93)) {
                            if (data93.sourceId === void 0) {
                              const err256 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i17, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
                              if (vErrors === null) {
                                vErrors = [err256];
                              } else {
                                vErrors.push(err256);
                              }
                              errors++;
                            }
                            if (data93.sourceRevision === void 0) {
                              const err257 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i17, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
                              if (vErrors === null) {
                                vErrors = [err257];
                              } else {
                                vErrors.push(err257);
                              }
                              errors++;
                            }
                            if (data93.chunkId === void 0) {
                              const err258 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i17, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "chunkId" }, message: "must have required property 'chunkId'" };
                              if (vErrors === null) {
                                vErrors = [err258];
                              } else {
                                vErrors.push(err258);
                              }
                              errors++;
                            }
                            for (const key22 in data93) {
                              if (!(key22 === "sourceId" || key22 === "sourceRevision" || key22 === "chunkId")) {
                                const err259 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i17, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key22 }, message: "must NOT have additional properties" };
                                if (vErrors === null) {
                                  vErrors = [err259];
                                } else {
                                  vErrors.push(err259);
                                }
                                errors++;
                              }
                            }
                            if (data93.sourceId !== void 0) {
                              let data94 = data93.sourceId;
                              if (typeof data94 === "string") {
                                if (func2(data94) < 1) {
                                  const err260 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i17 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err260];
                                  } else {
                                    vErrors.push(err260);
                                  }
                                  errors++;
                                }
                              } else {
                                const err261 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i17 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err261];
                                } else {
                                  vErrors.push(err261);
                                }
                                errors++;
                              }
                            }
                            if (data93.sourceRevision !== void 0) {
                              let data95 = data93.sourceRevision;
                              if (!(typeof data95 == "number" && (!(data95 % 1) && !isNaN(data95)))) {
                                const err262 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i17 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                if (vErrors === null) {
                                  vErrors = [err262];
                                } else {
                                  vErrors.push(err262);
                                }
                                errors++;
                              }
                              if (typeof data95 == "number") {
                                if (data95 < 1 || isNaN(data95)) {
                                  const err263 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i17 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                                  if (vErrors === null) {
                                    vErrors = [err263];
                                  } else {
                                    vErrors.push(err263);
                                  }
                                  errors++;
                                }
                              }
                            }
                            if (data93.chunkId !== void 0) {
                              let data96 = data93.chunkId;
                              if (typeof data96 === "string") {
                                if (func2(data96) < 1) {
                                  const err264 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i17 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/properties/chunkId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err264];
                                  } else {
                                    vErrors.push(err264);
                                  }
                                  errors++;
                                }
                              } else {
                                const err265 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i17 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/properties/chunkId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err265];
                                } else {
                                  vErrors.push(err265);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err266 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i17, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                            if (vErrors === null) {
                              vErrors = [err266];
                            } else {
                              vErrors.push(err266);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err267 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err267];
                        } else {
                          vErrors.push(err267);
                        }
                        errors++;
                      }
                    }
                    if (data86.hints !== void 0) {
                      let data97 = data86.hints;
                      if (Array.isArray(data97)) {
                        const len15 = data97.length;
                        for (let i18 = 0; i18 < len15; i18++) {
                          let data98 = data97[i18];
                          if (typeof data98 === "string") {
                            if (func2(data98) < 1) {
                              const err268 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints/" + i18, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err268];
                              } else {
                                vErrors.push(err268);
                              }
                              errors++;
                            }
                          } else {
                            const err269 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints/" + i18, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err269];
                            } else {
                              vErrors.push(err269);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err270 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err270];
                        } else {
                          vErrors.push(err270);
                        }
                        errors++;
                      }
                    }
                    if (data86.type !== void 0) {
                      if ("singleChoice" !== data86.type) {
                        const err271 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/type", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/type/const", keyword: "const", params: { allowedValue: "singleChoice" }, message: "must be equal to constant" };
                        if (vErrors === null) {
                          vErrors = [err271];
                        } else {
                          vErrors.push(err271);
                        }
                        errors++;
                      }
                    }
                    if (data86.options !== void 0) {
                      let data100 = data86.options;
                      if (Array.isArray(data100)) {
                        if (data100.length < 2) {
                          const err272 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/minItems", keyword: "minItems", params: { limit: 2 }, message: "must NOT have fewer than 2 items" };
                          if (vErrors === null) {
                            vErrors = [err272];
                          } else {
                            vErrors.push(err272);
                          }
                          errors++;
                        }
                        const len16 = data100.length;
                        for (let i19 = 0; i19 < len16; i19++) {
                          let data101 = data100[i19];
                          if (data101 && typeof data101 == "object" && !Array.isArray(data101)) {
                            if (data101.id === void 0) {
                              const err273 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options/" + i19, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                              if (vErrors === null) {
                                vErrors = [err273];
                              } else {
                                vErrors.push(err273);
                              }
                              errors++;
                            }
                            if (data101.text === void 0) {
                              const err274 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options/" + i19, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/items/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
                              if (vErrors === null) {
                                vErrors = [err274];
                              } else {
                                vErrors.push(err274);
                              }
                              errors++;
                            }
                            for (const key23 in data101) {
                              if (!(key23 === "id" || key23 === "text")) {
                                const err275 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options/" + i19, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key23 }, message: "must NOT have additional properties" };
                                if (vErrors === null) {
                                  vErrors = [err275];
                                } else {
                                  vErrors.push(err275);
                                }
                                errors++;
                              }
                            }
                            if (data101.id !== void 0) {
                              let data102 = data101.id;
                              if (typeof data102 === "string") {
                                if (func2(data102) < 1) {
                                  const err276 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options/" + i19 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err276];
                                  } else {
                                    vErrors.push(err276);
                                  }
                                  errors++;
                                }
                              } else {
                                const err277 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options/" + i19 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err277];
                                } else {
                                  vErrors.push(err277);
                                }
                                errors++;
                              }
                            }
                            if (data101.text !== void 0) {
                              let data103 = data101.text;
                              if (typeof data103 === "string") {
                                if (func2(data103) < 1) {
                                  const err278 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options/" + i19 + "/text", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/items/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err278];
                                  } else {
                                    vErrors.push(err278);
                                  }
                                  errors++;
                                }
                              } else {
                                const err279 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options/" + i19 + "/text", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/items/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err279];
                                } else {
                                  vErrors.push(err279);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err280 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options/" + i19, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                            if (vErrors === null) {
                              vErrors = [err280];
                            } else {
                              vErrors.push(err280);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err281 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err281];
                        } else {
                          vErrors.push(err281);
                        }
                        errors++;
                      }
                    }
                    if (data86.answerKey !== void 0) {
                      let data104 = data86.answerKey;
                      if (typeof data104 === "string") {
                        if (func2(data104) < 1) {
                          const err282 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/answerKey", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/answerKey/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err282];
                          } else {
                            vErrors.push(err282);
                          }
                          errors++;
                        }
                      } else {
                        const err283 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/answerKey", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/answerKey/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err283];
                        } else {
                          vErrors.push(err283);
                        }
                        errors++;
                      }
                    }
                    if (data86.scoring !== void 0) {
                      if ("exactMatch" !== data86.scoring) {
                        const err284 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/scoring", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/scoring/const", keyword: "const", params: { allowedValue: "exactMatch" }, message: "must be equal to constant" };
                        if (vErrors === null) {
                          vErrors = [err284];
                        } else {
                          vErrors.push(err284);
                        }
                        errors++;
                      }
                    }
                  } else {
                    const err285 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                    if (vErrors === null) {
                      vErrors = [err285];
                    } else {
                      vErrors.push(err285);
                    }
                    errors++;
                  }
                  var _valid1 = _errs192 === errors;
                  if (_valid1) {
                    valid50 = true;
                    passing1 = 0;
                    var props1 = true;
                  }
                  const _errs233 = errors;
                  if (data86 && typeof data86 == "object" && !Array.isArray(data86)) {
                    if (data86.id === void 0) {
                      const err286 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                      if (vErrors === null) {
                        vErrors = [err286];
                      } else {
                        vErrors.push(err286);
                      }
                      errors++;
                    }
                    if (data86.prompt === void 0) {
                      const err287 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
                      if (vErrors === null) {
                        vErrors = [err287];
                      } else {
                        vErrors.push(err287);
                      }
                      errors++;
                    }
                    if (data86.maxScore === void 0) {
                      const err288 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
                      if (vErrors === null) {
                        vErrors = [err288];
                      } else {
                        vErrors.push(err288);
                      }
                      errors++;
                    }
                    if (data86.objectiveIds === void 0) {
                      const err289 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
                      if (vErrors === null) {
                        vErrors = [err289];
                      } else {
                        vErrors.push(err289);
                      }
                      errors++;
                    }
                    if (data86.sourceRefs === void 0) {
                      const err290 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "sourceRefs" }, message: "must have required property 'sourceRefs'" };
                      if (vErrors === null) {
                        vErrors = [err290];
                      } else {
                        vErrors.push(err290);
                      }
                      errors++;
                    }
                    if (data86.hints === void 0) {
                      const err291 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
                      if (vErrors === null) {
                        vErrors = [err291];
                      } else {
                        vErrors.push(err291);
                      }
                      errors++;
                    }
                    if (data86.type === void 0) {
                      const err292 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                      if (vErrors === null) {
                        vErrors = [err292];
                      } else {
                        vErrors.push(err292);
                      }
                      errors++;
                    }
                    if (data86.answerKey === void 0) {
                      const err293 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "answerKey" }, message: "must have required property 'answerKey'" };
                      if (vErrors === null) {
                        vErrors = [err293];
                      } else {
                        vErrors.push(err293);
                      }
                      errors++;
                    }
                    if (data86.scoring === void 0) {
                      const err294 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "scoring" }, message: "must have required property 'scoring'" };
                      if (vErrors === null) {
                        vErrors = [err294];
                      } else {
                        vErrors.push(err294);
                      }
                      errors++;
                    }
                    for (const key24 in data86) {
                      if (!func1.call(schema32.properties.resources.items.properties.questions.items.oneOf[1].properties, key24)) {
                        const err295 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key24 }, message: "must NOT have additional properties" };
                        if (vErrors === null) {
                          vErrors = [err295];
                        } else {
                          vErrors.push(err295);
                        }
                        errors++;
                      }
                    }
                    if (data86.id !== void 0) {
                      let data106 = data86.id;
                      if (typeof data106 === "string") {
                        if (func2(data106) < 1) {
                          const err296 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err296];
                          } else {
                            vErrors.push(err296);
                          }
                          errors++;
                        }
                      } else {
                        const err297 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err297];
                        } else {
                          vErrors.push(err297);
                        }
                        errors++;
                      }
                    }
                    if (data86.prompt !== void 0) {
                      let data107 = data86.prompt;
                      if (typeof data107 === "string") {
                        if (func2(data107) < 1) {
                          const err298 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err298];
                          } else {
                            vErrors.push(err298);
                          }
                          errors++;
                        }
                      } else {
                        const err299 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err299];
                        } else {
                          vErrors.push(err299);
                        }
                        errors++;
                      }
                    }
                    if (data86.maxScore !== void 0) {
                      let data108 = data86.maxScore;
                      if (typeof data108 == "number") {
                        if (data108 <= 0 || isNaN(data108)) {
                          const err300 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                          if (vErrors === null) {
                            vErrors = [err300];
                          } else {
                            vErrors.push(err300);
                          }
                          errors++;
                        }
                      } else {
                        const err301 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                        if (vErrors === null) {
                          vErrors = [err301];
                        } else {
                          vErrors.push(err301);
                        }
                        errors++;
                      }
                    }
                    if (data86.objectiveIds !== void 0) {
                      let data109 = data86.objectiveIds;
                      if (Array.isArray(data109)) {
                        if (data109.length < 1) {
                          const err302 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                          if (vErrors === null) {
                            vErrors = [err302];
                          } else {
                            vErrors.push(err302);
                          }
                          errors++;
                        }
                        const len17 = data109.length;
                        for (let i20 = 0; i20 < len17; i20++) {
                          let data110 = data109[i20];
                          if (typeof data110 === "string") {
                            if (func2(data110) < 1) {
                              const err303 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds/" + i20, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err303];
                              } else {
                                vErrors.push(err303);
                              }
                              errors++;
                            }
                          } else {
                            const err304 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds/" + i20, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err304];
                            } else {
                              vErrors.push(err304);
                            }
                            errors++;
                          }
                        }
                        let i21 = data109.length;
                        let j3;
                        if (i21 > 1) {
                          const indices3 = {};
                          for (; i21--; ) {
                            let item3 = data109[i21];
                            if (typeof item3 !== "string") {
                              continue;
                            }
                            if (typeof indices3[item3] == "number") {
                              j3 = indices3[item3];
                              const err305 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i21, j: j3 }, message: "must NOT have duplicate items (items ## " + j3 + " and " + i21 + " are identical)" };
                              if (vErrors === null) {
                                vErrors = [err305];
                              } else {
                                vErrors.push(err305);
                              }
                              errors++;
                              break;
                            }
                            indices3[item3] = i21;
                          }
                        }
                      } else {
                        const err306 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err306];
                        } else {
                          vErrors.push(err306);
                        }
                        errors++;
                      }
                    }
                    if (data86.sourceRefs !== void 0) {
                      let data111 = data86.sourceRefs;
                      if (Array.isArray(data111)) {
                        const len18 = data111.length;
                        for (let i22 = 0; i22 < len18; i22++) {
                          let data112 = data111[i22];
                          if (data112 && typeof data112 == "object" && !Array.isArray(data112)) {
                            if (data112.sourceId === void 0) {
                              const err307 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i22, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
                              if (vErrors === null) {
                                vErrors = [err307];
                              } else {
                                vErrors.push(err307);
                              }
                              errors++;
                            }
                            if (data112.sourceRevision === void 0) {
                              const err308 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i22, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
                              if (vErrors === null) {
                                vErrors = [err308];
                              } else {
                                vErrors.push(err308);
                              }
                              errors++;
                            }
                            if (data112.chunkId === void 0) {
                              const err309 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i22, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "chunkId" }, message: "must have required property 'chunkId'" };
                              if (vErrors === null) {
                                vErrors = [err309];
                              } else {
                                vErrors.push(err309);
                              }
                              errors++;
                            }
                            for (const key25 in data112) {
                              if (!(key25 === "sourceId" || key25 === "sourceRevision" || key25 === "chunkId")) {
                                const err310 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i22, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key25 }, message: "must NOT have additional properties" };
                                if (vErrors === null) {
                                  vErrors = [err310];
                                } else {
                                  vErrors.push(err310);
                                }
                                errors++;
                              }
                            }
                            if (data112.sourceId !== void 0) {
                              let data113 = data112.sourceId;
                              if (typeof data113 === "string") {
                                if (func2(data113) < 1) {
                                  const err311 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i22 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err311];
                                  } else {
                                    vErrors.push(err311);
                                  }
                                  errors++;
                                }
                              } else {
                                const err312 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i22 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err312];
                                } else {
                                  vErrors.push(err312);
                                }
                                errors++;
                              }
                            }
                            if (data112.sourceRevision !== void 0) {
                              let data114 = data112.sourceRevision;
                              if (!(typeof data114 == "number" && (!(data114 % 1) && !isNaN(data114)))) {
                                const err313 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i22 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                if (vErrors === null) {
                                  vErrors = [err313];
                                } else {
                                  vErrors.push(err313);
                                }
                                errors++;
                              }
                              if (typeof data114 == "number") {
                                if (data114 < 1 || isNaN(data114)) {
                                  const err314 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i22 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                                  if (vErrors === null) {
                                    vErrors = [err314];
                                  } else {
                                    vErrors.push(err314);
                                  }
                                  errors++;
                                }
                              }
                            }
                            if (data112.chunkId !== void 0) {
                              let data115 = data112.chunkId;
                              if (typeof data115 === "string") {
                                if (func2(data115) < 1) {
                                  const err315 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i22 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/properties/chunkId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err315];
                                  } else {
                                    vErrors.push(err315);
                                  }
                                  errors++;
                                }
                              } else {
                                const err316 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i22 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/properties/chunkId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err316];
                                } else {
                                  vErrors.push(err316);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err317 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i22, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                            if (vErrors === null) {
                              vErrors = [err317];
                            } else {
                              vErrors.push(err317);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err318 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err318];
                        } else {
                          vErrors.push(err318);
                        }
                        errors++;
                      }
                    }
                    if (data86.hints !== void 0) {
                      let data116 = data86.hints;
                      if (Array.isArray(data116)) {
                        const len19 = data116.length;
                        for (let i23 = 0; i23 < len19; i23++) {
                          let data117 = data116[i23];
                          if (typeof data117 === "string") {
                            if (func2(data117) < 1) {
                              const err319 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints/" + i23, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err319];
                              } else {
                                vErrors.push(err319);
                              }
                              errors++;
                            }
                          } else {
                            const err320 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints/" + i23, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err320];
                            } else {
                              vErrors.push(err320);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err321 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err321];
                        } else {
                          vErrors.push(err321);
                        }
                        errors++;
                      }
                    }
                    if (data86.type !== void 0) {
                      if ("trueFalse" !== data86.type) {
                        const err322 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/type", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/type/const", keyword: "const", params: { allowedValue: "trueFalse" }, message: "must be equal to constant" };
                        if (vErrors === null) {
                          vErrors = [err322];
                        } else {
                          vErrors.push(err322);
                        }
                        errors++;
                      }
                    }
                    if (data86.answerKey !== void 0) {
                      if (typeof data86.answerKey !== "boolean") {
                        const err323 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/answerKey", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/answerKey/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" };
                        if (vErrors === null) {
                          vErrors = [err323];
                        } else {
                          vErrors.push(err323);
                        }
                        errors++;
                      }
                    }
                    if (data86.scoring !== void 0) {
                      if ("exactMatch" !== data86.scoring) {
                        const err324 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/scoring", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/scoring/const", keyword: "const", params: { allowedValue: "exactMatch" }, message: "must be equal to constant" };
                        if (vErrors === null) {
                          vErrors = [err324];
                        } else {
                          vErrors.push(err324);
                        }
                        errors++;
                      }
                    }
                  } else {
                    const err325 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                    if (vErrors === null) {
                      vErrors = [err325];
                    } else {
                      vErrors.push(err325);
                    }
                    errors++;
                  }
                  var _valid1 = _errs233 === errors;
                  if (_valid1 && valid50) {
                    valid50 = false;
                    passing1 = [passing1, 1];
                  } else {
                    if (_valid1) {
                      valid50 = true;
                      passing1 = 1;
                      if (props1 !== true) {
                        props1 = true;
                      }
                    }
                    const _errs265 = errors;
                    if (data86 && typeof data86 == "object" && !Array.isArray(data86)) {
                      if (data86.id === void 0) {
                        const err326 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                        if (vErrors === null) {
                          vErrors = [err326];
                        } else {
                          vErrors.push(err326);
                        }
                        errors++;
                      }
                      if (data86.prompt === void 0) {
                        const err327 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
                        if (vErrors === null) {
                          vErrors = [err327];
                        } else {
                          vErrors.push(err327);
                        }
                        errors++;
                      }
                      if (data86.maxScore === void 0) {
                        const err328 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
                        if (vErrors === null) {
                          vErrors = [err328];
                        } else {
                          vErrors.push(err328);
                        }
                        errors++;
                      }
                      if (data86.objectiveIds === void 0) {
                        const err329 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
                        if (vErrors === null) {
                          vErrors = [err329];
                        } else {
                          vErrors.push(err329);
                        }
                        errors++;
                      }
                      if (data86.sourceRefs === void 0) {
                        const err330 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "sourceRefs" }, message: "must have required property 'sourceRefs'" };
                        if (vErrors === null) {
                          vErrors = [err330];
                        } else {
                          vErrors.push(err330);
                        }
                        errors++;
                      }
                      if (data86.hints === void 0) {
                        const err331 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
                        if (vErrors === null) {
                          vErrors = [err331];
                        } else {
                          vErrors.push(err331);
                        }
                        errors++;
                      }
                      if (data86.type === void 0) {
                        const err332 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                        if (vErrors === null) {
                          vErrors = [err332];
                        } else {
                          vErrors.push(err332);
                        }
                        errors++;
                      }
                      if (data86.rubric === void 0) {
                        const err333 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "rubric" }, message: "must have required property 'rubric'" };
                        if (vErrors === null) {
                          vErrors = [err333];
                        } else {
                          vErrors.push(err333);
                        }
                        errors++;
                      }
                      if (data86.scoring === void 0) {
                        const err334 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "scoring" }, message: "must have required property 'scoring'" };
                        if (vErrors === null) {
                          vErrors = [err334];
                        } else {
                          vErrors.push(err334);
                        }
                        errors++;
                      }
                      for (const key26 in data86) {
                        if (!func1.call(schema32.properties.resources.items.properties.questions.items.oneOf[2].properties, key26)) {
                          const err335 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key26 }, message: "must NOT have additional properties" };
                          if (vErrors === null) {
                            vErrors = [err335];
                          } else {
                            vErrors.push(err335);
                          }
                          errors++;
                        }
                      }
                      if (data86.id !== void 0) {
                        let data121 = data86.id;
                        if (typeof data121 === "string") {
                          if (func2(data121) < 1) {
                            const err336 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                            if (vErrors === null) {
                              vErrors = [err336];
                            } else {
                              vErrors.push(err336);
                            }
                            errors++;
                          }
                        } else {
                          const err337 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                          if (vErrors === null) {
                            vErrors = [err337];
                          } else {
                            vErrors.push(err337);
                          }
                          errors++;
                        }
                      }
                      if (data86.prompt !== void 0) {
                        let data122 = data86.prompt;
                        if (typeof data122 === "string") {
                          if (func2(data122) < 1) {
                            const err338 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                            if (vErrors === null) {
                              vErrors = [err338];
                            } else {
                              vErrors.push(err338);
                            }
                            errors++;
                          }
                        } else {
                          const err339 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                          if (vErrors === null) {
                            vErrors = [err339];
                          } else {
                            vErrors.push(err339);
                          }
                          errors++;
                        }
                      }
                      if (data86.maxScore !== void 0) {
                        let data123 = data86.maxScore;
                        if (typeof data123 == "number") {
                          if (data123 <= 0 || isNaN(data123)) {
                            const err340 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                            if (vErrors === null) {
                              vErrors = [err340];
                            } else {
                              vErrors.push(err340);
                            }
                            errors++;
                          }
                        } else {
                          const err341 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                          if (vErrors === null) {
                            vErrors = [err341];
                          } else {
                            vErrors.push(err341);
                          }
                          errors++;
                        }
                      }
                      if (data86.objectiveIds !== void 0) {
                        let data124 = data86.objectiveIds;
                        if (Array.isArray(data124)) {
                          if (data124.length < 1) {
                            const err342 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                            if (vErrors === null) {
                              vErrors = [err342];
                            } else {
                              vErrors.push(err342);
                            }
                            errors++;
                          }
                          const len20 = data124.length;
                          for (let i24 = 0; i24 < len20; i24++) {
                            let data125 = data124[i24];
                            if (typeof data125 === "string") {
                              if (func2(data125) < 1) {
                                const err343 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds/" + i24, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                if (vErrors === null) {
                                  vErrors = [err343];
                                } else {
                                  vErrors.push(err343);
                                }
                                errors++;
                              }
                            } else {
                              const err344 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds/" + i24, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err344];
                              } else {
                                vErrors.push(err344);
                              }
                              errors++;
                            }
                          }
                          let i25 = data124.length;
                          let j4;
                          if (i25 > 1) {
                            const indices4 = {};
                            for (; i25--; ) {
                              let item4 = data124[i25];
                              if (typeof item4 !== "string") {
                                continue;
                              }
                              if (typeof indices4[item4] == "number") {
                                j4 = indices4[item4];
                                const err345 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i25, j: j4 }, message: "must NOT have duplicate items (items ## " + j4 + " and " + i25 + " are identical)" };
                                if (vErrors === null) {
                                  vErrors = [err345];
                                } else {
                                  vErrors.push(err345);
                                }
                                errors++;
                                break;
                              }
                              indices4[item4] = i25;
                            }
                          }
                        } else {
                          const err346 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                          if (vErrors === null) {
                            vErrors = [err346];
                          } else {
                            vErrors.push(err346);
                          }
                          errors++;
                        }
                      }
                      if (data86.sourceRefs !== void 0) {
                        let data126 = data86.sourceRefs;
                        if (Array.isArray(data126)) {
                          const len21 = data126.length;
                          for (let i26 = 0; i26 < len21; i26++) {
                            let data127 = data126[i26];
                            if (data127 && typeof data127 == "object" && !Array.isArray(data127)) {
                              if (data127.sourceId === void 0) {
                                const err347 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i26, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
                                if (vErrors === null) {
                                  vErrors = [err347];
                                } else {
                                  vErrors.push(err347);
                                }
                                errors++;
                              }
                              if (data127.sourceRevision === void 0) {
                                const err348 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i26, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
                                if (vErrors === null) {
                                  vErrors = [err348];
                                } else {
                                  vErrors.push(err348);
                                }
                                errors++;
                              }
                              if (data127.chunkId === void 0) {
                                const err349 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i26, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "chunkId" }, message: "must have required property 'chunkId'" };
                                if (vErrors === null) {
                                  vErrors = [err349];
                                } else {
                                  vErrors.push(err349);
                                }
                                errors++;
                              }
                              for (const key27 in data127) {
                                if (!(key27 === "sourceId" || key27 === "sourceRevision" || key27 === "chunkId")) {
                                  const err350 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i26, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key27 }, message: "must NOT have additional properties" };
                                  if (vErrors === null) {
                                    vErrors = [err350];
                                  } else {
                                    vErrors.push(err350);
                                  }
                                  errors++;
                                }
                              }
                              if (data127.sourceId !== void 0) {
                                let data128 = data127.sourceId;
                                if (typeof data128 === "string") {
                                  if (func2(data128) < 1) {
                                    const err351 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i26 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err351];
                                    } else {
                                      vErrors.push(err351);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err352 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i26 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err352];
                                  } else {
                                    vErrors.push(err352);
                                  }
                                  errors++;
                                }
                              }
                              if (data127.sourceRevision !== void 0) {
                                let data129 = data127.sourceRevision;
                                if (!(typeof data129 == "number" && (!(data129 % 1) && !isNaN(data129)))) {
                                  const err353 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i26 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                  if (vErrors === null) {
                                    vErrors = [err353];
                                  } else {
                                    vErrors.push(err353);
                                  }
                                  errors++;
                                }
                                if (typeof data129 == "number") {
                                  if (data129 < 1 || isNaN(data129)) {
                                    const err354 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i26 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                                    if (vErrors === null) {
                                      vErrors = [err354];
                                    } else {
                                      vErrors.push(err354);
                                    }
                                    errors++;
                                  }
                                }
                              }
                              if (data127.chunkId !== void 0) {
                                let data130 = data127.chunkId;
                                if (typeof data130 === "string") {
                                  if (func2(data130) < 1) {
                                    const err355 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i26 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/properties/chunkId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err355];
                                    } else {
                                      vErrors.push(err355);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err356 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i26 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/properties/chunkId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err356];
                                  } else {
                                    vErrors.push(err356);
                                  }
                                  errors++;
                                }
                              }
                            } else {
                              const err357 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i26, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                              if (vErrors === null) {
                                vErrors = [err357];
                              } else {
                                vErrors.push(err357);
                              }
                              errors++;
                            }
                          }
                        } else {
                          const err358 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                          if (vErrors === null) {
                            vErrors = [err358];
                          } else {
                            vErrors.push(err358);
                          }
                          errors++;
                        }
                      }
                      if (data86.hints !== void 0) {
                        let data131 = data86.hints;
                        if (Array.isArray(data131)) {
                          const len22 = data131.length;
                          for (let i27 = 0; i27 < len22; i27++) {
                            let data132 = data131[i27];
                            if (typeof data132 === "string") {
                              if (func2(data132) < 1) {
                                const err359 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints/" + i27, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                if (vErrors === null) {
                                  vErrors = [err359];
                                } else {
                                  vErrors.push(err359);
                                }
                                errors++;
                              }
                            } else {
                              const err360 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints/" + i27, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err360];
                              } else {
                                vErrors.push(err360);
                              }
                              errors++;
                            }
                          }
                        } else {
                          const err361 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                          if (vErrors === null) {
                            vErrors = [err361];
                          } else {
                            vErrors.push(err361);
                          }
                          errors++;
                        }
                      }
                      if (data86.type !== void 0) {
                        if ("shortAnswer" !== data86.type) {
                          const err362 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/type", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/type/const", keyword: "const", params: { allowedValue: "shortAnswer" }, message: "must be equal to constant" };
                          if (vErrors === null) {
                            vErrors = [err362];
                          } else {
                            vErrors.push(err362);
                          }
                          errors++;
                        }
                      }
                      if (data86.rubric !== void 0) {
                        let data134 = data86.rubric;
                        if (typeof data134 === "string") {
                          if (func2(data134) < 1) {
                            const err363 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/rubric", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/rubric/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                            if (vErrors === null) {
                              vErrors = [err363];
                            } else {
                              vErrors.push(err363);
                            }
                            errors++;
                          }
                        } else {
                          const err364 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/rubric", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/rubric/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                          if (vErrors === null) {
                            vErrors = [err364];
                          } else {
                            vErrors.push(err364);
                          }
                          errors++;
                        }
                      }
                      if (data86.scoring !== void 0) {
                        if ("manual" !== data86.scoring) {
                          const err365 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/scoring", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/scoring/const", keyword: "const", params: { allowedValue: "manual" }, message: "must be equal to constant" };
                          if (vErrors === null) {
                            vErrors = [err365];
                          } else {
                            vErrors.push(err365);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err366 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err366];
                      } else {
                        vErrors.push(err366);
                      }
                      errors++;
                    }
                    var _valid1 = _errs265 === errors;
                    if (_valid1 && valid50) {
                      valid50 = false;
                      passing1 = [passing1, 2];
                    } else {
                      if (_valid1) {
                        valid50 = true;
                        passing1 = 2;
                        if (props1 !== true) {
                          props1 = true;
                        }
                      }
                      const _errs297 = errors;
                      if (data86 && typeof data86 == "object" && !Array.isArray(data86)) {
                        if (data86.id === void 0) {
                          const err367 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                          if (vErrors === null) {
                            vErrors = [err367];
                          } else {
                            vErrors.push(err367);
                          }
                          errors++;
                        }
                        if (data86.prompt === void 0) {
                          const err368 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
                          if (vErrors === null) {
                            vErrors = [err368];
                          } else {
                            vErrors.push(err368);
                          }
                          errors++;
                        }
                        if (data86.maxScore === void 0) {
                          const err369 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
                          if (vErrors === null) {
                            vErrors = [err369];
                          } else {
                            vErrors.push(err369);
                          }
                          errors++;
                        }
                        if (data86.objectiveIds === void 0) {
                          const err370 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
                          if (vErrors === null) {
                            vErrors = [err370];
                          } else {
                            vErrors.push(err370);
                          }
                          errors++;
                        }
                        if (data86.sourceRefs === void 0) {
                          const err371 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/required", keyword: "required", params: { missingProperty: "sourceRefs" }, message: "must have required property 'sourceRefs'" };
                          if (vErrors === null) {
                            vErrors = [err371];
                          } else {
                            vErrors.push(err371);
                          }
                          errors++;
                        }
                        if (data86.hints === void 0) {
                          const err372 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
                          if (vErrors === null) {
                            vErrors = [err372];
                          } else {
                            vErrors.push(err372);
                          }
                          errors++;
                        }
                        if (data86.type === void 0) {
                          const err373 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                          if (vErrors === null) {
                            vErrors = [err373];
                          } else {
                            vErrors.push(err373);
                          }
                          errors++;
                        }
                        if (data86.options === void 0) {
                          const err374 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/required", keyword: "required", params: { missingProperty: "options" }, message: "must have required property 'options'" };
                          if (vErrors === null) {
                            vErrors = [err374];
                          } else {
                            vErrors.push(err374);
                          }
                          errors++;
                        }
                        if (data86.answerKey === void 0) {
                          const err375 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/required", keyword: "required", params: { missingProperty: "answerKey" }, message: "must have required property 'answerKey'" };
                          if (vErrors === null) {
                            vErrors = [err375];
                          } else {
                            vErrors.push(err375);
                          }
                          errors++;
                        }
                        if (data86.scoring === void 0) {
                          const err376 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/required", keyword: "required", params: { missingProperty: "scoring" }, message: "must have required property 'scoring'" };
                          if (vErrors === null) {
                            vErrors = [err376];
                          } else {
                            vErrors.push(err376);
                          }
                          errors++;
                        }
                        for (const key28 in data86) {
                          if (!func1.call(schema32.properties.resources.items.properties.questions.items.oneOf[3].properties, key28)) {
                            const err377 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key28 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err377];
                            } else {
                              vErrors.push(err377);
                            }
                            errors++;
                          }
                        }
                        if (data86.id !== void 0) {
                          let data136 = data86.id;
                          if (typeof data136 === "string") {
                            if (func2(data136) < 1) {
                              const err378 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err378];
                              } else {
                                vErrors.push(err378);
                              }
                              errors++;
                            }
                          } else {
                            const err379 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err379];
                            } else {
                              vErrors.push(err379);
                            }
                            errors++;
                          }
                        }
                        if (data86.prompt !== void 0) {
                          let data137 = data86.prompt;
                          if (typeof data137 === "string") {
                            if (func2(data137) < 1) {
                              const err380 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err380];
                              } else {
                                vErrors.push(err380);
                              }
                              errors++;
                            }
                          } else {
                            const err381 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err381];
                            } else {
                              vErrors.push(err381);
                            }
                            errors++;
                          }
                        }
                        if (data86.maxScore !== void 0) {
                          let data138 = data86.maxScore;
                          if (typeof data138 == "number") {
                            if (data138 <= 0 || isNaN(data138)) {
                              const err382 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                              if (vErrors === null) {
                                vErrors = [err382];
                              } else {
                                vErrors.push(err382);
                              }
                              errors++;
                            }
                          } else {
                            const err383 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                            if (vErrors === null) {
                              vErrors = [err383];
                            } else {
                              vErrors.push(err383);
                            }
                            errors++;
                          }
                        }
                        if (data86.objectiveIds !== void 0) {
                          let data139 = data86.objectiveIds;
                          if (Array.isArray(data139)) {
                            if (data139.length < 1) {
                              const err384 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                              if (vErrors === null) {
                                vErrors = [err384];
                              } else {
                                vErrors.push(err384);
                              }
                              errors++;
                            }
                            const len23 = data139.length;
                            for (let i28 = 0; i28 < len23; i28++) {
                              let data140 = data139[i28];
                              if (typeof data140 === "string") {
                                if (func2(data140) < 1) {
                                  const err385 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds/" + i28, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err385];
                                  } else {
                                    vErrors.push(err385);
                                  }
                                  errors++;
                                }
                              } else {
                                const err386 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds/" + i28, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err386];
                                } else {
                                  vErrors.push(err386);
                                }
                                errors++;
                              }
                            }
                            let i29 = data139.length;
                            let j5;
                            if (i29 > 1) {
                              const indices5 = {};
                              for (; i29--; ) {
                                let item5 = data139[i29];
                                if (typeof item5 !== "string") {
                                  continue;
                                }
                                if (typeof indices5[item5] == "number") {
                                  j5 = indices5[item5];
                                  const err387 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i29, j: j5 }, message: "must NOT have duplicate items (items ## " + j5 + " and " + i29 + " are identical)" };
                                  if (vErrors === null) {
                                    vErrors = [err387];
                                  } else {
                                    vErrors.push(err387);
                                  }
                                  errors++;
                                  break;
                                }
                                indices5[item5] = i29;
                              }
                            }
                          } else {
                            const err388 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                            if (vErrors === null) {
                              vErrors = [err388];
                            } else {
                              vErrors.push(err388);
                            }
                            errors++;
                          }
                        }
                        if (data86.sourceRefs !== void 0) {
                          let data141 = data86.sourceRefs;
                          if (Array.isArray(data141)) {
                            const len24 = data141.length;
                            for (let i30 = 0; i30 < len24; i30++) {
                              let data142 = data141[i30];
                              if (data142 && typeof data142 == "object" && !Array.isArray(data142)) {
                                if (data142.sourceId === void 0) {
                                  const err389 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i30, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
                                  if (vErrors === null) {
                                    vErrors = [err389];
                                  } else {
                                    vErrors.push(err389);
                                  }
                                  errors++;
                                }
                                if (data142.sourceRevision === void 0) {
                                  const err390 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i30, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
                                  if (vErrors === null) {
                                    vErrors = [err390];
                                  } else {
                                    vErrors.push(err390);
                                  }
                                  errors++;
                                }
                                if (data142.chunkId === void 0) {
                                  const err391 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i30, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "chunkId" }, message: "must have required property 'chunkId'" };
                                  if (vErrors === null) {
                                    vErrors = [err391];
                                  } else {
                                    vErrors.push(err391);
                                  }
                                  errors++;
                                }
                                for (const key29 in data142) {
                                  if (!(key29 === "sourceId" || key29 === "sourceRevision" || key29 === "chunkId")) {
                                    const err392 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i30, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/sourceRefs/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key29 }, message: "must NOT have additional properties" };
                                    if (vErrors === null) {
                                      vErrors = [err392];
                                    } else {
                                      vErrors.push(err392);
                                    }
                                    errors++;
                                  }
                                }
                                if (data142.sourceId !== void 0) {
                                  let data143 = data142.sourceId;
                                  if (typeof data143 === "string") {
                                    if (func2(data143) < 1) {
                                      const err393 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i30 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/sourceRefs/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err393];
                                      } else {
                                        vErrors.push(err393);
                                      }
                                      errors++;
                                    }
                                  } else {
                                    const err394 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i30 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/sourceRefs/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err394];
                                    } else {
                                      vErrors.push(err394);
                                    }
                                    errors++;
                                  }
                                }
                                if (data142.sourceRevision !== void 0) {
                                  let data144 = data142.sourceRevision;
                                  if (!(typeof data144 == "number" && (!(data144 % 1) && !isNaN(data144)))) {
                                    const err395 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i30 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/sourceRefs/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                    if (vErrors === null) {
                                      vErrors = [err395];
                                    } else {
                                      vErrors.push(err395);
                                    }
                                    errors++;
                                  }
                                  if (typeof data144 == "number") {
                                    if (data144 < 1 || isNaN(data144)) {
                                      const err396 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i30 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/sourceRefs/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                                      if (vErrors === null) {
                                        vErrors = [err396];
                                      } else {
                                        vErrors.push(err396);
                                      }
                                      errors++;
                                    }
                                  }
                                }
                                if (data142.chunkId !== void 0) {
                                  let data145 = data142.chunkId;
                                  if (typeof data145 === "string") {
                                    if (func2(data145) < 1) {
                                      const err397 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i30 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/sourceRefs/items/properties/chunkId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err397];
                                      } else {
                                        vErrors.push(err397);
                                      }
                                      errors++;
                                    }
                                  } else {
                                    const err398 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i30 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/sourceRefs/items/properties/chunkId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err398];
                                    } else {
                                      vErrors.push(err398);
                                    }
                                    errors++;
                                  }
                                }
                              } else {
                                const err399 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i30, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/sourceRefs/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                if (vErrors === null) {
                                  vErrors = [err399];
                                } else {
                                  vErrors.push(err399);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err400 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/sourceRefs/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                            if (vErrors === null) {
                              vErrors = [err400];
                            } else {
                              vErrors.push(err400);
                            }
                            errors++;
                          }
                        }
                        if (data86.hints !== void 0) {
                          let data146 = data86.hints;
                          if (Array.isArray(data146)) {
                            const len25 = data146.length;
                            for (let i31 = 0; i31 < len25; i31++) {
                              let data147 = data146[i31];
                              if (typeof data147 === "string") {
                                if (func2(data147) < 1) {
                                  const err401 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints/" + i31, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err401];
                                  } else {
                                    vErrors.push(err401);
                                  }
                                  errors++;
                                }
                              } else {
                                const err402 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints/" + i31, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err402];
                                } else {
                                  vErrors.push(err402);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err403 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                            if (vErrors === null) {
                              vErrors = [err403];
                            } else {
                              vErrors.push(err403);
                            }
                            errors++;
                          }
                        }
                        if (data86.type !== void 0) {
                          if ("multipleChoice" !== data86.type) {
                            const err404 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/type", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/type/const", keyword: "const", params: { allowedValue: "multipleChoice" }, message: "must be equal to constant" };
                            if (vErrors === null) {
                              vErrors = [err404];
                            } else {
                              vErrors.push(err404);
                            }
                            errors++;
                          }
                        }
                        if (data86.options !== void 0) {
                          let data149 = data86.options;
                          if (Array.isArray(data149)) {
                            if (data149.length < 2) {
                              const err405 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/options/minItems", keyword: "minItems", params: { limit: 2 }, message: "must NOT have fewer than 2 items" };
                              if (vErrors === null) {
                                vErrors = [err405];
                              } else {
                                vErrors.push(err405);
                              }
                              errors++;
                            }
                            const len26 = data149.length;
                            for (let i32 = 0; i32 < len26; i32++) {
                              let data150 = data149[i32];
                              if (data150 && typeof data150 == "object" && !Array.isArray(data150)) {
                                if (data150.id === void 0) {
                                  const err406 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options/" + i32, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/options/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                                  if (vErrors === null) {
                                    vErrors = [err406];
                                  } else {
                                    vErrors.push(err406);
                                  }
                                  errors++;
                                }
                                if (data150.text === void 0) {
                                  const err407 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options/" + i32, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/options/items/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
                                  if (vErrors === null) {
                                    vErrors = [err407];
                                  } else {
                                    vErrors.push(err407);
                                  }
                                  errors++;
                                }
                                for (const key30 in data150) {
                                  if (!(key30 === "id" || key30 === "text")) {
                                    const err408 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options/" + i32, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/options/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key30 }, message: "must NOT have additional properties" };
                                    if (vErrors === null) {
                                      vErrors = [err408];
                                    } else {
                                      vErrors.push(err408);
                                    }
                                    errors++;
                                  }
                                }
                                if (data150.id !== void 0) {
                                  let data151 = data150.id;
                                  if (typeof data151 === "string") {
                                    if (func2(data151) < 1) {
                                      const err409 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options/" + i32 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/options/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err409];
                                      } else {
                                        vErrors.push(err409);
                                      }
                                      errors++;
                                    }
                                  } else {
                                    const err410 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options/" + i32 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/options/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err410];
                                    } else {
                                      vErrors.push(err410);
                                    }
                                    errors++;
                                  }
                                }
                                if (data150.text !== void 0) {
                                  let data152 = data150.text;
                                  if (typeof data152 === "string") {
                                    if (func2(data152) < 1) {
                                      const err411 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options/" + i32 + "/text", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/options/items/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err411];
                                      } else {
                                        vErrors.push(err411);
                                      }
                                      errors++;
                                    }
                                  } else {
                                    const err412 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options/" + i32 + "/text", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/options/items/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err412];
                                    } else {
                                      vErrors.push(err412);
                                    }
                                    errors++;
                                  }
                                }
                              } else {
                                const err413 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options/" + i32, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/options/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                if (vErrors === null) {
                                  vErrors = [err413];
                                } else {
                                  vErrors.push(err413);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err414 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/options", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/options/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                            if (vErrors === null) {
                              vErrors = [err414];
                            } else {
                              vErrors.push(err414);
                            }
                            errors++;
                          }
                        }
                        if (data86.answerKey !== void 0) {
                          let data153 = data86.answerKey;
                          if (Array.isArray(data153)) {
                            if (data153.length > 30) {
                              const err415 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/answerKey", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/answerKey/maxItems", keyword: "maxItems", params: { limit: 30 }, message: "must NOT have more than 30 items" };
                              if (vErrors === null) {
                                vErrors = [err415];
                              } else {
                                vErrors.push(err415);
                              }
                              errors++;
                            }
                            if (data153.length < 1) {
                              const err416 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/answerKey", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/answerKey/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                              if (vErrors === null) {
                                vErrors = [err416];
                              } else {
                                vErrors.push(err416);
                              }
                              errors++;
                            }
                            const len27 = data153.length;
                            for (let i33 = 0; i33 < len27; i33++) {
                              let data154 = data153[i33];
                              if (typeof data154 === "string") {
                                if (func2(data154) < 1) {
                                  const err417 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/answerKey/" + i33, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/answerKey/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err417];
                                  } else {
                                    vErrors.push(err417);
                                  }
                                  errors++;
                                }
                              } else {
                                const err418 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/answerKey/" + i33, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/answerKey/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err418];
                                } else {
                                  vErrors.push(err418);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err419 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/answerKey", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/answerKey/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                            if (vErrors === null) {
                              vErrors = [err419];
                            } else {
                              vErrors.push(err419);
                            }
                            errors++;
                          }
                        }
                        if (data86.scoring !== void 0) {
                          if ("exactMatch" !== data86.scoring) {
                            const err420 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/scoring", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/properties/scoring/const", keyword: "const", params: { allowedValue: "exactMatch" }, message: "must be equal to constant" };
                            if (vErrors === null) {
                              vErrors = [err420];
                            } else {
                              vErrors.push(err420);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err421 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/3/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                        if (vErrors === null) {
                          vErrors = [err421];
                        } else {
                          vErrors.push(err421);
                        }
                        errors++;
                      }
                      var _valid1 = _errs297 === errors;
                      if (_valid1 && valid50) {
                        valid50 = false;
                        passing1 = [passing1, 3];
                      } else {
                        if (_valid1) {
                          valid50 = true;
                          passing1 = 3;
                          if (props1 !== true) {
                            props1 = true;
                          }
                        }
                        const _errs340 = errors;
                        if (data86 && typeof data86 == "object" && !Array.isArray(data86)) {
                          if (data86.id === void 0) {
                            const err422 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                            if (vErrors === null) {
                              vErrors = [err422];
                            } else {
                              vErrors.push(err422);
                            }
                            errors++;
                          }
                          if (data86.prompt === void 0) {
                            const err423 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
                            if (vErrors === null) {
                              vErrors = [err423];
                            } else {
                              vErrors.push(err423);
                            }
                            errors++;
                          }
                          if (data86.maxScore === void 0) {
                            const err424 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
                            if (vErrors === null) {
                              vErrors = [err424];
                            } else {
                              vErrors.push(err424);
                            }
                            errors++;
                          }
                          if (data86.objectiveIds === void 0) {
                            const err425 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
                            if (vErrors === null) {
                              vErrors = [err425];
                            } else {
                              vErrors.push(err425);
                            }
                            errors++;
                          }
                          if (data86.sourceRefs === void 0) {
                            const err426 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/required", keyword: "required", params: { missingProperty: "sourceRefs" }, message: "must have required property 'sourceRefs'" };
                            if (vErrors === null) {
                              vErrors = [err426];
                            } else {
                              vErrors.push(err426);
                            }
                            errors++;
                          }
                          if (data86.hints === void 0) {
                            const err427 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
                            if (vErrors === null) {
                              vErrors = [err427];
                            } else {
                              vErrors.push(err427);
                            }
                            errors++;
                          }
                          if (data86.type === void 0) {
                            const err428 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                            if (vErrors === null) {
                              vErrors = [err428];
                            } else {
                              vErrors.push(err428);
                            }
                            errors++;
                          }
                          if (data86.blanks === void 0) {
                            const err429 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/required", keyword: "required", params: { missingProperty: "blanks" }, message: "must have required property 'blanks'" };
                            if (vErrors === null) {
                              vErrors = [err429];
                            } else {
                              vErrors.push(err429);
                            }
                            errors++;
                          }
                          if (data86.scoring === void 0) {
                            const err430 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/required", keyword: "required", params: { missingProperty: "scoring" }, message: "must have required property 'scoring'" };
                            if (vErrors === null) {
                              vErrors = [err430];
                            } else {
                              vErrors.push(err430);
                            }
                            errors++;
                          }
                          for (const key31 in data86) {
                            if (!func1.call(schema32.properties.resources.items.properties.questions.items.oneOf[4].properties, key31)) {
                              const err431 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key31 }, message: "must NOT have additional properties" };
                              if (vErrors === null) {
                                vErrors = [err431];
                              } else {
                                vErrors.push(err431);
                              }
                              errors++;
                            }
                          }
                          if (data86.id !== void 0) {
                            let data156 = data86.id;
                            if (typeof data156 === "string") {
                              if (func2(data156) < 1) {
                                const err432 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                if (vErrors === null) {
                                  vErrors = [err432];
                                } else {
                                  vErrors.push(err432);
                                }
                                errors++;
                              }
                            } else {
                              const err433 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err433];
                              } else {
                                vErrors.push(err433);
                              }
                              errors++;
                            }
                          }
                          if (data86.prompt !== void 0) {
                            let data157 = data86.prompt;
                            if (typeof data157 === "string") {
                              if (func2(data157) < 1) {
                                const err434 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                if (vErrors === null) {
                                  vErrors = [err434];
                                } else {
                                  vErrors.push(err434);
                                }
                                errors++;
                              }
                            } else {
                              const err435 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err435];
                              } else {
                                vErrors.push(err435);
                              }
                              errors++;
                            }
                          }
                          if (data86.maxScore !== void 0) {
                            let data158 = data86.maxScore;
                            if (typeof data158 == "number") {
                              if (data158 <= 0 || isNaN(data158)) {
                                const err436 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                                if (vErrors === null) {
                                  vErrors = [err436];
                                } else {
                                  vErrors.push(err436);
                                }
                                errors++;
                              }
                            } else {
                              const err437 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                              if (vErrors === null) {
                                vErrors = [err437];
                              } else {
                                vErrors.push(err437);
                              }
                              errors++;
                            }
                          }
                          if (data86.objectiveIds !== void 0) {
                            let data159 = data86.objectiveIds;
                            if (Array.isArray(data159)) {
                              if (data159.length < 1) {
                                const err438 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                                if (vErrors === null) {
                                  vErrors = [err438];
                                } else {
                                  vErrors.push(err438);
                                }
                                errors++;
                              }
                              const len28 = data159.length;
                              for (let i34 = 0; i34 < len28; i34++) {
                                let data160 = data159[i34];
                                if (typeof data160 === "string") {
                                  if (func2(data160) < 1) {
                                    const err439 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds/" + i34, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err439];
                                    } else {
                                      vErrors.push(err439);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err440 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds/" + i34, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err440];
                                  } else {
                                    vErrors.push(err440);
                                  }
                                  errors++;
                                }
                              }
                              let i35 = data159.length;
                              let j6;
                              if (i35 > 1) {
                                const indices6 = {};
                                for (; i35--; ) {
                                  let item6 = data159[i35];
                                  if (typeof item6 !== "string") {
                                    continue;
                                  }
                                  if (typeof indices6[item6] == "number") {
                                    j6 = indices6[item6];
                                    const err441 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i35, j: j6 }, message: "must NOT have duplicate items (items ## " + j6 + " and " + i35 + " are identical)" };
                                    if (vErrors === null) {
                                      vErrors = [err441];
                                    } else {
                                      vErrors.push(err441);
                                    }
                                    errors++;
                                    break;
                                  }
                                  indices6[item6] = i35;
                                }
                              }
                            } else {
                              const err442 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                              if (vErrors === null) {
                                vErrors = [err442];
                              } else {
                                vErrors.push(err442);
                              }
                              errors++;
                            }
                          }
                          if (data86.sourceRefs !== void 0) {
                            let data161 = data86.sourceRefs;
                            if (Array.isArray(data161)) {
                              const len29 = data161.length;
                              for (let i36 = 0; i36 < len29; i36++) {
                                let data162 = data161[i36];
                                if (data162 && typeof data162 == "object" && !Array.isArray(data162)) {
                                  if (data162.sourceId === void 0) {
                                    const err443 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i36, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
                                    if (vErrors === null) {
                                      vErrors = [err443];
                                    } else {
                                      vErrors.push(err443);
                                    }
                                    errors++;
                                  }
                                  if (data162.sourceRevision === void 0) {
                                    const err444 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i36, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
                                    if (vErrors === null) {
                                      vErrors = [err444];
                                    } else {
                                      vErrors.push(err444);
                                    }
                                    errors++;
                                  }
                                  if (data162.chunkId === void 0) {
                                    const err445 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i36, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "chunkId" }, message: "must have required property 'chunkId'" };
                                    if (vErrors === null) {
                                      vErrors = [err445];
                                    } else {
                                      vErrors.push(err445);
                                    }
                                    errors++;
                                  }
                                  for (const key32 in data162) {
                                    if (!(key32 === "sourceId" || key32 === "sourceRevision" || key32 === "chunkId")) {
                                      const err446 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i36, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/sourceRefs/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key32 }, message: "must NOT have additional properties" };
                                      if (vErrors === null) {
                                        vErrors = [err446];
                                      } else {
                                        vErrors.push(err446);
                                      }
                                      errors++;
                                    }
                                  }
                                  if (data162.sourceId !== void 0) {
                                    let data163 = data162.sourceId;
                                    if (typeof data163 === "string") {
                                      if (func2(data163) < 1) {
                                        const err447 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i36 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/sourceRefs/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err447];
                                        } else {
                                          vErrors.push(err447);
                                        }
                                        errors++;
                                      }
                                    } else {
                                      const err448 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i36 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/sourceRefs/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                      if (vErrors === null) {
                                        vErrors = [err448];
                                      } else {
                                        vErrors.push(err448);
                                      }
                                      errors++;
                                    }
                                  }
                                  if (data162.sourceRevision !== void 0) {
                                    let data164 = data162.sourceRevision;
                                    if (!(typeof data164 == "number" && (!(data164 % 1) && !isNaN(data164)))) {
                                      const err449 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i36 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/sourceRefs/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                      if (vErrors === null) {
                                        vErrors = [err449];
                                      } else {
                                        vErrors.push(err449);
                                      }
                                      errors++;
                                    }
                                    if (typeof data164 == "number") {
                                      if (data164 < 1 || isNaN(data164)) {
                                        const err450 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i36 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/sourceRefs/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                                        if (vErrors === null) {
                                          vErrors = [err450];
                                        } else {
                                          vErrors.push(err450);
                                        }
                                        errors++;
                                      }
                                    }
                                  }
                                  if (data162.chunkId !== void 0) {
                                    let data165 = data162.chunkId;
                                    if (typeof data165 === "string") {
                                      if (func2(data165) < 1) {
                                        const err451 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i36 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/sourceRefs/items/properties/chunkId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err451];
                                        } else {
                                          vErrors.push(err451);
                                        }
                                        errors++;
                                      }
                                    } else {
                                      const err452 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i36 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/sourceRefs/items/properties/chunkId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                      if (vErrors === null) {
                                        vErrors = [err452];
                                      } else {
                                        vErrors.push(err452);
                                      }
                                      errors++;
                                    }
                                  }
                                } else {
                                  const err453 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i36, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/sourceRefs/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                  if (vErrors === null) {
                                    vErrors = [err453];
                                  } else {
                                    vErrors.push(err453);
                                  }
                                  errors++;
                                }
                              }
                            } else {
                              const err454 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/sourceRefs/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                              if (vErrors === null) {
                                vErrors = [err454];
                              } else {
                                vErrors.push(err454);
                              }
                              errors++;
                            }
                          }
                          if (data86.hints !== void 0) {
                            let data166 = data86.hints;
                            if (Array.isArray(data166)) {
                              const len30 = data166.length;
                              for (let i37 = 0; i37 < len30; i37++) {
                                let data167 = data166[i37];
                                if (typeof data167 === "string") {
                                  if (func2(data167) < 1) {
                                    const err455 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints/" + i37, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err455];
                                    } else {
                                      vErrors.push(err455);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err456 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints/" + i37, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err456];
                                  } else {
                                    vErrors.push(err456);
                                  }
                                  errors++;
                                }
                              }
                            } else {
                              const err457 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                              if (vErrors === null) {
                                vErrors = [err457];
                              } else {
                                vErrors.push(err457);
                              }
                              errors++;
                            }
                          }
                          if (data86.type !== void 0) {
                            if ("fillBlank" !== data86.type) {
                              const err458 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/type", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/type/const", keyword: "const", params: { allowedValue: "fillBlank" }, message: "must be equal to constant" };
                              if (vErrors === null) {
                                vErrors = [err458];
                              } else {
                                vErrors.push(err458);
                              }
                              errors++;
                            }
                          }
                          if (data86.blanks !== void 0) {
                            let data169 = data86.blanks;
                            if (Array.isArray(data169)) {
                              if (data169.length > 30) {
                                const err459 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/blanks", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/blanks/maxItems", keyword: "maxItems", params: { limit: 30 }, message: "must NOT have more than 30 items" };
                                if (vErrors === null) {
                                  vErrors = [err459];
                                } else {
                                  vErrors.push(err459);
                                }
                                errors++;
                              }
                              if (data169.length < 1) {
                                const err460 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/blanks", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/blanks/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                                if (vErrors === null) {
                                  vErrors = [err460];
                                } else {
                                  vErrors.push(err460);
                                }
                                errors++;
                              }
                              const len31 = data169.length;
                              for (let i38 = 0; i38 < len31; i38++) {
                                let data170 = data169[i38];
                                if (data170 && typeof data170 == "object" && !Array.isArray(data170)) {
                                  if (data170.id === void 0) {
                                    const err461 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/blanks/" + i38, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/blanks/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                                    if (vErrors === null) {
                                      vErrors = [err461];
                                    } else {
                                      vErrors.push(err461);
                                    }
                                    errors++;
                                  }
                                  if (data170.label === void 0) {
                                    const err462 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/blanks/" + i38, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/blanks/items/required", keyword: "required", params: { missingProperty: "label" }, message: "must have required property 'label'" };
                                    if (vErrors === null) {
                                      vErrors = [err462];
                                    } else {
                                      vErrors.push(err462);
                                    }
                                    errors++;
                                  }
                                  if (data170.answers === void 0) {
                                    const err463 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/blanks/" + i38, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/blanks/items/required", keyword: "required", params: { missingProperty: "answers" }, message: "must have required property 'answers'" };
                                    if (vErrors === null) {
                                      vErrors = [err463];
                                    } else {
                                      vErrors.push(err463);
                                    }
                                    errors++;
                                  }
                                  for (const key33 in data170) {
                                    if (!(key33 === "id" || key33 === "label" || key33 === "answers")) {
                                      const err464 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/blanks/" + i38, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/blanks/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key33 }, message: "must NOT have additional properties" };
                                      if (vErrors === null) {
                                        vErrors = [err464];
                                      } else {
                                        vErrors.push(err464);
                                      }
                                      errors++;
                                    }
                                  }
                                  if (data170.id !== void 0) {
                                    let data171 = data170.id;
                                    if (typeof data171 === "string") {
                                      if (func2(data171) < 1) {
                                        const err465 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/blanks/" + i38 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/blanks/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err465];
                                        } else {
                                          vErrors.push(err465);
                                        }
                                        errors++;
                                      }
                                    } else {
                                      const err466 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/blanks/" + i38 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/blanks/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                      if (vErrors === null) {
                                        vErrors = [err466];
                                      } else {
                                        vErrors.push(err466);
                                      }
                                      errors++;
                                    }
                                  }
                                  if (data170.label !== void 0) {
                                    let data172 = data170.label;
                                    if (typeof data172 === "string") {
                                      if (func2(data172) < 1) {
                                        const err467 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/blanks/" + i38 + "/label", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/blanks/items/properties/label/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err467];
                                        } else {
                                          vErrors.push(err467);
                                        }
                                        errors++;
                                      }
                                    } else {
                                      const err468 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/blanks/" + i38 + "/label", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/blanks/items/properties/label/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                      if (vErrors === null) {
                                        vErrors = [err468];
                                      } else {
                                        vErrors.push(err468);
                                      }
                                      errors++;
                                    }
                                  }
                                  if (data170.answers !== void 0) {
                                    let data173 = data170.answers;
                                    if (Array.isArray(data173)) {
                                      if (data173.length > 30) {
                                        const err469 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/blanks/" + i38 + "/answers", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/blanks/items/properties/answers/maxItems", keyword: "maxItems", params: { limit: 30 }, message: "must NOT have more than 30 items" };
                                        if (vErrors === null) {
                                          vErrors = [err469];
                                        } else {
                                          vErrors.push(err469);
                                        }
                                        errors++;
                                      }
                                      if (data173.length < 1) {
                                        const err470 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/blanks/" + i38 + "/answers", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/blanks/items/properties/answers/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                                        if (vErrors === null) {
                                          vErrors = [err470];
                                        } else {
                                          vErrors.push(err470);
                                        }
                                        errors++;
                                      }
                                      const len32 = data173.length;
                                      for (let i39 = 0; i39 < len32; i39++) {
                                        let data174 = data173[i39];
                                        if (typeof data174 === "string") {
                                          if (func2(data174) < 1) {
                                            const err471 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/blanks/" + i38 + "/answers/" + i39, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/blanks/items/properties/answers/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                            if (vErrors === null) {
                                              vErrors = [err471];
                                            } else {
                                              vErrors.push(err471);
                                            }
                                            errors++;
                                          }
                                        } else {
                                          const err472 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/blanks/" + i38 + "/answers/" + i39, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/blanks/items/properties/answers/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                          if (vErrors === null) {
                                            vErrors = [err472];
                                          } else {
                                            vErrors.push(err472);
                                          }
                                          errors++;
                                        }
                                      }
                                    } else {
                                      const err473 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/blanks/" + i38 + "/answers", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/blanks/items/properties/answers/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                      if (vErrors === null) {
                                        vErrors = [err473];
                                      } else {
                                        vErrors.push(err473);
                                      }
                                      errors++;
                                    }
                                  }
                                } else {
                                  const err474 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/blanks/" + i38, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/blanks/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                  if (vErrors === null) {
                                    vErrors = [err474];
                                  } else {
                                    vErrors.push(err474);
                                  }
                                  errors++;
                                }
                              }
                            } else {
                              const err475 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/blanks", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/blanks/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                              if (vErrors === null) {
                                vErrors = [err475];
                              } else {
                                vErrors.push(err475);
                              }
                              errors++;
                            }
                          }
                          if (data86.scoring !== void 0) {
                            if ("partial" !== data86.scoring) {
                              const err476 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/scoring", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/properties/scoring/const", keyword: "const", params: { allowedValue: "partial" }, message: "must be equal to constant" };
                              if (vErrors === null) {
                                vErrors = [err476];
                              } else {
                                vErrors.push(err476);
                              }
                              errors++;
                            }
                          }
                        } else {
                          const err477 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/4/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                          if (vErrors === null) {
                            vErrors = [err477];
                          } else {
                            vErrors.push(err477);
                          }
                          errors++;
                        }
                        var _valid1 = _errs340 === errors;
                        if (_valid1 && valid50) {
                          valid50 = false;
                          passing1 = [passing1, 4];
                        } else {
                          if (_valid1) {
                            valid50 = true;
                            passing1 = 4;
                            if (props1 !== true) {
                              props1 = true;
                            }
                          }
                          const _errs383 = errors;
                          if (data86 && typeof data86 == "object" && !Array.isArray(data86)) {
                            if (data86.id === void 0) {
                              const err478 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                              if (vErrors === null) {
                                vErrors = [err478];
                              } else {
                                vErrors.push(err478);
                              }
                              errors++;
                            }
                            if (data86.prompt === void 0) {
                              const err479 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
                              if (vErrors === null) {
                                vErrors = [err479];
                              } else {
                                vErrors.push(err479);
                              }
                              errors++;
                            }
                            if (data86.maxScore === void 0) {
                              const err480 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
                              if (vErrors === null) {
                                vErrors = [err480];
                              } else {
                                vErrors.push(err480);
                              }
                              errors++;
                            }
                            if (data86.objectiveIds === void 0) {
                              const err481 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
                              if (vErrors === null) {
                                vErrors = [err481];
                              } else {
                                vErrors.push(err481);
                              }
                              errors++;
                            }
                            if (data86.sourceRefs === void 0) {
                              const err482 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/required", keyword: "required", params: { missingProperty: "sourceRefs" }, message: "must have required property 'sourceRefs'" };
                              if (vErrors === null) {
                                vErrors = [err482];
                              } else {
                                vErrors.push(err482);
                              }
                              errors++;
                            }
                            if (data86.hints === void 0) {
                              const err483 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
                              if (vErrors === null) {
                                vErrors = [err483];
                              } else {
                                vErrors.push(err483);
                              }
                              errors++;
                            }
                            if (data86.type === void 0) {
                              const err484 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                              if (vErrors === null) {
                                vErrors = [err484];
                              } else {
                                vErrors.push(err484);
                              }
                              errors++;
                            }
                            if (data86.left === void 0) {
                              const err485 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/required", keyword: "required", params: { missingProperty: "left" }, message: "must have required property 'left'" };
                              if (vErrors === null) {
                                vErrors = [err485];
                              } else {
                                vErrors.push(err485);
                              }
                              errors++;
                            }
                            if (data86.right === void 0) {
                              const err486 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/required", keyword: "required", params: { missingProperty: "right" }, message: "must have required property 'right'" };
                              if (vErrors === null) {
                                vErrors = [err486];
                              } else {
                                vErrors.push(err486);
                              }
                              errors++;
                            }
                            if (data86.answerKey === void 0) {
                              const err487 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/required", keyword: "required", params: { missingProperty: "answerKey" }, message: "must have required property 'answerKey'" };
                              if (vErrors === null) {
                                vErrors = [err487];
                              } else {
                                vErrors.push(err487);
                              }
                              errors++;
                            }
                            if (data86.scoring === void 0) {
                              const err488 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/required", keyword: "required", params: { missingProperty: "scoring" }, message: "must have required property 'scoring'" };
                              if (vErrors === null) {
                                vErrors = [err488];
                              } else {
                                vErrors.push(err488);
                              }
                              errors++;
                            }
                            for (const key34 in data86) {
                              if (!func1.call(schema32.properties.resources.items.properties.questions.items.oneOf[5].properties, key34)) {
                                const err489 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key34 }, message: "must NOT have additional properties" };
                                if (vErrors === null) {
                                  vErrors = [err489];
                                } else {
                                  vErrors.push(err489);
                                }
                                errors++;
                              }
                            }
                            if (data86.id !== void 0) {
                              let data176 = data86.id;
                              if (typeof data176 === "string") {
                                if (func2(data176) < 1) {
                                  const err490 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err490];
                                  } else {
                                    vErrors.push(err490);
                                  }
                                  errors++;
                                }
                              } else {
                                const err491 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err491];
                                } else {
                                  vErrors.push(err491);
                                }
                                errors++;
                              }
                            }
                            if (data86.prompt !== void 0) {
                              let data177 = data86.prompt;
                              if (typeof data177 === "string") {
                                if (func2(data177) < 1) {
                                  const err492 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err492];
                                  } else {
                                    vErrors.push(err492);
                                  }
                                  errors++;
                                }
                              } else {
                                const err493 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err493];
                                } else {
                                  vErrors.push(err493);
                                }
                                errors++;
                              }
                            }
                            if (data86.maxScore !== void 0) {
                              let data178 = data86.maxScore;
                              if (typeof data178 == "number") {
                                if (data178 <= 0 || isNaN(data178)) {
                                  const err494 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                                  if (vErrors === null) {
                                    vErrors = [err494];
                                  } else {
                                    vErrors.push(err494);
                                  }
                                  errors++;
                                }
                              } else {
                                const err495 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                if (vErrors === null) {
                                  vErrors = [err495];
                                } else {
                                  vErrors.push(err495);
                                }
                                errors++;
                              }
                            }
                            if (data86.objectiveIds !== void 0) {
                              let data179 = data86.objectiveIds;
                              if (Array.isArray(data179)) {
                                if (data179.length < 1) {
                                  const err496 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                                  if (vErrors === null) {
                                    vErrors = [err496];
                                  } else {
                                    vErrors.push(err496);
                                  }
                                  errors++;
                                }
                                const len33 = data179.length;
                                for (let i40 = 0; i40 < len33; i40++) {
                                  let data180 = data179[i40];
                                  if (typeof data180 === "string") {
                                    if (func2(data180) < 1) {
                                      const err497 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds/" + i40, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err497];
                                      } else {
                                        vErrors.push(err497);
                                      }
                                      errors++;
                                    }
                                  } else {
                                    const err498 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds/" + i40, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err498];
                                    } else {
                                      vErrors.push(err498);
                                    }
                                    errors++;
                                  }
                                }
                                let i41 = data179.length;
                                let j7;
                                if (i41 > 1) {
                                  const indices7 = {};
                                  for (; i41--; ) {
                                    let item7 = data179[i41];
                                    if (typeof item7 !== "string") {
                                      continue;
                                    }
                                    if (typeof indices7[item7] == "number") {
                                      j7 = indices7[item7];
                                      const err499 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i41, j: j7 }, message: "must NOT have duplicate items (items ## " + j7 + " and " + i41 + " are identical)" };
                                      if (vErrors === null) {
                                        vErrors = [err499];
                                      } else {
                                        vErrors.push(err499);
                                      }
                                      errors++;
                                      break;
                                    }
                                    indices7[item7] = i41;
                                  }
                                }
                              } else {
                                const err500 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                if (vErrors === null) {
                                  vErrors = [err500];
                                } else {
                                  vErrors.push(err500);
                                }
                                errors++;
                              }
                            }
                            if (data86.sourceRefs !== void 0) {
                              let data181 = data86.sourceRefs;
                              if (Array.isArray(data181)) {
                                const len34 = data181.length;
                                for (let i42 = 0; i42 < len34; i42++) {
                                  let data182 = data181[i42];
                                  if (data182 && typeof data182 == "object" && !Array.isArray(data182)) {
                                    if (data182.sourceId === void 0) {
                                      const err501 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i42, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
                                      if (vErrors === null) {
                                        vErrors = [err501];
                                      } else {
                                        vErrors.push(err501);
                                      }
                                      errors++;
                                    }
                                    if (data182.sourceRevision === void 0) {
                                      const err502 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i42, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
                                      if (vErrors === null) {
                                        vErrors = [err502];
                                      } else {
                                        vErrors.push(err502);
                                      }
                                      errors++;
                                    }
                                    if (data182.chunkId === void 0) {
                                      const err503 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i42, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "chunkId" }, message: "must have required property 'chunkId'" };
                                      if (vErrors === null) {
                                        vErrors = [err503];
                                      } else {
                                        vErrors.push(err503);
                                      }
                                      errors++;
                                    }
                                    for (const key35 in data182) {
                                      if (!(key35 === "sourceId" || key35 === "sourceRevision" || key35 === "chunkId")) {
                                        const err504 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i42, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/sourceRefs/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key35 }, message: "must NOT have additional properties" };
                                        if (vErrors === null) {
                                          vErrors = [err504];
                                        } else {
                                          vErrors.push(err504);
                                        }
                                        errors++;
                                      }
                                    }
                                    if (data182.sourceId !== void 0) {
                                      let data183 = data182.sourceId;
                                      if (typeof data183 === "string") {
                                        if (func2(data183) < 1) {
                                          const err505 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i42 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/sourceRefs/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err505];
                                          } else {
                                            vErrors.push(err505);
                                          }
                                          errors++;
                                        }
                                      } else {
                                        const err506 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i42 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/sourceRefs/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err506];
                                        } else {
                                          vErrors.push(err506);
                                        }
                                        errors++;
                                      }
                                    }
                                    if (data182.sourceRevision !== void 0) {
                                      let data184 = data182.sourceRevision;
                                      if (!(typeof data184 == "number" && (!(data184 % 1) && !isNaN(data184)))) {
                                        const err507 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i42 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/sourceRefs/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                        if (vErrors === null) {
                                          vErrors = [err507];
                                        } else {
                                          vErrors.push(err507);
                                        }
                                        errors++;
                                      }
                                      if (typeof data184 == "number") {
                                        if (data184 < 1 || isNaN(data184)) {
                                          const err508 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i42 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/sourceRefs/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                                          if (vErrors === null) {
                                            vErrors = [err508];
                                          } else {
                                            vErrors.push(err508);
                                          }
                                          errors++;
                                        }
                                      }
                                    }
                                    if (data182.chunkId !== void 0) {
                                      let data185 = data182.chunkId;
                                      if (typeof data185 === "string") {
                                        if (func2(data185) < 1) {
                                          const err509 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i42 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/sourceRefs/items/properties/chunkId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err509];
                                          } else {
                                            vErrors.push(err509);
                                          }
                                          errors++;
                                        }
                                      } else {
                                        const err510 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i42 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/sourceRefs/items/properties/chunkId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err510];
                                        } else {
                                          vErrors.push(err510);
                                        }
                                        errors++;
                                      }
                                    }
                                  } else {
                                    const err511 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i42, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/sourceRefs/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                    if (vErrors === null) {
                                      vErrors = [err511];
                                    } else {
                                      vErrors.push(err511);
                                    }
                                    errors++;
                                  }
                                }
                              } else {
                                const err512 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/sourceRefs/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                if (vErrors === null) {
                                  vErrors = [err512];
                                } else {
                                  vErrors.push(err512);
                                }
                                errors++;
                              }
                            }
                            if (data86.hints !== void 0) {
                              let data186 = data86.hints;
                              if (Array.isArray(data186)) {
                                const len35 = data186.length;
                                for (let i43 = 0; i43 < len35; i43++) {
                                  let data187 = data186[i43];
                                  if (typeof data187 === "string") {
                                    if (func2(data187) < 1) {
                                      const err513 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints/" + i43, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err513];
                                      } else {
                                        vErrors.push(err513);
                                      }
                                      errors++;
                                    }
                                  } else {
                                    const err514 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints/" + i43, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err514];
                                    } else {
                                      vErrors.push(err514);
                                    }
                                    errors++;
                                  }
                                }
                              } else {
                                const err515 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                if (vErrors === null) {
                                  vErrors = [err515];
                                } else {
                                  vErrors.push(err515);
                                }
                                errors++;
                              }
                            }
                            if (data86.type !== void 0) {
                              if ("matching" !== data86.type) {
                                const err516 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/type", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/type/const", keyword: "const", params: { allowedValue: "matching" }, message: "must be equal to constant" };
                                if (vErrors === null) {
                                  vErrors = [err516];
                                } else {
                                  vErrors.push(err516);
                                }
                                errors++;
                              }
                            }
                            if (data86.left !== void 0) {
                              let data189 = data86.left;
                              if (Array.isArray(data189)) {
                                if (data189.length > 30) {
                                  const err517 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/left", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/left/maxItems", keyword: "maxItems", params: { limit: 30 }, message: "must NOT have more than 30 items" };
                                  if (vErrors === null) {
                                    vErrors = [err517];
                                  } else {
                                    vErrors.push(err517);
                                  }
                                  errors++;
                                }
                                if (data189.length < 1) {
                                  const err518 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/left", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/left/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                                  if (vErrors === null) {
                                    vErrors = [err518];
                                  } else {
                                    vErrors.push(err518);
                                  }
                                  errors++;
                                }
                                const len36 = data189.length;
                                for (let i44 = 0; i44 < len36; i44++) {
                                  let data190 = data189[i44];
                                  if (data190 && typeof data190 == "object" && !Array.isArray(data190)) {
                                    if (data190.id === void 0) {
                                      const err519 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/left/" + i44, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/left/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                                      if (vErrors === null) {
                                        vErrors = [err519];
                                      } else {
                                        vErrors.push(err519);
                                      }
                                      errors++;
                                    }
                                    if (data190.text === void 0) {
                                      const err520 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/left/" + i44, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/left/items/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
                                      if (vErrors === null) {
                                        vErrors = [err520];
                                      } else {
                                        vErrors.push(err520);
                                      }
                                      errors++;
                                    }
                                    for (const key36 in data190) {
                                      if (!(key36 === "id" || key36 === "text")) {
                                        const err521 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/left/" + i44, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/left/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key36 }, message: "must NOT have additional properties" };
                                        if (vErrors === null) {
                                          vErrors = [err521];
                                        } else {
                                          vErrors.push(err521);
                                        }
                                        errors++;
                                      }
                                    }
                                    if (data190.id !== void 0) {
                                      let data191 = data190.id;
                                      if (typeof data191 === "string") {
                                        if (func2(data191) < 1) {
                                          const err522 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/left/" + i44 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/left/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err522];
                                          } else {
                                            vErrors.push(err522);
                                          }
                                          errors++;
                                        }
                                      } else {
                                        const err523 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/left/" + i44 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/left/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err523];
                                        } else {
                                          vErrors.push(err523);
                                        }
                                        errors++;
                                      }
                                    }
                                    if (data190.text !== void 0) {
                                      let data192 = data190.text;
                                      if (typeof data192 === "string") {
                                        if (func2(data192) < 1) {
                                          const err524 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/left/" + i44 + "/text", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/left/items/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err524];
                                          } else {
                                            vErrors.push(err524);
                                          }
                                          errors++;
                                        }
                                      } else {
                                        const err525 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/left/" + i44 + "/text", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/left/items/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err525];
                                        } else {
                                          vErrors.push(err525);
                                        }
                                        errors++;
                                      }
                                    }
                                  } else {
                                    const err526 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/left/" + i44, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/left/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                    if (vErrors === null) {
                                      vErrors = [err526];
                                    } else {
                                      vErrors.push(err526);
                                    }
                                    errors++;
                                  }
                                }
                              } else {
                                const err527 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/left", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/left/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                if (vErrors === null) {
                                  vErrors = [err527];
                                } else {
                                  vErrors.push(err527);
                                }
                                errors++;
                              }
                            }
                            if (data86.right !== void 0) {
                              let data193 = data86.right;
                              if (Array.isArray(data193)) {
                                if (data193.length > 30) {
                                  const err528 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/right", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/right/maxItems", keyword: "maxItems", params: { limit: 30 }, message: "must NOT have more than 30 items" };
                                  if (vErrors === null) {
                                    vErrors = [err528];
                                  } else {
                                    vErrors.push(err528);
                                  }
                                  errors++;
                                }
                                if (data193.length < 1) {
                                  const err529 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/right", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/right/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                                  if (vErrors === null) {
                                    vErrors = [err529];
                                  } else {
                                    vErrors.push(err529);
                                  }
                                  errors++;
                                }
                                const len37 = data193.length;
                                for (let i45 = 0; i45 < len37; i45++) {
                                  let data194 = data193[i45];
                                  if (data194 && typeof data194 == "object" && !Array.isArray(data194)) {
                                    if (data194.id === void 0) {
                                      const err530 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/right/" + i45, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/right/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                                      if (vErrors === null) {
                                        vErrors = [err530];
                                      } else {
                                        vErrors.push(err530);
                                      }
                                      errors++;
                                    }
                                    if (data194.text === void 0) {
                                      const err531 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/right/" + i45, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/right/items/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
                                      if (vErrors === null) {
                                        vErrors = [err531];
                                      } else {
                                        vErrors.push(err531);
                                      }
                                      errors++;
                                    }
                                    for (const key37 in data194) {
                                      if (!(key37 === "id" || key37 === "text")) {
                                        const err532 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/right/" + i45, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/right/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key37 }, message: "must NOT have additional properties" };
                                        if (vErrors === null) {
                                          vErrors = [err532];
                                        } else {
                                          vErrors.push(err532);
                                        }
                                        errors++;
                                      }
                                    }
                                    if (data194.id !== void 0) {
                                      let data195 = data194.id;
                                      if (typeof data195 === "string") {
                                        if (func2(data195) < 1) {
                                          const err533 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/right/" + i45 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/right/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err533];
                                          } else {
                                            vErrors.push(err533);
                                          }
                                          errors++;
                                        }
                                      } else {
                                        const err534 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/right/" + i45 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/right/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err534];
                                        } else {
                                          vErrors.push(err534);
                                        }
                                        errors++;
                                      }
                                    }
                                    if (data194.text !== void 0) {
                                      let data196 = data194.text;
                                      if (typeof data196 === "string") {
                                        if (func2(data196) < 1) {
                                          const err535 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/right/" + i45 + "/text", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/right/items/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err535];
                                          } else {
                                            vErrors.push(err535);
                                          }
                                          errors++;
                                        }
                                      } else {
                                        const err536 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/right/" + i45 + "/text", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/right/items/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err536];
                                        } else {
                                          vErrors.push(err536);
                                        }
                                        errors++;
                                      }
                                    }
                                  } else {
                                    const err537 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/right/" + i45, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/right/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                    if (vErrors === null) {
                                      vErrors = [err537];
                                    } else {
                                      vErrors.push(err537);
                                    }
                                    errors++;
                                  }
                                }
                              } else {
                                const err538 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/right", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/right/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                if (vErrors === null) {
                                  vErrors = [err538];
                                } else {
                                  vErrors.push(err538);
                                }
                                errors++;
                              }
                            }
                            if (data86.answerKey !== void 0) {
                              let data197 = data86.answerKey;
                              if (data197 && typeof data197 == "object" && !Array.isArray(data197)) {
                                if (Object.keys(data197).length < 1) {
                                  const err539 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/answerKey", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/answerKey/minProperties", keyword: "minProperties", params: { limit: 1 }, message: "must NOT have fewer than 1 properties" };
                                  if (vErrors === null) {
                                    vErrors = [err539];
                                  } else {
                                    vErrors.push(err539);
                                  }
                                  errors++;
                                }
                                for (const key38 in data197) {
                                  let data198 = data197[key38];
                                  if (typeof data198 === "string") {
                                    if (func2(data198) < 1) {
                                      const err540 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/answerKey/" + key38.replace(/~/g, "~0").replace(/\//g, "~1"), schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/answerKey/additionalProperties/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err540];
                                      } else {
                                        vErrors.push(err540);
                                      }
                                      errors++;
                                    }
                                  } else {
                                    const err541 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/answerKey/" + key38.replace(/~/g, "~0").replace(/\//g, "~1"), schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/answerKey/additionalProperties/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err541];
                                    } else {
                                      vErrors.push(err541);
                                    }
                                    errors++;
                                  }
                                }
                              } else {
                                const err542 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/answerKey", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/answerKey/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                if (vErrors === null) {
                                  vErrors = [err542];
                                } else {
                                  vErrors.push(err542);
                                }
                                errors++;
                              }
                            }
                            if (data86.scoring !== void 0) {
                              if ("partial" !== data86.scoring) {
                                const err543 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/scoring", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/properties/scoring/const", keyword: "const", params: { allowedValue: "partial" }, message: "must be equal to constant" };
                                if (vErrors === null) {
                                  vErrors = [err543];
                                } else {
                                  vErrors.push(err543);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err544 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/5/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                            if (vErrors === null) {
                              vErrors = [err544];
                            } else {
                              vErrors.push(err544);
                            }
                            errors++;
                          }
                          var _valid1 = _errs383 === errors;
                          if (_valid1 && valid50) {
                            valid50 = false;
                            passing1 = [passing1, 5];
                          } else {
                            if (_valid1) {
                              valid50 = true;
                              passing1 = 5;
                              if (props1 !== true) {
                                props1 = true;
                              }
                            }
                            const _errs436 = errors;
                            if (data86 && typeof data86 == "object" && !Array.isArray(data86)) {
                              if (data86.id === void 0) {
                                const err545 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                                if (vErrors === null) {
                                  vErrors = [err545];
                                } else {
                                  vErrors.push(err545);
                                }
                                errors++;
                              }
                              if (data86.prompt === void 0) {
                                const err546 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
                                if (vErrors === null) {
                                  vErrors = [err546];
                                } else {
                                  vErrors.push(err546);
                                }
                                errors++;
                              }
                              if (data86.maxScore === void 0) {
                                const err547 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
                                if (vErrors === null) {
                                  vErrors = [err547];
                                } else {
                                  vErrors.push(err547);
                                }
                                errors++;
                              }
                              if (data86.objectiveIds === void 0) {
                                const err548 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
                                if (vErrors === null) {
                                  vErrors = [err548];
                                } else {
                                  vErrors.push(err548);
                                }
                                errors++;
                              }
                              if (data86.sourceRefs === void 0) {
                                const err549 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/required", keyword: "required", params: { missingProperty: "sourceRefs" }, message: "must have required property 'sourceRefs'" };
                                if (vErrors === null) {
                                  vErrors = [err549];
                                } else {
                                  vErrors.push(err549);
                                }
                                errors++;
                              }
                              if (data86.hints === void 0) {
                                const err550 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
                                if (vErrors === null) {
                                  vErrors = [err550];
                                } else {
                                  vErrors.push(err550);
                                }
                                errors++;
                              }
                              if (data86.type === void 0) {
                                const err551 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                                if (vErrors === null) {
                                  vErrors = [err551];
                                } else {
                                  vErrors.push(err551);
                                }
                                errors++;
                              }
                              if (data86.items === void 0) {
                                const err552 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/required", keyword: "required", params: { missingProperty: "items" }, message: "must have required property 'items'" };
                                if (vErrors === null) {
                                  vErrors = [err552];
                                } else {
                                  vErrors.push(err552);
                                }
                                errors++;
                              }
                              if (data86.answerKey === void 0) {
                                const err553 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/required", keyword: "required", params: { missingProperty: "answerKey" }, message: "must have required property 'answerKey'" };
                                if (vErrors === null) {
                                  vErrors = [err553];
                                } else {
                                  vErrors.push(err553);
                                }
                                errors++;
                              }
                              if (data86.scoring === void 0) {
                                const err554 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/required", keyword: "required", params: { missingProperty: "scoring" }, message: "must have required property 'scoring'" };
                                if (vErrors === null) {
                                  vErrors = [err554];
                                } else {
                                  vErrors.push(err554);
                                }
                                errors++;
                              }
                              for (const key39 in data86) {
                                if (!func1.call(schema32.properties.resources.items.properties.questions.items.oneOf[6].properties, key39)) {
                                  const err555 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key39 }, message: "must NOT have additional properties" };
                                  if (vErrors === null) {
                                    vErrors = [err555];
                                  } else {
                                    vErrors.push(err555);
                                  }
                                  errors++;
                                }
                              }
                              if (data86.id !== void 0) {
                                let data200 = data86.id;
                                if (typeof data200 === "string") {
                                  if (func2(data200) < 1) {
                                    const err556 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err556];
                                    } else {
                                      vErrors.push(err556);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err557 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err557];
                                  } else {
                                    vErrors.push(err557);
                                  }
                                  errors++;
                                }
                              }
                              if (data86.prompt !== void 0) {
                                let data201 = data86.prompt;
                                if (typeof data201 === "string") {
                                  if (func2(data201) < 1) {
                                    const err558 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err558];
                                    } else {
                                      vErrors.push(err558);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err559 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err559];
                                  } else {
                                    vErrors.push(err559);
                                  }
                                  errors++;
                                }
                              }
                              if (data86.maxScore !== void 0) {
                                let data202 = data86.maxScore;
                                if (typeof data202 == "number") {
                                  if (data202 <= 0 || isNaN(data202)) {
                                    const err560 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                                    if (vErrors === null) {
                                      vErrors = [err560];
                                    } else {
                                      vErrors.push(err560);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err561 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                  if (vErrors === null) {
                                    vErrors = [err561];
                                  } else {
                                    vErrors.push(err561);
                                  }
                                  errors++;
                                }
                              }
                              if (data86.objectiveIds !== void 0) {
                                let data203 = data86.objectiveIds;
                                if (Array.isArray(data203)) {
                                  if (data203.length < 1) {
                                    const err562 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                                    if (vErrors === null) {
                                      vErrors = [err562];
                                    } else {
                                      vErrors.push(err562);
                                    }
                                    errors++;
                                  }
                                  const len38 = data203.length;
                                  for (let i46 = 0; i46 < len38; i46++) {
                                    let data204 = data203[i46];
                                    if (typeof data204 === "string") {
                                      if (func2(data204) < 1) {
                                        const err563 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds/" + i46, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err563];
                                        } else {
                                          vErrors.push(err563);
                                        }
                                        errors++;
                                      }
                                    } else {
                                      const err564 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds/" + i46, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                      if (vErrors === null) {
                                        vErrors = [err564];
                                      } else {
                                        vErrors.push(err564);
                                      }
                                      errors++;
                                    }
                                  }
                                  let i47 = data203.length;
                                  let j8;
                                  if (i47 > 1) {
                                    const indices8 = {};
                                    for (; i47--; ) {
                                      let item8 = data203[i47];
                                      if (typeof item8 !== "string") {
                                        continue;
                                      }
                                      if (typeof indices8[item8] == "number") {
                                        j8 = indices8[item8];
                                        const err565 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i47, j: j8 }, message: "must NOT have duplicate items (items ## " + j8 + " and " + i47 + " are identical)" };
                                        if (vErrors === null) {
                                          vErrors = [err565];
                                        } else {
                                          vErrors.push(err565);
                                        }
                                        errors++;
                                        break;
                                      }
                                      indices8[item8] = i47;
                                    }
                                  }
                                } else {
                                  const err566 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                  if (vErrors === null) {
                                    vErrors = [err566];
                                  } else {
                                    vErrors.push(err566);
                                  }
                                  errors++;
                                }
                              }
                              if (data86.sourceRefs !== void 0) {
                                let data205 = data86.sourceRefs;
                                if (Array.isArray(data205)) {
                                  const len39 = data205.length;
                                  for (let i48 = 0; i48 < len39; i48++) {
                                    let data206 = data205[i48];
                                    if (data206 && typeof data206 == "object" && !Array.isArray(data206)) {
                                      if (data206.sourceId === void 0) {
                                        const err567 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i48, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
                                        if (vErrors === null) {
                                          vErrors = [err567];
                                        } else {
                                          vErrors.push(err567);
                                        }
                                        errors++;
                                      }
                                      if (data206.sourceRevision === void 0) {
                                        const err568 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i48, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
                                        if (vErrors === null) {
                                          vErrors = [err568];
                                        } else {
                                          vErrors.push(err568);
                                        }
                                        errors++;
                                      }
                                      if (data206.chunkId === void 0) {
                                        const err569 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i48, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "chunkId" }, message: "must have required property 'chunkId'" };
                                        if (vErrors === null) {
                                          vErrors = [err569];
                                        } else {
                                          vErrors.push(err569);
                                        }
                                        errors++;
                                      }
                                      for (const key40 in data206) {
                                        if (!(key40 === "sourceId" || key40 === "sourceRevision" || key40 === "chunkId")) {
                                          const err570 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i48, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/sourceRefs/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key40 }, message: "must NOT have additional properties" };
                                          if (vErrors === null) {
                                            vErrors = [err570];
                                          } else {
                                            vErrors.push(err570);
                                          }
                                          errors++;
                                        }
                                      }
                                      if (data206.sourceId !== void 0) {
                                        let data207 = data206.sourceId;
                                        if (typeof data207 === "string") {
                                          if (func2(data207) < 1) {
                                            const err571 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i48 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/sourceRefs/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                            if (vErrors === null) {
                                              vErrors = [err571];
                                            } else {
                                              vErrors.push(err571);
                                            }
                                            errors++;
                                          }
                                        } else {
                                          const err572 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i48 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/sourceRefs/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                          if (vErrors === null) {
                                            vErrors = [err572];
                                          } else {
                                            vErrors.push(err572);
                                          }
                                          errors++;
                                        }
                                      }
                                      if (data206.sourceRevision !== void 0) {
                                        let data208 = data206.sourceRevision;
                                        if (!(typeof data208 == "number" && (!(data208 % 1) && !isNaN(data208)))) {
                                          const err573 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i48 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/sourceRefs/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                          if (vErrors === null) {
                                            vErrors = [err573];
                                          } else {
                                            vErrors.push(err573);
                                          }
                                          errors++;
                                        }
                                        if (typeof data208 == "number") {
                                          if (data208 < 1 || isNaN(data208)) {
                                            const err574 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i48 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/sourceRefs/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                                            if (vErrors === null) {
                                              vErrors = [err574];
                                            } else {
                                              vErrors.push(err574);
                                            }
                                            errors++;
                                          }
                                        }
                                      }
                                      if (data206.chunkId !== void 0) {
                                        let data209 = data206.chunkId;
                                        if (typeof data209 === "string") {
                                          if (func2(data209) < 1) {
                                            const err575 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i48 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/sourceRefs/items/properties/chunkId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                            if (vErrors === null) {
                                              vErrors = [err575];
                                            } else {
                                              vErrors.push(err575);
                                            }
                                            errors++;
                                          }
                                        } else {
                                          const err576 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i48 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/sourceRefs/items/properties/chunkId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                          if (vErrors === null) {
                                            vErrors = [err576];
                                          } else {
                                            vErrors.push(err576);
                                          }
                                          errors++;
                                        }
                                      }
                                    } else {
                                      const err577 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i48, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/sourceRefs/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                      if (vErrors === null) {
                                        vErrors = [err577];
                                      } else {
                                        vErrors.push(err577);
                                      }
                                      errors++;
                                    }
                                  }
                                } else {
                                  const err578 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/sourceRefs/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                  if (vErrors === null) {
                                    vErrors = [err578];
                                  } else {
                                    vErrors.push(err578);
                                  }
                                  errors++;
                                }
                              }
                              if (data86.hints !== void 0) {
                                let data210 = data86.hints;
                                if (Array.isArray(data210)) {
                                  const len40 = data210.length;
                                  for (let i49 = 0; i49 < len40; i49++) {
                                    let data211 = data210[i49];
                                    if (typeof data211 === "string") {
                                      if (func2(data211) < 1) {
                                        const err579 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints/" + i49, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err579];
                                        } else {
                                          vErrors.push(err579);
                                        }
                                        errors++;
                                      }
                                    } else {
                                      const err580 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints/" + i49, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                      if (vErrors === null) {
                                        vErrors = [err580];
                                      } else {
                                        vErrors.push(err580);
                                      }
                                      errors++;
                                    }
                                  }
                                } else {
                                  const err581 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                  if (vErrors === null) {
                                    vErrors = [err581];
                                  } else {
                                    vErrors.push(err581);
                                  }
                                  errors++;
                                }
                              }
                              if (data86.type !== void 0) {
                                if ("ordering" !== data86.type) {
                                  const err582 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/type", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/type/const", keyword: "const", params: { allowedValue: "ordering" }, message: "must be equal to constant" };
                                  if (vErrors === null) {
                                    vErrors = [err582];
                                  } else {
                                    vErrors.push(err582);
                                  }
                                  errors++;
                                }
                              }
                              if (data86.items !== void 0) {
                                let data213 = data86.items;
                                if (Array.isArray(data213)) {
                                  if (data213.length > 30) {
                                    const err583 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/items", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/items/maxItems", keyword: "maxItems", params: { limit: 30 }, message: "must NOT have more than 30 items" };
                                    if (vErrors === null) {
                                      vErrors = [err583];
                                    } else {
                                      vErrors.push(err583);
                                    }
                                    errors++;
                                  }
                                  if (data213.length < 1) {
                                    const err584 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/items", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/items/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                                    if (vErrors === null) {
                                      vErrors = [err584];
                                    } else {
                                      vErrors.push(err584);
                                    }
                                    errors++;
                                  }
                                  const len41 = data213.length;
                                  for (let i50 = 0; i50 < len41; i50++) {
                                    let data214 = data213[i50];
                                    if (data214 && typeof data214 == "object" && !Array.isArray(data214)) {
                                      if (data214.id === void 0) {
                                        const err585 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/items/" + i50, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/items/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                                        if (vErrors === null) {
                                          vErrors = [err585];
                                        } else {
                                          vErrors.push(err585);
                                        }
                                        errors++;
                                      }
                                      if (data214.text === void 0) {
                                        const err586 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/items/" + i50, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/items/items/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
                                        if (vErrors === null) {
                                          vErrors = [err586];
                                        } else {
                                          vErrors.push(err586);
                                        }
                                        errors++;
                                      }
                                      for (const key41 in data214) {
                                        if (!(key41 === "id" || key41 === "text")) {
                                          const err587 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/items/" + i50, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/items/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key41 }, message: "must NOT have additional properties" };
                                          if (vErrors === null) {
                                            vErrors = [err587];
                                          } else {
                                            vErrors.push(err587);
                                          }
                                          errors++;
                                        }
                                      }
                                      if (data214.id !== void 0) {
                                        let data215 = data214.id;
                                        if (typeof data215 === "string") {
                                          if (func2(data215) < 1) {
                                            const err588 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/items/" + i50 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/items/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                            if (vErrors === null) {
                                              vErrors = [err588];
                                            } else {
                                              vErrors.push(err588);
                                            }
                                            errors++;
                                          }
                                        } else {
                                          const err589 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/items/" + i50 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/items/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                          if (vErrors === null) {
                                            vErrors = [err589];
                                          } else {
                                            vErrors.push(err589);
                                          }
                                          errors++;
                                        }
                                      }
                                      if (data214.text !== void 0) {
                                        let data216 = data214.text;
                                        if (typeof data216 === "string") {
                                          if (func2(data216) < 1) {
                                            const err590 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/items/" + i50 + "/text", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/items/items/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                            if (vErrors === null) {
                                              vErrors = [err590];
                                            } else {
                                              vErrors.push(err590);
                                            }
                                            errors++;
                                          }
                                        } else {
                                          const err591 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/items/" + i50 + "/text", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/items/items/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                          if (vErrors === null) {
                                            vErrors = [err591];
                                          } else {
                                            vErrors.push(err591);
                                          }
                                          errors++;
                                        }
                                      }
                                    } else {
                                      const err592 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/items/" + i50, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/items/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                      if (vErrors === null) {
                                        vErrors = [err592];
                                      } else {
                                        vErrors.push(err592);
                                      }
                                      errors++;
                                    }
                                  }
                                } else {
                                  const err593 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/items", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/items/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                  if (vErrors === null) {
                                    vErrors = [err593];
                                  } else {
                                    vErrors.push(err593);
                                  }
                                  errors++;
                                }
                              }
                              if (data86.answerKey !== void 0) {
                                let data217 = data86.answerKey;
                                if (Array.isArray(data217)) {
                                  if (data217.length > 30) {
                                    const err594 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/answerKey", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/answerKey/maxItems", keyword: "maxItems", params: { limit: 30 }, message: "must NOT have more than 30 items" };
                                    if (vErrors === null) {
                                      vErrors = [err594];
                                    } else {
                                      vErrors.push(err594);
                                    }
                                    errors++;
                                  }
                                  if (data217.length < 1) {
                                    const err595 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/answerKey", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/answerKey/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                                    if (vErrors === null) {
                                      vErrors = [err595];
                                    } else {
                                      vErrors.push(err595);
                                    }
                                    errors++;
                                  }
                                  const len42 = data217.length;
                                  for (let i51 = 0; i51 < len42; i51++) {
                                    let data218 = data217[i51];
                                    if (typeof data218 === "string") {
                                      if (func2(data218) < 1) {
                                        const err596 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/answerKey/" + i51, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/answerKey/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                        if (vErrors === null) {
                                          vErrors = [err596];
                                        } else {
                                          vErrors.push(err596);
                                        }
                                        errors++;
                                      }
                                    } else {
                                      const err597 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/answerKey/" + i51, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/answerKey/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                      if (vErrors === null) {
                                        vErrors = [err597];
                                      } else {
                                        vErrors.push(err597);
                                      }
                                      errors++;
                                    }
                                  }
                                } else {
                                  const err598 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/answerKey", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/answerKey/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                  if (vErrors === null) {
                                    vErrors = [err598];
                                  } else {
                                    vErrors.push(err598);
                                  }
                                  errors++;
                                }
                              }
                              if (data86.scoring !== void 0) {
                                if ("exactMatch" !== data86.scoring) {
                                  const err599 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/scoring", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/properties/scoring/const", keyword: "const", params: { allowedValue: "exactMatch" }, message: "must be equal to constant" };
                                  if (vErrors === null) {
                                    vErrors = [err599];
                                  } else {
                                    vErrors.push(err599);
                                  }
                                  errors++;
                                }
                              }
                            } else {
                              const err600 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/6/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                              if (vErrors === null) {
                                vErrors = [err600];
                              } else {
                                vErrors.push(err600);
                              }
                              errors++;
                            }
                            var _valid1 = _errs436 === errors;
                            if (_valid1 && valid50) {
                              valid50 = false;
                              passing1 = [passing1, 6];
                            } else {
                              if (_valid1) {
                                valid50 = true;
                                passing1 = 6;
                                if (props1 !== true) {
                                  props1 = true;
                                }
                              }
                              const _errs479 = errors;
                              if (data86 && typeof data86 == "object" && !Array.isArray(data86)) {
                                if (data86.id === void 0) {
                                  const err601 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                                  if (vErrors === null) {
                                    vErrors = [err601];
                                  } else {
                                    vErrors.push(err601);
                                  }
                                  errors++;
                                }
                                if (data86.prompt === void 0) {
                                  const err602 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
                                  if (vErrors === null) {
                                    vErrors = [err602];
                                  } else {
                                    vErrors.push(err602);
                                  }
                                  errors++;
                                }
                                if (data86.maxScore === void 0) {
                                  const err603 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
                                  if (vErrors === null) {
                                    vErrors = [err603];
                                  } else {
                                    vErrors.push(err603);
                                  }
                                  errors++;
                                }
                                if (data86.objectiveIds === void 0) {
                                  const err604 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
                                  if (vErrors === null) {
                                    vErrors = [err604];
                                  } else {
                                    vErrors.push(err604);
                                  }
                                  errors++;
                                }
                                if (data86.sourceRefs === void 0) {
                                  const err605 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/required", keyword: "required", params: { missingProperty: "sourceRefs" }, message: "must have required property 'sourceRefs'" };
                                  if (vErrors === null) {
                                    vErrors = [err605];
                                  } else {
                                    vErrors.push(err605);
                                  }
                                  errors++;
                                }
                                if (data86.hints === void 0) {
                                  const err606 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
                                  if (vErrors === null) {
                                    vErrors = [err606];
                                  } else {
                                    vErrors.push(err606);
                                  }
                                  errors++;
                                }
                                if (data86.type === void 0) {
                                  const err607 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                                  if (vErrors === null) {
                                    vErrors = [err607];
                                  } else {
                                    vErrors.push(err607);
                                  }
                                  errors++;
                                }
                                if (data86.rubric === void 0) {
                                  const err608 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/required", keyword: "required", params: { missingProperty: "rubric" }, message: "must have required property 'rubric'" };
                                  if (vErrors === null) {
                                    vErrors = [err608];
                                  } else {
                                    vErrors.push(err608);
                                  }
                                  errors++;
                                }
                                if (data86.scoring === void 0) {
                                  const err609 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/required", keyword: "required", params: { missingProperty: "scoring" }, message: "must have required property 'scoring'" };
                                  if (vErrors === null) {
                                    vErrors = [err609];
                                  } else {
                                    vErrors.push(err609);
                                  }
                                  errors++;
                                }
                                for (const key42 in data86) {
                                  if (!func1.call(schema32.properties.resources.items.properties.questions.items.oneOf[7].properties, key42)) {
                                    const err610 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key42 }, message: "must NOT have additional properties" };
                                    if (vErrors === null) {
                                      vErrors = [err610];
                                    } else {
                                      vErrors.push(err610);
                                    }
                                    errors++;
                                  }
                                }
                                if (data86.id !== void 0) {
                                  let data220 = data86.id;
                                  if (typeof data220 === "string") {
                                    if (func2(data220) < 1) {
                                      const err611 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err611];
                                      } else {
                                        vErrors.push(err611);
                                      }
                                      errors++;
                                    }
                                  } else {
                                    const err612 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err612];
                                    } else {
                                      vErrors.push(err612);
                                    }
                                    errors++;
                                  }
                                }
                                if (data86.prompt !== void 0) {
                                  let data221 = data86.prompt;
                                  if (typeof data221 === "string") {
                                    if (func2(data221) < 1) {
                                      const err613 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err613];
                                      } else {
                                        vErrors.push(err613);
                                      }
                                      errors++;
                                    }
                                  } else {
                                    const err614 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err614];
                                    } else {
                                      vErrors.push(err614);
                                    }
                                    errors++;
                                  }
                                }
                                if (data86.maxScore !== void 0) {
                                  let data222 = data86.maxScore;
                                  if (typeof data222 == "number") {
                                    if (data222 <= 0 || isNaN(data222)) {
                                      const err615 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                                      if (vErrors === null) {
                                        vErrors = [err615];
                                      } else {
                                        vErrors.push(err615);
                                      }
                                      errors++;
                                    }
                                  } else {
                                    const err616 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                                    if (vErrors === null) {
                                      vErrors = [err616];
                                    } else {
                                      vErrors.push(err616);
                                    }
                                    errors++;
                                  }
                                }
                                if (data86.objectiveIds !== void 0) {
                                  let data223 = data86.objectiveIds;
                                  if (Array.isArray(data223)) {
                                    if (data223.length < 1) {
                                      const err617 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                                      if (vErrors === null) {
                                        vErrors = [err617];
                                      } else {
                                        vErrors.push(err617);
                                      }
                                      errors++;
                                    }
                                    const len43 = data223.length;
                                    for (let i52 = 0; i52 < len43; i52++) {
                                      let data224 = data223[i52];
                                      if (typeof data224 === "string") {
                                        if (func2(data224) < 1) {
                                          const err618 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds/" + i52, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err618];
                                          } else {
                                            vErrors.push(err618);
                                          }
                                          errors++;
                                        }
                                      } else {
                                        const err619 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds/" + i52, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err619];
                                        } else {
                                          vErrors.push(err619);
                                        }
                                        errors++;
                                      }
                                    }
                                    let i53 = data223.length;
                                    let j9;
                                    if (i53 > 1) {
                                      const indices9 = {};
                                      for (; i53--; ) {
                                        let item9 = data223[i53];
                                        if (typeof item9 !== "string") {
                                          continue;
                                        }
                                        if (typeof indices9[item9] == "number") {
                                          j9 = indices9[item9];
                                          const err620 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i53, j: j9 }, message: "must NOT have duplicate items (items ## " + j9 + " and " + i53 + " are identical)" };
                                          if (vErrors === null) {
                                            vErrors = [err620];
                                          } else {
                                            vErrors.push(err620);
                                          }
                                          errors++;
                                          break;
                                        }
                                        indices9[item9] = i53;
                                      }
                                    }
                                  } else {
                                    const err621 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                    if (vErrors === null) {
                                      vErrors = [err621];
                                    } else {
                                      vErrors.push(err621);
                                    }
                                    errors++;
                                  }
                                }
                                if (data86.sourceRefs !== void 0) {
                                  let data225 = data86.sourceRefs;
                                  if (Array.isArray(data225)) {
                                    const len44 = data225.length;
                                    for (let i54 = 0; i54 < len44; i54++) {
                                      let data226 = data225[i54];
                                      if (data226 && typeof data226 == "object" && !Array.isArray(data226)) {
                                        if (data226.sourceId === void 0) {
                                          const err622 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i54, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
                                          if (vErrors === null) {
                                            vErrors = [err622];
                                          } else {
                                            vErrors.push(err622);
                                          }
                                          errors++;
                                        }
                                        if (data226.sourceRevision === void 0) {
                                          const err623 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i54, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
                                          if (vErrors === null) {
                                            vErrors = [err623];
                                          } else {
                                            vErrors.push(err623);
                                          }
                                          errors++;
                                        }
                                        if (data226.chunkId === void 0) {
                                          const err624 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i54, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "chunkId" }, message: "must have required property 'chunkId'" };
                                          if (vErrors === null) {
                                            vErrors = [err624];
                                          } else {
                                            vErrors.push(err624);
                                          }
                                          errors++;
                                        }
                                        for (const key43 in data226) {
                                          if (!(key43 === "sourceId" || key43 === "sourceRevision" || key43 === "chunkId")) {
                                            const err625 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i54, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/sourceRefs/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key43 }, message: "must NOT have additional properties" };
                                            if (vErrors === null) {
                                              vErrors = [err625];
                                            } else {
                                              vErrors.push(err625);
                                            }
                                            errors++;
                                          }
                                        }
                                        if (data226.sourceId !== void 0) {
                                          let data227 = data226.sourceId;
                                          if (typeof data227 === "string") {
                                            if (func2(data227) < 1) {
                                              const err626 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i54 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/sourceRefs/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                              if (vErrors === null) {
                                                vErrors = [err626];
                                              } else {
                                                vErrors.push(err626);
                                              }
                                              errors++;
                                            }
                                          } else {
                                            const err627 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i54 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/sourceRefs/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                            if (vErrors === null) {
                                              vErrors = [err627];
                                            } else {
                                              vErrors.push(err627);
                                            }
                                            errors++;
                                          }
                                        }
                                        if (data226.sourceRevision !== void 0) {
                                          let data228 = data226.sourceRevision;
                                          if (!(typeof data228 == "number" && (!(data228 % 1) && !isNaN(data228)))) {
                                            const err628 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i54 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/sourceRefs/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                            if (vErrors === null) {
                                              vErrors = [err628];
                                            } else {
                                              vErrors.push(err628);
                                            }
                                            errors++;
                                          }
                                          if (typeof data228 == "number") {
                                            if (data228 < 1 || isNaN(data228)) {
                                              const err629 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i54 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/sourceRefs/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                                              if (vErrors === null) {
                                                vErrors = [err629];
                                              } else {
                                                vErrors.push(err629);
                                              }
                                              errors++;
                                            }
                                          }
                                        }
                                        if (data226.chunkId !== void 0) {
                                          let data229 = data226.chunkId;
                                          if (typeof data229 === "string") {
                                            if (func2(data229) < 1) {
                                              const err630 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i54 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/sourceRefs/items/properties/chunkId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                              if (vErrors === null) {
                                                vErrors = [err630];
                                              } else {
                                                vErrors.push(err630);
                                              }
                                              errors++;
                                            }
                                          } else {
                                            const err631 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i54 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/sourceRefs/items/properties/chunkId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                            if (vErrors === null) {
                                              vErrors = [err631];
                                            } else {
                                              vErrors.push(err631);
                                            }
                                            errors++;
                                          }
                                        }
                                      } else {
                                        const err632 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs/" + i54, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/sourceRefs/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                        if (vErrors === null) {
                                          vErrors = [err632];
                                        } else {
                                          vErrors.push(err632);
                                        }
                                        errors++;
                                      }
                                    }
                                  } else {
                                    const err633 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/sourceRefs", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/sourceRefs/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                    if (vErrors === null) {
                                      vErrors = [err633];
                                    } else {
                                      vErrors.push(err633);
                                    }
                                    errors++;
                                  }
                                }
                                if (data86.hints !== void 0) {
                                  let data230 = data86.hints;
                                  if (Array.isArray(data230)) {
                                    const len45 = data230.length;
                                    for (let i55 = 0; i55 < len45; i55++) {
                                      let data231 = data230[i55];
                                      if (typeof data231 === "string") {
                                        if (func2(data231) < 1) {
                                          const err634 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints/" + i55, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                          if (vErrors === null) {
                                            vErrors = [err634];
                                          } else {
                                            vErrors.push(err634);
                                          }
                                          errors++;
                                        }
                                      } else {
                                        const err635 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints/" + i55, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                        if (vErrors === null) {
                                          vErrors = [err635];
                                        } else {
                                          vErrors.push(err635);
                                        }
                                        errors++;
                                      }
                                    }
                                  } else {
                                    const err636 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/hints", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                                    if (vErrors === null) {
                                      vErrors = [err636];
                                    } else {
                                      vErrors.push(err636);
                                    }
                                    errors++;
                                  }
                                }
                                if (data86.type !== void 0) {
                                  if ("upload" !== data86.type) {
                                    const err637 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/type", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/type/const", keyword: "const", params: { allowedValue: "upload" }, message: "must be equal to constant" };
                                    if (vErrors === null) {
                                      vErrors = [err637];
                                    } else {
                                      vErrors.push(err637);
                                    }
                                    errors++;
                                  }
                                }
                                if (data86.rubric !== void 0) {
                                  let data233 = data86.rubric;
                                  if (typeof data233 === "string") {
                                    if (func2(data233) < 1) {
                                      const err638 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/rubric", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/rubric/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                      if (vErrors === null) {
                                        vErrors = [err638];
                                      } else {
                                        vErrors.push(err638);
                                      }
                                      errors++;
                                    }
                                  } else {
                                    const err639 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/rubric", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/rubric/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                    if (vErrors === null) {
                                      vErrors = [err639];
                                    } else {
                                      vErrors.push(err639);
                                    }
                                    errors++;
                                  }
                                }
                                if (data86.scoring !== void 0) {
                                  if ("manual" !== data86.scoring) {
                                    const err640 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14 + "/scoring", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/properties/scoring/const", keyword: "const", params: { allowedValue: "manual" }, message: "must be equal to constant" };
                                    if (vErrors === null) {
                                      vErrors = [err640];
                                    } else {
                                      vErrors.push(err640);
                                    }
                                    errors++;
                                  }
                                }
                              } else {
                                const err641 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/7/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                                if (vErrors === null) {
                                  vErrors = [err641];
                                } else {
                                  vErrors.push(err641);
                                }
                                errors++;
                              }
                              var _valid1 = _errs479 === errors;
                              if (_valid1 && valid50) {
                                valid50 = false;
                                passing1 = [passing1, 7];
                              } else {
                                if (_valid1) {
                                  valid50 = true;
                                  passing1 = 7;
                                  if (props1 !== true) {
                                    props1 = true;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                  if (!valid50) {
                    const err642 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf", keyword: "oneOf", params: { passingSchemas: passing1 }, message: "must match exactly one schema in oneOf" };
                    if (vErrors === null) {
                      vErrors = [err642];
                    } else {
                      vErrors.push(err642);
                    }
                    errors++;
                  } else {
                    errors = _errs191;
                    if (vErrors !== null) {
                      if (_errs191) {
                        vErrors.length = _errs191;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                }
              } else {
                const err643 = { instancePath: instancePath + "/resources/" + i0 + "/questions", schemaPath: "#/properties/resources/items/properties/questions/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                if (vErrors === null) {
                  vErrors = [err643];
                } else {
                  vErrors.push(err643);
                }
                errors++;
              }
            }
          } else {
            const err644 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
            if (vErrors === null) {
              vErrors = [err644];
            } else {
              vErrors.push(err644);
            }
            errors++;
          }
        }
      } else {
        const err645 = { instancePath: instancePath + "/resources", schemaPath: "#/properties/resources/type", keyword: "type", params: { type: "array" }, message: "must be array" };
        if (vErrors === null) {
          vErrors = [err645];
        } else {
          vErrors.push(err645);
        }
        errors++;
      }
    }
    if (data.warnings !== void 0) {
      let data235 = data.warnings;
      if (Array.isArray(data235)) {
        const len46 = data235.length;
        for (let i56 = 0; i56 < len46; i56++) {
          let data236 = data235[i56];
          if (typeof data236 === "string") {
            if (func2(data236) < 1) {
              const err646 = { instancePath: instancePath + "/warnings/" + i56, schemaPath: "#/properties/warnings/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
              if (vErrors === null) {
                vErrors = [err646];
              } else {
                vErrors.push(err646);
              }
              errors++;
            }
          } else {
            const err647 = { instancePath: instancePath + "/warnings/" + i56, schemaPath: "#/properties/warnings/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
            if (vErrors === null) {
              vErrors = [err647];
            } else {
              vErrors.push(err647);
            }
            errors++;
          }
        }
      } else {
        const err648 = { instancePath: instancePath + "/warnings", schemaPath: "#/properties/warnings/type", keyword: "type", params: { type: "array" }, message: "must be array" };
        if (vErrors === null) {
          vErrors = [err648];
        } else {
          vErrors.push(err648);
        }
        errors++;
      }
    }
  } else {
    const err649 = { instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" };
    if (vErrors === null) {
      vErrors = [err649];
    } else {
      vErrors.push(err649);
    }
    errors++;
  }
  validate21.errors = vErrors;
  return errors === 0;
}
validate21.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var student_content = validate22;
var schema33 = { "type": "object", "properties": { "schemaVersion": { "const": "3.0.0" }, "assignmentId": { "type": "string", "minLength": 1 }, "allocationId": { "type": "string", "minLength": 1 }, "resourceVersionId": { "type": "string", "minLength": 1 }, "title": { "type": "string", "minLength": 1 }, "blocks": { "type": "array", "items": { "oneOf": [{ "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "type": { "enum": ["heading", "paragraph"] }, "data": { "type": "object", "properties": { "text": { "type": "string", "minLength": 1 } }, "required": ["text"], "additionalProperties": false }, "visibility": { "enum": ["student", "both"] } }, "required": ["id", "type", "data", "visibility"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "type": { "const": "questionSet" }, "data": { "type": "object", "properties": { "questionIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true } }, "required": ["questionIds"], "additionalProperties": false }, "visibility": { "enum": ["student", "both"] } }, "required": ["id", "type", "data", "visibility"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "type": { "const": "vocabularyList" }, "data": { "type": "object", "properties": { "entries": { "type": "array", "minItems": 1, "maxItems": 30, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "term": { "type": "string", "minLength": 1 }, "definition": { "type": "string", "minLength": 1 }, "example": { "type": "string" } }, "required": ["id", "term", "definition", "example"], "additionalProperties": false } } }, "required": ["entries"], "additionalProperties": false }, "visibility": { "enum": ["student", "both"] } }, "required": ["id", "type", "data", "visibility"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "type": { "const": "organizer" }, "data": { "type": "object", "properties": { "title": { "type": "string", "minLength": 1 }, "nodes": { "type": "array", "minItems": 1, "maxItems": 30, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "label": { "type": "string", "minLength": 1 } }, "required": ["id", "label"], "additionalProperties": false } }, "edges": { "type": "array", "maxItems": 100, "items": { "type": "object", "properties": { "from": { "type": "string", "minLength": 1 }, "to": { "type": "string", "minLength": 1 }, "label": { "type": "string" } }, "required": ["from", "to", "label"], "additionalProperties": false } } }, "required": ["title", "nodes", "edges"], "additionalProperties": false }, "visibility": { "enum": ["student", "both"] } }, "required": ["id", "type", "data", "visibility"], "additionalProperties": false }] } }, "questions": { "type": "array", "items": { "oneOf": [{ "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "singleChoice" }, "options": { "type": "array", "minItems": 2, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "text": { "type": "string", "minLength": 1 } }, "required": ["id", "text"], "additionalProperties": false } } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "hints", "type", "options"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "trueFalse" } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "hints", "type"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "shortAnswer" } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "hints", "type"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "multipleChoice" }, "options": { "type": "array", "minItems": 2, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "text": { "type": "string", "minLength": 1 } }, "required": ["id", "text"], "additionalProperties": false } } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "hints", "type", "options"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "fillBlank" }, "blanks": { "type": "array", "minItems": 1, "maxItems": 30, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "label": { "type": "string", "minLength": 1 } }, "required": ["id", "label"], "additionalProperties": false } } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "hints", "type", "blanks"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "matching" }, "left": { "type": "array", "minItems": 1, "maxItems": 30, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "text": { "type": "string", "minLength": 1 } }, "required": ["id", "text"], "additionalProperties": false } }, "right": { "type": "array", "minItems": 1, "maxItems": 30, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "text": { "type": "string", "minLength": 1 } }, "required": ["id", "text"], "additionalProperties": false } } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "hints", "type", "left", "right"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "ordering" }, "items": { "type": "array", "minItems": 1, "maxItems": 30, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "text": { "type": "string", "minLength": 1 } }, "required": ["id", "text"], "additionalProperties": false } } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "hints", "type", "items"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "upload" } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "hints", "type"], "additionalProperties": false }] } }, "releaseState": { "type": "object", "properties": { "score": { "const": false }, "answers": { "const": false }, "feedback": { "const": false } }, "required": ["score", "answers", "feedback"], "additionalProperties": false } }, "required": ["schemaVersion", "assignmentId", "allocationId", "resourceVersionId", "title", "blocks", "questions", "releaseState"], "additionalProperties": false, "$schema": "https://json-schema.org/draft/2020-12/schema", "title": "student-content" };
function validate22(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate22.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.schemaVersion === void 0) {
      const err0 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "schemaVersion" }, message: "must have required property 'schemaVersion'" };
      if (vErrors === null) {
        vErrors = [err0];
      } else {
        vErrors.push(err0);
      }
      errors++;
    }
    if (data.assignmentId === void 0) {
      const err1 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "assignmentId" }, message: "must have required property 'assignmentId'" };
      if (vErrors === null) {
        vErrors = [err1];
      } else {
        vErrors.push(err1);
      }
      errors++;
    }
    if (data.allocationId === void 0) {
      const err2 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "allocationId" }, message: "must have required property 'allocationId'" };
      if (vErrors === null) {
        vErrors = [err2];
      } else {
        vErrors.push(err2);
      }
      errors++;
    }
    if (data.resourceVersionId === void 0) {
      const err3 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "resourceVersionId" }, message: "must have required property 'resourceVersionId'" };
      if (vErrors === null) {
        vErrors = [err3];
      } else {
        vErrors.push(err3);
      }
      errors++;
    }
    if (data.title === void 0) {
      const err4 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "title" }, message: "must have required property 'title'" };
      if (vErrors === null) {
        vErrors = [err4];
      } else {
        vErrors.push(err4);
      }
      errors++;
    }
    if (data.blocks === void 0) {
      const err5 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "blocks" }, message: "must have required property 'blocks'" };
      if (vErrors === null) {
        vErrors = [err5];
      } else {
        vErrors.push(err5);
      }
      errors++;
    }
    if (data.questions === void 0) {
      const err6 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "questions" }, message: "must have required property 'questions'" };
      if (vErrors === null) {
        vErrors = [err6];
      } else {
        vErrors.push(err6);
      }
      errors++;
    }
    if (data.releaseState === void 0) {
      const err7 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "releaseState" }, message: "must have required property 'releaseState'" };
      if (vErrors === null) {
        vErrors = [err7];
      } else {
        vErrors.push(err7);
      }
      errors++;
    }
    for (const key0 in data) {
      if (!(key0 === "schemaVersion" || key0 === "assignmentId" || key0 === "allocationId" || key0 === "resourceVersionId" || key0 === "title" || key0 === "blocks" || key0 === "questions" || key0 === "releaseState")) {
        const err8 = { instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" };
        if (vErrors === null) {
          vErrors = [err8];
        } else {
          vErrors.push(err8);
        }
        errors++;
      }
    }
    if (data.schemaVersion !== void 0) {
      if ("3.0.0" !== data.schemaVersion) {
        const err9 = { instancePath: instancePath + "/schemaVersion", schemaPath: "#/properties/schemaVersion/const", keyword: "const", params: { allowedValue: "3.0.0" }, message: "must be equal to constant" };
        if (vErrors === null) {
          vErrors = [err9];
        } else {
          vErrors.push(err9);
        }
        errors++;
      }
    }
    if (data.assignmentId !== void 0) {
      let data1 = data.assignmentId;
      if (typeof data1 === "string") {
        if (func2(data1) < 1) {
          const err10 = { instancePath: instancePath + "/assignmentId", schemaPath: "#/properties/assignmentId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err10];
          } else {
            vErrors.push(err10);
          }
          errors++;
        }
      } else {
        const err11 = { instancePath: instancePath + "/assignmentId", schemaPath: "#/properties/assignmentId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err11];
        } else {
          vErrors.push(err11);
        }
        errors++;
      }
    }
    if (data.allocationId !== void 0) {
      let data2 = data.allocationId;
      if (typeof data2 === "string") {
        if (func2(data2) < 1) {
          const err12 = { instancePath: instancePath + "/allocationId", schemaPath: "#/properties/allocationId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err12];
          } else {
            vErrors.push(err12);
          }
          errors++;
        }
      } else {
        const err13 = { instancePath: instancePath + "/allocationId", schemaPath: "#/properties/allocationId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err13];
        } else {
          vErrors.push(err13);
        }
        errors++;
      }
    }
    if (data.resourceVersionId !== void 0) {
      let data3 = data.resourceVersionId;
      if (typeof data3 === "string") {
        if (func2(data3) < 1) {
          const err14 = { instancePath: instancePath + "/resourceVersionId", schemaPath: "#/properties/resourceVersionId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err14];
          } else {
            vErrors.push(err14);
          }
          errors++;
        }
      } else {
        const err15 = { instancePath: instancePath + "/resourceVersionId", schemaPath: "#/properties/resourceVersionId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err15];
        } else {
          vErrors.push(err15);
        }
        errors++;
      }
    }
    if (data.title !== void 0) {
      let data4 = data.title;
      if (typeof data4 === "string") {
        if (func2(data4) < 1) {
          const err16 = { instancePath: instancePath + "/title", schemaPath: "#/properties/title/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err16];
          } else {
            vErrors.push(err16);
          }
          errors++;
        }
      } else {
        const err17 = { instancePath: instancePath + "/title", schemaPath: "#/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err17];
        } else {
          vErrors.push(err17);
        }
        errors++;
      }
    }
    if (data.blocks !== void 0) {
      let data5 = data.blocks;
      if (Array.isArray(data5)) {
        const len0 = data5.length;
        for (let i0 = 0; i0 < len0; i0++) {
          let data6 = data5[i0];
          const _errs14 = errors;
          let valid3 = false;
          let passing0 = null;
          const _errs15 = errors;
          if (data6 && typeof data6 == "object" && !Array.isArray(data6)) {
            if (data6.id === void 0) {
              const err18 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/0/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
              if (vErrors === null) {
                vErrors = [err18];
              } else {
                vErrors.push(err18);
              }
              errors++;
            }
            if (data6.type === void 0) {
              const err19 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/0/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
              if (vErrors === null) {
                vErrors = [err19];
              } else {
                vErrors.push(err19);
              }
              errors++;
            }
            if (data6.data === void 0) {
              const err20 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/0/required", keyword: "required", params: { missingProperty: "data" }, message: "must have required property 'data'" };
              if (vErrors === null) {
                vErrors = [err20];
              } else {
                vErrors.push(err20);
              }
              errors++;
            }
            if (data6.visibility === void 0) {
              const err21 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/0/required", keyword: "required", params: { missingProperty: "visibility" }, message: "must have required property 'visibility'" };
              if (vErrors === null) {
                vErrors = [err21];
              } else {
                vErrors.push(err21);
              }
              errors++;
            }
            for (const key1 in data6) {
              if (!(key1 === "id" || key1 === "type" || key1 === "data" || key1 === "visibility")) {
                const err22 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/0/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" };
                if (vErrors === null) {
                  vErrors = [err22];
                } else {
                  vErrors.push(err22);
                }
                errors++;
              }
            }
            if (data6.id !== void 0) {
              let data7 = data6.id;
              if (typeof data7 === "string") {
                if (func2(data7) < 1) {
                  const err23 = { instancePath: instancePath + "/blocks/" + i0 + "/id", schemaPath: "#/properties/blocks/items/oneOf/0/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err23];
                  } else {
                    vErrors.push(err23);
                  }
                  errors++;
                }
              } else {
                const err24 = { instancePath: instancePath + "/blocks/" + i0 + "/id", schemaPath: "#/properties/blocks/items/oneOf/0/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err24];
                } else {
                  vErrors.push(err24);
                }
                errors++;
              }
            }
            if (data6.type !== void 0) {
              let data8 = data6.type;
              if (!(data8 === "heading" || data8 === "paragraph")) {
                const err25 = { instancePath: instancePath + "/blocks/" + i0 + "/type", schemaPath: "#/properties/blocks/items/oneOf/0/properties/type/enum", keyword: "enum", params: { allowedValues: schema33.properties.blocks.items.oneOf[0].properties.type.enum }, message: "must be equal to one of the allowed values" };
                if (vErrors === null) {
                  vErrors = [err25];
                } else {
                  vErrors.push(err25);
                }
                errors++;
              }
            }
            if (data6.data !== void 0) {
              let data9 = data6.data;
              if (data9 && typeof data9 == "object" && !Array.isArray(data9)) {
                if (data9.text === void 0) {
                  const err26 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/0/properties/data/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
                  if (vErrors === null) {
                    vErrors = [err26];
                  } else {
                    vErrors.push(err26);
                  }
                  errors++;
                }
                for (const key2 in data9) {
                  if (!(key2 === "text")) {
                    const err27 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/0/properties/data/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" };
                    if (vErrors === null) {
                      vErrors = [err27];
                    } else {
                      vErrors.push(err27);
                    }
                    errors++;
                  }
                }
                if (data9.text !== void 0) {
                  let data10 = data9.text;
                  if (typeof data10 === "string") {
                    if (func2(data10) < 1) {
                      const err28 = { instancePath: instancePath + "/blocks/" + i0 + "/data/text", schemaPath: "#/properties/blocks/items/oneOf/0/properties/data/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err28];
                      } else {
                        vErrors.push(err28);
                      }
                      errors++;
                    }
                  } else {
                    const err29 = { instancePath: instancePath + "/blocks/" + i0 + "/data/text", schemaPath: "#/properties/blocks/items/oneOf/0/properties/data/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err29];
                    } else {
                      vErrors.push(err29);
                    }
                    errors++;
                  }
                }
              } else {
                const err30 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/0/properties/data/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                if (vErrors === null) {
                  vErrors = [err30];
                } else {
                  vErrors.push(err30);
                }
                errors++;
              }
            }
            if (data6.visibility !== void 0) {
              let data11 = data6.visibility;
              if (!(data11 === "student" || data11 === "both")) {
                const err31 = { instancePath: instancePath + "/blocks/" + i0 + "/visibility", schemaPath: "#/properties/blocks/items/oneOf/0/properties/visibility/enum", keyword: "enum", params: { allowedValues: schema33.properties.blocks.items.oneOf[0].properties.visibility.enum }, message: "must be equal to one of the allowed values" };
                if (vErrors === null) {
                  vErrors = [err31];
                } else {
                  vErrors.push(err31);
                }
                errors++;
              }
            }
          } else {
            const err32 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/0/type", keyword: "type", params: { type: "object" }, message: "must be object" };
            if (vErrors === null) {
              vErrors = [err32];
            } else {
              vErrors.push(err32);
            }
            errors++;
          }
          var _valid0 = _errs15 === errors;
          if (_valid0) {
            valid3 = true;
            passing0 = 0;
            var props0 = true;
          }
          const _errs27 = errors;
          if (data6 && typeof data6 == "object" && !Array.isArray(data6)) {
            if (data6.id === void 0) {
              const err33 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/1/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
              if (vErrors === null) {
                vErrors = [err33];
              } else {
                vErrors.push(err33);
              }
              errors++;
            }
            if (data6.type === void 0) {
              const err34 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/1/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
              if (vErrors === null) {
                vErrors = [err34];
              } else {
                vErrors.push(err34);
              }
              errors++;
            }
            if (data6.data === void 0) {
              const err35 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/1/required", keyword: "required", params: { missingProperty: "data" }, message: "must have required property 'data'" };
              if (vErrors === null) {
                vErrors = [err35];
              } else {
                vErrors.push(err35);
              }
              errors++;
            }
            if (data6.visibility === void 0) {
              const err36 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/1/required", keyword: "required", params: { missingProperty: "visibility" }, message: "must have required property 'visibility'" };
              if (vErrors === null) {
                vErrors = [err36];
              } else {
                vErrors.push(err36);
              }
              errors++;
            }
            for (const key3 in data6) {
              if (!(key3 === "id" || key3 === "type" || key3 === "data" || key3 === "visibility")) {
                const err37 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/1/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" };
                if (vErrors === null) {
                  vErrors = [err37];
                } else {
                  vErrors.push(err37);
                }
                errors++;
              }
            }
            if (data6.id !== void 0) {
              let data12 = data6.id;
              if (typeof data12 === "string") {
                if (func2(data12) < 1) {
                  const err38 = { instancePath: instancePath + "/blocks/" + i0 + "/id", schemaPath: "#/properties/blocks/items/oneOf/1/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err38];
                  } else {
                    vErrors.push(err38);
                  }
                  errors++;
                }
              } else {
                const err39 = { instancePath: instancePath + "/blocks/" + i0 + "/id", schemaPath: "#/properties/blocks/items/oneOf/1/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err39];
                } else {
                  vErrors.push(err39);
                }
                errors++;
              }
            }
            if (data6.type !== void 0) {
              if ("questionSet" !== data6.type) {
                const err40 = { instancePath: instancePath + "/blocks/" + i0 + "/type", schemaPath: "#/properties/blocks/items/oneOf/1/properties/type/const", keyword: "const", params: { allowedValue: "questionSet" }, message: "must be equal to constant" };
                if (vErrors === null) {
                  vErrors = [err40];
                } else {
                  vErrors.push(err40);
                }
                errors++;
              }
            }
            if (data6.data !== void 0) {
              let data14 = data6.data;
              if (data14 && typeof data14 == "object" && !Array.isArray(data14)) {
                if (data14.questionIds === void 0) {
                  const err41 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/1/properties/data/required", keyword: "required", params: { missingProperty: "questionIds" }, message: "must have required property 'questionIds'" };
                  if (vErrors === null) {
                    vErrors = [err41];
                  } else {
                    vErrors.push(err41);
                  }
                  errors++;
                }
                for (const key4 in data14) {
                  if (!(key4 === "questionIds")) {
                    const err42 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/1/properties/data/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key4 }, message: "must NOT have additional properties" };
                    if (vErrors === null) {
                      vErrors = [err42];
                    } else {
                      vErrors.push(err42);
                    }
                    errors++;
                  }
                }
                if (data14.questionIds !== void 0) {
                  let data15 = data14.questionIds;
                  if (Array.isArray(data15)) {
                    if (data15.length < 1) {
                      const err43 = { instancePath: instancePath + "/blocks/" + i0 + "/data/questionIds", schemaPath: "#/properties/blocks/items/oneOf/1/properties/data/properties/questionIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                      if (vErrors === null) {
                        vErrors = [err43];
                      } else {
                        vErrors.push(err43);
                      }
                      errors++;
                    }
                    const len1 = data15.length;
                    for (let i1 = 0; i1 < len1; i1++) {
                      let data16 = data15[i1];
                      if (typeof data16 === "string") {
                        if (func2(data16) < 1) {
                          const err44 = { instancePath: instancePath + "/blocks/" + i0 + "/data/questionIds/" + i1, schemaPath: "#/properties/blocks/items/oneOf/1/properties/data/properties/questionIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err44];
                          } else {
                            vErrors.push(err44);
                          }
                          errors++;
                        }
                      } else {
                        const err45 = { instancePath: instancePath + "/blocks/" + i0 + "/data/questionIds/" + i1, schemaPath: "#/properties/blocks/items/oneOf/1/properties/data/properties/questionIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err45];
                        } else {
                          vErrors.push(err45);
                        }
                        errors++;
                      }
                    }
                    let i2 = data15.length;
                    let j0;
                    if (i2 > 1) {
                      const indices0 = {};
                      for (; i2--; ) {
                        let item0 = data15[i2];
                        if (typeof item0 !== "string") {
                          continue;
                        }
                        if (typeof indices0[item0] == "number") {
                          j0 = indices0[item0];
                          const err46 = { instancePath: instancePath + "/blocks/" + i0 + "/data/questionIds", schemaPath: "#/properties/blocks/items/oneOf/1/properties/data/properties/questionIds/uniqueItems", keyword: "uniqueItems", params: { i: i2, j: j0 }, message: "must NOT have duplicate items (items ## " + j0 + " and " + i2 + " are identical)" };
                          if (vErrors === null) {
                            vErrors = [err46];
                          } else {
                            vErrors.push(err46);
                          }
                          errors++;
                          break;
                        }
                        indices0[item0] = i2;
                      }
                    }
                  } else {
                    const err47 = { instancePath: instancePath + "/blocks/" + i0 + "/data/questionIds", schemaPath: "#/properties/blocks/items/oneOf/1/properties/data/properties/questionIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                    if (vErrors === null) {
                      vErrors = [err47];
                    } else {
                      vErrors.push(err47);
                    }
                    errors++;
                  }
                }
              } else {
                const err48 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/1/properties/data/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                if (vErrors === null) {
                  vErrors = [err48];
                } else {
                  vErrors.push(err48);
                }
                errors++;
              }
            }
            if (data6.visibility !== void 0) {
              let data17 = data6.visibility;
              if (!(data17 === "student" || data17 === "both")) {
                const err49 = { instancePath: instancePath + "/blocks/" + i0 + "/visibility", schemaPath: "#/properties/blocks/items/oneOf/1/properties/visibility/enum", keyword: "enum", params: { allowedValues: schema33.properties.blocks.items.oneOf[1].properties.visibility.enum }, message: "must be equal to one of the allowed values" };
                if (vErrors === null) {
                  vErrors = [err49];
                } else {
                  vErrors.push(err49);
                }
                errors++;
              }
            }
          } else {
            const err50 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/1/type", keyword: "type", params: { type: "object" }, message: "must be object" };
            if (vErrors === null) {
              vErrors = [err50];
            } else {
              vErrors.push(err50);
            }
            errors++;
          }
          var _valid0 = _errs27 === errors;
          if (_valid0 && valid3) {
            valid3 = false;
            passing0 = [passing0, 1];
          } else {
            if (_valid0) {
              valid3 = true;
              passing0 = 1;
              if (props0 !== true) {
                props0 = true;
              }
            }
            const _errs41 = errors;
            if (data6 && typeof data6 == "object" && !Array.isArray(data6)) {
              if (data6.id === void 0) {
                const err51 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/2/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                if (vErrors === null) {
                  vErrors = [err51];
                } else {
                  vErrors.push(err51);
                }
                errors++;
              }
              if (data6.type === void 0) {
                const err52 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/2/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                if (vErrors === null) {
                  vErrors = [err52];
                } else {
                  vErrors.push(err52);
                }
                errors++;
              }
              if (data6.data === void 0) {
                const err53 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/2/required", keyword: "required", params: { missingProperty: "data" }, message: "must have required property 'data'" };
                if (vErrors === null) {
                  vErrors = [err53];
                } else {
                  vErrors.push(err53);
                }
                errors++;
              }
              if (data6.visibility === void 0) {
                const err54 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/2/required", keyword: "required", params: { missingProperty: "visibility" }, message: "must have required property 'visibility'" };
                if (vErrors === null) {
                  vErrors = [err54];
                } else {
                  vErrors.push(err54);
                }
                errors++;
              }
              for (const key5 in data6) {
                if (!(key5 === "id" || key5 === "type" || key5 === "data" || key5 === "visibility")) {
                  const err55 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/2/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key5 }, message: "must NOT have additional properties" };
                  if (vErrors === null) {
                    vErrors = [err55];
                  } else {
                    vErrors.push(err55);
                  }
                  errors++;
                }
              }
              if (data6.id !== void 0) {
                let data18 = data6.id;
                if (typeof data18 === "string") {
                  if (func2(data18) < 1) {
                    const err56 = { instancePath: instancePath + "/blocks/" + i0 + "/id", schemaPath: "#/properties/blocks/items/oneOf/2/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                    if (vErrors === null) {
                      vErrors = [err56];
                    } else {
                      vErrors.push(err56);
                    }
                    errors++;
                  }
                } else {
                  const err57 = { instancePath: instancePath + "/blocks/" + i0 + "/id", schemaPath: "#/properties/blocks/items/oneOf/2/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err57];
                  } else {
                    vErrors.push(err57);
                  }
                  errors++;
                }
              }
              if (data6.type !== void 0) {
                if ("vocabularyList" !== data6.type) {
                  const err58 = { instancePath: instancePath + "/blocks/" + i0 + "/type", schemaPath: "#/properties/blocks/items/oneOf/2/properties/type/const", keyword: "const", params: { allowedValue: "vocabularyList" }, message: "must be equal to constant" };
                  if (vErrors === null) {
                    vErrors = [err58];
                  } else {
                    vErrors.push(err58);
                  }
                  errors++;
                }
              }
              if (data6.data !== void 0) {
                let data20 = data6.data;
                if (data20 && typeof data20 == "object" && !Array.isArray(data20)) {
                  if (data20.entries === void 0) {
                    const err59 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/2/properties/data/required", keyword: "required", params: { missingProperty: "entries" }, message: "must have required property 'entries'" };
                    if (vErrors === null) {
                      vErrors = [err59];
                    } else {
                      vErrors.push(err59);
                    }
                    errors++;
                  }
                  for (const key6 in data20) {
                    if (!(key6 === "entries")) {
                      const err60 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/2/properties/data/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key6 }, message: "must NOT have additional properties" };
                      if (vErrors === null) {
                        vErrors = [err60];
                      } else {
                        vErrors.push(err60);
                      }
                      errors++;
                    }
                  }
                  if (data20.entries !== void 0) {
                    let data21 = data20.entries;
                    if (Array.isArray(data21)) {
                      if (data21.length > 30) {
                        const err61 = { instancePath: instancePath + "/blocks/" + i0 + "/data/entries", schemaPath: "#/properties/blocks/items/oneOf/2/properties/data/properties/entries/maxItems", keyword: "maxItems", params: { limit: 30 }, message: "must NOT have more than 30 items" };
                        if (vErrors === null) {
                          vErrors = [err61];
                        } else {
                          vErrors.push(err61);
                        }
                        errors++;
                      }
                      if (data21.length < 1) {
                        const err62 = { instancePath: instancePath + "/blocks/" + i0 + "/data/entries", schemaPath: "#/properties/blocks/items/oneOf/2/properties/data/properties/entries/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                        if (vErrors === null) {
                          vErrors = [err62];
                        } else {
                          vErrors.push(err62);
                        }
                        errors++;
                      }
                      const len2 = data21.length;
                      for (let i3 = 0; i3 < len2; i3++) {
                        let data22 = data21[i3];
                        if (data22 && typeof data22 == "object" && !Array.isArray(data22)) {
                          if (data22.id === void 0) {
                            const err63 = { instancePath: instancePath + "/blocks/" + i0 + "/data/entries/" + i3, schemaPath: "#/properties/blocks/items/oneOf/2/properties/data/properties/entries/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                            if (vErrors === null) {
                              vErrors = [err63];
                            } else {
                              vErrors.push(err63);
                            }
                            errors++;
                          }
                          if (data22.term === void 0) {
                            const err64 = { instancePath: instancePath + "/blocks/" + i0 + "/data/entries/" + i3, schemaPath: "#/properties/blocks/items/oneOf/2/properties/data/properties/entries/items/required", keyword: "required", params: { missingProperty: "term" }, message: "must have required property 'term'" };
                            if (vErrors === null) {
                              vErrors = [err64];
                            } else {
                              vErrors.push(err64);
                            }
                            errors++;
                          }
                          if (data22.definition === void 0) {
                            const err65 = { instancePath: instancePath + "/blocks/" + i0 + "/data/entries/" + i3, schemaPath: "#/properties/blocks/items/oneOf/2/properties/data/properties/entries/items/required", keyword: "required", params: { missingProperty: "definition" }, message: "must have required property 'definition'" };
                            if (vErrors === null) {
                              vErrors = [err65];
                            } else {
                              vErrors.push(err65);
                            }
                            errors++;
                          }
                          if (data22.example === void 0) {
                            const err66 = { instancePath: instancePath + "/blocks/" + i0 + "/data/entries/" + i3, schemaPath: "#/properties/blocks/items/oneOf/2/properties/data/properties/entries/items/required", keyword: "required", params: { missingProperty: "example" }, message: "must have required property 'example'" };
                            if (vErrors === null) {
                              vErrors = [err66];
                            } else {
                              vErrors.push(err66);
                            }
                            errors++;
                          }
                          for (const key7 in data22) {
                            if (!(key7 === "id" || key7 === "term" || key7 === "definition" || key7 === "example")) {
                              const err67 = { instancePath: instancePath + "/blocks/" + i0 + "/data/entries/" + i3, schemaPath: "#/properties/blocks/items/oneOf/2/properties/data/properties/entries/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key7 }, message: "must NOT have additional properties" };
                              if (vErrors === null) {
                                vErrors = [err67];
                              } else {
                                vErrors.push(err67);
                              }
                              errors++;
                            }
                          }
                          if (data22.id !== void 0) {
                            let data23 = data22.id;
                            if (typeof data23 === "string") {
                              if (func2(data23) < 1) {
                                const err68 = { instancePath: instancePath + "/blocks/" + i0 + "/data/entries/" + i3 + "/id", schemaPath: "#/properties/blocks/items/oneOf/2/properties/data/properties/entries/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                if (vErrors === null) {
                                  vErrors = [err68];
                                } else {
                                  vErrors.push(err68);
                                }
                                errors++;
                              }
                            } else {
                              const err69 = { instancePath: instancePath + "/blocks/" + i0 + "/data/entries/" + i3 + "/id", schemaPath: "#/properties/blocks/items/oneOf/2/properties/data/properties/entries/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err69];
                              } else {
                                vErrors.push(err69);
                              }
                              errors++;
                            }
                          }
                          if (data22.term !== void 0) {
                            let data24 = data22.term;
                            if (typeof data24 === "string") {
                              if (func2(data24) < 1) {
                                const err70 = { instancePath: instancePath + "/blocks/" + i0 + "/data/entries/" + i3 + "/term", schemaPath: "#/properties/blocks/items/oneOf/2/properties/data/properties/entries/items/properties/term/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                if (vErrors === null) {
                                  vErrors = [err70];
                                } else {
                                  vErrors.push(err70);
                                }
                                errors++;
                              }
                            } else {
                              const err71 = { instancePath: instancePath + "/blocks/" + i0 + "/data/entries/" + i3 + "/term", schemaPath: "#/properties/blocks/items/oneOf/2/properties/data/properties/entries/items/properties/term/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err71];
                              } else {
                                vErrors.push(err71);
                              }
                              errors++;
                            }
                          }
                          if (data22.definition !== void 0) {
                            let data25 = data22.definition;
                            if (typeof data25 === "string") {
                              if (func2(data25) < 1) {
                                const err72 = { instancePath: instancePath + "/blocks/" + i0 + "/data/entries/" + i3 + "/definition", schemaPath: "#/properties/blocks/items/oneOf/2/properties/data/properties/entries/items/properties/definition/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                if (vErrors === null) {
                                  vErrors = [err72];
                                } else {
                                  vErrors.push(err72);
                                }
                                errors++;
                              }
                            } else {
                              const err73 = { instancePath: instancePath + "/blocks/" + i0 + "/data/entries/" + i3 + "/definition", schemaPath: "#/properties/blocks/items/oneOf/2/properties/data/properties/entries/items/properties/definition/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err73];
                              } else {
                                vErrors.push(err73);
                              }
                              errors++;
                            }
                          }
                          if (data22.example !== void 0) {
                            if (typeof data22.example !== "string") {
                              const err74 = { instancePath: instancePath + "/blocks/" + i0 + "/data/entries/" + i3 + "/example", schemaPath: "#/properties/blocks/items/oneOf/2/properties/data/properties/entries/items/properties/example/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err74];
                              } else {
                                vErrors.push(err74);
                              }
                              errors++;
                            }
                          }
                        } else {
                          const err75 = { instancePath: instancePath + "/blocks/" + i0 + "/data/entries/" + i3, schemaPath: "#/properties/blocks/items/oneOf/2/properties/data/properties/entries/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                          if (vErrors === null) {
                            vErrors = [err75];
                          } else {
                            vErrors.push(err75);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err76 = { instancePath: instancePath + "/blocks/" + i0 + "/data/entries", schemaPath: "#/properties/blocks/items/oneOf/2/properties/data/properties/entries/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                      if (vErrors === null) {
                        vErrors = [err76];
                      } else {
                        vErrors.push(err76);
                      }
                      errors++;
                    }
                  }
                } else {
                  const err77 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/2/properties/data/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                  if (vErrors === null) {
                    vErrors = [err77];
                  } else {
                    vErrors.push(err77);
                  }
                  errors++;
                }
              }
              if (data6.visibility !== void 0) {
                let data27 = data6.visibility;
                if (!(data27 === "student" || data27 === "both")) {
                  const err78 = { instancePath: instancePath + "/blocks/" + i0 + "/visibility", schemaPath: "#/properties/blocks/items/oneOf/2/properties/visibility/enum", keyword: "enum", params: { allowedValues: schema33.properties.blocks.items.oneOf[2].properties.visibility.enum }, message: "must be equal to one of the allowed values" };
                  if (vErrors === null) {
                    vErrors = [err78];
                  } else {
                    vErrors.push(err78);
                  }
                  errors++;
                }
              }
            } else {
              const err79 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/2/type", keyword: "type", params: { type: "object" }, message: "must be object" };
              if (vErrors === null) {
                vErrors = [err79];
              } else {
                vErrors.push(err79);
              }
              errors++;
            }
            var _valid0 = _errs41 === errors;
            if (_valid0 && valid3) {
              valid3 = false;
              passing0 = [passing0, 2];
            } else {
              if (_valid0) {
                valid3 = true;
                passing0 = 2;
                if (props0 !== true) {
                  props0 = true;
                }
              }
              const _errs64 = errors;
              if (data6 && typeof data6 == "object" && !Array.isArray(data6)) {
                if (data6.id === void 0) {
                  const err80 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/3/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                  if (vErrors === null) {
                    vErrors = [err80];
                  } else {
                    vErrors.push(err80);
                  }
                  errors++;
                }
                if (data6.type === void 0) {
                  const err81 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/3/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                  if (vErrors === null) {
                    vErrors = [err81];
                  } else {
                    vErrors.push(err81);
                  }
                  errors++;
                }
                if (data6.data === void 0) {
                  const err82 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/3/required", keyword: "required", params: { missingProperty: "data" }, message: "must have required property 'data'" };
                  if (vErrors === null) {
                    vErrors = [err82];
                  } else {
                    vErrors.push(err82);
                  }
                  errors++;
                }
                if (data6.visibility === void 0) {
                  const err83 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/3/required", keyword: "required", params: { missingProperty: "visibility" }, message: "must have required property 'visibility'" };
                  if (vErrors === null) {
                    vErrors = [err83];
                  } else {
                    vErrors.push(err83);
                  }
                  errors++;
                }
                for (const key8 in data6) {
                  if (!(key8 === "id" || key8 === "type" || key8 === "data" || key8 === "visibility")) {
                    const err84 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/3/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key8 }, message: "must NOT have additional properties" };
                    if (vErrors === null) {
                      vErrors = [err84];
                    } else {
                      vErrors.push(err84);
                    }
                    errors++;
                  }
                }
                if (data6.id !== void 0) {
                  let data28 = data6.id;
                  if (typeof data28 === "string") {
                    if (func2(data28) < 1) {
                      const err85 = { instancePath: instancePath + "/blocks/" + i0 + "/id", schemaPath: "#/properties/blocks/items/oneOf/3/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err85];
                      } else {
                        vErrors.push(err85);
                      }
                      errors++;
                    }
                  } else {
                    const err86 = { instancePath: instancePath + "/blocks/" + i0 + "/id", schemaPath: "#/properties/blocks/items/oneOf/3/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err86];
                    } else {
                      vErrors.push(err86);
                    }
                    errors++;
                  }
                }
                if (data6.type !== void 0) {
                  if ("organizer" !== data6.type) {
                    const err87 = { instancePath: instancePath + "/blocks/" + i0 + "/type", schemaPath: "#/properties/blocks/items/oneOf/3/properties/type/const", keyword: "const", params: { allowedValue: "organizer" }, message: "must be equal to constant" };
                    if (vErrors === null) {
                      vErrors = [err87];
                    } else {
                      vErrors.push(err87);
                    }
                    errors++;
                  }
                }
                if (data6.data !== void 0) {
                  let data30 = data6.data;
                  if (data30 && typeof data30 == "object" && !Array.isArray(data30)) {
                    if (data30.title === void 0) {
                      const err88 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/required", keyword: "required", params: { missingProperty: "title" }, message: "must have required property 'title'" };
                      if (vErrors === null) {
                        vErrors = [err88];
                      } else {
                        vErrors.push(err88);
                      }
                      errors++;
                    }
                    if (data30.nodes === void 0) {
                      const err89 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/required", keyword: "required", params: { missingProperty: "nodes" }, message: "must have required property 'nodes'" };
                      if (vErrors === null) {
                        vErrors = [err89];
                      } else {
                        vErrors.push(err89);
                      }
                      errors++;
                    }
                    if (data30.edges === void 0) {
                      const err90 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/required", keyword: "required", params: { missingProperty: "edges" }, message: "must have required property 'edges'" };
                      if (vErrors === null) {
                        vErrors = [err90];
                      } else {
                        vErrors.push(err90);
                      }
                      errors++;
                    }
                    for (const key9 in data30) {
                      if (!(key9 === "title" || key9 === "nodes" || key9 === "edges")) {
                        const err91 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key9 }, message: "must NOT have additional properties" };
                        if (vErrors === null) {
                          vErrors = [err91];
                        } else {
                          vErrors.push(err91);
                        }
                        errors++;
                      }
                    }
                    if (data30.title !== void 0) {
                      let data31 = data30.title;
                      if (typeof data31 === "string") {
                        if (func2(data31) < 1) {
                          const err92 = { instancePath: instancePath + "/blocks/" + i0 + "/data/title", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/title/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err92];
                          } else {
                            vErrors.push(err92);
                          }
                          errors++;
                        }
                      } else {
                        const err93 = { instancePath: instancePath + "/blocks/" + i0 + "/data/title", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err93];
                        } else {
                          vErrors.push(err93);
                        }
                        errors++;
                      }
                    }
                    if (data30.nodes !== void 0) {
                      let data32 = data30.nodes;
                      if (Array.isArray(data32)) {
                        if (data32.length > 30) {
                          const err94 = { instancePath: instancePath + "/blocks/" + i0 + "/data/nodes", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/nodes/maxItems", keyword: "maxItems", params: { limit: 30 }, message: "must NOT have more than 30 items" };
                          if (vErrors === null) {
                            vErrors = [err94];
                          } else {
                            vErrors.push(err94);
                          }
                          errors++;
                        }
                        if (data32.length < 1) {
                          const err95 = { instancePath: instancePath + "/blocks/" + i0 + "/data/nodes", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/nodes/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                          if (vErrors === null) {
                            vErrors = [err95];
                          } else {
                            vErrors.push(err95);
                          }
                          errors++;
                        }
                        const len3 = data32.length;
                        for (let i4 = 0; i4 < len3; i4++) {
                          let data33 = data32[i4];
                          if (data33 && typeof data33 == "object" && !Array.isArray(data33)) {
                            if (data33.id === void 0) {
                              const err96 = { instancePath: instancePath + "/blocks/" + i0 + "/data/nodes/" + i4, schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/nodes/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                              if (vErrors === null) {
                                vErrors = [err96];
                              } else {
                                vErrors.push(err96);
                              }
                              errors++;
                            }
                            if (data33.label === void 0) {
                              const err97 = { instancePath: instancePath + "/blocks/" + i0 + "/data/nodes/" + i4, schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/nodes/items/required", keyword: "required", params: { missingProperty: "label" }, message: "must have required property 'label'" };
                              if (vErrors === null) {
                                vErrors = [err97];
                              } else {
                                vErrors.push(err97);
                              }
                              errors++;
                            }
                            for (const key10 in data33) {
                              if (!(key10 === "id" || key10 === "label")) {
                                const err98 = { instancePath: instancePath + "/blocks/" + i0 + "/data/nodes/" + i4, schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/nodes/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key10 }, message: "must NOT have additional properties" };
                                if (vErrors === null) {
                                  vErrors = [err98];
                                } else {
                                  vErrors.push(err98);
                                }
                                errors++;
                              }
                            }
                            if (data33.id !== void 0) {
                              let data34 = data33.id;
                              if (typeof data34 === "string") {
                                if (func2(data34) < 1) {
                                  const err99 = { instancePath: instancePath + "/blocks/" + i0 + "/data/nodes/" + i4 + "/id", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/nodes/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err99];
                                  } else {
                                    vErrors.push(err99);
                                  }
                                  errors++;
                                }
                              } else {
                                const err100 = { instancePath: instancePath + "/blocks/" + i0 + "/data/nodes/" + i4 + "/id", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/nodes/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err100];
                                } else {
                                  vErrors.push(err100);
                                }
                                errors++;
                              }
                            }
                            if (data33.label !== void 0) {
                              let data35 = data33.label;
                              if (typeof data35 === "string") {
                                if (func2(data35) < 1) {
                                  const err101 = { instancePath: instancePath + "/blocks/" + i0 + "/data/nodes/" + i4 + "/label", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/nodes/items/properties/label/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err101];
                                  } else {
                                    vErrors.push(err101);
                                  }
                                  errors++;
                                }
                              } else {
                                const err102 = { instancePath: instancePath + "/blocks/" + i0 + "/data/nodes/" + i4 + "/label", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/nodes/items/properties/label/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err102];
                                } else {
                                  vErrors.push(err102);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err103 = { instancePath: instancePath + "/blocks/" + i0 + "/data/nodes/" + i4, schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/nodes/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                            if (vErrors === null) {
                              vErrors = [err103];
                            } else {
                              vErrors.push(err103);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err104 = { instancePath: instancePath + "/blocks/" + i0 + "/data/nodes", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/nodes/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err104];
                        } else {
                          vErrors.push(err104);
                        }
                        errors++;
                      }
                    }
                    if (data30.edges !== void 0) {
                      let data36 = data30.edges;
                      if (Array.isArray(data36)) {
                        if (data36.length > 100) {
                          const err105 = { instancePath: instancePath + "/blocks/" + i0 + "/data/edges", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/edges/maxItems", keyword: "maxItems", params: { limit: 100 }, message: "must NOT have more than 100 items" };
                          if (vErrors === null) {
                            vErrors = [err105];
                          } else {
                            vErrors.push(err105);
                          }
                          errors++;
                        }
                        const len4 = data36.length;
                        for (let i5 = 0; i5 < len4; i5++) {
                          let data37 = data36[i5];
                          if (data37 && typeof data37 == "object" && !Array.isArray(data37)) {
                            if (data37.from === void 0) {
                              const err106 = { instancePath: instancePath + "/blocks/" + i0 + "/data/edges/" + i5, schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/edges/items/required", keyword: "required", params: { missingProperty: "from" }, message: "must have required property 'from'" };
                              if (vErrors === null) {
                                vErrors = [err106];
                              } else {
                                vErrors.push(err106);
                              }
                              errors++;
                            }
                            if (data37.to === void 0) {
                              const err107 = { instancePath: instancePath + "/blocks/" + i0 + "/data/edges/" + i5, schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/edges/items/required", keyword: "required", params: { missingProperty: "to" }, message: "must have required property 'to'" };
                              if (vErrors === null) {
                                vErrors = [err107];
                              } else {
                                vErrors.push(err107);
                              }
                              errors++;
                            }
                            if (data37.label === void 0) {
                              const err108 = { instancePath: instancePath + "/blocks/" + i0 + "/data/edges/" + i5, schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/edges/items/required", keyword: "required", params: { missingProperty: "label" }, message: "must have required property 'label'" };
                              if (vErrors === null) {
                                vErrors = [err108];
                              } else {
                                vErrors.push(err108);
                              }
                              errors++;
                            }
                            for (const key11 in data37) {
                              if (!(key11 === "from" || key11 === "to" || key11 === "label")) {
                                const err109 = { instancePath: instancePath + "/blocks/" + i0 + "/data/edges/" + i5, schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/edges/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key11 }, message: "must NOT have additional properties" };
                                if (vErrors === null) {
                                  vErrors = [err109];
                                } else {
                                  vErrors.push(err109);
                                }
                                errors++;
                              }
                            }
                            if (data37.from !== void 0) {
                              let data38 = data37.from;
                              if (typeof data38 === "string") {
                                if (func2(data38) < 1) {
                                  const err110 = { instancePath: instancePath + "/blocks/" + i0 + "/data/edges/" + i5 + "/from", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/edges/items/properties/from/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err110];
                                  } else {
                                    vErrors.push(err110);
                                  }
                                  errors++;
                                }
                              } else {
                                const err111 = { instancePath: instancePath + "/blocks/" + i0 + "/data/edges/" + i5 + "/from", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/edges/items/properties/from/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err111];
                                } else {
                                  vErrors.push(err111);
                                }
                                errors++;
                              }
                            }
                            if (data37.to !== void 0) {
                              let data39 = data37.to;
                              if (typeof data39 === "string") {
                                if (func2(data39) < 1) {
                                  const err112 = { instancePath: instancePath + "/blocks/" + i0 + "/data/edges/" + i5 + "/to", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/edges/items/properties/to/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err112];
                                  } else {
                                    vErrors.push(err112);
                                  }
                                  errors++;
                                }
                              } else {
                                const err113 = { instancePath: instancePath + "/blocks/" + i0 + "/data/edges/" + i5 + "/to", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/edges/items/properties/to/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err113];
                                } else {
                                  vErrors.push(err113);
                                }
                                errors++;
                              }
                            }
                            if (data37.label !== void 0) {
                              if (typeof data37.label !== "string") {
                                const err114 = { instancePath: instancePath + "/blocks/" + i0 + "/data/edges/" + i5 + "/label", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/edges/items/properties/label/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err114];
                                } else {
                                  vErrors.push(err114);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err115 = { instancePath: instancePath + "/blocks/" + i0 + "/data/edges/" + i5, schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/edges/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                            if (vErrors === null) {
                              vErrors = [err115];
                            } else {
                              vErrors.push(err115);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err116 = { instancePath: instancePath + "/blocks/" + i0 + "/data/edges", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/properties/edges/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err116];
                        } else {
                          vErrors.push(err116);
                        }
                        errors++;
                      }
                    }
                  } else {
                    const err117 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/3/properties/data/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                    if (vErrors === null) {
                      vErrors = [err117];
                    } else {
                      vErrors.push(err117);
                    }
                    errors++;
                  }
                }
                if (data6.visibility !== void 0) {
                  let data41 = data6.visibility;
                  if (!(data41 === "student" || data41 === "both")) {
                    const err118 = { instancePath: instancePath + "/blocks/" + i0 + "/visibility", schemaPath: "#/properties/blocks/items/oneOf/3/properties/visibility/enum", keyword: "enum", params: { allowedValues: schema33.properties.blocks.items.oneOf[3].properties.visibility.enum }, message: "must be equal to one of the allowed values" };
                    if (vErrors === null) {
                      vErrors = [err118];
                    } else {
                      vErrors.push(err118);
                    }
                    errors++;
                  }
                }
              } else {
                const err119 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/3/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                if (vErrors === null) {
                  vErrors = [err119];
                } else {
                  vErrors.push(err119);
                }
                errors++;
              }
              var _valid0 = _errs64 === errors;
              if (_valid0 && valid3) {
                valid3 = false;
                passing0 = [passing0, 3];
              } else {
                if (_valid0) {
                  valid3 = true;
                  passing0 = 3;
                  if (props0 !== true) {
                    props0 = true;
                  }
                }
              }
            }
          }
          if (!valid3) {
            const err120 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf", keyword: "oneOf", params: { passingSchemas: passing0 }, message: "must match exactly one schema in oneOf" };
            if (vErrors === null) {
              vErrors = [err120];
            } else {
              vErrors.push(err120);
            }
            errors++;
          } else {
            errors = _errs14;
            if (vErrors !== null) {
              if (_errs14) {
                vErrors.length = _errs14;
              } else {
                vErrors = null;
              }
            }
          }
        }
      } else {
        const err121 = { instancePath: instancePath + "/blocks", schemaPath: "#/properties/blocks/type", keyword: "type", params: { type: "array" }, message: "must be array" };
        if (vErrors === null) {
          vErrors = [err121];
        } else {
          vErrors.push(err121);
        }
        errors++;
      }
    }
    if (data.questions !== void 0) {
      let data42 = data.questions;
      if (Array.isArray(data42)) {
        const len5 = data42.length;
        for (let i6 = 0; i6 < len5; i6++) {
          let data43 = data42[i6];
          const _errs99 = errors;
          let valid26 = false;
          let passing1 = null;
          const _errs100 = errors;
          if (data43 && typeof data43 == "object" && !Array.isArray(data43)) {
            if (data43.id === void 0) {
              const err122 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
              if (vErrors === null) {
                vErrors = [err122];
              } else {
                vErrors.push(err122);
              }
              errors++;
            }
            if (data43.prompt === void 0) {
              const err123 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
              if (vErrors === null) {
                vErrors = [err123];
              } else {
                vErrors.push(err123);
              }
              errors++;
            }
            if (data43.maxScore === void 0) {
              const err124 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
              if (vErrors === null) {
                vErrors = [err124];
              } else {
                vErrors.push(err124);
              }
              errors++;
            }
            if (data43.objectiveIds === void 0) {
              const err125 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
              if (vErrors === null) {
                vErrors = [err125];
              } else {
                vErrors.push(err125);
              }
              errors++;
            }
            if (data43.hints === void 0) {
              const err126 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
              if (vErrors === null) {
                vErrors = [err126];
              } else {
                vErrors.push(err126);
              }
              errors++;
            }
            if (data43.type === void 0) {
              const err127 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
              if (vErrors === null) {
                vErrors = [err127];
              } else {
                vErrors.push(err127);
              }
              errors++;
            }
            if (data43.options === void 0) {
              const err128 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "options" }, message: "must have required property 'options'" };
              if (vErrors === null) {
                vErrors = [err128];
              } else {
                vErrors.push(err128);
              }
              errors++;
            }
            for (const key12 in data43) {
              if (!(key12 === "id" || key12 === "prompt" || key12 === "maxScore" || key12 === "objectiveIds" || key12 === "hints" || key12 === "type" || key12 === "options")) {
                const err129 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/0/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key12 }, message: "must NOT have additional properties" };
                if (vErrors === null) {
                  vErrors = [err129];
                } else {
                  vErrors.push(err129);
                }
                errors++;
              }
            }
            if (data43.id !== void 0) {
              let data44 = data43.id;
              if (typeof data44 === "string") {
                if (func2(data44) < 1) {
                  const err130 = { instancePath: instancePath + "/questions/" + i6 + "/id", schemaPath: "#/properties/questions/items/oneOf/0/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err130];
                  } else {
                    vErrors.push(err130);
                  }
                  errors++;
                }
              } else {
                const err131 = { instancePath: instancePath + "/questions/" + i6 + "/id", schemaPath: "#/properties/questions/items/oneOf/0/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err131];
                } else {
                  vErrors.push(err131);
                }
                errors++;
              }
            }
            if (data43.prompt !== void 0) {
              let data45 = data43.prompt;
              if (typeof data45 === "string") {
                if (func2(data45) < 1) {
                  const err132 = { instancePath: instancePath + "/questions/" + i6 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/0/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err132];
                  } else {
                    vErrors.push(err132);
                  }
                  errors++;
                }
              } else {
                const err133 = { instancePath: instancePath + "/questions/" + i6 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/0/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err133];
                } else {
                  vErrors.push(err133);
                }
                errors++;
              }
            }
            if (data43.maxScore !== void 0) {
              let data46 = data43.maxScore;
              if (typeof data46 == "number") {
                if (data46 <= 0 || isNaN(data46)) {
                  const err134 = { instancePath: instancePath + "/questions/" + i6 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/0/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                  if (vErrors === null) {
                    vErrors = [err134];
                  } else {
                    vErrors.push(err134);
                  }
                  errors++;
                }
              } else {
                const err135 = { instancePath: instancePath + "/questions/" + i6 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/0/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                if (vErrors === null) {
                  vErrors = [err135];
                } else {
                  vErrors.push(err135);
                }
                errors++;
              }
            }
            if (data43.objectiveIds !== void 0) {
              let data47 = data43.objectiveIds;
              if (Array.isArray(data47)) {
                if (data47.length < 1) {
                  const err136 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/0/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                  if (vErrors === null) {
                    vErrors = [err136];
                  } else {
                    vErrors.push(err136);
                  }
                  errors++;
                }
                const len6 = data47.length;
                for (let i7 = 0; i7 < len6; i7++) {
                  let data48 = data47[i7];
                  if (typeof data48 === "string") {
                    if (func2(data48) < 1) {
                      const err137 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds/" + i7, schemaPath: "#/properties/questions/items/oneOf/0/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err137];
                      } else {
                        vErrors.push(err137);
                      }
                      errors++;
                    }
                  } else {
                    const err138 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds/" + i7, schemaPath: "#/properties/questions/items/oneOf/0/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err138];
                    } else {
                      vErrors.push(err138);
                    }
                    errors++;
                  }
                }
                let i8 = data47.length;
                let j1;
                if (i8 > 1) {
                  const indices1 = {};
                  for (; i8--; ) {
                    let item1 = data47[i8];
                    if (typeof item1 !== "string") {
                      continue;
                    }
                    if (typeof indices1[item1] == "number") {
                      j1 = indices1[item1];
                      const err139 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/0/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i8, j: j1 }, message: "must NOT have duplicate items (items ## " + j1 + " and " + i8 + " are identical)" };
                      if (vErrors === null) {
                        vErrors = [err139];
                      } else {
                        vErrors.push(err139);
                      }
                      errors++;
                      break;
                    }
                    indices1[item1] = i8;
                  }
                }
              } else {
                const err140 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/0/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                if (vErrors === null) {
                  vErrors = [err140];
                } else {
                  vErrors.push(err140);
                }
                errors++;
              }
            }
            if (data43.hints !== void 0) {
              let data49 = data43.hints;
              if (Array.isArray(data49)) {
                const len7 = data49.length;
                for (let i9 = 0; i9 < len7; i9++) {
                  let data50 = data49[i9];
                  if (typeof data50 === "string") {
                    if (func2(data50) < 1) {
                      const err141 = { instancePath: instancePath + "/questions/" + i6 + "/hints/" + i9, schemaPath: "#/properties/questions/items/oneOf/0/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err141];
                      } else {
                        vErrors.push(err141);
                      }
                      errors++;
                    }
                  } else {
                    const err142 = { instancePath: instancePath + "/questions/" + i6 + "/hints/" + i9, schemaPath: "#/properties/questions/items/oneOf/0/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err142];
                    } else {
                      vErrors.push(err142);
                    }
                    errors++;
                  }
                }
              } else {
                const err143 = { instancePath: instancePath + "/questions/" + i6 + "/hints", schemaPath: "#/properties/questions/items/oneOf/0/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                if (vErrors === null) {
                  vErrors = [err143];
                } else {
                  vErrors.push(err143);
                }
                errors++;
              }
            }
            if (data43.type !== void 0) {
              if ("singleChoice" !== data43.type) {
                const err144 = { instancePath: instancePath + "/questions/" + i6 + "/type", schemaPath: "#/properties/questions/items/oneOf/0/properties/type/const", keyword: "const", params: { allowedValue: "singleChoice" }, message: "must be equal to constant" };
                if (vErrors === null) {
                  vErrors = [err144];
                } else {
                  vErrors.push(err144);
                }
                errors++;
              }
            }
            if (data43.options !== void 0) {
              let data52 = data43.options;
              if (Array.isArray(data52)) {
                if (data52.length < 2) {
                  const err145 = { instancePath: instancePath + "/questions/" + i6 + "/options", schemaPath: "#/properties/questions/items/oneOf/0/properties/options/minItems", keyword: "minItems", params: { limit: 2 }, message: "must NOT have fewer than 2 items" };
                  if (vErrors === null) {
                    vErrors = [err145];
                  } else {
                    vErrors.push(err145);
                  }
                  errors++;
                }
                const len8 = data52.length;
                for (let i10 = 0; i10 < len8; i10++) {
                  let data53 = data52[i10];
                  if (data53 && typeof data53 == "object" && !Array.isArray(data53)) {
                    if (data53.id === void 0) {
                      const err146 = { instancePath: instancePath + "/questions/" + i6 + "/options/" + i10, schemaPath: "#/properties/questions/items/oneOf/0/properties/options/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                      if (vErrors === null) {
                        vErrors = [err146];
                      } else {
                        vErrors.push(err146);
                      }
                      errors++;
                    }
                    if (data53.text === void 0) {
                      const err147 = { instancePath: instancePath + "/questions/" + i6 + "/options/" + i10, schemaPath: "#/properties/questions/items/oneOf/0/properties/options/items/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
                      if (vErrors === null) {
                        vErrors = [err147];
                      } else {
                        vErrors.push(err147);
                      }
                      errors++;
                    }
                    for (const key13 in data53) {
                      if (!(key13 === "id" || key13 === "text")) {
                        const err148 = { instancePath: instancePath + "/questions/" + i6 + "/options/" + i10, schemaPath: "#/properties/questions/items/oneOf/0/properties/options/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key13 }, message: "must NOT have additional properties" };
                        if (vErrors === null) {
                          vErrors = [err148];
                        } else {
                          vErrors.push(err148);
                        }
                        errors++;
                      }
                    }
                    if (data53.id !== void 0) {
                      let data54 = data53.id;
                      if (typeof data54 === "string") {
                        if (func2(data54) < 1) {
                          const err149 = { instancePath: instancePath + "/questions/" + i6 + "/options/" + i10 + "/id", schemaPath: "#/properties/questions/items/oneOf/0/properties/options/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err149];
                          } else {
                            vErrors.push(err149);
                          }
                          errors++;
                        }
                      } else {
                        const err150 = { instancePath: instancePath + "/questions/" + i6 + "/options/" + i10 + "/id", schemaPath: "#/properties/questions/items/oneOf/0/properties/options/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err150];
                        } else {
                          vErrors.push(err150);
                        }
                        errors++;
                      }
                    }
                    if (data53.text !== void 0) {
                      let data55 = data53.text;
                      if (typeof data55 === "string") {
                        if (func2(data55) < 1) {
                          const err151 = { instancePath: instancePath + "/questions/" + i6 + "/options/" + i10 + "/text", schemaPath: "#/properties/questions/items/oneOf/0/properties/options/items/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err151];
                          } else {
                            vErrors.push(err151);
                          }
                          errors++;
                        }
                      } else {
                        const err152 = { instancePath: instancePath + "/questions/" + i6 + "/options/" + i10 + "/text", schemaPath: "#/properties/questions/items/oneOf/0/properties/options/items/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err152];
                        } else {
                          vErrors.push(err152);
                        }
                        errors++;
                      }
                    }
                  } else {
                    const err153 = { instancePath: instancePath + "/questions/" + i6 + "/options/" + i10, schemaPath: "#/properties/questions/items/oneOf/0/properties/options/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                    if (vErrors === null) {
                      vErrors = [err153];
                    } else {
                      vErrors.push(err153);
                    }
                    errors++;
                  }
                }
              } else {
                const err154 = { instancePath: instancePath + "/questions/" + i6 + "/options", schemaPath: "#/properties/questions/items/oneOf/0/properties/options/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                if (vErrors === null) {
                  vErrors = [err154];
                } else {
                  vErrors.push(err154);
                }
                errors++;
              }
            }
          } else {
            const err155 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/0/type", keyword: "type", params: { type: "object" }, message: "must be object" };
            if (vErrors === null) {
              vErrors = [err155];
            } else {
              vErrors.push(err155);
            }
            errors++;
          }
          var _valid1 = _errs100 === errors;
          if (_valid1) {
            valid26 = true;
            passing1 = 0;
            var props1 = true;
          }
          const _errs127 = errors;
          if (data43 && typeof data43 == "object" && !Array.isArray(data43)) {
            if (data43.id === void 0) {
              const err156 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
              if (vErrors === null) {
                vErrors = [err156];
              } else {
                vErrors.push(err156);
              }
              errors++;
            }
            if (data43.prompt === void 0) {
              const err157 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
              if (vErrors === null) {
                vErrors = [err157];
              } else {
                vErrors.push(err157);
              }
              errors++;
            }
            if (data43.maxScore === void 0) {
              const err158 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
              if (vErrors === null) {
                vErrors = [err158];
              } else {
                vErrors.push(err158);
              }
              errors++;
            }
            if (data43.objectiveIds === void 0) {
              const err159 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
              if (vErrors === null) {
                vErrors = [err159];
              } else {
                vErrors.push(err159);
              }
              errors++;
            }
            if (data43.hints === void 0) {
              const err160 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
              if (vErrors === null) {
                vErrors = [err160];
              } else {
                vErrors.push(err160);
              }
              errors++;
            }
            if (data43.type === void 0) {
              const err161 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
              if (vErrors === null) {
                vErrors = [err161];
              } else {
                vErrors.push(err161);
              }
              errors++;
            }
            for (const key14 in data43) {
              if (!(key14 === "id" || key14 === "prompt" || key14 === "maxScore" || key14 === "objectiveIds" || key14 === "hints" || key14 === "type")) {
                const err162 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/1/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key14 }, message: "must NOT have additional properties" };
                if (vErrors === null) {
                  vErrors = [err162];
                } else {
                  vErrors.push(err162);
                }
                errors++;
              }
            }
            if (data43.id !== void 0) {
              let data56 = data43.id;
              if (typeof data56 === "string") {
                if (func2(data56) < 1) {
                  const err163 = { instancePath: instancePath + "/questions/" + i6 + "/id", schemaPath: "#/properties/questions/items/oneOf/1/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err163];
                  } else {
                    vErrors.push(err163);
                  }
                  errors++;
                }
              } else {
                const err164 = { instancePath: instancePath + "/questions/" + i6 + "/id", schemaPath: "#/properties/questions/items/oneOf/1/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err164];
                } else {
                  vErrors.push(err164);
                }
                errors++;
              }
            }
            if (data43.prompt !== void 0) {
              let data57 = data43.prompt;
              if (typeof data57 === "string") {
                if (func2(data57) < 1) {
                  const err165 = { instancePath: instancePath + "/questions/" + i6 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/1/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err165];
                  } else {
                    vErrors.push(err165);
                  }
                  errors++;
                }
              } else {
                const err166 = { instancePath: instancePath + "/questions/" + i6 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/1/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err166];
                } else {
                  vErrors.push(err166);
                }
                errors++;
              }
            }
            if (data43.maxScore !== void 0) {
              let data58 = data43.maxScore;
              if (typeof data58 == "number") {
                if (data58 <= 0 || isNaN(data58)) {
                  const err167 = { instancePath: instancePath + "/questions/" + i6 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/1/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                  if (vErrors === null) {
                    vErrors = [err167];
                  } else {
                    vErrors.push(err167);
                  }
                  errors++;
                }
              } else {
                const err168 = { instancePath: instancePath + "/questions/" + i6 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/1/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                if (vErrors === null) {
                  vErrors = [err168];
                } else {
                  vErrors.push(err168);
                }
                errors++;
              }
            }
            if (data43.objectiveIds !== void 0) {
              let data59 = data43.objectiveIds;
              if (Array.isArray(data59)) {
                if (data59.length < 1) {
                  const err169 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/1/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                  if (vErrors === null) {
                    vErrors = [err169];
                  } else {
                    vErrors.push(err169);
                  }
                  errors++;
                }
                const len9 = data59.length;
                for (let i11 = 0; i11 < len9; i11++) {
                  let data60 = data59[i11];
                  if (typeof data60 === "string") {
                    if (func2(data60) < 1) {
                      const err170 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds/" + i11, schemaPath: "#/properties/questions/items/oneOf/1/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err170];
                      } else {
                        vErrors.push(err170);
                      }
                      errors++;
                    }
                  } else {
                    const err171 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds/" + i11, schemaPath: "#/properties/questions/items/oneOf/1/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err171];
                    } else {
                      vErrors.push(err171);
                    }
                    errors++;
                  }
                }
                let i12 = data59.length;
                let j2;
                if (i12 > 1) {
                  const indices2 = {};
                  for (; i12--; ) {
                    let item2 = data59[i12];
                    if (typeof item2 !== "string") {
                      continue;
                    }
                    if (typeof indices2[item2] == "number") {
                      j2 = indices2[item2];
                      const err172 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/1/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i12, j: j2 }, message: "must NOT have duplicate items (items ## " + j2 + " and " + i12 + " are identical)" };
                      if (vErrors === null) {
                        vErrors = [err172];
                      } else {
                        vErrors.push(err172);
                      }
                      errors++;
                      break;
                    }
                    indices2[item2] = i12;
                  }
                }
              } else {
                const err173 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/1/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                if (vErrors === null) {
                  vErrors = [err173];
                } else {
                  vErrors.push(err173);
                }
                errors++;
              }
            }
            if (data43.hints !== void 0) {
              let data61 = data43.hints;
              if (Array.isArray(data61)) {
                const len10 = data61.length;
                for (let i13 = 0; i13 < len10; i13++) {
                  let data62 = data61[i13];
                  if (typeof data62 === "string") {
                    if (func2(data62) < 1) {
                      const err174 = { instancePath: instancePath + "/questions/" + i6 + "/hints/" + i13, schemaPath: "#/properties/questions/items/oneOf/1/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err174];
                      } else {
                        vErrors.push(err174);
                      }
                      errors++;
                    }
                  } else {
                    const err175 = { instancePath: instancePath + "/questions/" + i6 + "/hints/" + i13, schemaPath: "#/properties/questions/items/oneOf/1/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err175];
                    } else {
                      vErrors.push(err175);
                    }
                    errors++;
                  }
                }
              } else {
                const err176 = { instancePath: instancePath + "/questions/" + i6 + "/hints", schemaPath: "#/properties/questions/items/oneOf/1/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                if (vErrors === null) {
                  vErrors = [err176];
                } else {
                  vErrors.push(err176);
                }
                errors++;
              }
            }
            if (data43.type !== void 0) {
              if ("trueFalse" !== data43.type) {
                const err177 = { instancePath: instancePath + "/questions/" + i6 + "/type", schemaPath: "#/properties/questions/items/oneOf/1/properties/type/const", keyword: "const", params: { allowedValue: "trueFalse" }, message: "must be equal to constant" };
                if (vErrors === null) {
                  vErrors = [err177];
                } else {
                  vErrors.push(err177);
                }
                errors++;
              }
            }
          } else {
            const err178 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/1/type", keyword: "type", params: { type: "object" }, message: "must be object" };
            if (vErrors === null) {
              vErrors = [err178];
            } else {
              vErrors.push(err178);
            }
            errors++;
          }
          var _valid1 = _errs127 === errors;
          if (_valid1 && valid26) {
            valid26 = false;
            passing1 = [passing1, 1];
          } else {
            if (_valid1) {
              valid26 = true;
              passing1 = 1;
              if (props1 !== true) {
                props1 = true;
              }
            }
            const _errs145 = errors;
            if (data43 && typeof data43 == "object" && !Array.isArray(data43)) {
              if (data43.id === void 0) {
                const err179 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                if (vErrors === null) {
                  vErrors = [err179];
                } else {
                  vErrors.push(err179);
                }
                errors++;
              }
              if (data43.prompt === void 0) {
                const err180 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
                if (vErrors === null) {
                  vErrors = [err180];
                } else {
                  vErrors.push(err180);
                }
                errors++;
              }
              if (data43.maxScore === void 0) {
                const err181 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
                if (vErrors === null) {
                  vErrors = [err181];
                } else {
                  vErrors.push(err181);
                }
                errors++;
              }
              if (data43.objectiveIds === void 0) {
                const err182 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
                if (vErrors === null) {
                  vErrors = [err182];
                } else {
                  vErrors.push(err182);
                }
                errors++;
              }
              if (data43.hints === void 0) {
                const err183 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
                if (vErrors === null) {
                  vErrors = [err183];
                } else {
                  vErrors.push(err183);
                }
                errors++;
              }
              if (data43.type === void 0) {
                const err184 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                if (vErrors === null) {
                  vErrors = [err184];
                } else {
                  vErrors.push(err184);
                }
                errors++;
              }
              for (const key15 in data43) {
                if (!(key15 === "id" || key15 === "prompt" || key15 === "maxScore" || key15 === "objectiveIds" || key15 === "hints" || key15 === "type")) {
                  const err185 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/2/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key15 }, message: "must NOT have additional properties" };
                  if (vErrors === null) {
                    vErrors = [err185];
                  } else {
                    vErrors.push(err185);
                  }
                  errors++;
                }
              }
              if (data43.id !== void 0) {
                let data64 = data43.id;
                if (typeof data64 === "string") {
                  if (func2(data64) < 1) {
                    const err186 = { instancePath: instancePath + "/questions/" + i6 + "/id", schemaPath: "#/properties/questions/items/oneOf/2/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                    if (vErrors === null) {
                      vErrors = [err186];
                    } else {
                      vErrors.push(err186);
                    }
                    errors++;
                  }
                } else {
                  const err187 = { instancePath: instancePath + "/questions/" + i6 + "/id", schemaPath: "#/properties/questions/items/oneOf/2/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err187];
                  } else {
                    vErrors.push(err187);
                  }
                  errors++;
                }
              }
              if (data43.prompt !== void 0) {
                let data65 = data43.prompt;
                if (typeof data65 === "string") {
                  if (func2(data65) < 1) {
                    const err188 = { instancePath: instancePath + "/questions/" + i6 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/2/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                    if (vErrors === null) {
                      vErrors = [err188];
                    } else {
                      vErrors.push(err188);
                    }
                    errors++;
                  }
                } else {
                  const err189 = { instancePath: instancePath + "/questions/" + i6 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/2/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err189];
                  } else {
                    vErrors.push(err189);
                  }
                  errors++;
                }
              }
              if (data43.maxScore !== void 0) {
                let data66 = data43.maxScore;
                if (typeof data66 == "number") {
                  if (data66 <= 0 || isNaN(data66)) {
                    const err190 = { instancePath: instancePath + "/questions/" + i6 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/2/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                    if (vErrors === null) {
                      vErrors = [err190];
                    } else {
                      vErrors.push(err190);
                    }
                    errors++;
                  }
                } else {
                  const err191 = { instancePath: instancePath + "/questions/" + i6 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/2/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                  if (vErrors === null) {
                    vErrors = [err191];
                  } else {
                    vErrors.push(err191);
                  }
                  errors++;
                }
              }
              if (data43.objectiveIds !== void 0) {
                let data67 = data43.objectiveIds;
                if (Array.isArray(data67)) {
                  if (data67.length < 1) {
                    const err192 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/2/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                    if (vErrors === null) {
                      vErrors = [err192];
                    } else {
                      vErrors.push(err192);
                    }
                    errors++;
                  }
                  const len11 = data67.length;
                  for (let i14 = 0; i14 < len11; i14++) {
                    let data68 = data67[i14];
                    if (typeof data68 === "string") {
                      if (func2(data68) < 1) {
                        const err193 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds/" + i14, schemaPath: "#/properties/questions/items/oneOf/2/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                        if (vErrors === null) {
                          vErrors = [err193];
                        } else {
                          vErrors.push(err193);
                        }
                        errors++;
                      }
                    } else {
                      const err194 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds/" + i14, schemaPath: "#/properties/questions/items/oneOf/2/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err194];
                      } else {
                        vErrors.push(err194);
                      }
                      errors++;
                    }
                  }
                  let i15 = data67.length;
                  let j3;
                  if (i15 > 1) {
                    const indices3 = {};
                    for (; i15--; ) {
                      let item3 = data67[i15];
                      if (typeof item3 !== "string") {
                        continue;
                      }
                      if (typeof indices3[item3] == "number") {
                        j3 = indices3[item3];
                        const err195 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/2/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i15, j: j3 }, message: "must NOT have duplicate items (items ## " + j3 + " and " + i15 + " are identical)" };
                        if (vErrors === null) {
                          vErrors = [err195];
                        } else {
                          vErrors.push(err195);
                        }
                        errors++;
                        break;
                      }
                      indices3[item3] = i15;
                    }
                  }
                } else {
                  const err196 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/2/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                  if (vErrors === null) {
                    vErrors = [err196];
                  } else {
                    vErrors.push(err196);
                  }
                  errors++;
                }
              }
              if (data43.hints !== void 0) {
                let data69 = data43.hints;
                if (Array.isArray(data69)) {
                  const len12 = data69.length;
                  for (let i16 = 0; i16 < len12; i16++) {
                    let data70 = data69[i16];
                    if (typeof data70 === "string") {
                      if (func2(data70) < 1) {
                        const err197 = { instancePath: instancePath + "/questions/" + i6 + "/hints/" + i16, schemaPath: "#/properties/questions/items/oneOf/2/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                        if (vErrors === null) {
                          vErrors = [err197];
                        } else {
                          vErrors.push(err197);
                        }
                        errors++;
                      }
                    } else {
                      const err198 = { instancePath: instancePath + "/questions/" + i6 + "/hints/" + i16, schemaPath: "#/properties/questions/items/oneOf/2/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err198];
                      } else {
                        vErrors.push(err198);
                      }
                      errors++;
                    }
                  }
                } else {
                  const err199 = { instancePath: instancePath + "/questions/" + i6 + "/hints", schemaPath: "#/properties/questions/items/oneOf/2/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                  if (vErrors === null) {
                    vErrors = [err199];
                  } else {
                    vErrors.push(err199);
                  }
                  errors++;
                }
              }
              if (data43.type !== void 0) {
                if ("shortAnswer" !== data43.type) {
                  const err200 = { instancePath: instancePath + "/questions/" + i6 + "/type", schemaPath: "#/properties/questions/items/oneOf/2/properties/type/const", keyword: "const", params: { allowedValue: "shortAnswer" }, message: "must be equal to constant" };
                  if (vErrors === null) {
                    vErrors = [err200];
                  } else {
                    vErrors.push(err200);
                  }
                  errors++;
                }
              }
            } else {
              const err201 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/2/type", keyword: "type", params: { type: "object" }, message: "must be object" };
              if (vErrors === null) {
                vErrors = [err201];
              } else {
                vErrors.push(err201);
              }
              errors++;
            }
            var _valid1 = _errs145 === errors;
            if (_valid1 && valid26) {
              valid26 = false;
              passing1 = [passing1, 2];
            } else {
              if (_valid1) {
                valid26 = true;
                passing1 = 2;
                if (props1 !== true) {
                  props1 = true;
                }
              }
              const _errs163 = errors;
              if (data43 && typeof data43 == "object" && !Array.isArray(data43)) {
                if (data43.id === void 0) {
                  const err202 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/3/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                  if (vErrors === null) {
                    vErrors = [err202];
                  } else {
                    vErrors.push(err202);
                  }
                  errors++;
                }
                if (data43.prompt === void 0) {
                  const err203 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/3/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
                  if (vErrors === null) {
                    vErrors = [err203];
                  } else {
                    vErrors.push(err203);
                  }
                  errors++;
                }
                if (data43.maxScore === void 0) {
                  const err204 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/3/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
                  if (vErrors === null) {
                    vErrors = [err204];
                  } else {
                    vErrors.push(err204);
                  }
                  errors++;
                }
                if (data43.objectiveIds === void 0) {
                  const err205 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/3/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
                  if (vErrors === null) {
                    vErrors = [err205];
                  } else {
                    vErrors.push(err205);
                  }
                  errors++;
                }
                if (data43.hints === void 0) {
                  const err206 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/3/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
                  if (vErrors === null) {
                    vErrors = [err206];
                  } else {
                    vErrors.push(err206);
                  }
                  errors++;
                }
                if (data43.type === void 0) {
                  const err207 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/3/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                  if (vErrors === null) {
                    vErrors = [err207];
                  } else {
                    vErrors.push(err207);
                  }
                  errors++;
                }
                if (data43.options === void 0) {
                  const err208 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/3/required", keyword: "required", params: { missingProperty: "options" }, message: "must have required property 'options'" };
                  if (vErrors === null) {
                    vErrors = [err208];
                  } else {
                    vErrors.push(err208);
                  }
                  errors++;
                }
                for (const key16 in data43) {
                  if (!(key16 === "id" || key16 === "prompt" || key16 === "maxScore" || key16 === "objectiveIds" || key16 === "hints" || key16 === "type" || key16 === "options")) {
                    const err209 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/3/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key16 }, message: "must NOT have additional properties" };
                    if (vErrors === null) {
                      vErrors = [err209];
                    } else {
                      vErrors.push(err209);
                    }
                    errors++;
                  }
                }
                if (data43.id !== void 0) {
                  let data72 = data43.id;
                  if (typeof data72 === "string") {
                    if (func2(data72) < 1) {
                      const err210 = { instancePath: instancePath + "/questions/" + i6 + "/id", schemaPath: "#/properties/questions/items/oneOf/3/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err210];
                      } else {
                        vErrors.push(err210);
                      }
                      errors++;
                    }
                  } else {
                    const err211 = { instancePath: instancePath + "/questions/" + i6 + "/id", schemaPath: "#/properties/questions/items/oneOf/3/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err211];
                    } else {
                      vErrors.push(err211);
                    }
                    errors++;
                  }
                }
                if (data43.prompt !== void 0) {
                  let data73 = data43.prompt;
                  if (typeof data73 === "string") {
                    if (func2(data73) < 1) {
                      const err212 = { instancePath: instancePath + "/questions/" + i6 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/3/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err212];
                      } else {
                        vErrors.push(err212);
                      }
                      errors++;
                    }
                  } else {
                    const err213 = { instancePath: instancePath + "/questions/" + i6 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/3/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err213];
                    } else {
                      vErrors.push(err213);
                    }
                    errors++;
                  }
                }
                if (data43.maxScore !== void 0) {
                  let data74 = data43.maxScore;
                  if (typeof data74 == "number") {
                    if (data74 <= 0 || isNaN(data74)) {
                      const err214 = { instancePath: instancePath + "/questions/" + i6 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/3/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                      if (vErrors === null) {
                        vErrors = [err214];
                      } else {
                        vErrors.push(err214);
                      }
                      errors++;
                    }
                  } else {
                    const err215 = { instancePath: instancePath + "/questions/" + i6 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/3/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                    if (vErrors === null) {
                      vErrors = [err215];
                    } else {
                      vErrors.push(err215);
                    }
                    errors++;
                  }
                }
                if (data43.objectiveIds !== void 0) {
                  let data75 = data43.objectiveIds;
                  if (Array.isArray(data75)) {
                    if (data75.length < 1) {
                      const err216 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/3/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                      if (vErrors === null) {
                        vErrors = [err216];
                      } else {
                        vErrors.push(err216);
                      }
                      errors++;
                    }
                    const len13 = data75.length;
                    for (let i17 = 0; i17 < len13; i17++) {
                      let data76 = data75[i17];
                      if (typeof data76 === "string") {
                        if (func2(data76) < 1) {
                          const err217 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds/" + i17, schemaPath: "#/properties/questions/items/oneOf/3/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err217];
                          } else {
                            vErrors.push(err217);
                          }
                          errors++;
                        }
                      } else {
                        const err218 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds/" + i17, schemaPath: "#/properties/questions/items/oneOf/3/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err218];
                        } else {
                          vErrors.push(err218);
                        }
                        errors++;
                      }
                    }
                    let i18 = data75.length;
                    let j4;
                    if (i18 > 1) {
                      const indices4 = {};
                      for (; i18--; ) {
                        let item4 = data75[i18];
                        if (typeof item4 !== "string") {
                          continue;
                        }
                        if (typeof indices4[item4] == "number") {
                          j4 = indices4[item4];
                          const err219 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/3/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i18, j: j4 }, message: "must NOT have duplicate items (items ## " + j4 + " and " + i18 + " are identical)" };
                          if (vErrors === null) {
                            vErrors = [err219];
                          } else {
                            vErrors.push(err219);
                          }
                          errors++;
                          break;
                        }
                        indices4[item4] = i18;
                      }
                    }
                  } else {
                    const err220 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/3/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                    if (vErrors === null) {
                      vErrors = [err220];
                    } else {
                      vErrors.push(err220);
                    }
                    errors++;
                  }
                }
                if (data43.hints !== void 0) {
                  let data77 = data43.hints;
                  if (Array.isArray(data77)) {
                    const len14 = data77.length;
                    for (let i19 = 0; i19 < len14; i19++) {
                      let data78 = data77[i19];
                      if (typeof data78 === "string") {
                        if (func2(data78) < 1) {
                          const err221 = { instancePath: instancePath + "/questions/" + i6 + "/hints/" + i19, schemaPath: "#/properties/questions/items/oneOf/3/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err221];
                          } else {
                            vErrors.push(err221);
                          }
                          errors++;
                        }
                      } else {
                        const err222 = { instancePath: instancePath + "/questions/" + i6 + "/hints/" + i19, schemaPath: "#/properties/questions/items/oneOf/3/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err222];
                        } else {
                          vErrors.push(err222);
                        }
                        errors++;
                      }
                    }
                  } else {
                    const err223 = { instancePath: instancePath + "/questions/" + i6 + "/hints", schemaPath: "#/properties/questions/items/oneOf/3/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                    if (vErrors === null) {
                      vErrors = [err223];
                    } else {
                      vErrors.push(err223);
                    }
                    errors++;
                  }
                }
                if (data43.type !== void 0) {
                  if ("multipleChoice" !== data43.type) {
                    const err224 = { instancePath: instancePath + "/questions/" + i6 + "/type", schemaPath: "#/properties/questions/items/oneOf/3/properties/type/const", keyword: "const", params: { allowedValue: "multipleChoice" }, message: "must be equal to constant" };
                    if (vErrors === null) {
                      vErrors = [err224];
                    } else {
                      vErrors.push(err224);
                    }
                    errors++;
                  }
                }
                if (data43.options !== void 0) {
                  let data80 = data43.options;
                  if (Array.isArray(data80)) {
                    if (data80.length < 2) {
                      const err225 = { instancePath: instancePath + "/questions/" + i6 + "/options", schemaPath: "#/properties/questions/items/oneOf/3/properties/options/minItems", keyword: "minItems", params: { limit: 2 }, message: "must NOT have fewer than 2 items" };
                      if (vErrors === null) {
                        vErrors = [err225];
                      } else {
                        vErrors.push(err225);
                      }
                      errors++;
                    }
                    const len15 = data80.length;
                    for (let i20 = 0; i20 < len15; i20++) {
                      let data81 = data80[i20];
                      if (data81 && typeof data81 == "object" && !Array.isArray(data81)) {
                        if (data81.id === void 0) {
                          const err226 = { instancePath: instancePath + "/questions/" + i6 + "/options/" + i20, schemaPath: "#/properties/questions/items/oneOf/3/properties/options/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                          if (vErrors === null) {
                            vErrors = [err226];
                          } else {
                            vErrors.push(err226);
                          }
                          errors++;
                        }
                        if (data81.text === void 0) {
                          const err227 = { instancePath: instancePath + "/questions/" + i6 + "/options/" + i20, schemaPath: "#/properties/questions/items/oneOf/3/properties/options/items/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
                          if (vErrors === null) {
                            vErrors = [err227];
                          } else {
                            vErrors.push(err227);
                          }
                          errors++;
                        }
                        for (const key17 in data81) {
                          if (!(key17 === "id" || key17 === "text")) {
                            const err228 = { instancePath: instancePath + "/questions/" + i6 + "/options/" + i20, schemaPath: "#/properties/questions/items/oneOf/3/properties/options/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key17 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err228];
                            } else {
                              vErrors.push(err228);
                            }
                            errors++;
                          }
                        }
                        if (data81.id !== void 0) {
                          let data82 = data81.id;
                          if (typeof data82 === "string") {
                            if (func2(data82) < 1) {
                              const err229 = { instancePath: instancePath + "/questions/" + i6 + "/options/" + i20 + "/id", schemaPath: "#/properties/questions/items/oneOf/3/properties/options/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err229];
                              } else {
                                vErrors.push(err229);
                              }
                              errors++;
                            }
                          } else {
                            const err230 = { instancePath: instancePath + "/questions/" + i6 + "/options/" + i20 + "/id", schemaPath: "#/properties/questions/items/oneOf/3/properties/options/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err230];
                            } else {
                              vErrors.push(err230);
                            }
                            errors++;
                          }
                        }
                        if (data81.text !== void 0) {
                          let data83 = data81.text;
                          if (typeof data83 === "string") {
                            if (func2(data83) < 1) {
                              const err231 = { instancePath: instancePath + "/questions/" + i6 + "/options/" + i20 + "/text", schemaPath: "#/properties/questions/items/oneOf/3/properties/options/items/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err231];
                              } else {
                                vErrors.push(err231);
                              }
                              errors++;
                            }
                          } else {
                            const err232 = { instancePath: instancePath + "/questions/" + i6 + "/options/" + i20 + "/text", schemaPath: "#/properties/questions/items/oneOf/3/properties/options/items/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err232];
                            } else {
                              vErrors.push(err232);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err233 = { instancePath: instancePath + "/questions/" + i6 + "/options/" + i20, schemaPath: "#/properties/questions/items/oneOf/3/properties/options/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                        if (vErrors === null) {
                          vErrors = [err233];
                        } else {
                          vErrors.push(err233);
                        }
                        errors++;
                      }
                    }
                  } else {
                    const err234 = { instancePath: instancePath + "/questions/" + i6 + "/options", schemaPath: "#/properties/questions/items/oneOf/3/properties/options/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                    if (vErrors === null) {
                      vErrors = [err234];
                    } else {
                      vErrors.push(err234);
                    }
                    errors++;
                  }
                }
              } else {
                const err235 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/3/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                if (vErrors === null) {
                  vErrors = [err235];
                } else {
                  vErrors.push(err235);
                }
                errors++;
              }
              var _valid1 = _errs163 === errors;
              if (_valid1 && valid26) {
                valid26 = false;
                passing1 = [passing1, 3];
              } else {
                if (_valid1) {
                  valid26 = true;
                  passing1 = 3;
                  if (props1 !== true) {
                    props1 = true;
                  }
                }
                const _errs190 = errors;
                if (data43 && typeof data43 == "object" && !Array.isArray(data43)) {
                  if (data43.id === void 0) {
                    const err236 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/4/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                    if (vErrors === null) {
                      vErrors = [err236];
                    } else {
                      vErrors.push(err236);
                    }
                    errors++;
                  }
                  if (data43.prompt === void 0) {
                    const err237 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/4/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
                    if (vErrors === null) {
                      vErrors = [err237];
                    } else {
                      vErrors.push(err237);
                    }
                    errors++;
                  }
                  if (data43.maxScore === void 0) {
                    const err238 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/4/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
                    if (vErrors === null) {
                      vErrors = [err238];
                    } else {
                      vErrors.push(err238);
                    }
                    errors++;
                  }
                  if (data43.objectiveIds === void 0) {
                    const err239 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/4/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
                    if (vErrors === null) {
                      vErrors = [err239];
                    } else {
                      vErrors.push(err239);
                    }
                    errors++;
                  }
                  if (data43.hints === void 0) {
                    const err240 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/4/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
                    if (vErrors === null) {
                      vErrors = [err240];
                    } else {
                      vErrors.push(err240);
                    }
                    errors++;
                  }
                  if (data43.type === void 0) {
                    const err241 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/4/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                    if (vErrors === null) {
                      vErrors = [err241];
                    } else {
                      vErrors.push(err241);
                    }
                    errors++;
                  }
                  if (data43.blanks === void 0) {
                    const err242 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/4/required", keyword: "required", params: { missingProperty: "blanks" }, message: "must have required property 'blanks'" };
                    if (vErrors === null) {
                      vErrors = [err242];
                    } else {
                      vErrors.push(err242);
                    }
                    errors++;
                  }
                  for (const key18 in data43) {
                    if (!(key18 === "id" || key18 === "prompt" || key18 === "maxScore" || key18 === "objectiveIds" || key18 === "hints" || key18 === "type" || key18 === "blanks")) {
                      const err243 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/4/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key18 }, message: "must NOT have additional properties" };
                      if (vErrors === null) {
                        vErrors = [err243];
                      } else {
                        vErrors.push(err243);
                      }
                      errors++;
                    }
                  }
                  if (data43.id !== void 0) {
                    let data84 = data43.id;
                    if (typeof data84 === "string") {
                      if (func2(data84) < 1) {
                        const err244 = { instancePath: instancePath + "/questions/" + i6 + "/id", schemaPath: "#/properties/questions/items/oneOf/4/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                        if (vErrors === null) {
                          vErrors = [err244];
                        } else {
                          vErrors.push(err244);
                        }
                        errors++;
                      }
                    } else {
                      const err245 = { instancePath: instancePath + "/questions/" + i6 + "/id", schemaPath: "#/properties/questions/items/oneOf/4/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err245];
                      } else {
                        vErrors.push(err245);
                      }
                      errors++;
                    }
                  }
                  if (data43.prompt !== void 0) {
                    let data85 = data43.prompt;
                    if (typeof data85 === "string") {
                      if (func2(data85) < 1) {
                        const err246 = { instancePath: instancePath + "/questions/" + i6 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/4/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                        if (vErrors === null) {
                          vErrors = [err246];
                        } else {
                          vErrors.push(err246);
                        }
                        errors++;
                      }
                    } else {
                      const err247 = { instancePath: instancePath + "/questions/" + i6 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/4/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err247];
                      } else {
                        vErrors.push(err247);
                      }
                      errors++;
                    }
                  }
                  if (data43.maxScore !== void 0) {
                    let data86 = data43.maxScore;
                    if (typeof data86 == "number") {
                      if (data86 <= 0 || isNaN(data86)) {
                        const err248 = { instancePath: instancePath + "/questions/" + i6 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/4/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                        if (vErrors === null) {
                          vErrors = [err248];
                        } else {
                          vErrors.push(err248);
                        }
                        errors++;
                      }
                    } else {
                      const err249 = { instancePath: instancePath + "/questions/" + i6 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/4/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                      if (vErrors === null) {
                        vErrors = [err249];
                      } else {
                        vErrors.push(err249);
                      }
                      errors++;
                    }
                  }
                  if (data43.objectiveIds !== void 0) {
                    let data87 = data43.objectiveIds;
                    if (Array.isArray(data87)) {
                      if (data87.length < 1) {
                        const err250 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/4/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                        if (vErrors === null) {
                          vErrors = [err250];
                        } else {
                          vErrors.push(err250);
                        }
                        errors++;
                      }
                      const len16 = data87.length;
                      for (let i21 = 0; i21 < len16; i21++) {
                        let data88 = data87[i21];
                        if (typeof data88 === "string") {
                          if (func2(data88) < 1) {
                            const err251 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds/" + i21, schemaPath: "#/properties/questions/items/oneOf/4/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                            if (vErrors === null) {
                              vErrors = [err251];
                            } else {
                              vErrors.push(err251);
                            }
                            errors++;
                          }
                        } else {
                          const err252 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds/" + i21, schemaPath: "#/properties/questions/items/oneOf/4/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                          if (vErrors === null) {
                            vErrors = [err252];
                          } else {
                            vErrors.push(err252);
                          }
                          errors++;
                        }
                      }
                      let i22 = data87.length;
                      let j5;
                      if (i22 > 1) {
                        const indices5 = {};
                        for (; i22--; ) {
                          let item5 = data87[i22];
                          if (typeof item5 !== "string") {
                            continue;
                          }
                          if (typeof indices5[item5] == "number") {
                            j5 = indices5[item5];
                            const err253 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/4/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i22, j: j5 }, message: "must NOT have duplicate items (items ## " + j5 + " and " + i22 + " are identical)" };
                            if (vErrors === null) {
                              vErrors = [err253];
                            } else {
                              vErrors.push(err253);
                            }
                            errors++;
                            break;
                          }
                          indices5[item5] = i22;
                        }
                      }
                    } else {
                      const err254 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/4/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                      if (vErrors === null) {
                        vErrors = [err254];
                      } else {
                        vErrors.push(err254);
                      }
                      errors++;
                    }
                  }
                  if (data43.hints !== void 0) {
                    let data89 = data43.hints;
                    if (Array.isArray(data89)) {
                      const len17 = data89.length;
                      for (let i23 = 0; i23 < len17; i23++) {
                        let data90 = data89[i23];
                        if (typeof data90 === "string") {
                          if (func2(data90) < 1) {
                            const err255 = { instancePath: instancePath + "/questions/" + i6 + "/hints/" + i23, schemaPath: "#/properties/questions/items/oneOf/4/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                            if (vErrors === null) {
                              vErrors = [err255];
                            } else {
                              vErrors.push(err255);
                            }
                            errors++;
                          }
                        } else {
                          const err256 = { instancePath: instancePath + "/questions/" + i6 + "/hints/" + i23, schemaPath: "#/properties/questions/items/oneOf/4/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                          if (vErrors === null) {
                            vErrors = [err256];
                          } else {
                            vErrors.push(err256);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err257 = { instancePath: instancePath + "/questions/" + i6 + "/hints", schemaPath: "#/properties/questions/items/oneOf/4/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                      if (vErrors === null) {
                        vErrors = [err257];
                      } else {
                        vErrors.push(err257);
                      }
                      errors++;
                    }
                  }
                  if (data43.type !== void 0) {
                    if ("fillBlank" !== data43.type) {
                      const err258 = { instancePath: instancePath + "/questions/" + i6 + "/type", schemaPath: "#/properties/questions/items/oneOf/4/properties/type/const", keyword: "const", params: { allowedValue: "fillBlank" }, message: "must be equal to constant" };
                      if (vErrors === null) {
                        vErrors = [err258];
                      } else {
                        vErrors.push(err258);
                      }
                      errors++;
                    }
                  }
                  if (data43.blanks !== void 0) {
                    let data92 = data43.blanks;
                    if (Array.isArray(data92)) {
                      if (data92.length > 30) {
                        const err259 = { instancePath: instancePath + "/questions/" + i6 + "/blanks", schemaPath: "#/properties/questions/items/oneOf/4/properties/blanks/maxItems", keyword: "maxItems", params: { limit: 30 }, message: "must NOT have more than 30 items" };
                        if (vErrors === null) {
                          vErrors = [err259];
                        } else {
                          vErrors.push(err259);
                        }
                        errors++;
                      }
                      if (data92.length < 1) {
                        const err260 = { instancePath: instancePath + "/questions/" + i6 + "/blanks", schemaPath: "#/properties/questions/items/oneOf/4/properties/blanks/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                        if (vErrors === null) {
                          vErrors = [err260];
                        } else {
                          vErrors.push(err260);
                        }
                        errors++;
                      }
                      const len18 = data92.length;
                      for (let i24 = 0; i24 < len18; i24++) {
                        let data93 = data92[i24];
                        if (data93 && typeof data93 == "object" && !Array.isArray(data93)) {
                          if (data93.id === void 0) {
                            const err261 = { instancePath: instancePath + "/questions/" + i6 + "/blanks/" + i24, schemaPath: "#/properties/questions/items/oneOf/4/properties/blanks/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                            if (vErrors === null) {
                              vErrors = [err261];
                            } else {
                              vErrors.push(err261);
                            }
                            errors++;
                          }
                          if (data93.label === void 0) {
                            const err262 = { instancePath: instancePath + "/questions/" + i6 + "/blanks/" + i24, schemaPath: "#/properties/questions/items/oneOf/4/properties/blanks/items/required", keyword: "required", params: { missingProperty: "label" }, message: "must have required property 'label'" };
                            if (vErrors === null) {
                              vErrors = [err262];
                            } else {
                              vErrors.push(err262);
                            }
                            errors++;
                          }
                          for (const key19 in data93) {
                            if (!(key19 === "id" || key19 === "label")) {
                              const err263 = { instancePath: instancePath + "/questions/" + i6 + "/blanks/" + i24, schemaPath: "#/properties/questions/items/oneOf/4/properties/blanks/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key19 }, message: "must NOT have additional properties" };
                              if (vErrors === null) {
                                vErrors = [err263];
                              } else {
                                vErrors.push(err263);
                              }
                              errors++;
                            }
                          }
                          if (data93.id !== void 0) {
                            let data94 = data93.id;
                            if (typeof data94 === "string") {
                              if (func2(data94) < 1) {
                                const err264 = { instancePath: instancePath + "/questions/" + i6 + "/blanks/" + i24 + "/id", schemaPath: "#/properties/questions/items/oneOf/4/properties/blanks/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                if (vErrors === null) {
                                  vErrors = [err264];
                                } else {
                                  vErrors.push(err264);
                                }
                                errors++;
                              }
                            } else {
                              const err265 = { instancePath: instancePath + "/questions/" + i6 + "/blanks/" + i24 + "/id", schemaPath: "#/properties/questions/items/oneOf/4/properties/blanks/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err265];
                              } else {
                                vErrors.push(err265);
                              }
                              errors++;
                            }
                          }
                          if (data93.label !== void 0) {
                            let data95 = data93.label;
                            if (typeof data95 === "string") {
                              if (func2(data95) < 1) {
                                const err266 = { instancePath: instancePath + "/questions/" + i6 + "/blanks/" + i24 + "/label", schemaPath: "#/properties/questions/items/oneOf/4/properties/blanks/items/properties/label/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                if (vErrors === null) {
                                  vErrors = [err266];
                                } else {
                                  vErrors.push(err266);
                                }
                                errors++;
                              }
                            } else {
                              const err267 = { instancePath: instancePath + "/questions/" + i6 + "/blanks/" + i24 + "/label", schemaPath: "#/properties/questions/items/oneOf/4/properties/blanks/items/properties/label/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err267];
                              } else {
                                vErrors.push(err267);
                              }
                              errors++;
                            }
                          }
                        } else {
                          const err268 = { instancePath: instancePath + "/questions/" + i6 + "/blanks/" + i24, schemaPath: "#/properties/questions/items/oneOf/4/properties/blanks/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                          if (vErrors === null) {
                            vErrors = [err268];
                          } else {
                            vErrors.push(err268);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err269 = { instancePath: instancePath + "/questions/" + i6 + "/blanks", schemaPath: "#/properties/questions/items/oneOf/4/properties/blanks/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                      if (vErrors === null) {
                        vErrors = [err269];
                      } else {
                        vErrors.push(err269);
                      }
                      errors++;
                    }
                  }
                } else {
                  const err270 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/4/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                  if (vErrors === null) {
                    vErrors = [err270];
                  } else {
                    vErrors.push(err270);
                  }
                  errors++;
                }
                var _valid1 = _errs190 === errors;
                if (_valid1 && valid26) {
                  valid26 = false;
                  passing1 = [passing1, 4];
                } else {
                  if (_valid1) {
                    valid26 = true;
                    passing1 = 4;
                    if (props1 !== true) {
                      props1 = true;
                    }
                  }
                  const _errs217 = errors;
                  if (data43 && typeof data43 == "object" && !Array.isArray(data43)) {
                    if (data43.id === void 0) {
                      const err271 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/5/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                      if (vErrors === null) {
                        vErrors = [err271];
                      } else {
                        vErrors.push(err271);
                      }
                      errors++;
                    }
                    if (data43.prompt === void 0) {
                      const err272 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/5/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
                      if (vErrors === null) {
                        vErrors = [err272];
                      } else {
                        vErrors.push(err272);
                      }
                      errors++;
                    }
                    if (data43.maxScore === void 0) {
                      const err273 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/5/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
                      if (vErrors === null) {
                        vErrors = [err273];
                      } else {
                        vErrors.push(err273);
                      }
                      errors++;
                    }
                    if (data43.objectiveIds === void 0) {
                      const err274 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/5/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
                      if (vErrors === null) {
                        vErrors = [err274];
                      } else {
                        vErrors.push(err274);
                      }
                      errors++;
                    }
                    if (data43.hints === void 0) {
                      const err275 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/5/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
                      if (vErrors === null) {
                        vErrors = [err275];
                      } else {
                        vErrors.push(err275);
                      }
                      errors++;
                    }
                    if (data43.type === void 0) {
                      const err276 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/5/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                      if (vErrors === null) {
                        vErrors = [err276];
                      } else {
                        vErrors.push(err276);
                      }
                      errors++;
                    }
                    if (data43.left === void 0) {
                      const err277 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/5/required", keyword: "required", params: { missingProperty: "left" }, message: "must have required property 'left'" };
                      if (vErrors === null) {
                        vErrors = [err277];
                      } else {
                        vErrors.push(err277);
                      }
                      errors++;
                    }
                    if (data43.right === void 0) {
                      const err278 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/5/required", keyword: "required", params: { missingProperty: "right" }, message: "must have required property 'right'" };
                      if (vErrors === null) {
                        vErrors = [err278];
                      } else {
                        vErrors.push(err278);
                      }
                      errors++;
                    }
                    for (const key20 in data43) {
                      if (!(key20 === "id" || key20 === "prompt" || key20 === "maxScore" || key20 === "objectiveIds" || key20 === "hints" || key20 === "type" || key20 === "left" || key20 === "right")) {
                        const err279 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/5/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key20 }, message: "must NOT have additional properties" };
                        if (vErrors === null) {
                          vErrors = [err279];
                        } else {
                          vErrors.push(err279);
                        }
                        errors++;
                      }
                    }
                    if (data43.id !== void 0) {
                      let data96 = data43.id;
                      if (typeof data96 === "string") {
                        if (func2(data96) < 1) {
                          const err280 = { instancePath: instancePath + "/questions/" + i6 + "/id", schemaPath: "#/properties/questions/items/oneOf/5/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err280];
                          } else {
                            vErrors.push(err280);
                          }
                          errors++;
                        }
                      } else {
                        const err281 = { instancePath: instancePath + "/questions/" + i6 + "/id", schemaPath: "#/properties/questions/items/oneOf/5/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err281];
                        } else {
                          vErrors.push(err281);
                        }
                        errors++;
                      }
                    }
                    if (data43.prompt !== void 0) {
                      let data97 = data43.prompt;
                      if (typeof data97 === "string") {
                        if (func2(data97) < 1) {
                          const err282 = { instancePath: instancePath + "/questions/" + i6 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/5/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err282];
                          } else {
                            vErrors.push(err282);
                          }
                          errors++;
                        }
                      } else {
                        const err283 = { instancePath: instancePath + "/questions/" + i6 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/5/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err283];
                        } else {
                          vErrors.push(err283);
                        }
                        errors++;
                      }
                    }
                    if (data43.maxScore !== void 0) {
                      let data98 = data43.maxScore;
                      if (typeof data98 == "number") {
                        if (data98 <= 0 || isNaN(data98)) {
                          const err284 = { instancePath: instancePath + "/questions/" + i6 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/5/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                          if (vErrors === null) {
                            vErrors = [err284];
                          } else {
                            vErrors.push(err284);
                          }
                          errors++;
                        }
                      } else {
                        const err285 = { instancePath: instancePath + "/questions/" + i6 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/5/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                        if (vErrors === null) {
                          vErrors = [err285];
                        } else {
                          vErrors.push(err285);
                        }
                        errors++;
                      }
                    }
                    if (data43.objectiveIds !== void 0) {
                      let data99 = data43.objectiveIds;
                      if (Array.isArray(data99)) {
                        if (data99.length < 1) {
                          const err286 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/5/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                          if (vErrors === null) {
                            vErrors = [err286];
                          } else {
                            vErrors.push(err286);
                          }
                          errors++;
                        }
                        const len19 = data99.length;
                        for (let i25 = 0; i25 < len19; i25++) {
                          let data100 = data99[i25];
                          if (typeof data100 === "string") {
                            if (func2(data100) < 1) {
                              const err287 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds/" + i25, schemaPath: "#/properties/questions/items/oneOf/5/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err287];
                              } else {
                                vErrors.push(err287);
                              }
                              errors++;
                            }
                          } else {
                            const err288 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds/" + i25, schemaPath: "#/properties/questions/items/oneOf/5/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err288];
                            } else {
                              vErrors.push(err288);
                            }
                            errors++;
                          }
                        }
                        let i26 = data99.length;
                        let j6;
                        if (i26 > 1) {
                          const indices6 = {};
                          for (; i26--; ) {
                            let item6 = data99[i26];
                            if (typeof item6 !== "string") {
                              continue;
                            }
                            if (typeof indices6[item6] == "number") {
                              j6 = indices6[item6];
                              const err289 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/5/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i26, j: j6 }, message: "must NOT have duplicate items (items ## " + j6 + " and " + i26 + " are identical)" };
                              if (vErrors === null) {
                                vErrors = [err289];
                              } else {
                                vErrors.push(err289);
                              }
                              errors++;
                              break;
                            }
                            indices6[item6] = i26;
                          }
                        }
                      } else {
                        const err290 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/5/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err290];
                        } else {
                          vErrors.push(err290);
                        }
                        errors++;
                      }
                    }
                    if (data43.hints !== void 0) {
                      let data101 = data43.hints;
                      if (Array.isArray(data101)) {
                        const len20 = data101.length;
                        for (let i27 = 0; i27 < len20; i27++) {
                          let data102 = data101[i27];
                          if (typeof data102 === "string") {
                            if (func2(data102) < 1) {
                              const err291 = { instancePath: instancePath + "/questions/" + i6 + "/hints/" + i27, schemaPath: "#/properties/questions/items/oneOf/5/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err291];
                              } else {
                                vErrors.push(err291);
                              }
                              errors++;
                            }
                          } else {
                            const err292 = { instancePath: instancePath + "/questions/" + i6 + "/hints/" + i27, schemaPath: "#/properties/questions/items/oneOf/5/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err292];
                            } else {
                              vErrors.push(err292);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err293 = { instancePath: instancePath + "/questions/" + i6 + "/hints", schemaPath: "#/properties/questions/items/oneOf/5/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err293];
                        } else {
                          vErrors.push(err293);
                        }
                        errors++;
                      }
                    }
                    if (data43.type !== void 0) {
                      if ("matching" !== data43.type) {
                        const err294 = { instancePath: instancePath + "/questions/" + i6 + "/type", schemaPath: "#/properties/questions/items/oneOf/5/properties/type/const", keyword: "const", params: { allowedValue: "matching" }, message: "must be equal to constant" };
                        if (vErrors === null) {
                          vErrors = [err294];
                        } else {
                          vErrors.push(err294);
                        }
                        errors++;
                      }
                    }
                    if (data43.left !== void 0) {
                      let data104 = data43.left;
                      if (Array.isArray(data104)) {
                        if (data104.length > 30) {
                          const err295 = { instancePath: instancePath + "/questions/" + i6 + "/left", schemaPath: "#/properties/questions/items/oneOf/5/properties/left/maxItems", keyword: "maxItems", params: { limit: 30 }, message: "must NOT have more than 30 items" };
                          if (vErrors === null) {
                            vErrors = [err295];
                          } else {
                            vErrors.push(err295);
                          }
                          errors++;
                        }
                        if (data104.length < 1) {
                          const err296 = { instancePath: instancePath + "/questions/" + i6 + "/left", schemaPath: "#/properties/questions/items/oneOf/5/properties/left/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                          if (vErrors === null) {
                            vErrors = [err296];
                          } else {
                            vErrors.push(err296);
                          }
                          errors++;
                        }
                        const len21 = data104.length;
                        for (let i28 = 0; i28 < len21; i28++) {
                          let data105 = data104[i28];
                          if (data105 && typeof data105 == "object" && !Array.isArray(data105)) {
                            if (data105.id === void 0) {
                              const err297 = { instancePath: instancePath + "/questions/" + i6 + "/left/" + i28, schemaPath: "#/properties/questions/items/oneOf/5/properties/left/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                              if (vErrors === null) {
                                vErrors = [err297];
                              } else {
                                vErrors.push(err297);
                              }
                              errors++;
                            }
                            if (data105.text === void 0) {
                              const err298 = { instancePath: instancePath + "/questions/" + i6 + "/left/" + i28, schemaPath: "#/properties/questions/items/oneOf/5/properties/left/items/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
                              if (vErrors === null) {
                                vErrors = [err298];
                              } else {
                                vErrors.push(err298);
                              }
                              errors++;
                            }
                            for (const key21 in data105) {
                              if (!(key21 === "id" || key21 === "text")) {
                                const err299 = { instancePath: instancePath + "/questions/" + i6 + "/left/" + i28, schemaPath: "#/properties/questions/items/oneOf/5/properties/left/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key21 }, message: "must NOT have additional properties" };
                                if (vErrors === null) {
                                  vErrors = [err299];
                                } else {
                                  vErrors.push(err299);
                                }
                                errors++;
                              }
                            }
                            if (data105.id !== void 0) {
                              let data106 = data105.id;
                              if (typeof data106 === "string") {
                                if (func2(data106) < 1) {
                                  const err300 = { instancePath: instancePath + "/questions/" + i6 + "/left/" + i28 + "/id", schemaPath: "#/properties/questions/items/oneOf/5/properties/left/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err300];
                                  } else {
                                    vErrors.push(err300);
                                  }
                                  errors++;
                                }
                              } else {
                                const err301 = { instancePath: instancePath + "/questions/" + i6 + "/left/" + i28 + "/id", schemaPath: "#/properties/questions/items/oneOf/5/properties/left/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err301];
                                } else {
                                  vErrors.push(err301);
                                }
                                errors++;
                              }
                            }
                            if (data105.text !== void 0) {
                              let data107 = data105.text;
                              if (typeof data107 === "string") {
                                if (func2(data107) < 1) {
                                  const err302 = { instancePath: instancePath + "/questions/" + i6 + "/left/" + i28 + "/text", schemaPath: "#/properties/questions/items/oneOf/5/properties/left/items/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err302];
                                  } else {
                                    vErrors.push(err302);
                                  }
                                  errors++;
                                }
                              } else {
                                const err303 = { instancePath: instancePath + "/questions/" + i6 + "/left/" + i28 + "/text", schemaPath: "#/properties/questions/items/oneOf/5/properties/left/items/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err303];
                                } else {
                                  vErrors.push(err303);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err304 = { instancePath: instancePath + "/questions/" + i6 + "/left/" + i28, schemaPath: "#/properties/questions/items/oneOf/5/properties/left/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                            if (vErrors === null) {
                              vErrors = [err304];
                            } else {
                              vErrors.push(err304);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err305 = { instancePath: instancePath + "/questions/" + i6 + "/left", schemaPath: "#/properties/questions/items/oneOf/5/properties/left/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err305];
                        } else {
                          vErrors.push(err305);
                        }
                        errors++;
                      }
                    }
                    if (data43.right !== void 0) {
                      let data108 = data43.right;
                      if (Array.isArray(data108)) {
                        if (data108.length > 30) {
                          const err306 = { instancePath: instancePath + "/questions/" + i6 + "/right", schemaPath: "#/properties/questions/items/oneOf/5/properties/right/maxItems", keyword: "maxItems", params: { limit: 30 }, message: "must NOT have more than 30 items" };
                          if (vErrors === null) {
                            vErrors = [err306];
                          } else {
                            vErrors.push(err306);
                          }
                          errors++;
                        }
                        if (data108.length < 1) {
                          const err307 = { instancePath: instancePath + "/questions/" + i6 + "/right", schemaPath: "#/properties/questions/items/oneOf/5/properties/right/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                          if (vErrors === null) {
                            vErrors = [err307];
                          } else {
                            vErrors.push(err307);
                          }
                          errors++;
                        }
                        const len22 = data108.length;
                        for (let i29 = 0; i29 < len22; i29++) {
                          let data109 = data108[i29];
                          if (data109 && typeof data109 == "object" && !Array.isArray(data109)) {
                            if (data109.id === void 0) {
                              const err308 = { instancePath: instancePath + "/questions/" + i6 + "/right/" + i29, schemaPath: "#/properties/questions/items/oneOf/5/properties/right/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                              if (vErrors === null) {
                                vErrors = [err308];
                              } else {
                                vErrors.push(err308);
                              }
                              errors++;
                            }
                            if (data109.text === void 0) {
                              const err309 = { instancePath: instancePath + "/questions/" + i6 + "/right/" + i29, schemaPath: "#/properties/questions/items/oneOf/5/properties/right/items/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
                              if (vErrors === null) {
                                vErrors = [err309];
                              } else {
                                vErrors.push(err309);
                              }
                              errors++;
                            }
                            for (const key22 in data109) {
                              if (!(key22 === "id" || key22 === "text")) {
                                const err310 = { instancePath: instancePath + "/questions/" + i6 + "/right/" + i29, schemaPath: "#/properties/questions/items/oneOf/5/properties/right/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key22 }, message: "must NOT have additional properties" };
                                if (vErrors === null) {
                                  vErrors = [err310];
                                } else {
                                  vErrors.push(err310);
                                }
                                errors++;
                              }
                            }
                            if (data109.id !== void 0) {
                              let data110 = data109.id;
                              if (typeof data110 === "string") {
                                if (func2(data110) < 1) {
                                  const err311 = { instancePath: instancePath + "/questions/" + i6 + "/right/" + i29 + "/id", schemaPath: "#/properties/questions/items/oneOf/5/properties/right/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err311];
                                  } else {
                                    vErrors.push(err311);
                                  }
                                  errors++;
                                }
                              } else {
                                const err312 = { instancePath: instancePath + "/questions/" + i6 + "/right/" + i29 + "/id", schemaPath: "#/properties/questions/items/oneOf/5/properties/right/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err312];
                                } else {
                                  vErrors.push(err312);
                                }
                                errors++;
                              }
                            }
                            if (data109.text !== void 0) {
                              let data111 = data109.text;
                              if (typeof data111 === "string") {
                                if (func2(data111) < 1) {
                                  const err313 = { instancePath: instancePath + "/questions/" + i6 + "/right/" + i29 + "/text", schemaPath: "#/properties/questions/items/oneOf/5/properties/right/items/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err313];
                                  } else {
                                    vErrors.push(err313);
                                  }
                                  errors++;
                                }
                              } else {
                                const err314 = { instancePath: instancePath + "/questions/" + i6 + "/right/" + i29 + "/text", schemaPath: "#/properties/questions/items/oneOf/5/properties/right/items/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err314];
                                } else {
                                  vErrors.push(err314);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err315 = { instancePath: instancePath + "/questions/" + i6 + "/right/" + i29, schemaPath: "#/properties/questions/items/oneOf/5/properties/right/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                            if (vErrors === null) {
                              vErrors = [err315];
                            } else {
                              vErrors.push(err315);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err316 = { instancePath: instancePath + "/questions/" + i6 + "/right", schemaPath: "#/properties/questions/items/oneOf/5/properties/right/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err316];
                        } else {
                          vErrors.push(err316);
                        }
                        errors++;
                      }
                    }
                  } else {
                    const err317 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/5/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                    if (vErrors === null) {
                      vErrors = [err317];
                    } else {
                      vErrors.push(err317);
                    }
                    errors++;
                  }
                  var _valid1 = _errs217 === errors;
                  if (_valid1 && valid26) {
                    valid26 = false;
                    passing1 = [passing1, 5];
                  } else {
                    if (_valid1) {
                      valid26 = true;
                      passing1 = 5;
                      if (props1 !== true) {
                        props1 = true;
                      }
                    }
                    const _errs253 = errors;
                    if (data43 && typeof data43 == "object" && !Array.isArray(data43)) {
                      if (data43.id === void 0) {
                        const err318 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/6/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                        if (vErrors === null) {
                          vErrors = [err318];
                        } else {
                          vErrors.push(err318);
                        }
                        errors++;
                      }
                      if (data43.prompt === void 0) {
                        const err319 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/6/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
                        if (vErrors === null) {
                          vErrors = [err319];
                        } else {
                          vErrors.push(err319);
                        }
                        errors++;
                      }
                      if (data43.maxScore === void 0) {
                        const err320 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/6/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
                        if (vErrors === null) {
                          vErrors = [err320];
                        } else {
                          vErrors.push(err320);
                        }
                        errors++;
                      }
                      if (data43.objectiveIds === void 0) {
                        const err321 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/6/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
                        if (vErrors === null) {
                          vErrors = [err321];
                        } else {
                          vErrors.push(err321);
                        }
                        errors++;
                      }
                      if (data43.hints === void 0) {
                        const err322 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/6/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
                        if (vErrors === null) {
                          vErrors = [err322];
                        } else {
                          vErrors.push(err322);
                        }
                        errors++;
                      }
                      if (data43.type === void 0) {
                        const err323 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/6/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                        if (vErrors === null) {
                          vErrors = [err323];
                        } else {
                          vErrors.push(err323);
                        }
                        errors++;
                      }
                      if (data43.items === void 0) {
                        const err324 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/6/required", keyword: "required", params: { missingProperty: "items" }, message: "must have required property 'items'" };
                        if (vErrors === null) {
                          vErrors = [err324];
                        } else {
                          vErrors.push(err324);
                        }
                        errors++;
                      }
                      for (const key23 in data43) {
                        if (!(key23 === "id" || key23 === "prompt" || key23 === "maxScore" || key23 === "objectiveIds" || key23 === "hints" || key23 === "type" || key23 === "items")) {
                          const err325 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/6/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key23 }, message: "must NOT have additional properties" };
                          if (vErrors === null) {
                            vErrors = [err325];
                          } else {
                            vErrors.push(err325);
                          }
                          errors++;
                        }
                      }
                      if (data43.id !== void 0) {
                        let data112 = data43.id;
                        if (typeof data112 === "string") {
                          if (func2(data112) < 1) {
                            const err326 = { instancePath: instancePath + "/questions/" + i6 + "/id", schemaPath: "#/properties/questions/items/oneOf/6/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                            if (vErrors === null) {
                              vErrors = [err326];
                            } else {
                              vErrors.push(err326);
                            }
                            errors++;
                          }
                        } else {
                          const err327 = { instancePath: instancePath + "/questions/" + i6 + "/id", schemaPath: "#/properties/questions/items/oneOf/6/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                          if (vErrors === null) {
                            vErrors = [err327];
                          } else {
                            vErrors.push(err327);
                          }
                          errors++;
                        }
                      }
                      if (data43.prompt !== void 0) {
                        let data113 = data43.prompt;
                        if (typeof data113 === "string") {
                          if (func2(data113) < 1) {
                            const err328 = { instancePath: instancePath + "/questions/" + i6 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/6/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                            if (vErrors === null) {
                              vErrors = [err328];
                            } else {
                              vErrors.push(err328);
                            }
                            errors++;
                          }
                        } else {
                          const err329 = { instancePath: instancePath + "/questions/" + i6 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/6/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                          if (vErrors === null) {
                            vErrors = [err329];
                          } else {
                            vErrors.push(err329);
                          }
                          errors++;
                        }
                      }
                      if (data43.maxScore !== void 0) {
                        let data114 = data43.maxScore;
                        if (typeof data114 == "number") {
                          if (data114 <= 0 || isNaN(data114)) {
                            const err330 = { instancePath: instancePath + "/questions/" + i6 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/6/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                            if (vErrors === null) {
                              vErrors = [err330];
                            } else {
                              vErrors.push(err330);
                            }
                            errors++;
                          }
                        } else {
                          const err331 = { instancePath: instancePath + "/questions/" + i6 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/6/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                          if (vErrors === null) {
                            vErrors = [err331];
                          } else {
                            vErrors.push(err331);
                          }
                          errors++;
                        }
                      }
                      if (data43.objectiveIds !== void 0) {
                        let data115 = data43.objectiveIds;
                        if (Array.isArray(data115)) {
                          if (data115.length < 1) {
                            const err332 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/6/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                            if (vErrors === null) {
                              vErrors = [err332];
                            } else {
                              vErrors.push(err332);
                            }
                            errors++;
                          }
                          const len23 = data115.length;
                          for (let i30 = 0; i30 < len23; i30++) {
                            let data116 = data115[i30];
                            if (typeof data116 === "string") {
                              if (func2(data116) < 1) {
                                const err333 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds/" + i30, schemaPath: "#/properties/questions/items/oneOf/6/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                if (vErrors === null) {
                                  vErrors = [err333];
                                } else {
                                  vErrors.push(err333);
                                }
                                errors++;
                              }
                            } else {
                              const err334 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds/" + i30, schemaPath: "#/properties/questions/items/oneOf/6/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err334];
                              } else {
                                vErrors.push(err334);
                              }
                              errors++;
                            }
                          }
                          let i31 = data115.length;
                          let j7;
                          if (i31 > 1) {
                            const indices7 = {};
                            for (; i31--; ) {
                              let item7 = data115[i31];
                              if (typeof item7 !== "string") {
                                continue;
                              }
                              if (typeof indices7[item7] == "number") {
                                j7 = indices7[item7];
                                const err335 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/6/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i31, j: j7 }, message: "must NOT have duplicate items (items ## " + j7 + " and " + i31 + " are identical)" };
                                if (vErrors === null) {
                                  vErrors = [err335];
                                } else {
                                  vErrors.push(err335);
                                }
                                errors++;
                                break;
                              }
                              indices7[item7] = i31;
                            }
                          }
                        } else {
                          const err336 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/6/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                          if (vErrors === null) {
                            vErrors = [err336];
                          } else {
                            vErrors.push(err336);
                          }
                          errors++;
                        }
                      }
                      if (data43.hints !== void 0) {
                        let data117 = data43.hints;
                        if (Array.isArray(data117)) {
                          const len24 = data117.length;
                          for (let i32 = 0; i32 < len24; i32++) {
                            let data118 = data117[i32];
                            if (typeof data118 === "string") {
                              if (func2(data118) < 1) {
                                const err337 = { instancePath: instancePath + "/questions/" + i6 + "/hints/" + i32, schemaPath: "#/properties/questions/items/oneOf/6/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                if (vErrors === null) {
                                  vErrors = [err337];
                                } else {
                                  vErrors.push(err337);
                                }
                                errors++;
                              }
                            } else {
                              const err338 = { instancePath: instancePath + "/questions/" + i6 + "/hints/" + i32, schemaPath: "#/properties/questions/items/oneOf/6/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err338];
                              } else {
                                vErrors.push(err338);
                              }
                              errors++;
                            }
                          }
                        } else {
                          const err339 = { instancePath: instancePath + "/questions/" + i6 + "/hints", schemaPath: "#/properties/questions/items/oneOf/6/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                          if (vErrors === null) {
                            vErrors = [err339];
                          } else {
                            vErrors.push(err339);
                          }
                          errors++;
                        }
                      }
                      if (data43.type !== void 0) {
                        if ("ordering" !== data43.type) {
                          const err340 = { instancePath: instancePath + "/questions/" + i6 + "/type", schemaPath: "#/properties/questions/items/oneOf/6/properties/type/const", keyword: "const", params: { allowedValue: "ordering" }, message: "must be equal to constant" };
                          if (vErrors === null) {
                            vErrors = [err340];
                          } else {
                            vErrors.push(err340);
                          }
                          errors++;
                        }
                      }
                      if (data43.items !== void 0) {
                        let data120 = data43.items;
                        if (Array.isArray(data120)) {
                          if (data120.length > 30) {
                            const err341 = { instancePath: instancePath + "/questions/" + i6 + "/items", schemaPath: "#/properties/questions/items/oneOf/6/properties/items/maxItems", keyword: "maxItems", params: { limit: 30 }, message: "must NOT have more than 30 items" };
                            if (vErrors === null) {
                              vErrors = [err341];
                            } else {
                              vErrors.push(err341);
                            }
                            errors++;
                          }
                          if (data120.length < 1) {
                            const err342 = { instancePath: instancePath + "/questions/" + i6 + "/items", schemaPath: "#/properties/questions/items/oneOf/6/properties/items/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                            if (vErrors === null) {
                              vErrors = [err342];
                            } else {
                              vErrors.push(err342);
                            }
                            errors++;
                          }
                          const len25 = data120.length;
                          for (let i33 = 0; i33 < len25; i33++) {
                            let data121 = data120[i33];
                            if (data121 && typeof data121 == "object" && !Array.isArray(data121)) {
                              if (data121.id === void 0) {
                                const err343 = { instancePath: instancePath + "/questions/" + i6 + "/items/" + i33, schemaPath: "#/properties/questions/items/oneOf/6/properties/items/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                                if (vErrors === null) {
                                  vErrors = [err343];
                                } else {
                                  vErrors.push(err343);
                                }
                                errors++;
                              }
                              if (data121.text === void 0) {
                                const err344 = { instancePath: instancePath + "/questions/" + i6 + "/items/" + i33, schemaPath: "#/properties/questions/items/oneOf/6/properties/items/items/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
                                if (vErrors === null) {
                                  vErrors = [err344];
                                } else {
                                  vErrors.push(err344);
                                }
                                errors++;
                              }
                              for (const key24 in data121) {
                                if (!(key24 === "id" || key24 === "text")) {
                                  const err345 = { instancePath: instancePath + "/questions/" + i6 + "/items/" + i33, schemaPath: "#/properties/questions/items/oneOf/6/properties/items/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key24 }, message: "must NOT have additional properties" };
                                  if (vErrors === null) {
                                    vErrors = [err345];
                                  } else {
                                    vErrors.push(err345);
                                  }
                                  errors++;
                                }
                              }
                              if (data121.id !== void 0) {
                                let data122 = data121.id;
                                if (typeof data122 === "string") {
                                  if (func2(data122) < 1) {
                                    const err346 = { instancePath: instancePath + "/questions/" + i6 + "/items/" + i33 + "/id", schemaPath: "#/properties/questions/items/oneOf/6/properties/items/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err346];
                                    } else {
                                      vErrors.push(err346);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err347 = { instancePath: instancePath + "/questions/" + i6 + "/items/" + i33 + "/id", schemaPath: "#/properties/questions/items/oneOf/6/properties/items/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err347];
                                  } else {
                                    vErrors.push(err347);
                                  }
                                  errors++;
                                }
                              }
                              if (data121.text !== void 0) {
                                let data123 = data121.text;
                                if (typeof data123 === "string") {
                                  if (func2(data123) < 1) {
                                    const err348 = { instancePath: instancePath + "/questions/" + i6 + "/items/" + i33 + "/text", schemaPath: "#/properties/questions/items/oneOf/6/properties/items/items/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err348];
                                    } else {
                                      vErrors.push(err348);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err349 = { instancePath: instancePath + "/questions/" + i6 + "/items/" + i33 + "/text", schemaPath: "#/properties/questions/items/oneOf/6/properties/items/items/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err349];
                                  } else {
                                    vErrors.push(err349);
                                  }
                                  errors++;
                                }
                              }
                            } else {
                              const err350 = { instancePath: instancePath + "/questions/" + i6 + "/items/" + i33, schemaPath: "#/properties/questions/items/oneOf/6/properties/items/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                              if (vErrors === null) {
                                vErrors = [err350];
                              } else {
                                vErrors.push(err350);
                              }
                              errors++;
                            }
                          }
                        } else {
                          const err351 = { instancePath: instancePath + "/questions/" + i6 + "/items", schemaPath: "#/properties/questions/items/oneOf/6/properties/items/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                          if (vErrors === null) {
                            vErrors = [err351];
                          } else {
                            vErrors.push(err351);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err352 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/6/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err352];
                      } else {
                        vErrors.push(err352);
                      }
                      errors++;
                    }
                    var _valid1 = _errs253 === errors;
                    if (_valid1 && valid26) {
                      valid26 = false;
                      passing1 = [passing1, 6];
                    } else {
                      if (_valid1) {
                        valid26 = true;
                        passing1 = 6;
                        if (props1 !== true) {
                          props1 = true;
                        }
                      }
                      const _errs280 = errors;
                      if (data43 && typeof data43 == "object" && !Array.isArray(data43)) {
                        if (data43.id === void 0) {
                          const err353 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/7/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                          if (vErrors === null) {
                            vErrors = [err353];
                          } else {
                            vErrors.push(err353);
                          }
                          errors++;
                        }
                        if (data43.prompt === void 0) {
                          const err354 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/7/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
                          if (vErrors === null) {
                            vErrors = [err354];
                          } else {
                            vErrors.push(err354);
                          }
                          errors++;
                        }
                        if (data43.maxScore === void 0) {
                          const err355 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/7/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
                          if (vErrors === null) {
                            vErrors = [err355];
                          } else {
                            vErrors.push(err355);
                          }
                          errors++;
                        }
                        if (data43.objectiveIds === void 0) {
                          const err356 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/7/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
                          if (vErrors === null) {
                            vErrors = [err356];
                          } else {
                            vErrors.push(err356);
                          }
                          errors++;
                        }
                        if (data43.hints === void 0) {
                          const err357 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/7/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
                          if (vErrors === null) {
                            vErrors = [err357];
                          } else {
                            vErrors.push(err357);
                          }
                          errors++;
                        }
                        if (data43.type === void 0) {
                          const err358 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/7/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                          if (vErrors === null) {
                            vErrors = [err358];
                          } else {
                            vErrors.push(err358);
                          }
                          errors++;
                        }
                        for (const key25 in data43) {
                          if (!(key25 === "id" || key25 === "prompt" || key25 === "maxScore" || key25 === "objectiveIds" || key25 === "hints" || key25 === "type")) {
                            const err359 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/7/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key25 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err359];
                            } else {
                              vErrors.push(err359);
                            }
                            errors++;
                          }
                        }
                        if (data43.id !== void 0) {
                          let data124 = data43.id;
                          if (typeof data124 === "string") {
                            if (func2(data124) < 1) {
                              const err360 = { instancePath: instancePath + "/questions/" + i6 + "/id", schemaPath: "#/properties/questions/items/oneOf/7/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err360];
                              } else {
                                vErrors.push(err360);
                              }
                              errors++;
                            }
                          } else {
                            const err361 = { instancePath: instancePath + "/questions/" + i6 + "/id", schemaPath: "#/properties/questions/items/oneOf/7/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err361];
                            } else {
                              vErrors.push(err361);
                            }
                            errors++;
                          }
                        }
                        if (data43.prompt !== void 0) {
                          let data125 = data43.prompt;
                          if (typeof data125 === "string") {
                            if (func2(data125) < 1) {
                              const err362 = { instancePath: instancePath + "/questions/" + i6 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/7/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err362];
                              } else {
                                vErrors.push(err362);
                              }
                              errors++;
                            }
                          } else {
                            const err363 = { instancePath: instancePath + "/questions/" + i6 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/7/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err363];
                            } else {
                              vErrors.push(err363);
                            }
                            errors++;
                          }
                        }
                        if (data43.maxScore !== void 0) {
                          let data126 = data43.maxScore;
                          if (typeof data126 == "number") {
                            if (data126 <= 0 || isNaN(data126)) {
                              const err364 = { instancePath: instancePath + "/questions/" + i6 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/7/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                              if (vErrors === null) {
                                vErrors = [err364];
                              } else {
                                vErrors.push(err364);
                              }
                              errors++;
                            }
                          } else {
                            const err365 = { instancePath: instancePath + "/questions/" + i6 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/7/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                            if (vErrors === null) {
                              vErrors = [err365];
                            } else {
                              vErrors.push(err365);
                            }
                            errors++;
                          }
                        }
                        if (data43.objectiveIds !== void 0) {
                          let data127 = data43.objectiveIds;
                          if (Array.isArray(data127)) {
                            if (data127.length < 1) {
                              const err366 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/7/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                              if (vErrors === null) {
                                vErrors = [err366];
                              } else {
                                vErrors.push(err366);
                              }
                              errors++;
                            }
                            const len26 = data127.length;
                            for (let i34 = 0; i34 < len26; i34++) {
                              let data128 = data127[i34];
                              if (typeof data128 === "string") {
                                if (func2(data128) < 1) {
                                  const err367 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds/" + i34, schemaPath: "#/properties/questions/items/oneOf/7/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err367];
                                  } else {
                                    vErrors.push(err367);
                                  }
                                  errors++;
                                }
                              } else {
                                const err368 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds/" + i34, schemaPath: "#/properties/questions/items/oneOf/7/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err368];
                                } else {
                                  vErrors.push(err368);
                                }
                                errors++;
                              }
                            }
                            let i35 = data127.length;
                            let j8;
                            if (i35 > 1) {
                              const indices8 = {};
                              for (; i35--; ) {
                                let item8 = data127[i35];
                                if (typeof item8 !== "string") {
                                  continue;
                                }
                                if (typeof indices8[item8] == "number") {
                                  j8 = indices8[item8];
                                  const err369 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/7/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i35, j: j8 }, message: "must NOT have duplicate items (items ## " + j8 + " and " + i35 + " are identical)" };
                                  if (vErrors === null) {
                                    vErrors = [err369];
                                  } else {
                                    vErrors.push(err369);
                                  }
                                  errors++;
                                  break;
                                }
                                indices8[item8] = i35;
                              }
                            }
                          } else {
                            const err370 = { instancePath: instancePath + "/questions/" + i6 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/7/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                            if (vErrors === null) {
                              vErrors = [err370];
                            } else {
                              vErrors.push(err370);
                            }
                            errors++;
                          }
                        }
                        if (data43.hints !== void 0) {
                          let data129 = data43.hints;
                          if (Array.isArray(data129)) {
                            const len27 = data129.length;
                            for (let i36 = 0; i36 < len27; i36++) {
                              let data130 = data129[i36];
                              if (typeof data130 === "string") {
                                if (func2(data130) < 1) {
                                  const err371 = { instancePath: instancePath + "/questions/" + i6 + "/hints/" + i36, schemaPath: "#/properties/questions/items/oneOf/7/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err371];
                                  } else {
                                    vErrors.push(err371);
                                  }
                                  errors++;
                                }
                              } else {
                                const err372 = { instancePath: instancePath + "/questions/" + i6 + "/hints/" + i36, schemaPath: "#/properties/questions/items/oneOf/7/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err372];
                                } else {
                                  vErrors.push(err372);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err373 = { instancePath: instancePath + "/questions/" + i6 + "/hints", schemaPath: "#/properties/questions/items/oneOf/7/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                            if (vErrors === null) {
                              vErrors = [err373];
                            } else {
                              vErrors.push(err373);
                            }
                            errors++;
                          }
                        }
                        if (data43.type !== void 0) {
                          if ("upload" !== data43.type) {
                            const err374 = { instancePath: instancePath + "/questions/" + i6 + "/type", schemaPath: "#/properties/questions/items/oneOf/7/properties/type/const", keyword: "const", params: { allowedValue: "upload" }, message: "must be equal to constant" };
                            if (vErrors === null) {
                              vErrors = [err374];
                            } else {
                              vErrors.push(err374);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err375 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf/7/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                        if (vErrors === null) {
                          vErrors = [err375];
                        } else {
                          vErrors.push(err375);
                        }
                        errors++;
                      }
                      var _valid1 = _errs280 === errors;
                      if (_valid1 && valid26) {
                        valid26 = false;
                        passing1 = [passing1, 7];
                      } else {
                        if (_valid1) {
                          valid26 = true;
                          passing1 = 7;
                          if (props1 !== true) {
                            props1 = true;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
          if (!valid26) {
            const err376 = { instancePath: instancePath + "/questions/" + i6, schemaPath: "#/properties/questions/items/oneOf", keyword: "oneOf", params: { passingSchemas: passing1 }, message: "must match exactly one schema in oneOf" };
            if (vErrors === null) {
              vErrors = [err376];
            } else {
              vErrors.push(err376);
            }
            errors++;
          } else {
            errors = _errs99;
            if (vErrors !== null) {
              if (_errs99) {
                vErrors.length = _errs99;
              } else {
                vErrors = null;
              }
            }
          }
        }
      } else {
        const err377 = { instancePath: instancePath + "/questions", schemaPath: "#/properties/questions/type", keyword: "type", params: { type: "array" }, message: "must be array" };
        if (vErrors === null) {
          vErrors = [err377];
        } else {
          vErrors.push(err377);
        }
        errors++;
      }
    }
    if (data.releaseState !== void 0) {
      let data132 = data.releaseState;
      if (data132 && typeof data132 == "object" && !Array.isArray(data132)) {
        if (data132.score === void 0) {
          const err378 = { instancePath: instancePath + "/releaseState", schemaPath: "#/properties/releaseState/required", keyword: "required", params: { missingProperty: "score" }, message: "must have required property 'score'" };
          if (vErrors === null) {
            vErrors = [err378];
          } else {
            vErrors.push(err378);
          }
          errors++;
        }
        if (data132.answers === void 0) {
          const err379 = { instancePath: instancePath + "/releaseState", schemaPath: "#/properties/releaseState/required", keyword: "required", params: { missingProperty: "answers" }, message: "must have required property 'answers'" };
          if (vErrors === null) {
            vErrors = [err379];
          } else {
            vErrors.push(err379);
          }
          errors++;
        }
        if (data132.feedback === void 0) {
          const err380 = { instancePath: instancePath + "/releaseState", schemaPath: "#/properties/releaseState/required", keyword: "required", params: { missingProperty: "feedback" }, message: "must have required property 'feedback'" };
          if (vErrors === null) {
            vErrors = [err380];
          } else {
            vErrors.push(err380);
          }
          errors++;
        }
        for (const key26 in data132) {
          if (!(key26 === "score" || key26 === "answers" || key26 === "feedback")) {
            const err381 = { instancePath: instancePath + "/releaseState", schemaPath: "#/properties/releaseState/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key26 }, message: "must NOT have additional properties" };
            if (vErrors === null) {
              vErrors = [err381];
            } else {
              vErrors.push(err381);
            }
            errors++;
          }
        }
        if (data132.score !== void 0) {
          if (false !== data132.score) {
            const err382 = { instancePath: instancePath + "/releaseState/score", schemaPath: "#/properties/releaseState/properties/score/const", keyword: "const", params: { allowedValue: false }, message: "must be equal to constant" };
            if (vErrors === null) {
              vErrors = [err382];
            } else {
              vErrors.push(err382);
            }
            errors++;
          }
        }
        if (data132.answers !== void 0) {
          if (false !== data132.answers) {
            const err383 = { instancePath: instancePath + "/releaseState/answers", schemaPath: "#/properties/releaseState/properties/answers/const", keyword: "const", params: { allowedValue: false }, message: "must be equal to constant" };
            if (vErrors === null) {
              vErrors = [err383];
            } else {
              vErrors.push(err383);
            }
            errors++;
          }
        }
        if (data132.feedback !== void 0) {
          if (false !== data132.feedback) {
            const err384 = { instancePath: instancePath + "/releaseState/feedback", schemaPath: "#/properties/releaseState/properties/feedback/const", keyword: "const", params: { allowedValue: false }, message: "must be equal to constant" };
            if (vErrors === null) {
              vErrors = [err384];
            } else {
              vErrors.push(err384);
            }
            errors++;
          }
        }
      } else {
        const err385 = { instancePath: instancePath + "/releaseState", schemaPath: "#/properties/releaseState/type", keyword: "type", params: { type: "object" }, message: "must be object" };
        if (vErrors === null) {
          vErrors = [err385];
        } else {
          vErrors.push(err385);
        }
        errors++;
      }
    }
  } else {
    const err386 = { instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" };
    if (vErrors === null) {
      vErrors = [err386];
    } else {
      vErrors.push(err386);
    }
    errors++;
  }
  validate22.errors = vErrors;
  return errors === 0;
}
validate22.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
export {
  generate_request,
  generate_result,
  student_content
};
