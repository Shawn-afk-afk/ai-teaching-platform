import {Registry} from '../registries/capabilities.js';
import {AppError} from '../contracts/errors.js';
import {checkText,readyCoverage,MAX_TEXT_BYTES} from '../domain/materials.js';
export class ParserRegistry extends Registry {
  async parse(type,input){
    const entry=this.get(type);
    if(entry.state!=='enabled'||typeof entry.parse!=='function') throw new AppError('UNSUPPORTED_FORMAT','此解析格式尚未啟用，請先貼上文字。');
    return entry.parse(input);
  }
}
export const parsers=new ParserRegistry();
export async function parseTxt(file){
  if(!file||typeof file.arrayBuffer!=='function'||! /\.txt$/i.test(file.name??'')||!['','text/plain'].includes(file.type??''))throw new AppError('UNSUPPORTED_FORMAT','目前只接受 UTF-8 .txt 檔案。PDF、DOCX 與 OCR 尚未啟用。');
  if(file.size>MAX_TEXT_BYTES)throw new AppError('FILE_TOO_LARGE','TXT 上限為 1 MiB，請拆分教材。');
  let text;
  try{const data=await file.arrayBuffer();if(data.byteLength>MAX_TEXT_BYTES)throw new AppError('FILE_TOO_LARGE','TXT 上限為 1 MiB。');text=new TextDecoder('utf-8',{fatal:true}).decode(data);}
  catch(e){if(e instanceof AppError)throw e;throw new AppError('UNSUPPORTED_FORMAT','檔案無法讀取或不是有效 UTF-8；請另存 UTF-8 TXT 後再試。');}
  if(text.startsWith('%PDF-')||text.startsWith('PK\u0003\u0004'))throw new AppError('UNSUPPORTED_FORMAT','檔案內容不是純文字，不能只改副檔名為 TXT。');
  checkText(text);return {text,originalText:text,originalName:file.name,mimeType:'text/plain',parseStatus:'ready',coverage:readyCoverage(text)};
}
parsers.register({type:'text/plain',state:'enabled',parse:parseTxt});
for(const type of ['application/pdf','application/vnd.openxmlformats-officedocument.wordprocessingml.document','image/ocr'])parsers.register({type,state:'disabled'});
