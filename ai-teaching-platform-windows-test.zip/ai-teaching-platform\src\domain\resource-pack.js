import {validateContract} from '../contracts/validate.js';
import {validateContent,contentOfVersion} from './content.js';
import {reject} from './assessment.js';
import {timestamp} from './rules.js';
import {versionFor,requestVersion} from './extended-questions.js';
export const PACK_FORMAT='ai-teaching-resource-pack',MAX_PACK_BYTES=5*1024*1024;
const clone=structuredClone;
function keys(value,allowed){if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).some(k=>!allowed.includes(k))||allowed.some(k=>!Object.hasOwn(value,k)))reject('教材包欄位遺漏或包含未知欄位。');}
export function makePack(project,versionId,now){
  const v=project.versions?.find(v=>v.id===versionId);if(!v)reject('請選擇已發布版本。');const c=v.context;
  if(!c)reject('此版本沒有可攜來源快照。');
  const content=contentOfVersion(v),chunks=clone(c.chunks),sources=[...new Set(chunks.map(c=>c.sourceId))].map(id=>({id,revision:chunks.find(c=>c.sourceId===id).sourceRevision,text:chunks.filter(c=>c.sourceId===id).map(c=>c.text).join('\n')}));
  const pack={format:PACK_FORMAT,packageVersion:1,schemaVersion:versionFor(content),exportedAt:now,manifest:{scope:'one-published-version',sourceScope:'published-chunks-only',attachments:'none',studentData:false,inputMode:c.inputMode},resources:[{id:v.resourceId,projectId:project.id,sourceMaterialIds:sources.map(s=>s.id),profileId:v.profileId,type:v.resourceType,currentDraftId:null,latestPublishedVersionId:v.id}],versions:[{content,versionNo:v.versionNo,publishedAt:v.publishedAt}],profiles:[clone(c.profile)],objectives:c.objectives.map(({id,description})=>({id,description})),sources,chunks};
  validatePack(pack);return pack;
}
export function validatePack(pack){
  keys(pack,['format','packageVersion','schemaVersion','exportedAt','manifest','resources','versions','profiles','objectives','sources','chunks']);
  if(pack.format!==PACK_FORMAT||pack.packageVersion!==1||!['2.0.0','3.0.0'].includes(pack.schemaVersion))reject('不支援的教材包版本，原檔不會被改動。','UNSUPPORTED_FORMAT');
  try{timestamp(pack.exportedAt);}catch{reject('教材包匯出時間無效。');}
  keys(pack.manifest,['scope','sourceScope','attachments','studentData','inputMode']);
  if(pack.manifest.scope!=='one-published-version'||pack.manifest.sourceScope!=='published-chunks-only'||pack.manifest.attachments!=='none'||pack.manifest.studentData!==false||!['source','topic'].includes(pack.manifest.inputMode))reject('教材包範圍或附件宣告不支援。');
  for(const name of ['resources','versions','profiles','objectives','sources','chunks'])if(!Array.isArray(pack[name]))reject('教材包集合格式無效。');
  if(pack.resources.length!==1||pack.versions.length!==1||pack.profiles.length!==1||pack.sources.length>1)reject('目前每包支援一個發布版本與一份文字來源快照。');
  const r=pack.resources[0],v=pack.versions[0];if(versionFor(v.content)!==pack.schemaVersion)reject('教材包版本與內容不符。');keys(v,['content','versionNo','publishedAt']);validateContract('resource',r);
  if(!Number.isInteger(v.versionNo)||v.versionNo<1)reject('發布版本號無效。');try{timestamp(v.publishedAt);}catch{reject('發布時間無效。');}
  const context={inputMode:pack.manifest.inputMode,chunks:pack.chunks,objectives:pack.objectives,profile:pack.profiles[0]};
  const request={schemaVersion:pack.schemaVersion,requestId:'pack-check',task:'generateResources',inputMode:context.inputMode,projectId:r.projectId,topicDescription:v.content.title,sourceChunks:pack.chunks,objectives:pack.objectives,profile:context.profile,outputSpec:{resourceType:r.type,title:v.content.title,questionCount:v.content.questions?.length??0,questionTypes:[...new Set((v.content.questions??[]).map(q=>q.type))]}};
  validateContract('generate-request',request);validateContent(v.content,context);
  if(v.content.resourceId!==r.id||v.content.id!==r.latestPublishedVersionId||r.currentDraftId!==null||v.content.profileId!==r.profileId||r.type!==v.content.resourceType)reject('教材包的資源、版本或分支參照不一致。');
  if(new Set(pack.objectives.map(o=>o.id)).size!==pack.objectives.length||new Set(pack.chunks.map(c=>c.id)).size!==pack.chunks.length)reject('教材包包含重複引用識別碼。');
  for(const s of pack.sources){keys(s,['id','revision','text']);if(typeof s.id!=='string'||!s.id||typeof s.text!=='string'||!Number.isInteger(s.revision)||s.revision<1)reject('來源快照格式無效。');}
  if((context.inputMode==='source'&&pack.sources.length!==1)||(context.inputMode==='topic'&&(pack.sources.length||pack.chunks.length)))reject('來源模式與來源快照不一致。');
  if(r.sourceMaterialIds.length!==pack.sources.length||r.sourceMaterialIds.some(id=>!pack.sources.some(s=>s.id===id)))reject('來源參照不一致。');
  if(pack.chunks.some(c=>!pack.sources.some(s=>s.id===c.sourceId&&s.revision===c.sourceRevision)))reject('段落與來源修訂不一致。');
  for(const s of pack.sources)if(s.text!==pack.chunks.filter(c=>c.sourceId===s.id).map(c=>c.text).join('\n'))reject('來源快照文字與段落不一致。');
  return pack;
}
export function parsePack(text){if(typeof text!=='string'||new TextEncoder().encode(text).length>MAX_PACK_BYTES)reject('教材包上限為 5 MiB。','FILE_TOO_LARGE');let value;try{value=JSON.parse(text);}catch{reject('不是有效的 JSON 教材包。');}try{return validatePack(value);}catch(e){if(e.code)throw e;reject('教材包結構不完整，請使用本平台輸出的格式。');}}
export function packIds(pack){const c=pack.versions[0].content;return [...new Set([pack.resources[0].id,c.id,c.profileId,...pack.objectives.map(o=>o.id),...pack.sources.map(s=>s.id),...pack.chunks.map(c=>c.id),...c.blocks.flatMap(b=>[b.id,...(b.data.entries??b.data.nodes??[]).map(x=>x.id)]),...c.questions.flatMap(q=>[q.id,...['options','blanks','left','right','items'].flatMap(k=>(q[k]??[]).map(o=>o.id))])])];}
export function importAsDraft(pack,actor,now){
  validatePack(pack);const map=new Map(packIds(pack).map(id=>[id,crypto.randomUUID()])),id=crypto.randomUUID(),remap=value=>map.get(value),v=pack.versions[0],content=clone(v.content);
  for(const k of ['id','resourceId','profileId'])content[k]=remap(content[k]);content.objectiveIds=content.objectiveIds.map(remap);
  for(const item of [...content.blocks,...content.questions]){item.id=remap(item.id);item.sourceRefs=item.sourceRefs.map(r=>({...r,sourceId:remap(r.sourceId),chunkId:remap(r.chunkId)}));if(item.type==='questionSet')item.data.questionIds=item.data.questionIds.map(remap);if(item.objectiveIds)item.objectiveIds=item.objectiveIds.map(remap);
   for(const key of ['options','blanks','left','right','items'])if(item[key])item[key]=item[key].map(o=>({...o,id:remap(o.id)}));
   if(item.type==='singleChoice')item.answerKey=remap(item.answerKey);
   if(['multipleChoice','ordering'].includes(item.type))item.answerKey=item.answerKey.map(remap);
   if(item.type==='matching')item.answerKey=Object.fromEntries(Object.entries(item.answerKey).map(([k,v])=>[remap(k),remap(v)]));
   if(item.type==='vocabularyList')item.data.entries=item.data.entries.map(e=>({...e,id:remap(e.id)}));
   if(item.type==='organizer'){item.data.nodes=item.data.nodes.map(e=>({...e,id:remap(e.id)}));item.data.edges=item.data.edges.map(e=>({...e,from:remap(e.from),to:remap(e.to)}));}
  }
  const profile={...clone(pack.profiles[0]),id:remap(pack.profiles[0].id)},objectives=pack.objectives.map(o=>({...o,id:remap(o.id),projectId:id,teacherConfirmed:false})),chunks=pack.chunks.map(c=>({...clone(c),id:remap(c.id),sourceId:remap(c.sourceId)}));
  const sourcePack=pack.sources[0],text=sourcePack?.text??content.title,source={id:sourcePack?remap(sourcePack.id):crypto.randomUUID(),projectId:id,inputMode:pack.manifest.inputMode,sourceType:sourcePack?'text':'topic',text,originalText:text,originalName:null,mimeType:sourcePack?'text/plain':null,revision:sourcePack?.revision??1,parseStatus:'ready',coverage:{unit:sourcePack?'paragraph':'topic',total:sourcePack?chunks.length:null,processed:sourcePack?chunks.length:0,missing:[]}};
  const context={inputMode:source.inputMode,chunks,objectives,profile};validateContent(content,context);
  const resource={id:content.resourceId,projectId:id,profileId:profile.id,sourceMaterialIds:sourcePack?[source.id]:[],type:content.resourceType,currentDraftId:content.id,latestPublishedVersionId:null};validateContract('resource',resource);
  return {id,title:content.title+'（匯入副本）',tenantId:actor.tenantId,ownerId:actor.actorId,status:'active',source,sourceHistory:[],preparation:null,analysisCandidate:null,resources:[resource],profiles:[profile],drafts:[{id:content.id,revision:1,content,context,parentVersionId:null,provenance:{origin:'imported',provider:'resource-pack',generatedAt:null,teacherReviewedAt:null},importedFrom:{versionId:v.content.id,versionNo:v.versionNo,publishedAt:v.publishedAt,exportedAt:pack.exportedAt}}],versions:[],jobs:[],publishKeys:[],updatedAt:now};
}
