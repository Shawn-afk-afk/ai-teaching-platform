export class AppError extends Error {
  constructor(code, message, {retryable=false, details=[]}={}) {
    super(message); this.name='AppError'; this.code=code; this.retryable=retryable; this.details=details;
  }
}
export function classifyError(error){
 if(error instanceof AppError)return error;
 if(error?.name==='AbortError')return new AppError('JOB_CANCELLED','已取消操作；既有內容保持不變。');
 if(['ENOSPC','EACCES','EROFS','SQLITE_FULL','SQLITE_BUSY'].includes(error?.code)||/^ERR_SQLITE/.test(error?.code??''))return new AppError('STORAGE_UNAVAILABLE','資料保存失敗；請確認磁碟空間、檔案權限或資料庫占用狀態。',{retryable:true});
 return new AppError('OPERATION_FAILED','操作發生未預期錯誤；輸入已保留，請提供追蹤碼查詢。');
}
export function errorEnvelope(error, requestId=error?.requestId??crypto.randomUUID()) {
  return {error:error instanceof AppError ? {code:error.code,message:error.message,retryable:error.retryable,details:error.details} :
    {code:'OPERATION_FAILED',message:'操作發生未預期錯誤；輸入已保留，請提供追蹤碼查詢。',retryable:false,details:[]},requestId};
}
