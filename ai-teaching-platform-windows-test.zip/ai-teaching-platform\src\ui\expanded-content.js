import {el,button,field} from './content-editor.js';
import {TYPE_LABELS,answerLabel} from '../domain/extended-questions.js';
const uid=()=>crypto.randomUUID();
export function editExtra(card,q,update,redraw){
 if(q.type==='multipleChoice'){
  for(const o of q.options){const row=field('選項文字',o.text,v=>{o.text=v;update();});row.append(field('此項為正解',q.answerKey.includes(o.id),v=>{q.answerKey=v?[...q.answerKey,o.id]:q.answerKey.filter(id=>id!==o.id);update();},{type:'checkbox'}),button('移除選項',()=>{q.options=q.options.filter(x=>x!==o);q.answerKey=q.answerKey.filter(id=>id!==o.id);redraw();}));card.append(row);}
  card.append(button('新增選項',()=>{q.options.push({id:uid(),text:''});redraw();}));
 }else if(q.type==='fillBlank'){
  for(const b of q.blanks)card.append(field('空格名稱',b.label,v=>{b.label=v;update();}),field('可接受答案（每行一種；忽略英文大小寫與首尾空白）',b.answers.join('\n'),v=>{b.answers=v.split('\n').filter(s=>s.trim());update();},{type:'textarea'}),button('移除此空格',()=>{q.blanks=q.blanks.filter(x=>x!==b);redraw();}));
  card.append(button('新增空格',()=>{q.blanks.push({id:uid(),label:`第 ${q.blanks.length+1} 格`,answers:[]});redraw();}));
 }else if(q.type==='matching'){
  for(const l of q.left)card.append(field('左側項目',l.text,v=>{l.text=v;update();}),field('正確配對',q.answerKey[l.id],v=>{q.answerKey[l.id]=v;update();},{options:[['','請選擇'],...q.right.map(r=>[r.id,r.text])]}));
  for(const r of q.right)card.append(field('右側項目',r.text,v=>{r.text=v;update();}));
  card.append(button('新增配對組',()=>{const l={id:uid(),text:'新項目'},r={id:uid(),text:'新對應'};q.left.push(l);q.right.push(r);q.answerKey[l.id]=r.id;redraw();}),button('移除最後一組',()=>{const l=q.left.pop(),r=q.right.pop();if(l)delete q.answerKey[l.id];for(const k of Object.keys(q.answerKey))if(q.answerKey[k]===r?.id)q.answerKey[k]='';redraw();}));
 }else if(q.type==='ordering'){
  for(const item of q.items)card.append(field('排序項目文字',item.text,v=>{item.text=v;update();}));
  const order=el('ol');q.answerKey.forEach((id,i)=>{const row=el('li',q.items.find(x=>x.id===id)?.text??'無效項目');for(const [delta,label]of [[-1,'答案上移'],[1,'答案下移']])row.append(button(label,()=>{const next=i+delta;if(next>=0&&next<q.answerKey.length){[q.answerKey[i],q.answerKey[next]]=[q.answerKey[next],q.answerKey[i]];redraw();}}));order.append(row);});card.append(el('p','正確順序（全對才得分）'),order,button('新增排序項目',()=>{const item={id:uid(),text:'新項目'};q.items.push(item);q.answerKey.push(item.id);redraw();}),button('移除最後項目',()=>{const item=q.items.pop();q.answerKey=q.answerKey.filter(id=>id!==item?.id);redraw();}));
 }else if(q.type==='upload')card.append(el('p','PDF／DOCX／TXT／PNG／JPG；每題最多五檔，每檔 20 MiB；教師人工評分。'),field('作品評分規準',q.rubric,v=>{q.rubric=v;update();},{type:'textarea'}));
}
export function editRichBlock(card,b,update,redraw){
 if(b.type==='vocabularyList'){
  for(const entry of b.data.entries){for(const [key,label]of [['term','詞彙'],['definition','詞義'],['example','例句（改編內容請明示）']])card.append(field(label,entry[key],v=>{entry[key]=v;update();},{type:key==='definition'?'textarea':'text'}));card.append(button('移除此詞條',()=>{b.data.entries=b.data.entries.filter(e=>e!==entry);redraw();}));}
  card.append(button('新增詞條',()=>{b.data.entries.push({id:uid(),term:'新詞彙',definition:'請填寫詞義',example:''});redraw();}));
 }else{
  card.append(field('概念圖標題',b.data.title,v=>{b.data.title=v;update();}));
  for(const node of b.data.nodes)card.append(field('概念節點',node.label,v=>{node.label=v;update();}),button('移除節點',()=>{b.data.nodes=b.data.nodes.filter(n=>n!==node);b.data.edges=b.data.edges.filter(e=>e.from!==node.id&&e.to!==node.id);redraw();}));
  const choices=b.data.nodes.map(n=>[n.id,n.label]);for(const edge of b.data.edges)card.append(field('連線起點',edge.from,v=>{edge.from=v;update();},{options:choices}),field('連線終點',edge.to,v=>{edge.to=v;update();},{options:choices}),field('關係文字',edge.label,v=>{edge.label=v;update();}),button('移除連線',()=>{b.data.edges=b.data.edges.filter(e=>e!==edge);redraw();}));
  card.append(button('新增概念節點',()=>{b.data.nodes.push({id:uid(),label:'新概念'});redraw();}),button('新增關係連線',()=>{if(b.data.nodes.length<2)return;b.data.edges.push({from:b.data.nodes[0].id,to:b.data.nodes[1].id,label:'關聯'});redraw();}));
 }
}
export function renderRichBlock(b){
 const root=el('section','',{class:'rich-block'});
 if(b.type==='vocabularyList'){const list=el('dl');for(const e of b.data.entries)list.append(el('dt',e.term),el('dd',e.definition),el('dd',e.example));root.append(list);}
 else{root.append(el('h4',b.data.title));const nodes=el('div','',{class:'organizer-nodes'}),relations=el('ul');for(const n of b.data.nodes){const box=button(n.label,()=>{for(const row of relations.children)row.hidden=!row.dataset.nodes.split(',').includes(n.id);});box.className='concept-node';nodes.append(box);}for(const e of b.data.edges)relations.append(el('li',`${b.data.nodes.find(n=>n.id===e.from)?.label} → ${e.label} → ${b.data.nodes.find(n=>n.id===e.to)?.label}`,{'data-nodes':`${e.from},${e.to}`}));root.append(nodes,button('顯示所有關係',()=>{for(const row of relations.children)row.hidden=false;}),relations);}
 return root;
}
export function studentExtra(card,q,value,update,{upload,files=[]}={}){
 if(q.type==='multipleChoice'){const selected=new Set(value??[]);for(const o of q.options)card.append(field(o.text,selected.has(o.id),v=>{v?selected.add(o.id):selected.delete(o.id);update([...selected]);},{type:'checkbox'}));}
 else if(q.type==='fillBlank'){const answer={...value};for(const b of q.blanks)card.append(field(b.label,answer[b.id]??'',v=>{answer[b.id]=v;update({...answer});}));}
 else if(q.type==='matching'){const answer={...value};for(const l of q.left)card.append(field(l.text,answer[l.id]??'',v=>{answer[l.id]=v;update({...answer});},{options:[['','尚未配對'],...q.right.map(r=>[r.id,r.text])]}));}
 else if(q.type==='ordering'){
  let ids=value?.length?[...value]:q.items.map(x=>x.id);const list=el('ol');const draw=()=>{list.replaceChildren();ids.forEach((id,i)=>{const row=el('li',q.items.find(x=>x.id===id)?.text??'');for(const [delta,label]of [[-1,'上移'],[1,'下移']]){const b=button(label,()=>{const next=i+delta;if(next<0||next>=ids.length)return;[ids[i],ids[next]]=[ids[next],ids[i]];update([...ids]);draw();});b.disabled=i+delta<0||i+delta>=ids.length;row.append(b);}list.append(row);});};draw();card.append(list,button('確認目前順序',()=>update([...ids])),button('清空作答',()=>{update(null);}));
 }else if(q.type==='upload'){
  let ids=[...(value??[])];const status=el('p','',{role:'status'}),list=el('ul'),input=el('input','',{type:'file',multiple:'',accept:'.pdf,.docx,.txt,.png,.jpg,.jpeg'});
  const draw=()=>{list.replaceChildren();for(const id of ids){const meta=files.find(f=>f.id===id),row=el('li');row.append(el('a',meta?.name??'已上傳作品',{href:`/api/works/${id}`,download:''}),button('移除此作品',()=>{ids=ids.filter(x=>x!==id);update([...ids]);draw();}));list.append(row);}};draw();
  input.addEventListener('change',async()=>{if(!upload)return;input.disabled=true;try{for(const file of input.files){if(ids.length>=5)throw Error('每題最多五個檔案。');status.textContent=`正在上傳 ${file.name}`;const meta=await upload(q,file,ids);files.push(meta);ids.push(meta.id);update([...ids]);draw();}status.textContent='上傳完成；請保存作答或提交。';}catch(e){status.textContent=e.message;}finally{input.disabled=false;input.value='';}});
  card.append(el('p','每題最多五檔，每檔 20 MiB。PDF／DOCX／TXT／PNG／JPG，由教師人工給分。'),input,list,status);
 }
}
