import {api,uploadTextbook} from './api.js';
import {el,button,field} from '../ui/content-editor.js';
export async function mountKnowledge(root){
 const section=el('section','',{class:'wide',id:'knowledge-base'});root.querySelector('main').prepend(section);
 let subject='英文',query='',busy=false;const selected=new Set();
 const status=el('p','',{role:'status'}),cards=el('div'),chips=el('div');
 const input=el('input','',{id:'knowledge-files',name:'knowledgeFiles',type:'file',multiple:'',accept:'.pdf,.docx,.txt,.md,.csv'});input.hidden=true;
 const choose=button('選擇檔案',()=>input.click());
 const refresh=async()=>{const units=await api('/api/knowledge?'+new URLSearchParams({subject}));chips.replaceChildren();selected.clear();for(const unit of units){const f=field(`${unit.id} · ${unit.title}`,false,value=>value?selected.add(unit.id):selected.delete(unit.id),{type:'checkbox'});chips.append(f);}};
 input.addEventListener('change',async()=>{if(busy)return;busy=true;choose.disabled=true;cards.replaceChildren();const count=input.files.length;
  for(let i=0;i<count;i++){
   const file=input.files[i];status.textContent=`⏳ 正在逐檔讀取並解析 ${count} 個教材檔案 (抽取課文、單字與句型結構)... ${i+1}/${count}：${file.name}`;
   try{const result=await uploadTextbook(file,subject);const card=el('p',result.is_scanned_image?`${file.name}：${result.message}`:`${file.name}：${result.updated?'已更新':'已索引'} ${result.id} ${result.title}；${result.encoding??'文件文字層'}。${result.warnings?.join('；')??''}`);if(result.is_scanned_image){card.style.backgroundColor='#fff3cd';card.style.padding='1rem';card.setAttribute('role','alert');}cards.append(card);}catch(e){cards.append(el('p',`${file.name}：${e.message}`,{role:'alert'}));}
  }
  input.value='';busy=false;choose.disabled=false;status.textContent=`已完成 ${count} 個檔案的逐檔處理；請查看個別結果。`;await refresh();
 });
 section.append(el('h2','教材知識庫與出題範圍'),field('科目',subject,v=>{if(busy)return;subject=v;void refresh();}),choose,input,status,cards,chips,field('檢索詞／出題主題',query,v=>query=v),button('檢索並載入出題來源',async()=>{
  try{const result=await api('/api/knowledge/retrieve',{method:'POST',data:{subject,unitIds:[...selected],query}});if(!result.chunks.length){status.textContent='沒有相關片段，請調整科目、單元或檢索詞。';return;}
   if(!confirm('將檢索片段載入教材文字欄；請先確認目前輸入已保存。是否繼續？'))return;
   const source=root.querySelector('#source-text');source.value=result.chunks.map(c=>`[來源 ${c.unitId}：${c.title}／${c.locator.kind} ${c.locator.index}]\n${c.text}`).join('\n');root.querySelector('#input-mode').value='source';source.dispatchEvent(new Event('input',{bubbles:true}));status.textContent=`已載入 ${result.chunks.length} 個來源片段。請保存專案並核對學習目標後生成；本次為科目限定關鍵詞檢索。`;root.dispatchEvent(new CustomEvent('teaching:source'));
  }catch(e){status.textContent=e.message;}
 }));await refresh();
}
