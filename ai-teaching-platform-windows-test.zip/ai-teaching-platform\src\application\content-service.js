import {AppError,classifyError} from '../contracts/errors.js';
import {validateContract} from '../contracts/validate.js';
import {sourceChunks} from '../domain/materials.js';
import {validateContent,contentOfVersion,ENABLED_RESOURCES,fail} from '../domain/content.js';
import {requestVersion} from '../domain/extended-questions.js';
const copy=structuredClone, now=()=>new Date().toISOString(), uid=()=>crypto.randomUUID();
function ensureWorkspace(p){if(!p)fail('專案不存在。','VERSION_CONFLICT');p.resources??=[];p.drafts??=[];p.versions??=[];p.profiles??=[];p.jobs??=[];p.publishKeys??=[];return p;}
function checkRevision(p,revision){if(!p||p.revision!==revision)fail('專案已更新，請重新載入後再操作。','VERSION_CONFLICT');if(p.status==='archived')fail('請先恢復封存專案再編修。');}
function draftEntry(p,resourceId){const resource=p.resources.find(r=>r.id===resourceId);const entry=p.drafts.find(d=>d.id===resource?.currentDraftId);if(!resource||!entry)fail('沒有可編輯草稿，請先從發布版本另開修訂。');return {resource,entry};}
export class ContentService {
  constructor(repository,ai,{timeoutMs=10000}={}){this.repository=repository;this.ai=ai;this.timeoutMs=timeoutMs;}
  async getProject(projectId){return this.repository.get(projectId);}
  async generationStatus(projectId,{profile,spec}){const p=ensureWorkspace(await this.repository.get(projectId));if(!this.ai.generationStatus)return {state:'idle',completed:0,total:0};return this.ai.generationStatus({projectId,sourceChunks:sourceChunks(p.source),profile,objectives:(p.preparation?.objectives??[]).map(({id,description})=>({id,description})),outputSpec:spec});}
  async validateDraft(projectId,revision,resourceId,content){const p=ensureWorkspace(await this.repository.get(projectId));checkRevision(p,revision);const {entry}=draftEntry(p,resourceId);validateContent(content,entry.context);return {valid:true};}
  async analysisStatus(projectId){const p=ensureWorkspace(await this.repository.get(projectId));return this.ai.analysisStatus?this.ai.analysisStatus({projectId,inputMode:p.source.inputMode,sourceChunks:sourceChunks(p.source)}):{state:'idle',completed:0,total:0};}
  async analyze(projectId,revision,{signal}={}){
    const p=ensureWorkspace(await this.repository.get(projectId));checkRevision(p,revision);
    if(!['ready','partial'].includes(p.source.parseStatus??'ready'))fail('來源尚未可用。');
    const candidate=await this.ai.analyzeMaterials({projectId,inputMode:p.source.inputMode,text:p.source.text,sourceChunks:sourceChunks(p.source)},{signal});
    if(signal?.aborted)throw new AppError('JOB_CANCELLED','教材分析已取消。');
    if(candidate?.origin!==(this.ai.mode??'mock')||['summary','concepts','vocabulary','objectiveText'].some(k=>typeof candidate[k]!=='string'||!candidate[k].trim()&&k==='objectiveText'))fail('分析結果格式不符。','MODEL_OUTPUT_INVALID');
    p.analysisCandidate={...copy(candidate),sourceRevision:p.source.revision,createdAt:now()};
    // An analysis proposal never approves the source or objectives.
    p.preparation=null;return this.repository.save(p,revision,{signal});
  }
  async prepare(projectId,revision,{objectiveText,summary='',concepts='',vocabulary='',scopeAccepted=false}){
    const p=ensureWorkspace(await this.repository.get(projectId));checkRevision(p,revision);
    if(!scopeAccepted)fail('請先核對並確認來源範圍。');
    if(!['ready','partial'].includes(p.source.parseStatus??'ready'))fail('來源尚未可用，不能進行生成。');
    const descriptions=objectiveText.split('\n').map(s=>s.trim()).filter(Boolean);
    if(!descriptions.length)fail('請填寫並確認至少一個學習目標。');
    p.preparation={sourceRevision:p.source.revision,reviewedAt:now(),scopeAccepted:true,partial:p.source.parseStatus==='partial',summary,concepts,vocabulary,origin:p.analysisCandidate?.sourceRevision===p.source.revision?(p.analysisCandidate.origin==='model'?'model-reviewed-by-teacher':'mock-reviewed-by-teacher'):'teacher',objectives:descriptions.map((description,i)=>({id:p.preparation?.objectives[i]?.id??uid(),projectId,description,teacherConfirmed:true}))};
    return this.repository.save(p,revision);
  }
  async generate(projectId,revision,{profile,spec},{signal,onState=()=>{}}={}){
    let p=ensureWorkspace(await this.repository.get(projectId));checkRevision(p,revision);
    if(!p.preparation?.scopeAccepted||p.preparation.sourceRevision!==p.source.revision)fail('來源已更新或尚未核對，請先確認範圍與目標。');
    if(!ENABLED_RESOURCES.includes(spec.resourceType))fail('此資源類型未啟用。','UNSUPPORTED_FORMAT');
    if(!Number.isInteger(spec.questionCount)||spec.questionCount<0||spec.questionCount>100||(spec.questionCount>0&&!spec.questionTypes.length))fail('請填寫 0～100 題；有題數時至少選擇一種題型。');
    const requestId=uid(),jobId=uid(),profileData={...copy(profile),id:uid()};
    const request={schemaVersion:requestVersion(spec),requestId,task:'generateResources',inputMode:p.source.inputMode,projectId,topicDescription:p.source.inputMode==='topic'?p.source.text:p.title,sourceChunks:sourceChunks(p.source),objectives:p.preparation.objectives.map(({id,description})=>({id,description})),profile:profileData,outputSpec:copy(spec)};
    validateContract('generate-request',request);
    const job={id:jobId,requestId,state:'queued',origin:this.ai.mode??'mock',createdAt:now(),sourceRevision:p.source.revision,generationSettings:{profile:copy(profile),spec:copy(spec)}};
    p.jobs.push(job);p=await this.repository.save(p,revision,{signal});onState({state:'queued',requestId});
    const abort=new AbortController();let timer;
    const relay=()=>abort.abort(new AppError('JOB_CANCELLED','模擬生成已取消；既有草稿保持不變。'));
    signal?.addEventListener('abort',relay,{once:true});if(signal?.aborted)relay();
    const cancelled=new Promise((_,reject)=>{const stop=()=>reject(abort.signal.reason);if(abort.signal.aborted)stop();else abort.signal.addEventListener('abort',stop,{once:true});});
    try{
      onState({state:'running',requestId});
      if(!this.ai.managesTimeout)timer=setTimeout(()=>abort.abort(new AppError('UPSTREAM_TIMEOUT','生成逾時，既有草稿保持不變，可重新嘗試。',{retryable:true})),this.timeoutMs);
      let result=await Promise.race([this.ai.generateResources(copy(request),{signal:abort.signal}),cancelled]);
      if(abort.signal.aborted)throw abort.signal.reason;
      onState({state:'validating',requestId});
      try{if(typeof result==='string')result=JSON.parse(result);validateContract('generate-result',result);}catch{fail('模擬服務回傳無效結構；沒有建立新草稿。','MODEL_OUTPUT_INVALID');}
      if(result.requestId!==requestId||result.origin!==(this.ai.mode??'mock')||result.resources.length!==1)fail('生成結果與本次請求不符。','MODEL_OUTPUT_INVALID');
      const content=copy(result.resources[0]);
      if(content.profileId!==profileData.id||content.resourceType!==spec.resourceType||content.questions.length!==spec.questionCount||content.questions.some(q=>!spec.questionTypes.includes(q.type)))fail('生成內容與類型、分支或題數設定不符。','MODEL_OUTPUT_INVALID');
      const context={inputMode:p.source.inputMode,chunks:copy(request.sourceChunks),objectives:copy(p.preparation.objectives),profile:copy(profileData)};
      try{validateContent(content,context);}catch(e){fail(e.message,'MODEL_OUTPUT_INVALID');}
      content.id=uid();content.resourceId=uid();
      const resource={id:content.resourceId,projectId,sourceMaterialIds:p.source.inputMode==='source'?[p.source.id]:[],profileId:profileData.id,type:content.resourceType,currentDraftId:content.id,latestPublishedVersionId:null};
      validateContract('resource',resource);
      const provenance={origin:result.origin,generationJobId:jobId,provider:result.providerInfo.provider,modelId:result.providerInfo.modelId,promptTemplateVersion:result.origin==='model'?(this.ai.promptVersionFor?.(spec)??'p6-firsts-2'):'local-template-1',generatedAt:now(),teacherReviewedAt:null};
      const latest=ensureWorkspace(await this.repository.get(projectId));
      if(latest.status==='archived'||latest.source.revision!==p.source.revision||JSON.stringify(latest.preparation)!==JSON.stringify(p.preparation))fail('生成期間來源或目標已更新，結果未套用。','VERSION_CONFLICT');
      p=latest;
      p.resources.push(resource);p.profiles.push(profileData);p.drafts.push({id:content.id,revision:1,content,context,provenance,parentVersionId:null});
      Object.assign(p.jobs.find(j=>j.id===jobId),{state:'succeeded',finishedAt:now(),warnings:result.warnings});
      p=await this.repository.save(p,p.revision,{signal:abort.signal});onState({state:'succeeded',requestId});return {project:p,resourceId:resource.id};
    }catch(error){
      const e=classifyError(error);
      const state=e.code==='JOB_CANCELLED'?'cancelled':'failed';
      // Only job metadata is updated on failure; never write the old project over newer edits.
      try{const latest=ensureWorkspace(await this.repository.get(projectId));const target=latest.jobs.find(j=>j.id===jobId);if(target){Object.assign(target,{state,error:{code:e.code,message:e.message},finishedAt:now()});await this.repository.save(latest,latest.revision);}}catch{/* A storage/conflict failure remains visible through the thrown error. */}
      onState({state,requestId});throw e;
    }finally{clearTimeout(timer);signal?.removeEventListener('abort',relay);}
  }
  async saveDraft(projectId,revision,resourceId,content,expectedDraftRevision){
    const p=ensureWorkspace(await this.repository.get(projectId));checkRevision(p,revision);const {resource,entry}=draftEntry(p,resourceId);
    if(entry.revision!==expectedDraftRevision||content.id!==entry.id||content.resourceId!==resourceId||content.resourceType!==resource.type)fail('草稿識別或修訂不符。','VERSION_CONFLICT');
    validateContent(content,entry.context);entry.content=copy(content);entry.revision++;entry.provenance.teacherReviewedAt=null;
    return this.repository.save(p,revision);
  }
  async publish(projectId,revision,resourceId,draftRevision,idempotencyKey,reviewed){
    if(!reviewed)fail('請明確確認已審核內容、答案與規準。');
    if(typeof idempotencyKey!=='string'||!idempotencyKey)fail('發布需要有效操作識別。');
    const p=ensureWorkspace(await this.repository.get(projectId));
    const previous=p.publishKeys.find(k=>k.key===idempotencyKey);
    if(previous){const active=p.resources.find(r=>r.id===resourceId)?.currentDraftId;if(previous.resourceId!==resourceId||previous.draftRevision!==draftRevision||(active&&active!==previous.draftId))fail('相同發布識別用於不同內容。','IDEMPOTENCY_CONFLICT');return {project:p,versionId:previous.versionId};}
    checkRevision(p,revision);const {resource,entry}=draftEntry(p,resourceId);
    if(entry.revision!==draftRevision)fail('草稿已更新，請重新審核。','VERSION_CONFLICT');
    validateContract('resource',resource);validateContent(entry.content,entry.context);
    const versions=p.versions.filter(v=>v.resourceId===resource.id);
    const version={...copy(entry.content),id:uid(),versionNo:versions.length+1,parentVersionId:resource.latestPublishedVersionId,publishedAt:now(),provenance:{...copy(entry.provenance),teacherReviewedAt:now()},context:copy(entry.context)};
    if(version.parentVersionId&&!versions.some(v=>v.id===version.parentVersionId))fail('發布版本鏈不可跨資源。');
    p.versions.push(version);resource.latestPublishedVersionId=version.id;resource.currentDraftId=null;
    p.publishKeys.push({key:idempotencyKey,resourceId,draftId:entry.id,draftRevision,versionId:version.id});
    return {project:await this.repository.save(p,revision),versionId:version.id};
  }
  async revise(projectId,revision,resourceId){
    const p=ensureWorkspace(await this.repository.get(projectId));checkRevision(p,revision);const r=p.resources.find(r=>r.id===resourceId);
    if(!r||r.currentDraftId)fail('已有草稿或找不到資源，請先選擇正確資源。');
    const v=p.versions.find(v=>v.id===r.latestPublishedVersionId);if(!v)fail('尚無發布版本可修訂。');
    const content=contentOfVersion(v);content.id=uid();
    p.drafts.push({id:content.id,revision:1,content,context:copy(v.context),provenance:{...copy(v.provenance),teacherReviewedAt:null},parentVersionId:v.id});r.currentDraftId=content.id;
    return this.repository.save(p,revision);
  }
}
