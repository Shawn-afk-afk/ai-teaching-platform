import {mkdtemp,rm} from 'node:fs/promises';
import {createWriteStream} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {pipeline} from 'node:stream/promises';
import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {randomUUID} from 'node:crypto';
import {AppError} from '../src/contracts/errors.js';
export class KnowledgeBase{
 constructor(db){this.db=db;db.exec(`CREATE TABLE IF NOT EXISTS kb_units(owner TEXT,subject TEXT,id TEXT,name TEXT,title TEXT,batch TEXT,encoding TEXT,warnings TEXT,PRIMARY KEY(owner,subject,id));CREATE UNIQUE INDEX IF NOT EXISTS kb_name ON kb_units(owner,subject,name);CREATE TABLE IF NOT EXISTS kb_chunks(owner TEXT,batch TEXT,seq INTEGER,locator TEXT,text TEXT);CREATE INDEX IF NOT EXISTS kb_batch ON kb_chunks(owner,batch);`);}
 list(owner,subject){return this.db.prepare('SELECT id,name,title,encoding,warnings FROM kb_units WHERE owner=? AND subject=? ORDER BY id').all(owner,subject);}
 async ingest(req,owner,{name,subject='未分類',unitId}){
  if(!/\.(pdf|docx|txt|md|csv)$/i.test(name??''))throw new AppError('UNSUPPORTED_FORMAT','僅支援 PDF、DOCX、TXT、MD、CSV。');
  if(!subject.trim())throw new AppError('VALIDATION_FAILED','請填科目。');
  unitId??=/^(Unit_\d+)\b/i.exec(name)?.[1];
  const batch=randomUUID(),dir=await mkdtemp(join(tmpdir(),'teaching-ingest-')),file=join(dir,'upload');let child;
  try{
   await pipeline(req,createWriteStream(file));
   child=spawn(process.env.PDF_PYTHON??'C:\\Program Files\\WindowsApps\\OpenAI.CodexPrimaryRuntime.v26-1119-907-0_26.1119.907.0_x64__3k8sg7r9htsxt\\dependencies\\python\\python.exe',[resolve('tools/ingest_textbook.py'),file,name],{windowsHide:true,stdio:['ignore','pipe','pipe']});
   let stderr='';child.stderr.on('data',b=>{stderr=(stderr+b.toString()).slice(-4000);});
   const finished=new Promise((ok,no)=>{child.once('error',no);child.once('close',code=>code===0?ok():no(new Error(stderr)));});finished.catch(()=>{});
   const insert=this.db.prepare('INSERT INTO kb_chunks VALUES(?,?,?,?,?)');let seq=0,end;
   for await(const line of createInterface({input:child.stdout})){const record=JSON.parse(line);if(record.type==='text'){
    for(let i=0;i<record.text.length;i+=1800)insert.run(owner,batch,++seq,JSON.stringify(record.locator),record.text.slice(i,i+1800));
   }else if(record.type==='end')end=record;}
   await finished;if(!end)throw Error('Parser returned no completion record');
   if(end.is_scanned_image){this.db.prepare('DELETE FROM kb_chunks WHERE owner=? AND batch=?').run(owner,batch);return {name,is_scanned_image:true,indexed:false,message:'文字少於 30 字：請改傳含文字層 PDF 或直接貼上課文。'};}
   if(end.warnings.some(w=>w.startsWith('Page ')))throw Error(end.warnings.join('; '));
   if(!end.characters)throw Error('No readable text');
   const old=this.db.prepare('SELECT * FROM kb_units WHERE owner=? AND subject=? AND (name=? OR id=?)').all(owner,subject,name,unitId??'');
   if(old.length>1)throw Error('檔名與 Unit ID 指向不同單元，請修正 Unit ID');
   const used=this.list(owner,subject);const id=old[0]?.id??unitId??`Unit_${String(Math.max(0,...used.map(x=>Number(x.id.replace('Unit_',''))||0))+1).padStart(2,'0')}`;
   const generic=/^(新建文件|未命名|untitled|document|scan|\d+)/i.test(name);
   const preview=end.preview.map(x=>x.trim()).filter(x=>x.length>=4&&x.length<=100&&!/^(track|page|\d|thinking ahead|reading selection)/i.test(x));
   const title=generic?(preview[0]??id):name.replace(/\.[^.]+$/,'');
   this.db.exec('BEGIN IMMEDIATE');try{
    if(old[0])this.db.prepare('DELETE FROM kb_chunks WHERE owner=? AND batch=?').run(owner,old[0].batch);
    this.db.prepare('INSERT INTO kb_units VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(owner,subject,id) DO UPDATE SET name=excluded.name,title=excluded.title,batch=excluded.batch,encoding=excluded.encoding,warnings=excluded.warnings').run(owner,subject,id,name,title,batch,end.encoding,JSON.stringify(end.warnings));
    this.db.exec('COMMIT');
   }catch(e){this.db.exec('ROLLBACK');throw e;}
   return {id,title,name,subject,indexed:true,updated:!!old[0],characters:end.characters,encoding:end.encoding,warnings:end.warnings};
  }catch(e){this.db.prepare('DELETE FROM kb_chunks WHERE owner=? AND batch=?').run(owner,batch);throw new AppError('INGEST_FAILED',`教材匯入失敗：${e.message}`);}
  finally{child?.kill();await rm(dir,{recursive:true,force:true});}
 }
 retrieve(owner,{subject,unitIds,query=''}){
  if(!subject||!Array.isArray(unitIds)||!unitIds.length)throw new AppError('VALIDATION_FAILED','請選科目與至少一個單元。');
  const units=this.list(owner,subject).filter(x=>unitIds.includes(x.id));
  const terms=[...new Set(query.toLowerCase().match(/[a-z0-9]+|[\u3400-\u9fff]/g)??[])];
  const best=[];
  for(const unit of units){const batch=this.db.prepare('SELECT batch FROM kb_units WHERE owner=? AND subject=? AND id=?').get(owner,subject,unit.id).batch;
   for(const row of this.db.prepare('SELECT seq,locator,text FROM kb_chunks WHERE owner=? AND batch=? ORDER BY seq').iterate(owner,batch)){
    const score=terms.reduce((n,t)=>n+(row.text.toLowerCase().includes(t)?1:0),0);if(terms.length&&!score)continue;
    best.push({...row,unitId:unit.id,title:unit.title,score});best.sort((a,b)=>b.score-a.score||a.seq-b.seq);if(best.length>6)best.pop();
   }
  }
  return {subject,method:'scoped-keyword-retrieval',chunks:best.map(x=>({...x,locator:JSON.parse(x.locator)})),warnings:['檢索範圍為選定科目及單元；僅回傳相關片段，不代表完整教材分析。']};
 }
}
