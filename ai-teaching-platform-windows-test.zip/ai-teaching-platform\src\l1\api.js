import {AppError} from '../contracts/errors.js';
let csrf=null;
export async function uploadWork({projectId,attemptId,questionId,file,current}){
 if(file.size>20*1024*1024)throw new AppError('FILE_TOO_LARGE','作品每檔上限 20 MiB。');
 const response=await fetch('/api/student/works?'+new URLSearchParams({projectId,attemptId,questionId,name:file.name,current:JSON.stringify(current)}),{method:'POST',headers:{'X-CSRF-Token':csrf??'','Content-Type':'application/octet-stream'},body:file});
 const value=await response.json();if(!response.ok)throw new AppError(value.error?.code??'UPLOAD_FAILED',value.error?.message??'作品上傳失敗。');return value;
}
export async function uploadTextbook(file,subject){
 const response=await fetch('/api/knowledge/file?'+new URLSearchParams({name:file.name,subject}),{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/octet-stream','X-CSRF-Token':csrf??''},body:file});
 const value=await response.json();if(!response.ok)throw new AppError(value.error?.code??'INGEST_FAILED',value.error?.message??'教材上傳失敗');return value;
}
export async function api(path,{method='GET',data,signal}={}){
  const requestId=crypto.randomUUID();let response;
  try{response=await fetch(path,{method,credentials:'same-origin',cache:'no-store',headers:{'X-Request-ID':requestId,...(method==='POST'?{'Content-Type':'application/json','X-CSRF-Token':csrf??''}:{})},body:method==='POST'?JSON.stringify(data??{}):undefined,signal});}
  catch(error){const e=new AppError(signal?.aborted||error.name==='AbortError'?'JOB_CANCELLED':'NETWORK_UNAVAILABLE',signal?.aborted||error.name==='AbortError'?'已取消操作；既有內容保持不變。':'無法連線至平台後端；請確認服務仍啟動，輸入已保留。',{retryable:!signal?.aborted});e.requestId=requestId;throw e;}
  let value;try{value=await response.json();}catch{const e=new AppError('INVALID_SERVER_RESPONSE','後端回應無法解析；請提供追蹤碼查詢。');e.requestId=response.headers.get('X-Request-ID')??requestId;throw e;}
  if(!response.ok){const e=new AppError(value.error?.code??'SERVER_ERROR',value.error?.message??'後端操作失敗。',{retryable:value.error?.retryable,details:value.error?.details});e.requestId=value.requestId??response.headers.get('X-Request-ID')??requestId;if(response.status===401)window.dispatchEvent(new Event('l1-auth-expired'));throw e;}return value;
}
export async function me(){const value=await api('/api/me');csrf=value.csrf;return value;}
export async function login(path,data){const value=await api(path,{method:'POST',data});csrf=value.csrf;return value;}
export function remoteService(group,names){return Object.fromEntries(names.map(name=>[name,async(...args)=>{
  let options;if(group==='content'&&name==='generate'){options=args[3];args=args.slice(0,3);options?.onState?.({state:'running',requestId:'server'});}
  if(group==='content'&&name==='analyze'){options=args[2];args=args.slice(0,2);}
  return api(`/api/teacher/${group}/${name}`,{method:'POST',data:{args},signal:options?.signal});
}]));}
export function authExpiry(root){const listener=()=>{root.dataset.authExpired='true';let notice=root.querySelector('#auth-expired');if(!notice){notice=document.createElement('p');notice.id='auth-expired';notice.setAttribute('role','alert');notice.textContent='登入已失效。未保存的輸入仍保留；請先複製需要的文字，再重新登入。';const link=document.createElement('a');link.href='/';link.textContent='重新登入';notice.append(' ',link);root.prepend(notice);}root.querySelectorAll('fieldset').forEach(f=>f.disabled=true);};window.addEventListener('l1-auth-expired',listener);return ()=>window.removeEventListener('l1-auth-expired',listener);}
