import {validateContract} from '../contracts/validate.js';
import {AppError} from '../contracts/errors.js';
import {ENABLED_RESOURCES} from '../domain/content.js';
import {EXTRA_TYPES,versionFor} from '../domain/extended-questions.js';
import {extraTemplate,decorateResource} from '../domain/expansion-templates.js';
export class TemplateAI {
  mode='mock';
  async analyzeMaterials({inputMode,text,sourceChunks:chunks}){
    const excerpt=inputMode==='source'?chunks.slice(0,2).map(c=>c.text).join('\n'):text;
    const phrases=text.split(/[，。！？、,\n\r\t ]+/).map(s=>s.trim()).filter(s=>s&&s.length<=16).slice(0,5);
    return {origin:'mock',summary:`【mock 原文摘錄，非語義摘要】\n${excerpt}`,concepts:phrases.join('\n'),vocabulary:'',objectiveText:'能以自己的話說明本次教材的核心內容（請教師具體化）',sourceRefs:chunks.slice(0,2).map(c=>({sourceId:c.sourceId,sourceRevision:c.sourceRevision,chunkId:c.id})),warnings:['概念欄僅切分原文短句；詞彙待教師補充。沒有呼叫真實模型。']};
  }
  async generateResources(request,{signal}={}){
    validateContract('generate-request',request);
    if(!ENABLED_RESOURCES.includes(request.outputSpec.resourceType))throw new AppError('UNSUPPORTED_FORMAT','此資源類型尚未啟用。');
    if(signal?.aborted)throw new AppError('JOB_CANCELLED','模擬生成已取消。');
    // Yield to allow the user to cancel. No model, translation or semantic analysis is performed.
    await new Promise(resolve=>setTimeout(resolve,80));
    const id=()=>crypto.randomUUID(),source=request.inputMode==='source',chunks=request.sourceChunks;
    const refs=c=>c?[{sourceId:c.sourceId,sourceRevision:c.sourceRevision,chunkId:c.id}]:[];
    const first=chunks[0],objectiveIds=request.objectives.map(o=>o.id),profile=request.profile;
    const blocks=[{id:id(),type:'heading',data:{text:request.outputSpec.title},visibility:'both',sourceRefs:refs(first)}];
    const paragraphs=source?chunks:[{text:`教學主題：${request.topicDescription}。這是 mock 範本，請教師自行撰寫教材內容。`}];
    for(const chunk of paragraphs)blocks.push({id:id(),type:'paragraph',data:{text:chunk.text},visibility:'both',sourceRefs:source?refs(chunk):[]});
    const questions=[];
    for(let i=0;i<request.outputSpec.questionCount;i++){
      const type=request.outputSpec.questionTypes[i%request.outputSpec.questionTypes.length];
      if(!type)throw new AppError('VALIDATION_FAILED','有題數時至少選擇一種題型。');
      const chunk=chunks[i%chunks.length],excerpt=chunk?.text??request.topicDescription;
      const q={id:id(),type,prompt:'',maxScore:type==='shortAnswer'?3:1,objectiveIds,sourceRefs:source?refs(chunk):[],hints:profile.readingLoad.vocabularySupport?['請回看對應來源段落。']:[]};
      if(type==='singleChoice'){q.prompt=`【mock 原文辨識】哪一項與${source?'來源原文':'教學主題'}完全相同？`;q.options=[{id:id(),text:excerpt},{id:id(),text:`不同敘述：${excerpt}`}];q.answerKey=q.options[0].id;q.scoring='exactMatch';}
      if(type==='trueFalse'){q.prompt=`【mock 原文核對】「${excerpt}」是${source?'來源原文':'本次教學主題'}的文字。`;q.answerKey=true;q.scoring='exactMatch';}
      if(type==='shortAnswer'){q.prompt=`【mock 簡答範本】請以自己的話說明「${excerpt}」。`;q.rubric='請教師依教學目標補充具體給分條件；此為人工批改題。';q.scoring='manual';}
      if(EXTRA_TYPES.includes(type))Object.assign(q,extraTemplate(type,excerpt));
      questions.push(q);
      blocks.push({id:id(),type:'questionSet',data:{questionIds:[q.id]},visibility:'both',sourceRefs:q.sourceRefs});
    }
    blocks.push({id:id(),type:'teacherNote',data:{text:`mock 範本，不代表教學品質已驗證。分支：${profile.readingLoad.teacherLabel}；閱讀指引：${profile.readingLoad.sentenceGuidance}；認知挑戰：${profile.cognitiveChallenge}；鷹架：${profile.scaffolds.join('、')||'無'}；語言設定：${profile.language}（未自動翻譯）。`},visibility:'teacher',sourceRefs:refs(first)});
    const content=decorateResource({id:id(),resourceId:id(),resourceType:request.outputSpec.resourceType,title:request.outputSpec.title,profileId:profile.id,objectiveIds,blocks,questions},chunks);
    return {schemaVersion:versionFor(content),requestId:request.requestId,jobId:id(),state:'succeeded',origin:'mock',providerInfo:{provider:'local-template',modelId:null},generatedAt:new Date().toISOString(),resources:[content],warnings:['本機 mock 只複製來源並產生固定題目範本，不提供 AI 摘要、改寫、翻譯或答案品質保證；發布前請教師逐題核對。']};
  }
}
