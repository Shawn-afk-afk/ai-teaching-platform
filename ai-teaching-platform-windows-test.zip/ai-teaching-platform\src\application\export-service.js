import {AssessmentService} from './assessment-service.js';
import {makePack,parsePack,packIds,importAsDraft} from '../domain/resource-pack.js';
import {reject} from '../domain/assessment.js';
export class ExportService extends AssessmentService {
  async resourceJSON(projectId,versionId){const {p}=await this.context(projectId,'teacher');return JSON.stringify(makePack(p,versionId,this.clock()),null,2);}
  async previewImport(text){
    const actor=await this.identity.getContext();if(actor.role!=='teacher')reject('僅教師可匯入教材。','FORBIDDEN');
    const pack=parsePack(text),ids=new Set(packIds(pack)),existing=new Set();
    for(const p of await this.repository.list()){
      if(p.tenantId!==actor.tenantId||p.ownerId!==actor.actorId)continue;
      existing.add(p.id);existing.add(p.source?.id);for(const source of p.sourceHistory??[])existing.add(source.id);for(const r of p.resources??[])existing.add(r.id);
      for(const entry of [...p.versions??[],...p.drafts??[]]){const v=entry.content??entry;existing.add(v.id);existing.add(v.profileId);for(const id of v.objectiveIds)existing.add(id);for(const item of [...v.blocks,...v.questions]){existing.add(item.id);for(const option of item.options??[])existing.add(option.id);for(const ref of item.sourceRefs??[]){existing.add(ref.sourceId);existing.add(ref.chunkId);}}for(const chunk of entry.context?.chunks??[]){existing.add(chunk.id);existing.add(chunk.sourceId);}for(const objective of entry.context?.objectives??[])existing.add(objective.id);}
    }
    return {title:pack.versions[0].content.title,questions:pack.versions[0].content.questions.length,blocks:pack.versions[0].content.blocks.length,conflicts:[...ids].filter(id=>existing.has(id)),sourceScope:pack.manifest.sourceScope,importMode:'new-project-draft'};
  }
  async importResource(text,confirmed){if(!confirmed)reject('請先查看匯入預覽並確認建立副本。');await this.previewImport(text);const actor=await this.identity.getContext(),p=importAsDraft(parsePack(text),actor,this.clock());return this.repository.save(p,0);}
  async printVersion(projectId,versionId){const {p}=await this.context(projectId,'teacher');const version=p.versions?.find(v=>v.id===versionId);if(!version)reject('找不到發布版本。');return structuredClone(version);}
}
