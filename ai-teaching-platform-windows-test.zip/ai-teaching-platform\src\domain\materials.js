import {AppError} from '../contracts/errors.js';
export const MAX_TEXT_BYTES=1024*1024;
export function checkText(text){
  if(typeof text!=='string'||!text.trim())throw new AppError('VALIDATION_FAILED','內容不可空白。');
  if(new TextEncoder().encode(text).length>MAX_TEXT_BYTES)throw new AppError('FILE_TOO_LARGE','本機切片每份文字上限為 1 MiB，請拆分教材。');
  if(text.includes('\0'))throw new AppError('UNSUPPORTED_FORMAT','內容包含二進位字元，請使用 UTF-8 純文字。');
}
export function sourceChunks(source){
  if(source.inputMode==='topic')return [];
  if(source.text.includes('[PDF頁 ')){
    let page=1,parts=[],buffer='';
    const push=()=>{if(buffer.trim())parts.push({text:buffer.trim(),page});buffer='';};
    for(const line of source.text.split(/\r?\n/)){const match=/^\[PDF頁 (\d+)\]$/.exec(line);if(match){push();page=Number(match[1]);}else{if(buffer.length+line.length>3000)push();buffer+=line+'\n';}}push();
    return parts.map((c,i)=>({id:`${source.id}-r${source.revision}-c${i+1}`,sourceId:source.id,sourceRevision:source.revision,text:c.text,locator:{kind:'page',index:c.page}}));
  }
  return source.text.split(/\r?\n/).map((text,index)=>({id:`${source.id}-r${source.revision}-p${index+1}`,sourceId:source.id,sourceRevision:source.revision,text,locator:{kind:'paragraph',index:index+1}})).filter(c=>c.text.trim());
}
export function readyCoverage(text){const count=text.split(/\r?\n/).filter(t=>t.trim()).length;return {unit:'paragraph',total:count,processed:count,missing:[]};}
