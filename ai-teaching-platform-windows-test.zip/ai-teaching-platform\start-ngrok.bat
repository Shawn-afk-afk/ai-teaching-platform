@echo off
setlocal
title AI Teaching Platform - ngrok
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\start-ngrok.ps1" %*
set "LAUNCH_EXIT=%ERRORLEVEL%"
echo.
if not "%LAUNCH_EXIT%"=="0" echo Launch stopped. Read the instructions above.
pause
exit /b %LAUNCH_EXIT%
