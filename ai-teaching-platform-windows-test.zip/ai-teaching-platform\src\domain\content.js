import {AppError} from '../contracts/errors.js';
import {validateContract} from '../contracts/validate.js';
import {validate_layout} from './rules.js';
import {requireValidDraft} from './draft-validation.js';
import {ALL_TYPES,RESOURCE_LABELS,versionFor,validateExtra} from './extended-questions.js';
export const ENABLED_RESOURCES=Object.keys(RESOURCE_LABELS);
export const QUESTION_TYPES=ALL_TYPES;
export function fail(message,code='VALIDATION_FAILED'){throw new AppError(code,message);}
export function validateContent(content,context){
  if(Array.isArray(content?.questions)&&Array.isArray(content?.blocks)&&content.questions.every(q=>q&&Array.isArray(q.options??[])&&Array.isArray(q.objectiveIds)&&Array.isArray(q.sourceRefs))&&content.blocks.every(b=>b?.data&&(b.type!=='questionSet'||Array.isArray(b.data.questionIds))))requireValidDraft(content,context);
  validateContract('generate-result',{schemaVersion:versionFor(content),requestId:'validation',jobId:'validation',state:'succeeded',origin:'mock',providerInfo:{provider:'local-validation',modelId:null},generatedAt:'2026-11-19T00:00:00Z',resources:[content],warnings:[]});
  try{validate_layout(content);}catch(e){fail(`題目排版不完整：每題必須放入一個且僅一個題組，題組不能空白。${e.message}`);}
  if(!ENABLED_RESOURCES.includes(content.resourceType))fail('此資源類型尚未啟用。','UNSUPPORTED_FORMAT');
  if(content.resourceType==='vocabulary'&&!content.blocks.some(b=>b.type==='vocabularyList'))fail('字彙活動須包含可編輯字彙表。');
  if(content.resourceType==='organizer'&&!content.blocks.some(b=>b.type==='organizer'))fail('圖像組織工具須包含概念圖。');
  const objectives=new Set(context.objectives.map(o=>o.id));
  if(content.profileId!==context.profile.id)fail('資源不能跨差異化分支。');
  for(const id of content.objectiveIds)if(!objectives.has(id))fail('資源引用了不存在的學習目標。');
  const chunks=new Map(context.chunks.map(c=>[c.id,c]));
  for(const item of [...content.blocks,...content.questions]){
    for(const ref of item.sourceRefs){const c=chunks.get(ref.chunkId);if(!c||c.sourceId!==ref.sourceId||c.sourceRevision!==ref.sourceRevision)fail('來源引用不存在或修訂不符。');}
    if(context.inputMode==='source'&&['paragraph','heading','vocabularyList','organizer',...ALL_TYPES].includes(item.type)&&!item.sourceRefs.length)fail('教材模式的內容與題目必須標示來源依據。');
    if(item.type==='organizer'){const ids=item.data.nodes.map(n=>n.id);if(new Set(ids).size!==ids.length||item.data.edges.some(e=>!ids.includes(e.from)||!ids.includes(e.to)))fail('概念圖節點或連線不完整。');}
  }
  for(const q of content.questions){
    try{validateExtra(q);}catch(e){fail(e.message);}
    if(!q.prompt.trim())fail('題目內容不可空白。');
    if(q.objectiveIds.some(id=>!objectives.has(id)))fail('題目引用了不存在的學習目標。');
    if(q.type==='singleChoice'){
      const ids=q.options.map(o=>o.id);
      if(new Set(ids).size!==ids.length||!ids.includes(q.answerKey))fail('單選題的選項識別不可重複，正解必須在選項中。');
      if(q.options.some(o=>!o.text.trim()))fail('選項文字不可空白。');
    }
    if(q.type==='shortAnswer'&&!q.rubric.trim())fail('簡答題必須填寫評分規準。');
  }
  return content;
}
export function contentOfVersion(v){return Object.fromEntries(['id','resourceId','resourceType','title','profileId','objectiveIds','blocks','questions'].map(k=>[k,structuredClone(v[k])]));}
