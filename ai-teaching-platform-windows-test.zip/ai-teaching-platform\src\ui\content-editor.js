import {project_student} from '../domain/rules.js';
import {validateContent} from '../domain/content.js';
import {EXTRA_TYPES,TYPE_LABELS,answerLabel} from '../domain/extended-questions.js';
import {extraTemplate} from '../domain/expansion-templates.js';
import {editExtra,editRichBlock,renderRichBlock} from './expanded-content.js';
export function el(tag,text='',attrs={}){const e=document.createElement(tag);e.textContent=text;for(const [key,value] of Object.entries(attrs))e.setAttribute(key,value);return e;}
export function button(text,action){const e=el('button',text,{type:'button'});e.addEventListener('click',action);return e;}
export function field(label,value,onChange,{type='text',options,rows=3}={}){
  const wrap=el('label',label),input=el(options?'select':type==='textarea'?'textarea':'input');
  input.id=`field-${crypto.randomUUID()}`;input.name=input.id;
  if(options)for(const [value,text] of options)input.append(el('option',text,{value}));
  else if(type==='textarea')input.rows=rows;else input.type=type;
  if(type==='checkbox')input.checked=Boolean(value);else input.value=value??'';
  input.addEventListener('input',()=>onChange(type==='checkbox'?input.checked:type==='number'?Number(input.value):input.value));wrap.append(input);return wrap;
}
function move(array,index,offset){const to=index+offset;if(to<0||to>=array.length)return;[array[index],array[to]]=[array[to],array[index]];}
export function renderDraftEditor(container,content,context,changed){
  container.replaceChildren();
  const update=()=>changed();const redraw=()=>{update();renderDraftEditor(container,content,context,changed);};
  container.append(field('資源標題',content.title,v=>{content.title=v;update();}));
  const controls=el('div','',{class:'actions'});
  for(const [type,label] of [['paragraph','段落'],['heading','標題'],['teacherNote','教師說明']])controls.append(button(`新增${label}`,()=>{
    const first=context.chunks[0];content.blocks.push({id:crypto.randomUUID(),type,data:{text:''},visibility:type==='teacherNote'?'teacher':'both',sourceRefs:first?[{sourceId:first.sourceId,sourceRevision:first.sourceRevision,chunkId:first.id}]:[]});redraw();
  }));
  controls.append(button('新增題組',()=>{content.blocks.push({id:crypto.randomUUID(),type:'questionSet',data:{questionIds:[]},visibility:'both',sourceRefs:[]});redraw();}));container.append(el('h4','區塊排列'),controls);
  for(const [type,label]of [['vocabularyList','字彙表'],['organizer','概念圖']])controls.append(button(`新增${label}`,()=>{const first=context.chunks[0],sourceRefs=first?[{sourceId:first.sourceId,sourceRevision:first.sourceRevision,chunkId:first.id}]:[],data=type==='vocabularyList'?{entries:[{id:crypto.randomUUID(),term:'詞彙',definition:'請填詞義',example:''}]}:{title:'概念圖',nodes:[{id:crypto.randomUUID(),label:'核心概念'}],edges:[]};content.blocks.push({id:crypto.randomUUID(),type,data,visibility:'both',sourceRefs});redraw();}));
  content.blocks.forEach((block,index)=>{
    const card=el('div','',{class:'edit-card','data-block-id':block.id});const header=el('div','',{class:'section-heading'});
    header.append(el('strong',`${index+1}. ${{heading:'標題',paragraph:'段落',teacherNote:'教師說明',questionSet:'題組'}[block.type]}`));
    const actions=el('div','',{class:'actions'});actions.append(button('上移',()=>{move(content.blocks,index,-1);redraw();}),button('下移',()=>{move(content.blocks,index,1);redraw();}),button('移除區塊',()=>{content.blocks.splice(index,1);redraw();}));header.append(actions);card.append(header);
    if(block.type==='questionSet'){
      card.append(el('p','勾選本題組要呈現的題目。每題必須恰好出現在一個題組。'));
      for(const q of content.questions)card.append(field(q.prompt||'尚未填寫的題目',block.data.questionIds.includes(q.id),checked=>{block.data.questionIds=checked?[...block.data.questionIds,q.id]:block.data.questionIds.filter(id=>id!==q.id);redraw();},{type:'checkbox'}));
      const order=el('ol');for(const [i,id] of block.data.questionIds.entries()){const item=el('li',content.questions.find(q=>q.id===id)?.prompt??'不存在的題目');item.append(button('題目上移',()=>{move(block.data.questionIds,i,-1);redraw();}),button('題目下移',()=>{move(block.data.questionIds,i,1);redraw();}));order.append(item);}card.append(order);
    }else if(['vocabularyList','organizer'].includes(block.type))editRichBlock(card,block,update,redraw);
    else card.append(field('區塊文字',block.data.text,v=>{block.data.text=v;update();},{type:'textarea'}));
    if(!['teacherNote','questionSet'].includes(block.type))card.append(field('可見對象',block.visibility,v=>{block.visibility=v;update();},{options:[['both','教師與學生'],['teacher','僅教師'],['student','學生']] }));
    if(context.chunks.length){const refs=el('details');refs.append(el('summary','核對／修改來源依據'));for(const chunk of context.chunks)refs.append(field(`原文第 ${chunk.locator.index} 段：${chunk.text}`,block.sourceRefs.some(r=>r.chunkId===chunk.id),checked=>{block.sourceRefs=checked?[...block.sourceRefs,{sourceId:chunk.sourceId,sourceRevision:chunk.sourceRevision,chunkId:chunk.id}]:block.sourceRefs.filter(r=>r.chunkId!==chunk.id);update();},{type:'checkbox'}));card.append(refs);}
    container.append(card);
  });
  container.append(el('h4','題目內容與配分'));
  const add=el('div','',{class:'actions'});
  for(const [type,name] of Object.entries(TYPE_LABELS))add.append(button(`新增${name}題`,()=>{
    const first=context.chunks[0],q={id:crypto.randomUUID(),type,prompt:'',maxScore:1,objectiveIds:[...content.objectiveIds],sourceRefs:first?[{sourceId:first.sourceId,sourceRevision:first.sourceRevision,chunkId:first.id}]:[],hints:[],scoring:type==='shortAnswer'?'manual':'exactMatch'};
    if(type==='singleChoice'){q.options=[{id:crypto.randomUUID(),text:''},{id:crypto.randomUUID(),text:''}];q.answerKey=q.options[0].id;}else if(type==='trueFalse')q.answerKey=true;else if(EXTRA_TYPES.includes(type)){Object.assign(q,extraTemplate(type,first?.text??'source words'));q.prompt='';}else q.rubric='';
    content.questions.push(q);content.blocks.push({id:crypto.randomUUID(),type:'questionSet',data:{questionIds:[q.id]},visibility:'both',sourceRefs:[]});redraw();
  }));container.append(add);
  content.questions.forEach((q,index)=>{
    const card=el('div','',{class:'edit-card','data-question-id':q.id});card.append(el('h5',`${index+1}. ${TYPE_LABELS[q.type]}`));
    card.append(field('題目',q.prompt,v=>{q.prompt=v;update();},{type:'textarea'}),field('配分',q.maxScore,v=>{q.maxScore=v;update();},{type:'number'}));
    if(q.type==='singleChoice'){
      q.options.forEach((option,i)=>{const row=field(`選項 ${i+1}`,option.text,v=>{option.text=v;update();});row.append(button('移除此選項',()=>{q.options.splice(i,1);redraw();}));card.append(row);});
      card.append(button('增加選項',()=>{q.options.push({id:crypto.randomUUID(),text:''});redraw();}),field('正確選項',q.answerKey,v=>{q.answerKey=v;update();},{options:[['','請選擇正解'],...q.options.map((o,i)=>[o.id,`選項 ${i+1}`])]}));
    }else if(q.type==='trueFalse')card.append(field('正確答案',String(q.answerKey),v=>{q.answerKey=v==='true';update();},{options:[['true','是'],['false','否']]}));
    else if(EXTRA_TYPES.includes(q.type))editExtra(card,q,update,redraw);
    else card.append(field('評分規準',q.rubric,v=>{q.rubric=v;update();},{type:'textarea'}));
    card.append(field('提示（每行一則）',q.hints.join('\n'),v=>{q.hints=v.split('\n').filter(s=>s.trim());update();},{type:'textarea'}));
    const refs=el('details');refs.append(el('summary','學習目標與來源'));
    for(const o of context.objectives)refs.append(field(o.description,q.objectiveIds.includes(o.id),checked=>{q.objectiveIds=checked?[...q.objectiveIds,o.id]:q.objectiveIds.filter(id=>id!==o.id);update();},{type:'checkbox'}));
    for(const c of context.chunks)refs.append(field(`原文第 ${c.locator.index} 段：${c.text}`,q.sourceRefs.some(r=>r.chunkId===c.id),checked=>{q.sourceRefs=checked?[...q.sourceRefs,{sourceId:c.sourceId,sourceRevision:c.sourceRevision,chunkId:c.id}]:q.sourceRefs.filter(r=>r.chunkId!==c.id);update();},{type:'checkbox'}));card.append(refs);
    card.append(button('刪除此題',()=>{content.questions.splice(index,1);for(const b of content.blocks)if(b.type==='questionSet')b.data.questionIds=b.data.questionIds.filter(id=>id!==q.id);content.blocks=content.blocks.filter(b=>b.type!=='questionSet'||b.data.questionIds.length);redraw();}));container.append(card);
  });
}
export function renderPreview(container,content,context,student){
  validateContent(content,context);
  const data=student?project_student(content,'local-preview','local-preview'):content;
  container.replaceChildren(el('h4',`${student?'學生':'教師'}預覽：${data.title}`));
  container.append(el('p','教師本機預覽，不是正式學生授權端點。',{class:'help'}));
  for(const block of data.blocks){
    const part=el('div','',{class:'preview-block'});
    if(block.type==='questionSet')for(const id of block.data.questionIds){const q=data.questions.find(q=>q.id===id),article=el('article');article.append(el('strong',`${q.prompt}（${q.maxScore} 分）`));if(q.options){const list=el('ol');for(const o of q.options)list.append(el('li',o.text));article.append(list);}for(const hint of q.hints)article.append(el('p',`提示：${hint}`));if(!student)article.append(el('p',answerLabel(q),{class:'teacher-answer'}));part.append(article);}
    else if(['vocabularyList','organizer'].includes(block.type))part.append(renderRichBlock(block));
    else part.append(el(block.type==='heading'?'h5':'p',`${block.type==='teacherNote'?'教師說明：':''}${block.data.text}`));
    if(!student&&block.sourceRefs?.length){const refs=el('details');refs.append(el('summary','來源依據'));for(const ref of block.sourceRefs){const c=context.chunks.find(c=>c.id===ref.chunkId);refs.append(el('p',`來源修訂 ${ref.sourceRevision}，原文第 ${c?.locator.index} 段：${c?.text??'來源缺失'}`));}part.append(refs);}
    container.append(part);
  }
}
