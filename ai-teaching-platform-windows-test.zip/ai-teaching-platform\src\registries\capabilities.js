import {AppError} from '../contracts/errors.js';
export class Registry {
  entries=new Map();
  register(entry){if(this.entries.has(entry.type)) throw new AppError('VALIDATION_FAILED','類型已登錄。');this.entries.set(entry.type,Object.freeze({...entry}));}
  get(type){const entry=this.entries.get(type);if(!entry) throw new AppError('UNSUPPORTED_FORMAT',`未支援的類型：${type}`);return entry;}
  list(){return [...this.entries.values()];}
}
export const resources=new Registry();
for(const [type,label] of Object.entries({handout:'講義',reading:'閱讀文章',comprehension:'理解題',quiz:'測驗',vocabulary:'字彙活動',stations:'學習站',exitTicket:'退出單',organizer:'圖像組織工具',tieredPractice:'分層練習'})) resources.register({type,label,state:'本機編修／生成草稿需教師審核',schemaVersion:['vocabulary','organizer'].includes(type)?'3.0.0':'2.0.0'});
export const capabilities=[
  {label:'專案與教材文字保存',state:'本機實作',detail:'IndexedDB；同一瀏覽器重新載入後可恢復。'},
  {label:'教師身分',state:'mock',detail:'固定示範教師，並非正式登入。'},
  {label:'教材草稿生成',state:'mock',detail:'複製來源與固定題目範本，不做 AI 改寫、翻譯或語義分析。'},
  {label:'事件通道',state:'mock',detail:'本機事件匯流排，沒有多人同步。'},
  {label:'教材編修與發布',state:'本機實作',detail:'教師確認後發布不可變版本；分支各自演進。'},
  {label:'學生作答與評分',state:'本機示範',detail:'固定版本指派、作答暫存、提交、規則計分及教師覆核；分數、答案、回饋分別發布。'},
  {label:'課堂與報告',state:'本機示範',detail:'開始、暫停、繼續、結束與定時快照；版本分組的提交、題目與目標證據。'},
  {label:'列印與可攜教材',state:'本機實作',detail:'學生／教師版列印與另存 PDF、教材 JSON 草稿副本匯入、成績 CSV。'},
  {label:'AI agent',state:'未啟用',detail:'本輪不提供自主操作。'}
];
