$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$node = Get-Command node.exe -ErrorAction SilentlyContinue
if (-not $node) { throw 'Install Node.js 24 or newer, then reopen PowerShell.' }
& $node.Source -e "if (+process.versions.node.split('.')[0] < 24) process.exit(1)"
if ($LASTEXITCODE -ne 0) { throw 'Node.js 24 or newer is required.' }
$npm = Get-Command npm.cmd -ErrorAction SilentlyContinue
if (-not $npm) { throw 'npm is required; reinstall Node.js with npm.' }
& $npm.Source install --include=dev --no-audit --no-fund
if ($LASTEXITCODE -ne 0) { throw 'JavaScript dependency installation failed.' }
$py = Get-Command py.exe -ErrorAction SilentlyContinue
if (-not $py) { throw 'Install Python 3.12 with the Windows Python launcher, then reopen PowerShell.' }
if (-not (Test-Path -LiteralPath '.venv\Scripts\python.exe')) { & $py.Source -3.12 -m venv .venv; if ($LASTEXITCODE -ne 0) { throw 'Python 3.12 environment creation failed.' } }
& '.\.venv\Scripts\python.exe' -m pip install -r 'tools\ingestion-requirements.txt'
if ($LASTEXITCODE -ne 0) { throw 'Python dependency installation failed.' }
& '.\.venv\Scripts\python.exe' -c 'import pdfplumber, docx'
if ($LASTEXITCODE -ne 0) { throw 'Python dependency verification failed.' }
Write-Host 'Setup complete. Start Ollama, pull gemma4:12b, then run start-p7.ps1.'
