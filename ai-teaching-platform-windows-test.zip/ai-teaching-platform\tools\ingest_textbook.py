"""Extract one untrusted textbook into newline-delimited records.

Text is emitted incrementally. This process never executes uploaded content.
The caller must isolate each file and commit only after a successful end record.
"""
import codecs, csv, hashlib, json, re, sys
from pathlib import Path
import pdfplumber
from docx import Document

sys.stdout.reconfigure(encoding='utf-8')
path=Path(sys.argv[1]); name=sys.argv[2]; ext=Path(name).suffix.lower()
def emit(value):
    print(json.dumps(value,ensure_ascii=False),flush=True)
def digest():
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
def decode_text():
    # Latin-1 is total and cannot establish encoding correctness. Mark it untrusted.
    for encoding in ('utf-8-sig','cp950','gb18030','latin-1'):
        try:
            decoder=codecs.getincrementaldecoder(encoding)(errors='strict')
            with path.open('rb') as f:
                for block in iter(lambda:f.read(65536),b''):
                    if b'\0' in block: raise ValueError('Binary NUL bytes are not text')
                    text=decoder.decode(block)
                    if sum(ord(c)<32 and c not in '\r\n\t' for c in text)>0: raise ValueError('Binary control characters are not supported')
                decoder.decode(b'',final=True)
            return encoding
        except UnicodeDecodeError: continue
    raise ValueError('Unable to decode')
if ext not in ('.pdf','.docx','.txt','.md','.csv'): raise ValueError('Unsupported format')
with path.open('rb') as f: signature=f.read(8)
if ext=='.pdf' and not signature.startswith(b'%PDF-'): raise ValueError('Invalid PDF signature')
if ext=='.docx' and not signature.startswith(b'PK\x03\x04'): raise ValueError('Invalid DOCX signature')
if ext in ('.txt','.md','.csv') and (signature.startswith(b'%PDF-') or signature.startswith(b'PK\x03\x04') or signature.startswith(b'MZ')): raise ValueError('Binary file disguised as text')
emit({'type':'start','sha256':digest(),'name':name,'extension':ext})
count=0; preview=[]
def record(text,locator):
    global count
    count+=len(text.strip())
    if len(preview)<15: preview.extend(text.splitlines()[:15-len(preview)])
    for offset in range(0,max(1,len(text)),1800):
        emit({'type':'text','locator':{**locator,'offset':offset},'text':text[offset:offset+1800]})
encoding=None; warnings=[]
if ext=='.pdf':
    with pdfplumber.open(path) as doc:
        for i,page in enumerate(doc.pages,1):
            try:
                text=page.dedupe_chars().extract_text() or ''
                record(text,{'kind':'page','index':i,'status':'text_extracted' if text.strip() else 'needs_ocr'})
            except Exception as e:
                warnings.append(f'Page {i} extraction failed: {type(e).__name__}')
                emit({'type':'page_error','page':i,'message':str(e)})
elif ext=='.docx':
    doc=Document(path)
    for i,p in enumerate(doc.paragraphs,1):
        if p.text.strip():record(p.text,{'kind':'paragraph','index':i})
    if doc.tables: warnings.append('DOCX tables are not included in paragraph extraction')
else:
    encoding=decode_text()
    with path.open('r',encoding=encoding,newline='') as f:
        for i,line in enumerate(f,1):
            if line.strip():record(line.rstrip('\r\n'),{'kind':'line','index':i})
    if encoding=='latin-1':warnings.append('Latin-1 is a fallback; encoding requires teacher confirmation')
emit({'type':'end','characters':count,'is_scanned_image':ext=='.pdf' and count<30,
      'encoding':encoding,'preview':preview[:15],'warnings':warnings})
