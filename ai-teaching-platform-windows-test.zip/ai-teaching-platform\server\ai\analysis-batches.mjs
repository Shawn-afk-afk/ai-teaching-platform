import {createHash} from 'node:crypto';
export const ANALYSIS_VERSION='merged-analysis-2';
export function analysisKey(input,digest,config){return createHash('sha256').update(JSON.stringify({projectId:input.projectId,chunks:input.sourceChunks,digest,config,version:ANALYSIS_VERSION})).digest('hex');}
export function analysisBatches(chunks,max=2600){
 const result=[];let current=null;
 for(const c of chunks){
  for(let offset=0;offset<c.text.length;offset+=max){
   const text=c.text.slice(offset,offset+max),ref={sourceId:c.sourceId,sourceRevision:c.sourceRevision,chunkId:c.id,locator:c.locator,offset};
   if(!current||current.sourceId!==c.sourceId||current.sourceRevision!==c.sourceRevision||current.text.length+text.length+1>max){current={sourceId:c.sourceId,sourceRevision:c.sourceRevision,text:'',refs:[]};result.push(current);}
   current.text+=(current.text?'\n':'')+text;current.refs.push(ref);
  }
 }
 return result;
}
export function mergeAnalysis(completed){
 return Object.fromEntries(['objectiveText','summary','concepts','vocabulary'].map(k=>{
  const seen=new Set(),lines=[];for(const value of completed)for(const line of value[k].split('\n')){const s=line.trim(),key=s.normalize('NFKC').toLowerCase().replace(/[\s\p{P}]/gu,'');if(key&&!seen.has(key)){seen.add(key);lines.push(s);}}
  return [k,lines.join('\n')];
 }));
}
