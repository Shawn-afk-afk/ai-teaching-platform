import {el} from '../ui/content-editor.js';
const pages={home:'教師首頁',knowledge:'教材知識庫',projects:'教學專案',students:'學生管理',assignments:'作業與批改',settings:'帳號設定'};
export async function mountTeacherRouter(root,workspace,settings){
 root.classList.add('teacher-shell');
 const main=root.querySelector('main'),sidebar=el('nav','',{class:'teacher-sidebar','aria-label':'教師功能導覽'}),tabs=el('nav','',{id:'project-tabs','aria-label':'專案步驟'}),notice=el('p','',{id:'route-state',role:'status'});
 for(const [key,label] of Object.entries(pages)){const a=el('a',label,{href:`#/${key}`});sidebar.append(a);}
 sidebar.append(el('span','遊戲（預留，未啟用）',{'aria-disabled':'true',class:'disabled-nav',id:'games-placeholder'}));
 root.insertBefore(sidebar,main);main.prepend(notice,tabs);
 const home=el('section','',{id:'teacher-home'});home.append(el('h2','教師首頁'),el('p','從教材知識庫匯入教材，或開啟教學專案繼續分析、生成與編修。'));
 for(const [key,label] of [['projects','開啟教學專案'],['knowledge','匯入教材'],['assignments','查看作業與批改']])home.append(el('a',label,{href:`#/${key}`,class:'route-shortcut'}));
 main.prepend(home);const settingsPage=el('section','',{id:'teacher-settings'});settingsPage.append(el('h2','帳號設定'),settings);main.append(settingsPage);
 let currentId=null,currentResource=null,step='',lastHash='',loading=false,disposed=false;
 const hide=(selector,value)=>{const n=root.querySelector(selector);if(n)n.hidden=value;};
 function apply(){
  const match=/^#\/projects\/([^/]+)\/(source|analysis|resources|assign|drafts)(?:\/([^/]+))?$/.exec(location.hash);
  const page=match?'project':location.hash.slice(2),project=workspace.currentProject();
  hide('#teacher-home',page!=='home');hide('#knowledge-base',page!=='knowledge');hide('#roster-panel',page!=='students');hide('.library',page!=='projects');
  hide('.editor',!(page==='new'||page==='project'&&step==='source'));
  hide('#workbench',!(page==='project'&&['analysis','resources','drafts'].includes(step)));
  hide('#assessment',!(page==='assignments'||page==='project'&&step==='assign'));hide('#reports',!(page==='assignments'||page==='project'&&step==='assign'));hide('#teacher-settings',page!=='settings');hide('.capabilities',true);
  tabs.hidden=page!=='project';
  hide('#preparation-panel',step!=='analysis');hide('#generation-panel',step!=='resources');hide('#resource-library',step!=='resources');hide('#resource-editor',step!=='drafts');
  const controls=root.querySelector('#workbench-controls');if(controls)for(const child of controls.children)if(!['preparation-panel','generation-panel','resource-library','resource-editor'].includes(child.id))child.hidden=true;
  if(step==='analysis')root.querySelector('#preparation-panel')?.setAttribute('open','');
  if(step==='resources')root.querySelector('#generation-panel')?.setAttribute('open','');
  const heading=root.querySelector('#workbench > h2');const headingText=step==='drafts'?'草稿編輯':step==='analysis'?'教材分析':'生成與資源庫';if(heading&&heading.textContent!==headingText)heading.textContent=headingText;
  for(const a of sidebar.querySelectorAll('a')){const active=a.hash===location.hash||a.hash==='#/projects'&&page==='project';if(active)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');}
  for(const a of tabs.querySelectorAll('a')){if(a.dataset.step===step)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');}
  notice.textContent=page==='assignments'&&!project?'請先到教學專案開啟專案，再查看該專案的作業與批改。':page==='project'&&step==='drafts'&&!root.querySelector('#resource-editor')?'找不到指定資源，請回生成與資源庫選擇草稿。':'';
  document.title=`${page==='project'?`${project?.title??'專案'} · ${step==='drafts'?'草稿編輯':tabs.querySelector('[aria-current]')?.textContent??''}`:pages[page]??'新增專案'}｜AI 互動教學平台`;
 }
 const observer=new MutationObserver(()=>apply());observer.observe(root.querySelector('#workbench'),{childList:true,subtree:true});
 function buildTabs(id){tabs.replaceChildren();for(const [key,label] of [['source','教材與來源'],['analysis','AI 分析'],['resources','生成與資源庫'],['assign','發布與指派']]){const a=el('a',label,{href:`#/projects/${encodeURIComponent(id)}/${key}`});a.dataset.step=key;tabs.append(a);}if(step==='drafts'){const a=el('a','草稿編輯',{href:location.hash});a.dataset.step='drafts';tabs.append(a);}}
 async function route(){
  if(loading||disposed)return;
  if(lastHash&&location.hash!==lastHash&&(workspace.isBusy()||workspace.hasChanges()&&!confirm('有尚未保存的修改，確定切換頁面？'))){history.replaceState(null,'',lastHash);return;}
  loading=true;try{
   const m=/^#\/projects\/([^/]+)\/(source|analysis|resources|assign|drafts)(?:\/([^/]+))?$/.exec(location.hash);
   if(m){const id=decodeURIComponent(m[1]),resource=m[3]?decodeURIComponent(m[3]):null;step=m[2];await workspace.openProject(id);if(!workspace.currentProject())throw Error('找不到此專案或無權存取。');if(step==='drafts'&&(id!==currentId||resource!==currentResource))workspace.selectResource(resource);currentId=id;currentResource=resource;buildTabs(id);}
   else if(location.hash==='#/new'){step='';await workspace.openProject(null);currentId=null;}
   else if(!Object.hasOwn(pages,location.hash.slice(2))){history.replaceState(null,'','#/home');step='';}else step='';
   lastHash=location.hash;apply();window.scrollTo(0,0);
  }catch(e){notice.textContent=e.message;history.replaceState(null,'','#/projects');step='';apply();notice.textContent=e.message;lastHash=location.hash;}finally{loading=false;}
 }
 const internalNavigate=target=>{history.pushState(null,'',target);lastHash=target;void route();};
 const projectEvent=e=>{if(loading)return;if(e.detail.id){if(!location.hash.startsWith(`#/projects/${e.detail.id}/`))internalNavigate(`#/projects/${e.detail.id}/source`);}else internalNavigate('#/new');};
 const resourceEvent=e=>{location.hash=`/projects/${e.detail.projectId}/drafts/${e.detail.resourceId}`;};
 const generationEvent=()=>{const id=workspace.currentProject()?.id;if(id)location.hash=`/projects/${id}/resources`;};
 const sourceEvent=()=>{const id=workspace.currentProject()?.id;const target=id?`#/projects/${id}/source`:'#/new';history.pushState(null,'',target);lastHash=target;void route();};
 const click=e=>{const a=e.target.closest('a[href^="#/"]');if(a&&workspace.isBusy()){e.preventDefault();notice.textContent='請先完成或取消目前工作，再切換頁面。';}};
 root.addEventListener('teaching:project',projectEvent);root.addEventListener('teaching:resource',resourceEvent);root.addEventListener('click',click);window.addEventListener('hashchange',route);
 root.addEventListener('teaching:source',sourceEvent);
 root.addEventListener('teaching:generation',generationEvent);
 if(!location.hash)history.replaceState(null,'','#/home');await route();
 return ()=>{disposed=true;observer.disconnect();root.removeEventListener('teaching:generation',generationEvent);root.removeEventListener('teaching:source',sourceEvent);root.removeEventListener('teaching:project',projectEvent);root.removeEventListener('teaching:resource',resourceEvent);root.removeEventListener('click',click);window.removeEventListener('hashchange',route);};
}
