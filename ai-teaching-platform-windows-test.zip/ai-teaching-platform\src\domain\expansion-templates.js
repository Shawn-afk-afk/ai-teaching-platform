import {EXTRA_TYPES} from './extended-questions.js';
const uid=()=>crypto.randomUUID();
export function extraTemplate(type,text){
 const words=[...new Set(text.match(/[A-Za-z]{3,}/g)??[])].slice(0,3);while(words.length<3)words.push(`來源片段${words.length+1}`);
 const items=words.map(text=>({id:uid(),text}));
 if(type==='multipleChoice')return {prompt:'【mock】選出列出的來源詞彙（可複選）。',options:[...items,{id:uid(),text:'非來源選項'}],answerKey:items.map(x=>x.id),scoring:'exactMatch'};
 if(type==='fillBlank')return {prompt:`【mock】請填入來源詞彙：${words[0][0]}____。`,blanks:[{id:uid(),label:'第一格',answers:[words[0]]}],scoring:'partial'};
 if(type==='matching'){const right=items.map((x,i)=>({id:uid(),text:`來源順序 ${i+1}：${x.text}`}));return {prompt:'【mock】將來源詞彙與標示的對應項目配對。',left:items,right:[...right].reverse(),answerKey:Object.fromEntries(items.map((x,i)=>[x.id,right[i].id])),scoring:'partial'};}
 if(type==='ordering')return {prompt:'【mock】依來源詞彙的出現順序排列。',items:[...items].reverse(),answerKey:items.map(x=>x.id),scoring:'exactMatch'};
 if(type==='upload')return {prompt:'請依教師指定的學習目標完成作品，並上傳檔案。',rubric:'教師依內容正確性與學習目標人工給分；請在發布前補充具體規準。',scoring:'manual'};
 throw Error('Unsupported extended template');
}
export function decorateResource(content,chunks){
 const first=chunks[0],refs=first?[{sourceId:first.sourceId,sourceRevision:first.sourceRevision,chunkId:first.id}]:[],type=content.resourceType;
 if(type==='vocabulary'){
  const terms=[...new Set((first?.text??content.title).match(/[A-Za-z]{3,}/g)??[])].slice(0,5);if(!terms.length)terms.push(content.title);
  content.blocks.unshift({id:uid(),type:'vocabularyList',visibility:'both',sourceRefs:refs,data:{entries:terms.map(term=>({id:uid(),term,definition:'請教師核對並填寫詞義。',example:''}))}});
 }
 if(type==='organizer'){
  const nodes=[{id:uid(),label:content.title},{id:uid(),label:'核心概念（請教師核對）'}];content.blocks.unshift({id:uid(),type:'organizer',visibility:'both',sourceRefs:refs,data:{title:content.title,nodes,edges:[{from:nodes[0].id,to:nodes[1].id,label:'包含'}]}});
 }
 if(['stations','tieredPractice'].includes(type)){
  let n=0;content.blocks=content.blocks.flatMap(b=>b.type==='questionSet'?[{id:uid(),type:'heading',data:{text:type==='stations'?`學習站 ${++n}`:['基礎練習','進階練習','挑戰練習'][n++%3]},visibility:'both',sourceRefs:b.sourceRefs},b]:[b]);
 }
 return content;
}
