import {api,me,remoteService,authExpiry} from './api.js';
import {mountWorkspace} from '../ui/workspace.js';
import {el,button,field} from '../ui/content-editor.js';
import {mountKnowledge} from './knowledge.js';
import {mountTeacherRouter} from './teacher-router.js';
const root=document.querySelector('#teaching-app'),current=await me();
if(current.actor?.role!=='teacher')location.replace('/');
else {
const unwatch=authExpiry(root),header=root.querySelector('header');header.append(el('p',`教師：${current.actor.name}`),button('登出',async()=>{await api('/api/logout',{method:'POST'});location.assign('/');}));
root.querySelector('.editor .help').textContent='資料保存在本機後端的 SQLite。學生使用另一個登入工作階段，無法取得教師資料。';
const roster=el('section','',{class:'wide',id:'roster-panel'});root.querySelector('main').prepend(roster);let rosterBusy=false;
async function drawRoster(){const data=await api('/api/roster');roster.replaceChildren(el('h2','合成資料班級與邀請碼'),el('p','每名學生有固定身分與個別邀請碼。新增學生後，重新載入選定專案即可指派。暱稱（例如 123）不是登入邀請碼。按建立後，請複製系統產生的完整邀請碼，只顯示一次；不要輸入真實學生資料。'));
  let name='',learnerId='',expiry=new Date(Date.now()+7*86400000).toISOString().slice(0,16);const state=el('p','',{id:'roster-state',role:'status'}),error=el('p','',{id:'roster-error',role:'alert'}),form=el('fieldset');
  const target=field('新增或更新邀請','',v=>learnerId=v,{options:[['','新增學生'],...data.learners.map(l=>[l.id,l.name])]});target.querySelector('select').id='invite-learner';const nameInput=field('合成學生暱稱（不是邀請碼）','',v=>name=v);nameInput.querySelector('input').id='learner-name';const expires=field('有效期限（UTC）',expiry,v=>expiry=v,{type:'datetime-local'});expires.querySelector('input').id='invite-expiry';
  const issue=button('建立／更新個別邀請碼',async()=>{if(rosterBusy)return;rosterBusy=true;form.disabled=true;error.textContent='';try{const result=await api('/api/invite',{method:'POST',data:{name,learnerId:learnerId||undefined,expiresAt:new Date(expiry+'Z').toISOString()}});await drawRoster();const output=el('textarea','',{id:'issued-code',readonly:'',rows:'2'});output.value=result.code;const codeLabel=el('label','學生登入邀請碼（請複製完整內容，不是學生暱稱）');codeLabel.append(output);const copy=button('複製邀請碼',async()=>{try{await navigator.clipboard.writeText(output.value);copy.textContent='已複製邀請碼';}catch{output.focus();output.select();copy.textContent='請按 Ctrl+C 複製選取的邀請碼';}});copy.id='copy-invite-code';roster.prepend(el('p','邀請碼已建立（只顯示此次；更新邀請會使舊碼與既有學生登入失效）。'),codeLabel,copy);}catch(e){error.textContent=e.message;}finally{rosterBusy=false;form.disabled=false;}});issue.id='issue-invite';form.append(target,nameInput,expires,issue);roster.append(form,state,error);
  const list=el('ul');for(const i of data.invitations){const row=el('li',`${i.name} · 到期 ${new Date(i.expires).toLocaleString('zh-TW')} · ${i.revoked!==null?'已撤銷':i.expires<=Date.now()?'已過期':'有效'}`);if(i.revoked===null){const revoke=button('撤銷邀請與登入',async()=>{if(!confirm('撤銷後，該邀請碼與其登入工作階段立即失效。'))return;try{await api('/api/revoke',{method:'POST',data:{id:i.id}});await drawRoster();}catch(e){error.textContent=e.message;}});revoke.dataset.inviteId=i.id;row.append(revoke);}list.append(row);}roster.append(list);
}
await drawRoster();
const projects=remoteService('project',['list','get','save']),content=remoteService('content',['generationStatus','validateDraft','getProject','analyze','analysisStatus','prepare','generate','saveDraft','publish','revise']),assessment=remoteService('assessment',['assign','grade','revokeGrade','saveFeedback','release']),classroom=remoteService('classroom',['snapshot','transition','exportCSV']),exports=remoteService('export',['resourceJSON','previewImport','importResource','printVersion','docxVersion']);
content.mode=(await api('/api/model')).mode;
root.querySelector('footer').textContent='發布內容保留歷史版本 · 所有草稿需教師審核';
projects.importPDF=async file=>{const bytes=new Uint8Array(await file.arrayBuffer());let binary='';for(const b of bytes)binary+=String.fromCharCode(b);return api('/api/pdf',{method:'POST',data:{name:file.name,base64:btoa(binary)}});};
const upload=root.querySelector('#txt-file');upload.accept='.txt,.pdf,text/plain,application/pdf';root.querySelector('label[for="txt-file"]').textContent='匯入 TXT（1 MiB）或文字型 PDF（4 MiB）';
header.querySelector('.notice').textContent=`L1 本機開發版 · AI：${content.mode==='model'?'Gemma 4 12B 真實模型（待教師品質驗收）':'mock 範本'}；PDF 為文字擷取，圖像及掃描 OCR 尚未啟用。`;
const unmount=await mountWorkspace(root,projects,content,assessment,null,classroom,exports,{serverMode:true});
await mountKnowledge(root);
root.querySelector('#txt-file').hidden=true;root.querySelector('label[for="txt-file"]').hidden=true;
root.querySelector('#capability-list').replaceChildren(...['教師帳密與個別邀請：伺服器驗證、可撤銷及到期','資料與評分：後端 SQLite 交易及授權','課堂進度：已保存進度快照',content.mode==='model'?'AI：本機 Gemma 4 12B；每份資源 180 秒；所有草稿需審核':'AI：mock 範本','外網部署與真實學生資料：未啟用'].map(s=>el('li',s)));
const settings=el('details');settings.append(el('summary','變更教師密碼（所有登入將失效）'));let old='',next='';settings.append(field('目前密碼','',v=>old=v,{type:'password'}),field('新密碼（至少 12 字元）','',v=>next=v,{type:'password'}));const result=el('p','',{role:'status'});settings.append(button('更新密碼',async()=>{try{await api('/api/password',{method:'POST',data:{current:old,next}});location.assign('/');}catch(e){result.textContent=e.message;}}),result);header.append(settings);
const unroute=await mountTeacherRouter(root,unmount,settings);
window.addEventListener('pagehide',e=>{if(!e.persisted){unroute();unmount();unwatch();}});
}
