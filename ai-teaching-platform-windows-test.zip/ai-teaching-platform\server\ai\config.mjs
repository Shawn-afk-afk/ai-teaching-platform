// One versioned configuration for the local P6 trial, never sent to students.
export const P6_CONFIG = Object.freeze({
  provider: 'ollama', baseUrl: 'http://127.0.0.1:11434', model: 'gemma4:12b',
  resourceTimeoutMs: 180000, requestTimeoutMs: 180000, concurrency: 1,
  maxAutomaticRetries: 1, stream: false,
  options: Object.freeze({num_ctx: 4096, num_predict: 1024, temperature: 0, seed: 42}),
  promptTemplateVersion: 'p6-firsts-1', targetGrade: '國一',
  acceptanceStatus: 'pending_real_model_and_teacher_review'
});
