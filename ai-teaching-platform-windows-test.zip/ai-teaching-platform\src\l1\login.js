import {me,login} from './api.js';
const $=id=>document.getElementById(id);let busy=false;
function route(actor){location.assign(actor.role==='teacher'?'/teacher':'/student');}
try{const current=await me();if(current.actor)route(current.actor);else $('setup-panel').hidden=!current.setupRequired;}catch(e){$('login-error').textContent=e.message;}
async function send(path,data){if(busy)return;busy=true;$('login-error').textContent='';try{const result=await login(path,data);route(result.actor);}catch(e){$('login-error').textContent=`${e.message}（${e.code??'NETWORK_ERROR'}）`;}finally{busy=false;}}
$('teacher-login').addEventListener('submit',e=>{e.preventDefault();void send('/api/login',{username:$('username').value,password:$('password').value});});
$('student-login').addEventListener('submit',e=>{e.preventDefault();void send('/api/join',{code:$('invite-code').value});});
$('setup-form').addEventListener('submit',e=>{e.preventDefault();void send('/api/setup',{setupToken:$('setup-token').value,username:$('setup-user').value,password:$('setup-password').value});});
