import {validateContract} from '../contracts/validate.js';
import {timestamp,project_student,effective_scores,latest_submitted_attempt} from '../domain/rules.js';
import {learnersFor,normalizeAnswers,attemptResult,reject} from '../domain/assessment.js';
import {requireActiveSession,sessionFor,publicSession} from '../domain/session.js';
import {objectiveScore,answerLabel} from '../domain/extended-questions.js';
const uid=()=>crypto.randomUUID(),copy=structuredClone;
const collections=['assignments','allocations','attempts','responses','scoreRevisions','feedbackDrafts','releases','submissionKeys','assessmentKeys'];
function initialize(p){if(!p)reject('專案不存在。','NOT_FOUND');for(const name of collections)p[name]??=[];return p;}
function revision(p,expected){if(p.revision!==expected)reject('資料已更新，請重新載入並核對輸入後重試。','VERSION_CONFLICT');}
function submitted(a){if(!a||!['submitted','closed'].includes(a.status)||a.invalidatedAt)reject('只可處理有效的已提交作答。');}
function key(value){if(typeof value!=='string'||!value.trim())reject('操作需要冪等識別碼。');}
export class AssessmentService {
  constructor(repository,identity,{clock=()=>new Date().toISOString()}={}){this.repository=repository;this.identity=identity;this.clock=clock;}
  async context(projectId,role){
    const p=initialize(await this.repository.get(projectId)),actor=await this.identity.getContext();
    if(actor.role!==role||actor.tenantId!==p.tenantId||(role==='teacher'&&actor.actorId!==p.ownerId)||(role==='student'&&!learnersFor(p).some(l=>l.id===actor.actorId)))reject('此身分無法進行這項操作。','FORBIDDEN');
    return {p,actor};
  }
  allocation(p,id,actor){
    const a=p.allocations.find(x=>x.id===id),assignment=p.assignments.find(x=>x.id===a?.assignmentId),version=p.versions?.find(x=>x.id===a?.resourceVersionId);
    if(!a||!assignment||!version||(actor.role==='student'&&a.learnerId!==actor.actorId))reject('找不到此身分可用的指派。','FORBIDDEN');
    validateContract('student-content',project_student(version,assignment.id,a.id));
    return {allocation:a,assignment,version};
  }
  open(p,assignment){
    requireActiveSession(p,assignment);
    if(p.status==='archived'||assignment.status!=='published')reject('作業目前未開放。','ASSIGNMENT_CLOSED');
    const time=timestamp(this.clock());
    if(assignment.opensAt&&time<timestamp(assignment.opensAt))reject('尚未到作業開放時間。','ASSIGNMENT_NOT_OPEN');
    if(assignment.closesAt&&time>=timestamp(assignment.closesAt))reject('作業已到截止時間，暫存與提交均未寫入。','DEADLINE_EXCEEDED');
  }
  async assign(projectId,expected,{title,opensAt=null,closesAt=null,maxAttempts=1,allocations,mode='selfPaced'},idempotencyKey){
    const {p,actor}=await this.context(projectId,'teacher');key(idempotencyKey);
    const fingerprint=JSON.stringify({title,opensAt,closesAt,maxAttempts,allocations,mode});
    const prior=p.assessmentKeys.find(k=>k.actorId===actor.actorId&&k.operation==='assign'&&k.key===idempotencyKey);
    if(prior){if(prior.fingerprint!==fingerprint)reject('相同操作識別用於不同指派。','IDEMPOTENCY_CONFLICT');return p;}
    revision(p,expected);if(p.status==='archived')reject('請先恢復封存專案。');
    if(!['selfPaced','synchronous'].includes(mode))reject('不支援的教學模式。');
    if(typeof title!=='string'||!title.trim())reject('請填寫作業名稱。');
    for(const date of [opensAt,closesAt])if(date!==null){try{timestamp(date);}catch{reject('時間必須包含日期、時間與時區。');}}
    if(opensAt&&closesAt&&timestamp(opensAt)>=timestamp(closesAt))reject('截止時間必須晚於開放時間。');
    if(!Number.isInteger(maxAttempts)||maxAttempts<1||maxAttempts>100)reject('作答次數必須是 1～100。');
    if(!Array.isArray(allocations)||!allocations.length||new Set(allocations.map(a=>a.learnerId)).size!==allocations.length)reject('請選擇學生，同一作業每人只能指派一個版本。');
    for(const a of allocations){if(!learnersFor(p).some(l=>l.id===a.learnerId)||!p.versions?.some(v=>v.id===a.resourceVersionId&&v.publishedAt))reject('請選擇班級學生與已發布版本。');validateContract('student-content',project_student(p.versions.find(v=>v.id===a.resourceVersionId),'check','check'));}
    const assignment={id:uid(),tenantId:p.tenantId,title:title.trim(),mode,status:'published',opensAt,closesAt,attemptPolicy:{maxAttempts,reportSelection:'latestSubmitted',blankObjective:'zero',blankShortAnswer:'pending',lateSubmission:'reject'},releasePolicy:{score:'teacher',answers:'teacher',feedback:'teacher'},createdAt:this.clock()};
    if(mode==='synchronous'){p.sessions??=[];p.sessions.push({id:uid(),assignmentId:assignment.id,state:'lobby',pacing:'free',sequence:1,updatedAt:this.clock()});}
    p.assignments.push(assignment);p.allocations.push(...allocations.map(a=>({id:uid(),assignmentId:assignment.id,learnerId:a.learnerId,resourceVersionId:a.resourceVersionId})));
    p.assessmentKeys.push({operation:'assign',key:idempotencyKey,actorId:actor.actorId,fingerprint,resultId:assignment.id});return this.repository.save(p,expected);
  }
  async listMine(projectId){const {p,actor}=await this.context(projectId,'student');return p.allocations.filter(a=>a.learnerId===actor.actorId).map(a=>{const {assignment,version}=this.allocation(p,a.id,actor);return {allocationId:a.id,title:assignment.title,resourceTitle:version.title,versionNo:version.versionNo};});}
  async sessionState(projectId,allocationId){const {p,actor}=await this.context(projectId,'student');const {assignment}=this.allocation(p,allocationId,actor);return publicSession(sessionFor(p,assignment.id));}
  view(p,allocationId,actor){
    const {assignment,allocation,version}=this.allocation(p,allocationId,actor),content=project_student(version,assignment.id,allocation.id);validateContract('student-content',content);
    const attempts=p.attempts.filter(a=>a.allocationId===allocationId),attemptIds=new Set(attempts.map(a=>a.id));
    // The original student-content schema remains unchanged. Teacher releases are a separate allowlisted envelope.
    const released=Object.fromEntries(attempts.map(a=>[a.id,Object.fromEntries(['score','answers','feedback'].flatMap(kind=>{const items=p.releases.filter(r=>r.attemptId===a.id&&r.kind===kind);const last=items.at(-1);return last?[[kind,{publishedAt:last.publishedAt,data:copy(last.data)}]]:[];}))]));
    return {content,resourceVersionNo:version.versionNo,session:publicSession(sessionFor(p,assignment.id)),assignment:{id:assignment.id,title:assignment.title,opensAt:assignment.opensAt,closesAt:assignment.closesAt,maxAttempts:assignment.attemptPolicy.maxAttempts,status:assignment.status},attempts:copy(attempts),responses:p.responses.filter(r=>attemptIds.has(r.attemptId)).map(({id,attemptId,questionId,answer,savedAt,revision})=>({id,attemptId,questionId,answer:copy(answer),savedAt,revision})),files:(p.workFiles??[]).filter(f=>attemptIds.has(f.attemptId)),released,latestSubmittedId:latest_submitted_attempt(attempts,allocationId)?.id??null,archived:p.status==='archived'};
  }
  async getMine(projectId,allocationId){const {p,actor}=await this.context(projectId,'student');const {assignment}=this.allocation(p,allocationId,actor);if(assignment.opensAt&&timestamp(this.clock())<timestamp(assignment.opensAt))reject('尚未到作業開放時間。','ASSIGNMENT_NOT_OPEN');return this.view(p,allocationId,actor);}
  async begin(projectId,allocationId){
    const {p,actor}=await this.context(projectId,'student'),{assignment,version}=this.allocation(p,allocationId,actor);this.open(p,assignment);
    const previous=p.attempts.filter(a=>a.allocationId===allocationId);
    if(previous.some(a=>a.status==='in_progress'&&!a.invalidatedAt))return this.view(p,allocationId,actor);
    if(previous.length>=assignment.attemptPolicy.maxAttempts)reject('已達這份作業的作答次數上限。','ATTEMPT_LIMIT');
    const time=this.clock(),a={id:uid(),allocationId,attemptNo:previous.length+1,status:'in_progress',gradingStatus:'not_started',startedAt:time,submittedAt:null,invalidatedAt:null,revision:1};validateContract('attempt',a);p.attempts.push(a);
    p.responses.push(...version.questions.map(q=>({id:uid(),attemptId:a.id,questionId:q.id,answer:null,savedAt:time,revision:1})));
    return this.view(await this.repository.save(p,p.revision),allocationId,actor);
  }
  target(p,actor,attemptId){const attempt=p.attempts.find(a=>a.id===attemptId);if(!attempt)reject('找不到作答紀錄。','FORBIDDEN');return {attempt,...this.allocation(p,attempt.allocationId,actor)};}
  writeAnswers(p,attempt,answers,time){for(const r of p.responses.filter(r=>r.attemptId===attempt.id)){r.answer=answers[r.questionId];r.savedAt=time;r.revision++;}}
  async saveAnswers(projectId,attemptId,expected,answers){
    const {p,actor}=await this.context(projectId,'student'),{attempt,assignment,version}=this.target(p,actor,attemptId);this.open(p,assignment);
    if(attempt.status!=='in_progress'||attempt.invalidatedAt)reject('已提交或失效的作答不可修改。','ATTEMPT_CLOSED');revision(attempt,expected);
    const values=normalizeAnswers(version,answers);this.repository.validateUploads?.(p,attempt,version,values);this.writeAnswers(p,attempt,values,this.clock());attempt.revision++;validateContract('attempt',attempt);
    return this.view(await this.repository.save(p,p.revision),attempt.allocationId,actor);
  }
  async submit(projectId,attemptId,expected,answers,idempotencyKey){
    const {p,actor}=await this.context(projectId,'student'),{attempt,assignment,version}=this.target(p,actor,attemptId);key(idempotencyKey);
    const values=normalizeAnswers(version,answers),fingerprint=JSON.stringify(values),prior=p.submissionKeys.find(k=>k.actorId===actor.actorId&&k.attemptId===attemptId&&k.key===idempotencyKey);
    this.repository.validateUploads?.(p,attempt,version,values);
    if(prior){if(prior.fingerprint!==fingerprint)reject('同一提交識別的內容已改變。','IDEMPOTENCY_CONFLICT');return this.view(p,attempt.allocationId,actor);}
    this.open(p,assignment);if(attempt.status!=='in_progress'||attempt.invalidatedAt)reject('此作答已提交或失效。','ATTEMPT_CLOSED');revision(attempt,expected);
    const time=this.clock();this.writeAnswers(p,attempt,values,time);
    for(const q of version.questions.filter(q=>!['shortAnswer','upload'].includes(q.type))){const r=p.responses.find(r=>r.attemptId===attempt.id&&r.questionId===q.id);p.scoreRevisions.push({id:uid(),responseId:r.id,origin:'rule',score:objectiveScore(q,values[q.id]),maxScore:q.maxScore,reason:values[q.id]===null?'空白客觀題，依 D-08 計 0 分':'依固定版本題型規則計分',supersedesId:null,actorId:'local-rule',createdAt:time,invalidatedAt:null});}
    attempt.status='submitted';attempt.submittedAt=time;attempt.revision++;attempt.gradingStatus=attemptResult(p,attempt).gradingStatus;validateContract('attempt',attempt);
    p.submissionKeys.push({key:idempotencyKey,actorId:actor.actorId,attemptId,fingerprint,submittedAt:time});
    try{return this.view(await this.repository.save(p,p.revision),attempt.allocationId,actor);}
    catch(error){if(error.code!=='VERSION_CONFLICT')throw error;const fresh=initialize(await this.repository.get(projectId));const committed=fresh.submissionKeys.find(k=>k.actorId===actor.actorId&&k.attemptId===attemptId&&k.key===idempotencyKey);if(!committed)throw error;if(committed.fingerprint!==fingerprint)reject('同一提交識別的內容已改變。','IDEMPOTENCY_CONFLICT');return this.view(fresh,attempt.allocationId,actor);}
  }
  async grade(projectId,expected,responseId,score,reason=''){
    const {p,actor}=await this.context(projectId,'teacher');revision(p,expected);const response=p.responses.find(r=>r.id===responseId);if(!response)reject('作答不存在。');
    const {attempt,version}=this.target(p,actor,response.attemptId);submitted(attempt);const q=version.questions.find(q=>q.id===response.questionId);
    if(!q||!Number.isFinite(score)||score<0||score>q.maxScore||typeof reason!=='string')reject('分數必須在 0 與本題配分之間。');
    const previous=effective_scores(p.scoreRevisions.filter(s=>s.responseId===responseId&&s.origin==='teacher'))[responseId];
    p.scoreRevisions.push({id:uid(),responseId,origin:'teacher',score,maxScore:q.maxScore,reason,supersedesId:previous?.id??null,actorId:actor.actorId,createdAt:this.clock(),invalidatedAt:null});
    attempt.gradingStatus=attemptResult(p,attempt).gradingStatus;attempt.revision++;validateContract('attempt',attempt);return this.repository.save(p,expected);
  }
  async revokeGrade(projectId,expected,scoreRevisionId){
    const {p}=await this.context(projectId,'teacher');revision(p,expected);const score=p.scoreRevisions.find(s=>s.id===scoreRevisionId);if(!score||score.origin!=='teacher'||score.invalidatedAt)reject('只能撤銷尚有效的教師評分修訂。');
    const response=p.responses.find(r=>r.id===score.responseId),attempt=p.attempts.find(a=>a.id===response?.attemptId);submitted(attempt);score.invalidatedAt=this.clock();attempt.gradingStatus=attemptResult(p,attempt).gradingStatus;attempt.revision++;return this.repository.save(p,expected);
  }
  async saveFeedback(projectId,expected,attemptId,body){
    const {p}=await this.context(projectId,'teacher');revision(p,expected);submitted(p.attempts.find(a=>a.id===attemptId));if(typeof body!=='string'||body.length>20000)reject('回饋必須是文字且不超過 20,000 字元。');
    const old=p.feedbackDrafts.find(f=>f.attemptId===attemptId);if(old){old.body=body;old.revision++;}else p.feedbackDrafts.push({id:uid(),attemptId,origin:'teacher',body,status:'draft',revision:1,publishedAt:null});return this.repository.save(p,expected);
  }
  async release(projectId,expected,attemptId,kind,idempotencyKey){
    const {p,actor}=await this.context(projectId,'teacher');key(idempotencyKey);if(!['score','answers','feedback'].includes(kind))reject('未知發布類別。');
    const prior=p.assessmentKeys.find(k=>k.operation==='release'&&k.actorId===actor.actorId&&k.key===idempotencyKey);
    if(prior){if(prior.attemptId!==attemptId||prior.kind!==kind||prior.expected!==expected)reject('同一發布識別用於不同內容。','IDEMPOTENCY_CONFLICT');return p;}
    revision(p,expected);const {attempt,version}=this.target(p,actor,attemptId);submitted(attempt);let data;
    if(kind==='score'){const result=attemptResult(p,attempt);data={score:result.score,scoredMax:result.scoredMax,totalMax:result.totalMax,scoreComplete:result.scoreComplete,questions:result.questions.map(({questionId,score,maxScore})=>({questionId,score,maxScore}))};}
    if(kind==='answers')data=version.questions.map(q=>['shortAnswer','upload'].includes(q.type)?{questionId:q.id,rubric:q.rubric}:['singleChoice','trueFalse'].includes(q.type)?{questionId:q.id,answer:q.answerKey}:{questionId:q.id,display:answerLabel(q)});
    if(kind==='feedback'){const draft=p.feedbackDrafts.find(f=>f.attemptId===attemptId);if(!draft?.body.trim())reject('請先保存非空白的回饋草稿。');data={body:draft.body,revision:draft.revision};}
    const record={id:uid(),attemptId,kind,data:copy(data),publishedAt:this.clock(),actorId:actor.actorId};p.releases.push(record);p.assessmentKeys.push({operation:'release',key:idempotencyKey,actorId:actor.actorId,attemptId,kind,expected,resultId:record.id});return this.repository.save(p,expected);
  }
}
