import {el,button,field,renderDraftEditor,renderPreview} from './content-editor.js';
import {errorEnvelope} from '../contracts/errors.js';
import {contentOfVersion,validateContent} from '../domain/content.js';
import {draftIssues} from '../domain/draft-validation.js';
import {validateGenerationSettings} from '../domain/generation-settings.js';
import {RESOURCE_LABELS,TYPE_LABELS} from '../domain/extended-questions.js';
const labels=RESOURCE_LABELS;
export function mountWorkbench(root,service,onUpdate,onBusy=()=>{},canAct=()=>true){
  const model=service.mode==='model';
  let updatePublish=()=>{};
  let pendingGeneration=null;
  let project=null,selected=null,draft=null,dirty=false,busy=false,sourceDirty=false,externalBusy=false,abort=null;
  const heading=el('h2','教材與資源工作台'),notice=el('p','先選擇或儲存一個專案。'),status=el('p','',{role:'status',id:'workbench-state'}),error=el('p','',{role:'alert',id:'workbench-error'}),fieldset=el('fieldset','',{id:'workbench-controls'}),cancel=button('取消生成',()=>abort?.abort());
  cancel.id='cancel-generation';cancel.hidden=true;root.replaceChildren(heading,notice,status,error,fieldset,cancel);
  function showError(e){const out=errorEnvelope(e);error.textContent=`${out.error.message}（${out.error.code}，追蹤碼 ${out.requestId}）`;showValidation(out.error.details);}
  function showValidation(issues=[]){
    root.querySelector('#draft-validation')?.remove();root.querySelectorAll('[data-validation-error]').forEach(n=>{n.removeAttribute('data-validation-error');n.removeAttribute('aria-invalid');n.style.outline='';});
    if(!issues.length)return;const box=el('div','',{id:'draft-validation',role:'alert'});box.append(el('strong','請修正以下欄位：'));
    for(const item of issues){const target=[...root.querySelectorAll('[data-question-id],[data-block-id]')].find(n=>n.dataset.questionId===item.targetId||n.dataset.blockId===item.targetId);
      let field=target;if(target&&item.field){const label=[...target.querySelectorAll('label')].find(l=>l.firstChild?.textContent===item.field);field=label?.querySelector('input,textarea,select')??label??target;}
      if(field){field.dataset.validationError='true';field.setAttribute('aria-invalid','true');field.style.outline='2px solid #b42318';}
      box.append(button(item.message??`${item.path??''}：欄位不符合格式`,()=>{field?.scrollIntoView({block:'center'});field?.focus?.();}));
    }root.querySelector('#draft-fields')?.prepend(box);
  }
  function syncBusy(){fieldset.disabled=busy||sourceDirty||externalBusy||!project||project.status==='archived';updatePublish();}
  async function action(operation){if(busy||sourceDirty||externalBusy||!canAct())return;busy=true;onBusy(true);syncBusy();error.textContent='';try{await operation();}catch(e){showError(e);}finally{busy=false;onBusy(false);syncBusy();}}
  function changed(){dirty=true;status.textContent='工作台有未保存修改；發布前請先儲存並重新審核。';const reviewed=root.querySelector('#reviewed');if(reviewed)reviewed.checked=false;updatePublish();}
  function accept(p){project=p;dirty=false;onUpdate(p);render();}
  function render(){
    updatePublish=()=>{};
    fieldset.replaceChildren();syncBusy();if(!project)return;
    notice.textContent=project.status==='archived'?'此專案已封存，請恢復後編修。':sourceDirty?'請先保存上方來源修改，再進行分析與生成。':model?'Gemma 4 12B 真實模型草稿；請核對來源及答案。評量資源固定 5 題，可選八種題型；簡答與作品由教師批改。閱讀／講義／字彙／概念圖設 0 題；遊戲未啟用。':'AI 為 mock 範本：複製原文與固定題目，不提供語義改寫、翻譯或教學品質保證。';
    const source=project.source,prep=project.preparation;
    const details=el('details','',{id:'preparation-panel'});details.open=!prep;details.append(el('summary','核對來源範圍與確認學習目標'));
    details.append(el('p',source.inputMode==='topic'?'教學主題模式：沒有教材來源定位，不會虛構頁碼。':`解析狀態：${source.parseStatus??'ready'}；已處理 ${source.coverage?.processed??'?'}／${source.coverage?.total??'未知'} 段；缺漏：${JSON.stringify(source.coverage?.missing??[])}。`));
    const original=el('details');original.append(el('summary','查看原始匯入與目前文字'),el('h4','原始內容'),el('pre',source.originalText??source.text),el('h4','目前採用內容'),el('pre',source.text));details.append(original);
    const candidate=project.analysisCandidate;
    const analyze=button(model?'AI 分析教材並填入草案（Ollama）':'填入 mock 分析範本（需教師修改）',()=>action(async()=>{
      if(dirty&&!confirm('重新分析會取代目前四欄尚未保存的修改，是否繼續？'))return;
      abort=new AbortController();cancel.hidden=false;status.textContent=model?'Ollama 正在分析目前教材範圍，請稍候…':'正在產生分析範本…';
      let polling=false;const progressTimer=model&&service.analysisStatus?setInterval(async()=>{if(polling)return;polling=true;try{const p=await service.analysisStatus(project.id);if(abort)status.textContent=`教材分析：${p.state}；已完成 ${p.completed}/${p.total} 批。`;}catch{/* Keep original analysis error visible. */}finally{polling=false;}},1000):null;
      try{accept(await service.analyze(project.id,project.revision,{signal:abort.signal}));status.textContent=model?'AI 已填入四欄分析草案，可任意修改；請核對後保存確認。':'已填入原文摘錄與固定分析範本；尚未確認範圍與目標。';}
      finally{clearInterval(progressTimer);abort=null;cancel.hidden=true;}
    }));analyze.id='analyze-material';details.append(analyze);
    if(model&&service.analysisStatus){const resume=button('繼續上次分析',()=>analyze.click());resume.id='resume-analysis';details.append(resume,el('p','來源與模型版本一致時，按分析或續作均會跳過已完成批次；來源或配置改變則重新分析。'));}
    if(candidate)details.append(el('p',`分析來源：${candidate.origin==='model'?'Ollama Gemma 4 12B':'mock'}，來源修訂 ${candidate.sourceRevision}。${candidate.warnings?.join('；')??''}`));
    const values={objectiveText:prep?.objectives.map(o=>o.description).join('\n')??candidate?.objectiveText??'',summary:prep?.summary??candidate?.summary??'',concepts:prep?.concepts??candidate?.concepts??'',vocabulary:prep?.vocabulary??candidate?.vocabulary??'',scopeAccepted:prep?.sourceRevision===source.revision&&prep?.scopeAccepted};
    const objective=field('學習目標（每行一項；由教師確認）',values.objectiveText,v=>{values.objectiveText=v;changed();},{type:'textarea'});objective.querySelector('textarea').id='learning-objectives';details.append(objective);
    for(const [key,label] of [['summary','教師摘要'],['concepts','核心概念'],['vocabulary','候選詞彙']])details.append(field(label,values[key],v=>{values[key]=v;changed();},{type:'textarea'}));
    const scope=field(source.parseStatus==='partial'?'我已看過缺漏，明確同意只使用已處理範圍':'我已核對以上內容與學習目標',values.scopeAccepted,v=>values.scopeAccepted=v,{type:'checkbox'});scope.querySelector('input').id='scope-accepted';details.append(scope);
    const confirm=button('保存核對結果與目標',()=>action(async()=>{accept(await service.prepare(project.id,project.revision,values));status.textContent='來源範圍與學習目標已確認。';}));confirm.id='confirm-preparation';details.append(confirm);fieldset.append(details);
    const generation=el('details','',{id:'generation-panel'});generation.open=Boolean(prep);generation.append(el('summary',model?'建立差異化資源分支（Gemma）':'建立差異化資源分支（mock）'));
    const profile={language:'zh-Hant',readingLoad:{teacherLabel:'閱讀支持版',sentenceGuidance:'使用短句並保留核心概念',vocabularySupport:true},cognitiveChallenge:'理解與解釋',scaffolds:['sentenceFrames'],supportTier:null};
    const spec={resourceType:'reading',title:`${project.title}教材`,questionTypes:model?[]:['singleChoice','trueFalse','shortAnswer'],questionCount:model?0:3};
    const lastJob=(project.jobs??[]).at(-1);const failed=['failed','cancelled'].includes(lastJob?.state)&&lastJob.sourceRevision===project.source.revision&&lastJob.generationSettings?.spec.questionCount===0?lastJob:null;
    const restored=pendingGeneration??failed?.generationSettings;if(model&&restored){Object.assign(profile,structuredClone(restored.profile));Object.assign(spec,structuredClone(restored.spec));}
    generation.append(field('分支範本','support',v=>{if(v==='challenge'){profile.readingLoad={teacherLabel:'延伸挑戰版',sentenceGuidance:'保留原文並說明因果關係',vocabularySupport:false};profile.cognitiveChallenge='推論與解釋';profile.scaffolds=[];}else{profile.readingLoad={teacherLabel:'閱讀支持版',sentenceGuidance:'使用短句並保留核心概念',vocabularySupport:true};profile.cognitiveChallenge='理解與解釋';profile.scaffolds=['sentenceFrames'];}renderProfile();},{options:[['support','閱讀支持版'],['challenge','延伸挑戰版']]}));
    const profileFields=el('div');function renderProfile(){profileFields.replaceChildren(field('分支名稱',profile.readingLoad.teacherLabel,v=>profile.readingLoad.teacherLabel=v),field(model?'輸出語言（例如英文題目、繁體中文解析）':'語言設定（mock 不自動翻譯）',profile.language,v=>profile.language=v),field('閱讀負荷指引',profile.readingLoad.sentenceGuidance,v=>profile.readingLoad.sentenceGuidance=v),field('認知挑戰',profile.cognitiveChallenge,v=>profile.cognitiveChallenge=v),field('詞彙支持提示',profile.readingLoad.vocabularySupport,v=>profile.readingLoad.vocabularySupport=v,{type:'checkbox'}),field('鷹架（每行一項）',profile.scaffolds.join('\n'),v=>profile.scaffolds=v.split('\n').filter(s=>s.trim()),{type:'textarea'}));}renderProfile();generation.append(profileFields);
    const type=field('資源類型',spec.resourceType,v=>{spec.resourceType=v;if(model){spec.questionCount=['reading','handout','vocabulary','organizer'].includes(v)?0:5;spec.questionTypes=spec.questionCount?['singleChoice']:[];syncSpec();}},{options:Object.entries(labels)});type.querySelector('select').id='resource-type';generation.append(type);
    const title=field('資源名稱',spec.title,v=>spec.title=v);title.querySelector('input').id='resource-title';generation.append(title);
    const count=field('題數（0～100）',spec.questionCount,v=>spec.questionCount=v,{type:'number'});count.querySelector('input').id='question-count';generation.append(count);
    for(const [type,label] of Object.entries(TYPE_LABELS)){const choice=field(label,spec.questionTypes.includes(type),checked=>{spec.questionTypes=checked?[...spec.questionTypes,type]:spec.questionTypes.filter(x=>x!==type);},{type:'checkbox'});choice.querySelector('input').dataset.questionType=type;generation.append(choice);}
    function syncSpec(){count.querySelector('input').value=spec.questionCount;if(model){count.querySelector('input').disabled=true;for(const input of generation.querySelectorAll('[data-question-type]')){input.checked=spec.questionTypes.includes(input.dataset.questionType);input.disabled=spec.questionCount===0;}}}
    syncSpec();
    const generate=button(model?'生成 Gemma 草稿分支':'生成 mock 草稿分支',()=>action(async()=>{
      validateGenerationSettings(spec,model);
      if(dirty&&!confirm('目前草稿有未保存的修改。要放棄修改並生成新分支嗎？'))return;
      abort=new AbortController();cancel.hidden=false;
      let polling=false;const generationTimer=model&&['reading','handout'].includes(spec.resourceType)&&service.generationStatus?setInterval(async()=>{if(polling)return;polling=true;try{const p=await service.generationStatus(project.id,{profile,spec});if(abort)status.textContent=`講義生成：${p.state}；已完成 ${p.completed}/${p.total} 批。`;}catch{}finally{polling=false;}},1000):null;
      try{const result=await service.generate(project.id,project.revision,{profile,spec},{signal:abort.signal,onState:job=>{status.textContent=`${model?'Gemma':'mock'} 工作：${job.state}；追蹤碼 ${job.requestId}`;}});selected=result.resourceId;pendingGeneration=null;accept(result.project);root.dispatchEvent(new CustomEvent('teaching:resource',{bubbles:true,detail:{projectId:project.id,resourceId:result.resourceId}}));status.textContent=(model?'Gemma':'mock')+' 草稿已建立，尚未發布。請逐項核對與編修。';}
      catch(e){pendingGeneration=structuredClone({profile,spec});try{const latest=await service.getProject(project.id);if(latest){project=latest;onUpdate(latest);}}catch{/* Preserve the original generation failure if reload also fails. */}throw e;}
      finally{clearInterval(generationTimer);cancel.hidden=true;abort=null;}
    }));generate.id='generate-resource';generation.append(generate);fieldset.append(generation);
    if(model){const resume=button('繼續上次講義生成',async()=>{if(busy||sourceDirty||externalBusy)return;if(!['reading','handout'].includes(spec.resourceType)){status.textContent='請先選擇講義或閱讀文章；續作須使用相同來源與分支設定。';return;}try{const latest=await service.getProject(project.id);if(!latest||latest.source.revision!==project.source.revision||JSON.stringify(latest.preparation)!==JSON.stringify(project.preparation)){status.textContent='來源或學習目標已變更，請重新載入並確認。';return;}project=latest;generate.click();}catch(e){showError(e);}});resume.id='resume-handout';generation.append(resume,el('p','講義失敗後保留已完成批次；同一來源、模型與設定可續作，變更後重新生成。'));}
    const list=el('div','',{id:'resource-library'});list.append(el('h3','差異化分支與版本'));
    for(const r of project.resources??[]){const p=project.profiles.find(p=>p.id===r.profileId);const entry=project.drafts.find(d=>d.id===r.currentDraftId),latest=project.versions.find(v=>v.id===r.latestPublishedVersionId);list.append(button(`${p.readingLoad.teacherLabel} · ${labels[r.type]} · ${entry?'草稿':`已發布 v${latest?.versionNo}`}`,()=>{if(dirty&&!confirm('要放棄尚未保存的草稿修改並切換嗎？'))return;selected=r.id;dirty=false;render();root.dispatchEvent(new CustomEvent('teaching:resource',{bubbles:true,detail:{projectId:project.id,resourceId:r.id}}));}));}
    if(!project.resources?.length)list.append(el('p','尚未建立資源分支。'));fieldset.append(list);
    const resource=project.resources?.find(r=>r.id===selected);if(resource){
      const entry=project.drafts.find(d=>d.id===resource.currentDraftId);const panel=el('div','',{id:'resource-editor'});panel.append(el('h3','資源編修與發布'));
      const cloneSettings=button('複製此分支設定',()=>{const savedProfile=project.profiles.find(p=>p.id===resource.profileId),content=entry?.content??project.versions.find(v=>v.id===resource.latestPublishedVersionId);Object.assign(profile,structuredClone(savedProfile));spec.resourceType=resource.type;spec.title=content.title+'（副本）';spec.questionCount=content.questions.length;spec.questionTypes=[...new Set(content.questions.map(q=>q.type))];renderProfile();type.querySelector('select').value=spec.resourceType;title.querySelector('input').value=spec.title;count.querySelector('input').value=spec.questionCount;for(const input of generation.querySelectorAll('[data-question-type]'))input.checked=spec.questionTypes.includes(input.dataset.questionType);syncSpec();generation.open=true;status.textContent='已複製設定，可修改後生成新的獨立分支；原分支保持不變。';});cloneSettings.addEventListener('click',()=>root.dispatchEvent(new CustomEvent('teaching:generation',{bubbles:true})));cloneSettings.id='copy-profile';panel.append(cloneSettings);
      const preview=el('div','',{id:'resource-preview',class:'resource-preview'});
      if(entry){
        draft=structuredClone(entry.content);const editor=el('div','',{id:'draft-fields'});renderDraftEditor(editor,draft,entry.context,changed);panel.append(editor);
        const actions=el('div','',{class:'actions'});const save=button('保存草稿',()=>action(async()=>{showValidation([]);try{validateContent(draft,entry.context);}catch(localError){if(service.validateDraft){try{await service.validateDraft(project.id,project.revision,resource.id,draft);}catch(serverError){if(serverError.code==='VALIDATION_FAILED')throw serverError;}}throw localError;}accept(await service.saveDraft(project.id,project.revision,resource.id,draft,entry.revision));status.textContent='草稿已保存；發布前請重新核對。';}));save.id='save-draft';actions.append(save);
        for(const student of [true,false])actions.append(button(`${student?'學生':'教師'}預覽`,()=>{try{renderPreview(preview,draft,entry.context,student);error.textContent='';}catch(e){showError(e);}}));panel.append(actions);
        const reviewed=field('我已逐項審核最終內容、正解、配分、規準與來源',false,()=>updatePublish(),{type:'checkbox'});reviewed.querySelector('input').id='reviewed';panel.append(reviewed);
        const publish=button('確認發布不可變版本',()=>action(async()=>{if(dirty){status.textContent='請先保存草稿，再審核發布。';return;}const result=await service.publish(project.id,project.revision,resource.id,entry.revision,crypto.randomUUID(),root.querySelector('#reviewed').checked);accept(result.project);status.textContent='已發布新的不可變版本；舊版本保持不變。';}));publish.id='publish-resource';panel.append(publish);
        const blockers=el('p','',{id:'publish-blockers',role:'status'});panel.append(blockers);
        updatePublish=()=>{const reasons=[];if(dirty)reasons.push('尚有未保存修改');if(!reviewed.querySelector('input').checked)reasons.push('尚未勾選審核');const count=draftIssues(draft,entry.context).length;if(count)reasons.push(`草稿尚有 ${count} 個欄位問題，請按保存草稿查看`);if(busy||sourceDirty||externalBusy)reasons.push('請先完成目前操作或保存來源');blockers.textContent=reasons.length?'發布受阻：'+reasons.join('；'):'可確認發布。';publish.disabled=!!reasons.length;};updatePublish();
      }else{const revise=button('從最新發布版另開修訂草稿',()=>action(async()=>{accept(await service.revise(project.id,project.revision,resource.id));status.textContent='已建立新草稿，原發布版保持不變。';}));revise.id='revise-resource';panel.append(revise);}
      const history=el('div','',{id:'version-history'});history.append(el('h4','歷史版本（唯讀）'));for(const v of project.versions.filter(v=>v.resourceId===resource.id))history.append(button(`查看 v${v.versionNo} · ${new Date(v.publishedAt).toLocaleString('zh-TW')}`,()=>{renderPreview(preview,contentOfVersion(v),v.context,false);}));panel.append(history,preview);fieldset.append(panel);
    }
    const jobs=el('details');jobs.append(el('summary',model?'近期模型工作紀錄':'近期 mock 工作紀錄'));for(const job of (project.jobs??[]).slice(-8).reverse())jobs.append(el('p',`${job.state} · ${job.requestId}${job.error?' · '+job.error.message:''}${job.warnings?' · '+job.warnings.join('；'):''}`));fieldset.append(jobs);
  }
  return {selectResource(id){selected=id;dirty=false;render();},setProject(p){if(p?.id!==project?.id){selected=null;pendingGeneration=null;}project=p;dirty=false;error.textContent='';render();},setExternalBusy(value){externalBusy=value;syncBusy();},setSourceDirty(value){sourceDirty=value;syncBusy();notice.textContent=value?'來源有未儲存的變更，請先保存再繼續。':'AI 為 mock 範本，請教師核對後發布。';},hasChanges(){return dirty;},isBusy(){return busy;},dispose(){abort?.abort();root.replaceChildren();}};
}
