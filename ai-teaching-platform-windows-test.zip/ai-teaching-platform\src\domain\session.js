import {reject} from './assessment.js';
export const SESSION_LABELS={lobby:'準備中',active:'進行中',paused:'已暫停',ended:'已結束'};
export function sessionFor(p,assignmentId){return (p.sessions??[]).find(s=>s.assignmentId===assignmentId)??null;}
export function requireActiveSession(p,assignment){if(assignment.mode==='synchronous'&&sessionFor(p,assignment.id)?.state!=='active')reject('課堂尚未開始、已暫停或已結束；本次操作未保存。','SESSION_NOT_ACTIVE');}
export function publicSession(session){if(!session)return null;const {id,assignmentId,state,sequence,pacing,updatedAt}=session;return {id,assignmentId,state,sequence,pacing,updatedAt};}
// Notifications never supply authoritative data. A gap requires a fresh snapshot.
export class SnapshotTracker {
  constructor({ttlMs=15000}={}){this.ttlMs=ttlMs;this.sequence=0;this.aggregateId=null;this.lastRead=null;this.connected=true;this.needsSnapshot=true;}
  hydrate(snapshot,now=Date.now()){if(this.aggregateId===snapshot.id&&snapshot.sequence<this.sequence)return false;this.aggregateId=snapshot.id;this.sequence=snapshot.sequence;this.lastRead=now;this.needsSnapshot=false;this.connected=true;return true;}
  receive(event){if(event.aggregateId!==this.aggregateId)return 'other';if(!Number.isInteger(event.sequence)||event.sequence<1)return 'invalid';if(event.sequence<=this.sequence)return 'duplicate';if(event.sequence!==this.sequence+1){this.needsSnapshot=true;return 'gap';}this.sequence=event.sequence;this.needsSnapshot=true;return 'refresh';}
  disconnect(){this.connected=false;}
  freshness(now=Date.now()){return this.lastRead===null?'unknown':!this.connected||this.needsSnapshot||now-this.lastRead>this.ttlMs?'stale':'fresh';}
}
