import {AppError} from '../contracts/errors.js';
import {validateContract} from '../contracts/validate.js';
import {validate_layout} from '../domain/rules.js';
export class MockIdentity {
  mode='mock';
  async getContext(){return {actorId:'demo-teacher',tenantId:'local-demo',role:'teacher',mode:'mock'};}
}
export class DemoLearnerIdentity {
  mode='mock';
  constructor(actorId){this.actorId=actorId;}
  async getContext(){return {actorId:this.actorId,tenantId:'local-demo',role:'student',mode:'mock'};}
}
export class FixtureAI {
  mode='mock';
  constructor(request,result){this.request=structuredClone(request);this.result=structuredClone(result);}
  async generateResources(request){
    validateContract('generate-request',request);
    const compare=({...request,requestId:this.request.requestId});
    if(JSON.stringify(compare)!==JSON.stringify(this.request)) throw new AppError('UNSUPPORTED_FORMAT','此 mock 僅支援內附水循環示範請求，尚無通用 AI 生成。');
    const result={...structuredClone(this.result),requestId:request.requestId};
    validateContract('generate-result',result);result.resources.forEach(validate_layout);return result;
  }
}
export class LocalEventBus {
  mode='mock'; listeners=new Set();
  subscribe(listener){this.listeners.add(listener);return ()=>this.listeners.delete(listener);}
  publish(event){for(const listener of this.listeners) listener(structuredClone(event));}
  dispose(){this.listeners.clear();}
}
export class LocalHostBridge {
  async getContext(){return {mode:'standalone-local',authenticated:false};}
  requestNavigation(){throw new AppError('UNSUPPORTED_FORMAT','宿主導覽尚未啟用。');}
  onContextChange(){return ()=>{};}
  dispose(){}
}
