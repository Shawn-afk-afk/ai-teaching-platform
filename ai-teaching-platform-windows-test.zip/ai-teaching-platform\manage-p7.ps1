param(
 [ValidateSet('start','backup','restore','diagnose','trace')][string]$Action = 'diagnose',
 [string]$DatabasePath = 'data/l1.sqlite', [string]$Destination, [string]$BackupPath, [string]$RequestId
)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$p7Node = Get-Command node.exe -ErrorAction SilentlyContinue
if (-not $p7Node) { throw 'Node.js 24 or newer is required. Install it, then reopen PowerShell.' }
$pythonPath = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $pythonPath)) { throw 'Python environment missing. Run setup.ps1 first.' }
$env:PDF_PYTHON = $pythonPath
switch ($Action) {
 'start' { $env:AI_PROVIDER = 'ollama'; $env:L1_DB = [IO.Path]::GetFullPath((Join-Path $PWD $DatabasePath)); & $p7Node.Source 'server/main.mjs' }
 'backup' { if (-not $Destination) { throw 'Specify -Destination.' }; & $p7Node.Source 'tools/maintenance.mjs' 'backup' $DatabasePath $Destination }
 'restore' { if (-not $BackupPath -or -not $Destination) { throw 'Specify -BackupPath and -Destination.' }; & $p7Node.Source 'tools/maintenance.mjs' 'restore' $BackupPath $Destination }
 'diagnose' { & $p7Node.Source 'tools/diagnose-p7.mjs' $DatabasePath }
 'trace' { if (-not $RequestId) { throw 'Specify -RequestId.' }; & $p7Node.Source 'tools/diagnose-p7.mjs' $DatabasePath $RequestId }
}
exit $LASTEXITCODE
