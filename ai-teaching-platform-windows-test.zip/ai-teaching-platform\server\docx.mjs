import {spawn} from 'node:child_process';
import {resolve} from 'node:path';
import {project_student} from '../src/domain/rules.js';
import {answerLabel} from '../src/domain/extended-questions.js';
import {AppError} from '../src/contracts/errors.js';
export async function exportDocx(version,teacher){
 if(typeof teacher!=='boolean')throw new AppError('VALIDATION_FAILED','請選擇教師版或學生版。');
 const content=teacher?version:project_student(version,'docx','docx'),payload={content,teacher,versionNo:version.versionNo,answers:teacher?Object.fromEntries(version.questions.map(q=>[q.id,answerLabel(q)])):{}};
 const python=process.env.PDF_PYTHON??'C:\\Program Files\\WindowsApps\\OpenAI.CodexPrimaryRuntime.v26-1119-907-0_26.1119.907.0_x64__3k8sg7r9htsxt\\dependencies\\python\\python.exe';
 const bytes=await new Promise((resolvePromise,reject)=>{const child=spawn(python,[resolve('tools/export_docx.py')],{windowsHide:true,stdio:['pipe','pipe','pipe']}),chunks=[];let size=0;const timer=setTimeout(()=>{child.kill();reject(new AppError('UPSTREAM_TIMEOUT','可編輯文件匯出逾時。'));},30000);child.on('error',e=>{clearTimeout(timer);reject(e);});child.stdin.on('error',()=>{});child.stdout.on('data',chunk=>{size+=chunk.length;if(size>10*1024*1024){child.kill();reject(new AppError('FILE_TOO_LARGE','可編輯文件超過匯出上限。'));}else chunks.push(chunk);});child.stderr.on('data',()=>{});child.on('close',code=>{clearTimeout(timer);if(code!==0)reject(new AppError('EXPORT_FAILED','DOCX 匯出失敗，請確認 Python／python-docx 可用。'));else resolvePromise(Buffer.concat(chunks));});child.stdin.end(JSON.stringify(payload));});
 return {name:teacher?'教師教材.docx':'學生教材.docx',mime:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',base64:bytes.toString('base64')};
}
