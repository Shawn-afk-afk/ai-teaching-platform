import {responseLabel} from './extended-questions.js';
import {latest_submitted_attempt,timestamp,csv_safe_text} from './rules.js';
import {attemptResult,learnersFor,reject} from './assessment.js';
export function buildReport(project,assignmentId){
  const assignment=(project.assignments??[]).find(a=>a.id===assignmentId);if(!assignment)reject('請選擇作業。');
  const allocations=(project.allocations??[]).filter(a=>a.assignmentId===assignmentId),attempts=project.attempts??[],DEMO_LEARNERS=learnersFor(project);
  const rows=allocations.map(allocation=>{
    const version=project.versions.find(v=>v.id===allocation.resourceVersionId);if(!version)reject('指派版本不存在。');
    const own=attempts.filter(a=>a.allocationId===allocation.id&&!a.invalidatedAt),selected=latest_submitted_attempt(own,allocation.id),progress=own.filter(a=>a.status==='in_progress').sort((a,b)=>b.attemptNo-a.attemptNo)[0]??selected;
    const responses=(project.responses??[]).filter(r=>r.attemptId===progress?.id),dates=[...responses.map(r=>r.savedAt),progress?.startedAt,progress?.submittedAt].filter(Boolean).sort((a,b)=>timestamp(a)<timestamp(b)?-1:timestamp(a)>timestamp(b)?1:0);
    return {allocationId:allocation.id,learnerId:allocation.learnerId,learnerName:DEMO_LEARNERS.find(l=>l.id===allocation.learnerId)?.name??allocation.learnerId,versionId:version.id,versionNo:version.versionNo,resourceTitle:version.title,attemptId:selected?.id??null,attemptNo:selected?.attemptNo??null,status:selected?.status??'not_submitted',gradingStatus:selected?.gradingStatus??'not_started',progressStatus:progress?.status??'not_started',answered:responses.filter(r=>r.answer!==null&&r.answer!=='').length,questionCount:version.questions.length,lastActivityAt:dates.at(-1)??null,result:selected?attemptResult(project,selected):null};
  });
  const groups=[...new Set(rows.map(r=>r.versionId))].map(versionId=>{
    const version=project.versions.find(v=>v.id===versionId),members=rows.filter(r=>r.versionId===versionId),submitted=members.filter(r=>r.result);
    const questions=version.questions.map(q=>{
      const evidence=submitted.map(row=>{const score=row.result.questions.find(s=>s.questionId===q.id),response=project.responses.find(r=>r.attemptId===row.attemptId&&r.questionId===q.id),answer=response.answer;const answerText=answer===null?'未作答':q.type==='singleChoice'?q.options.find(o=>o.id===answer)?.text??answer:q.type==='trueFalse'?answer?'是':'否':answer;return {learnerId:row.learnerId,attemptId:row.attemptId,answer,answerText,score:score.score,maxScore:q.maxScore};});
      const scored=evidence.filter(e=>e.score!==null),objective=!['shortAnswer','upload'].includes(q.type)&&q.maxScore>0;
      return {questionId:q.id,prompt:q.prompt,type:q.type,objectiveIds:q.objectiveIds,maxScore:q.maxScore,assigned:members.length,submitted:evidence.length,pending:evidence.length-scored.length,notSubmitted:members.length-evidence.length,scored:scored.length,scoreSum:scored.reduce((sum,e)=>sum+e.score,0),scoredMax:scored.length*q.maxScore,correct:objective?scored.filter(e=>e.score===q.maxScore).length:null,correctDenominator:objective?scored.length:0,excludedFromCorrect:objective?members.length-scored.length:members.length,evidence};
    });
    const objectiveIds=[...new Set(questions.flatMap(q=>q.objectiveIds))];
    const objectives=objectiveIds.map(id=>{const items=questions.filter(q=>q.objectiveIds.includes(id));return {objectiveId:id,description:version.context?.objectives?.find(o=>o.id===id)?.description??id,questionIds:items.map(q=>q.questionId),score:items.reduce((n,q)=>n+q.scoreSum,0),scoredMax:items.reduce((n,q)=>n+q.scoredMax,0),pending:items.reduce((n,q)=>n+q.pending,0),notSubmitted:items.reduce((n,q)=>n+q.notSubmitted,0)};});
    return {versionId,versionNo:version.versionNo,title:version.title,assigned:members.length,submitted:submitted.length,complete:submitted.filter(r=>r.result.scoreComplete).length,questions,objectives};
  });
  return {assignmentId,title:assignment.title,projectRevision:project.revision,assigned:rows.length,submitted:rows.filter(r=>r.result).length,notSubmitted:rows.filter(r=>!r.result).length,rows,groups};
}
export function serializeCSV(rows){return '\uFEFF'+rows.map(row=>row.map(v=>'"'+(typeof v==='string'?csv_safe_text(v):v==null?'':String(v)).replaceAll('"','""')+'"').join(',')).join('\r\n')+'\r\n';}
export function reportCSV(report,project){
  const rows=[['作業','學生','版本ID','教材','版本號','提交次數','流程','評分狀態','得分','已評配分','總配分','評分完整','題目ID','題目','作答','題目得分','題目配分']];
  for(const row of report.rows){const version=project.versions.find(v=>v.id===row.versionId),result=row.result;const base=[report.title,row.learnerName,row.versionId,row.resourceTitle,row.versionNo,row.attemptNo,row.status,row.gradingStatus,result?.score??null,result?.scoredMax??null,result?.totalMax??version.questions.reduce((n,q)=>n+q.maxScore,0),result?.scoreComplete??false];
    if(!result||!version.questions.length){rows.push([...base,'','','',null,null]);continue;}
    for(const q of version.questions){const response=project.responses.find(r=>r.attemptId===row.attemptId&&r.questionId===q.id),score=result.questions.find(s=>s.questionId===q.id);const answer=response.answer===null?'':responseLabel(q,response.answer);rows.push([...base,q.id,q.prompt,answer,score.score,q.maxScore]);}
  }
  return serializeCSV(rows);
}
