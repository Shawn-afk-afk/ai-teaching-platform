import {el,field,button} from './content-editor.js';
import {errorEnvelope} from '../contracts/errors.js';
import {SnapshotTracker,SESSION_LABELS} from '../domain/session.js';
import {renderPrint} from './print-view.js';
import {MAX_PACK_BYTES} from '../domain/resource-pack.js';
import {reject} from '../domain/assessment.js';
function download(text,name,type){const url=URL.createObjectURL(new Blob([text],{type})),a=el('a','',{href:url,download:name});a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function table(headers,rows){const wrap=el('div','',{class:'table-scroll'}),t=el('table'),head=el('thead'),tr=el('tr');for(const h of headers)tr.append(el('th',h,{scope:'col'}));head.append(tr);t.append(head);const body=el('tbody');for(const row of rows){const line=el('tr');for(const value of row)line.append(el('td',String(value??'—')));body.append(line);}t.append(body);wrap.append(t);return wrap;}
export function mountReports(root,classroom,exports,onUpdated,onBusy,canAct,{serverMode=false}={}){
  let project=null,assignmentId=null,busy=false,externalBusy=false,disposed=false,offline=false,sequence=0,previewText=null;
  let tracker=new SnapshotTracker(),snapshot=null;
  const status=el('p','',{id:'report-state',role:'status'}),error=el('p','',{id:'report-error',role:'alert'}),controls=el('fieldset','',{id:'report-controls'}),report=el('div','',{id:'report-content'}),freshness=el('p','',{id:'report-freshness'}),sessionControls=el('div','',{id:'session-controls'});
  const printRoot=el('section','',{id:'print-root','aria-label':'列印預覽'});printRoot.hidden=true;root.parentElement.parentElement.append(printRoot);
  root.replaceChildren(el('h2','課堂、報告與輸出'),el('p',`${serverMode?'每 2 秒讀取伺服器快照':'本機示範；每 2 秒讀取同一瀏覽器資料庫'}。fresh 表示最近成功取得快照，不代表學生在線。`),status,error,controls);
  const sync=()=>{controls.disabled=busy||externalBusy;};
  function showError(e){const v=errorEnvelope(e);error.textContent=`${v.error.message}（${v.error.code}；追蹤碼 ${v.requestId}）`;}
  async function action(fn){if(busy||externalBusy||!canAct())return;busy=true;onBusy(true);sync();error.textContent='';try{await fn();}catch(e){showError(e);}finally{busy=false;onBusy(false);sync();await refresh();}}
  function clearPrint(){printRoot.hidden=true;printRoot.replaceChildren();document.body.classList.remove('print-ready');}
  function renderReport(value){
    report.replaceChildren();const r=value.report;
    report.append(el('h3',r.title),el('p',`指派 ${r.assigned} 人；有效提交 ${r.submitted} 人；尚未提交 ${r.notSubmitted} 人。不同版本分組呈現，不以原始總分排名。`));
    report.append(table(['學生','教材版本','目前進度','已答題數','最後保存活動','採計提交','評分','得分／已評配分／總配分'],r.rows.map(row=>[row.learnerName,`${row.resourceTitle} v${row.versionNo}`,{not_started:'未開始',in_progress:'作答中',submitted:'已提交',closed:'已關閉'}[row.progressStatus],`${row.answered}／${row.questionCount}`,row.lastActivityAt?new Date(row.lastActivityAt).toLocaleString('zh-TW'):'未知',row.attemptNo?`第 ${row.attemptNo} 次`:'尚未提交',row.result?row.result.scoreComplete?'完整':'待批改／部分已評':'尚無提交',row.result?`${row.result.score}／${row.result.scoredMax}／${row.result.totalMax}`:'未計分'])));
    for(const g of r.groups){const group=el('details');group.open=true;group.append(el('summary',`${g.title} v${g.versionNo}：${g.submitted}／${g.assigned} 人提交；${g.complete} 人評分完整`));
      group.append(el('h4','題目證據'),table(['題目','已評／提交／指派','待批改／未交','滿分作答比（客觀題）','排除數'],g.questions.map(q=>[q.prompt,`${q.scored}／${q.submitted}／${q.assigned}`,`${q.pending}／${q.notSubmitted}`,q.correct===null?'不適用（人工評量或零配分）':`${q.correct}／${q.correctDenominator}`,q.excludedFromCorrect])));
      group.append(el('p','客觀題比率以最新有效教師／規則分數達滿分為分子；待批改、未交與不適用題型不進分母。'));
      group.append(el('h4','學習目標證據'),table(['目標','證據題數','得分／已評配分','待批改題次','未交題次'],g.objectives.map(o=>[o.description,o.questionIds.length,`${o.score}／${o.scoredMax}`,o.pending,o.notSubmitted])));
      for(const o of g.objectives){const evidence=el('details');evidence.append(el('summary',`目標「${o.description}」的證據題目`),...g.questions.filter(q=>o.questionIds.includes(q.questionId)).map(q=>el('p',q.prompt)));group.append(evidence);}group.append(el('p','目標數據只描述本版本題目證據；一題可對應多目標，不加總為跨版本能力值。'));
      const learner=el('details');learner.append(el('summary','逐題學生作答與評分證據'));for(const q of g.questions)learner.append(el('h5',q.prompt),table(['學生','作答','得分／配分'],q.evidence.map(e=>[r.rows.find(x=>x.learnerId===e.learnerId)?.learnerName,e.answerText,`${e.score??'待批改'}／${e.maxScore}`])));group.append(learner);report.append(group);
    }
  }
  async function refresh(){
    if(disposed||!project||!assignmentId||busy)return;if(offline){tracker.disconnect();freshness.textContent=`${tracker.freshness()} · 模擬斷線；畫面保留上次快照，不能控制課堂。`;sessionControls.querySelectorAll('button').forEach(b=>b.disabled=true);return;}
    const ticket=++sequence,pid=project.id,aid=assignmentId;
    try{const value=await classroom.snapshot(pid,aid);if(disposed||ticket!==sequence||aid!==assignmentId||pid!==project?.id)return;
      const changed=snapshot?.projectRevision!==value.projectRevision||snapshot?.report.assignmentId!==aid,wasStale=tracker.freshness()!=='fresh';
      if(value.session){for(const event of value.events)tracker.receive(event);tracker.hydrate(value.session);}else tracker.hydrate({id:aid,sequence:value.projectRevision});snapshot=value;
      freshness.textContent=`${tracker.freshness()} · 快照取得：${new Date(value.readAt).toLocaleString('zh-TW')}（${serverMode?'伺服器':'本機'}）`;if(changed)renderReport(value);if(changed||wasStale)renderSession();
    }catch(e){tracker.disconnect();freshness.textContent=`${tracker.freshness()} · 讀取失敗，保留上次快照。`;sessionControls.querySelectorAll('button').forEach(b=>b.disabled=true);showError(e);}
  }
  function renderSession(){sessionControls.replaceChildren();const s=snapshot?.session;if(!s){sessionControls.append(el('p','自主學習作業，沒有同步課堂控制。'));return;}
    sessionControls.append(el('h3',`課堂：${SESSION_LABELS[s.state]}`),el('p','自由作答節奏；暫停禁止修改、暫存與提交。結束後唯讀，不自動提交草稿。'));
    for(const [actionName,label] of Object.entries({start:'開始課堂',pause:'暫停課堂',resume:'繼續課堂',end:'結束課堂'})){
      if(!({lobby:['start','end'],active:['pause','end'],paused:['resume','end'],ended:[]}[s.state].includes(actionName)))continue;
      const b=button(label,()=>action(async()=>{if(offline)reject('模擬斷線中，請先重新取得快照。');if(actionName==='end'&&!confirm('結束後唯讀且不會自動收卷，確定結束嗎？'))return;const p=await classroom.transition(project.id,snapshot.projectRevision,assignmentId,actionName,...(serverMode?[{sessionSequence:s.sequence}]:[]));onUpdated(p);status.textContent=`已${label}；狀態已保存。`;}));b.id='session-'+actionName;sessionControls.append(b);
    }
  }
  function draw(){controls.replaceChildren();report.replaceChildren();snapshot=null;tracker=new SnapshotTracker();sequence++;clearPrint();
    if(project){const assignments=project.assignments??[];if(!assignments.some(a=>a.id===assignmentId))assignmentId=assignments[0]?.id??null;
      if(assignments.length){const select=field('報告作業',assignmentId,v=>{assignmentId=v;tracker=new SnapshotTracker();void refresh();},{options:assignments.map(a=>[a.id,a.title])});select.querySelector('select').id='report-assignment';controls.append(select);
        const off=field('模擬中斷快照讀取',offline,v=>{offline=v;void refresh();},{type:'checkbox'});off.querySelector('input').id='simulate-offline';controls.append(off,freshness,button('重新取得快照',()=>void refresh()),sessionControls,report);
        const csv=button('下載成績 CSV',()=>action(async()=>{download(await classroom.exportCSV(project.id,assignmentId),'成績.csv','text/csv;charset=utf-8');status.textContent='已產生成績 CSV（含最新有效提交、版本與評分完整度）。';}));csv.id='export-csv';controls.append(csv);
      }else controls.append(el('p','尚無作業。可先在指派區建立自主學習或同步課堂作業。'));
      const versions=project.versions??[];if(versions.length){let vid=versions.at(-1).id,teacher=false;const area=el('details');area.open=true;area.append(el('summary','教材列印與 JSON 輸出'));
        const select=field('輸出教材版本',vid,v=>{vid=v;clearPrint();},{options:versions.map(v=>[v.id,`${v.title} v${v.versionNo}`])});select.querySelector('select').id='export-version';area.append(select);
        const kind=field('列印對象','student',v=>{teacher=v==='teacher';clearPrint();},{options:[['student','學生版（無答案）'],['teacher','教師版（含答案與規準）']]});kind.querySelector('select').id='print-audience';area.append(kind);
        const preview=button('建立列印預覽',()=>action(async()=>{renderPrint(printRoot,await exports.printVersion(project.id,vid),teacher);status.textContent='列印預覽已建立於頁面下方。';}));preview.id='preview-print';const print=button('列印／另存 PDF',()=>action(async()=>{renderPrint(printRoot,await exports.printVersion(project.id,vid),teacher);window.print();}));print.id='print-resource';const json=button('下載教材 JSON',()=>action(async()=>{download(await exports.resourceJSON(project.id,vid),'教材資源.json','application/json');status.textContent='已產生教材包；含教師內容與必要來源快照，不含學生資料。';}));json.id='export-json';area.append(preview,print,json,el('p','每包一個已發布版本，含教師答案、規準與發布時段落；不含學生作答、完整來源附件或系統備份。'));if(exports.docxVersion){const docx=button('下載可編輯 DOCX',()=>action(async()=>{const file=await exports.docxVersion(project.id,vid,teacher);download(Uint8Array.from(atob(file.base64),c=>c.charCodeAt(0)),file.name,file.mime);status.textContent='已產生可編輯 DOCX。';}));docx.id='export-docx';area.append(docx);}controls.append(area);}
    }else controls.append(el('p','選擇專案後查看報告；也可匯入教材包建立新專案。'));
    const importArea=el('details');importArea.open=true;importArea.append(el('summary','匯入教材 JSON（建立草稿副本）'));const input=el('input','',{type:'file',accept:'.json,application/json',id:'import-pack'}),preview=el('p','',{id:'import-preview'}),confirm=button('確認匯入草稿副本',()=>action(async()=>{if(!previewText)reject('請先選擇有效教材包。');const p=await exports.importResource(previewText,true);previewText=null;onUpdated(p);status.textContent='教材已匯入為新專案草稿，請教師重新審核後發布。';}));confirm.id='confirm-import';confirm.disabled=true;previewText=null;
    input.addEventListener('change',()=>action(async()=>{previewText=null;confirm.disabled=true;preview.textContent='';const f=input.files[0];if(!f)return;if(f.size>MAX_PACK_BYTES)reject('教材包上限為 5 MiB。','FILE_TOO_LARGE');const text=await f.text(),result=await exports.previewImport(text);previewText=text;preview.textContent=`${result.title}：${result.questions} 題、${result.blocks} 區塊；偵測 ${result.conflicts.length} 個既有 ID 衝突。所有 ID 都會重建，原資料保留；匯入為未發布草稿。`;confirm.disabled=false;}));const label=el('label','選擇 JSON 教材包（上限 5 MiB）',{for:'import-pack'});importArea.append(label,input,preview,confirm);controls.append(importArea);sync();void refresh();
  }
  const timer=setInterval(()=>void refresh(),2000);
  draw();
  return {setProject(p){project=p;error.textContent='';draw();},setExternalBusy(v){externalBusy=v;sync();},isBusy:()=>busy,hasChanges:()=>Boolean(previewText),dispose(){disposed=true;sequence++;clearInterval(timer);clearPrint();printRoot.remove();root.replaceChildren();}};
}
