import {DatabaseSync} from 'node:sqlite';
import {readFile} from 'node:fs/promises';
import {P6_CONFIG} from '../server/ai/config.mjs';
const [database='data/l1.sqlite',requestId]=process.argv.slice(2),report={at:new Date().toISOString(),node:process.version,checks:[]};
async function check(name,fn){try{report.checks.push({name,passed:true,details:await fn()});}catch(error){report.checks.push({name,passed:false,message:error.message,cause:error.cause?.code});process.exitCode=1;}}
await check('database',()=>{const db=new DatabaseSync(database,{readOnly:true});try{
 const integrity=db.prepare('PRAGMA integrity_check').all(),foreignKeys=db.prepare('PRAGMA foreign_key_check').all();if(integrity.some(r=>r.integrity_check!=='ok')||foreignKeys.length)throw Error('Database integrity check failed');
 if(requestId){if(!/^[a-f0-9-]{36}$/i.test(requestId))throw Error('Expected a request UUID');return {errors:db.prepare('SELECT request_id,path,code,at FROM request_errors WHERE request_id=?').all(requestId),validation:db.prepare('SELECT summary FROM request_validation WHERE request_id=?').all(requestId).map(r=>JSON.parse(r.summary))};}
 return {integrity:'ok',foreignKeys:'ok',projects:db.prepare('SELECT count(*) n FROM projects').get().n};
}finally{db.close();}});
if(!requestId){
 await check('website',async()=>{const origin=process.env.L1_ORIGIN??'http://127.0.0.1:4180';const response=await fetch(origin+'/',{signal:AbortSignal.timeout(5000)});if(!response.ok)throw Error('HTTP '+response.status);return {origin,status:response.status};});
 await check('model',async()=>{const installed=JSON.parse(await readFile('docs/evidence/p6/model-install.json','utf8'));const response=await fetch(P6_CONFIG.baseUrl+'/api/tags',{signal:AbortSignal.timeout(10000)});if(!response.ok)throw Error('HTTP '+response.status);const model=(await response.json()).models.find(m=>m.name===P6_CONFIG.model);if(!model||model.digest!==installed.tags[0].digest)throw Error('Model missing or digest changed; revalidation required');return {model:model.name,digest:model.digest,quantization:model.details?.quantization_level};});
}
console.log(JSON.stringify(report,null,2));
