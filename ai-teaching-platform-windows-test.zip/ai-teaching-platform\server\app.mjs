import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {resolve,extname,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
import {timingSafeEqual,randomUUID} from 'node:crypto';
import {Store,ScopedRepository,token} from './store.mjs';
import {LocalAuthProvider} from './auth.mjs';
import {AppError,errorEnvelope,classifyError} from '../src/contracts/errors.js';
import {ProjectService} from '../src/application/project-service.js';
import {ContentService} from '../src/application/content-service.js';
import {AssessmentService} from '../src/application/assessment-service.js';
import {ClassroomService} from '../src/application/classroom-service.js';
import {ExportService} from '../src/application/export-service.js';
import {TemplateAI} from '../src/infrastructure/template-ai.js';
import {parsePDF} from './pdf.mjs';
import {KnowledgeBase} from './knowledge.mjs';
import {OllamaAI} from './ai/ollama-ai.mjs';
import {readWork,saveWork} from './works.mjs';
import {exportDocx} from './docx.mjs';
const ROOT=resolve(fileURLToPath(new URL('..',import.meta.url))),fail=(message,code='VALIDATION_FAILED')=>{throw new AppError(code,message);};
const same=(a,b)=>typeof a==='string'&&typeof b==='string'&&Buffer.byteLength(a)===Buffer.byteLength(b)&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
const methods={project:['list','get','save'],content:['generationStatus','validateDraft','getProject','analyze','analysisStatus','prepare','generate','saveDraft','publish','revise'],assessment:['assign','grade','revokeGrade','saveFeedback','release'],classroom:['snapshot','transition','exportCSV'],export:['resourceJSON','previewImport','importResource','printVersion','docxVersion']};
async function body(req){if(!req.headers['content-type']?.startsWith('application/json'))fail('請使用 JSON 請求。');let bytes=0,chunks=[];for await(const chunk of req){bytes+=chunk.length;if(bytes>6*1024*1024)fail('請求超過 6 MiB。','FILE_TOO_LARGE');chunks.push(chunk);}try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{fail('JSON 格式無效。');}}
export function createApp({dbPath,publicOrigin,store=new Store(dbPath),auth=new LocalAuthProvider(store),setupToken=token(),ai=new TemplateAI()}={}){
  if(publicOrigin!==undefined){let parsed;try{parsed=new URL(publicOrigin);}catch{throw new Error('PUBLIC_ORIGIN must be an HTTPS origin.');}if(parsed.protocol!=='https:'||parsed.username||parsed.password||parsed.pathname!=='/'||parsed.search||parsed.hash)throw new Error('PUBLIC_ORIGIN must be an HTTPS origin without a path, credentials, query or fragment.');publicOrigin=parsed.origin;}
  const rate=new Map(),queues=new Map();let origin;
  const knowledge=new KnowledgeBase(store.db);
  store.db.exec('CREATE TABLE IF NOT EXISTS request_validation(request_id TEXT, summary TEXT)');
  store.db.exec('CREATE TABLE IF NOT EXISTS request_errors(request_id TEXT, path TEXT, code TEXT, at TEXT)');
  // Serialize commands on one project in this process; SQLite CAS still rejects
  // stale teacher edits and writers from another process. Reads see committed JSON.
  async function command(id,fn){const previous=queues.get(id)??Promise.resolve();const job=previous.catch(()=>{}).then(fn);queues.set(id,job);try{return await job;}finally{if(queues.get(id)===job)queues.delete(id);}}
  const cookie=req=>/\bl1_session=([A-Za-z0-9_-]+)/.exec(req.headers.cookie??'')?.[1];
  const session=req=>auth.authenticate(cookie(req));
  function requireSession(req,role){const s=session(req);if(!s)fail('登入已失效，請重新登入。','UNAUTHENTICATED');if(role&&s.actor.role!==role)fail('此身分無權使用此功能。','FORBIDDEN');return s;}
  const services=(req,actor,action)=>{const repo=new ScopedRepository(store,actor,action),identity={getContext:async()=>{requireSession(req,actor.role);return actor;}};const get=repo.get.bind(repo),list=repo.list.bind(repo),save=repo.save.bind(repo);repo.get=async id=>{requireSession(req);return get(id);};repo.list=async()=>{requireSession(req);return list();};repo.save=async(...args)=>{requireSession(req);return save(...args);};return {repo,project:new ProjectService(repo,identity),content:new ContentService(repo,ai),assessment:new AssessmentService(repo,identity,{clock:()=>new Date(store.clock()).toISOString()}),classroom:new ClassroomService(repo,identity,{clock:()=>new Date(store.clock()).toISOString()}),export:new ExportService(repo,identity)};};
  function throttle(req){const key=req.socket.remoteAddress,now=store.clock(),entry=rate.get(key);if(!entry||now-entry.start>15*60*1000)rate.set(key,{start:now,count:1});else if(++entry.count>100)fail('登入嘗試過於頻繁，請稍後重試。','RATE_LIMITED');}
  const headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'no-referrer','Cross-Origin-Resource-Policy':'same-origin','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"};
  const server=http.createServer(async(req,res)=>{
    const supplied=req.headers['x-request-id'];const requestId=typeof supplied==='string'&&/^[0-9a-f-]{36}$/i.test(supplied)?supplied:randomUUID();res.setHeader('X-Request-ID',requestId);
    const send=(data,status=200,extra={})=>{res.writeHead(status,{...headers,'Content-Type':'application/json; charset=utf-8',...extra});res.end(JSON.stringify(data));};
    try{
      const requestOrigin=publicOrigin&&req.headers.host===new URL(publicOrigin).host?publicOrigin:origin;
      if(req.headers.host!==new URL(requestOrigin).host)fail('不接受此主機名稱。','FORBIDDEN');const url=new URL(req.url,requestOrigin),path=url.pathname;
      const secureCookie=requestOrigin===publicOrigin?'; Secure':'';
      if(path.startsWith('/api/')){
        if(path==='/api/student/works'&&req.method==='POST'){
          if(req.headers.origin!==requestOrigin)fail('不接受跨來源操作。','FORBIDDEN');const s=requireSession(req,'student');if(!same(req.headers['x-csrf-token'],s.csrf))fail('操作驗證失效。','FORBIDDEN');
          const projectId=url.searchParams.get('projectId'),svc=services(req,s.actor,'work.upload');
          return send(await command(projectId,async()=>{requireSession(req,'student');const p=await svc.repo.get(projectId);if(!p)fail('專案不存在。','NOT_FOUND');const {attempt,assignment,version}=svc.assessment.target(p,s.actor,url.searchParams.get('attemptId'));svc.assessment.open(p,assignment);if(attempt.status!=='in_progress'||attempt.invalidatedAt)fail('已提交作品不可更動。','ATTEMPT_CLOSED');const q=version.questions.find(q=>q.id===url.searchParams.get('questionId'));if(q?.type!=='upload')fail('題目不接受作品上傳。');let current;try{current=JSON.parse(url.searchParams.get('current')??'[]');}catch{fail('作品清單無效。');}const file=await readWork(req,url.searchParams.get('name'));requireSession(req,'student');svc.assessment.open(p,assignment);return saveWork(store,p,s.actor,attempt,q,current,file);}));
        }
        if(path.startsWith('/api/works/')&&req.method==='GET'){
          const s=requireSession(req),file=store.db.prepare('SELECT * FROM work_files WHERE id=?').get(path.split('/').at(-1));if(!file)fail('作品不存在。','NOT_FOUND');const p=await services(req,s.actor,'work.download').repo.get(file.project_id);if(!p||(s.actor.role==='student'&&file.student_id!==s.actor.actorId))fail('不能下載此作品。','FORBIDDEN');
          res.writeHead(200,{...headers,'Content-Type':'application/octet-stream','Content-Disposition':`attachment; filename="work.${file.name.split('.').at(-1)}"; filename*=UTF-8''${encodeURIComponent(file.name)}`,'Content-Length':file.size});return res.end(Buffer.from(file.body));
        }
        if(!['GET','POST'].includes(req.method))fail('不支援的 HTTP 方法。');
        if(path==='/api/knowledge/file'&&req.method==='POST'){
          if(req.headers.origin!==requestOrigin)fail('不接受跨來源操作。','FORBIDDEN');const s=requireSession(req,'teacher');
          if(!same(req.headers['x-csrf-token'],s.csrf))fail('操作驗證失效。','FORBIDDEN');
          return send(await command('ingest:'+s.actor.actorId,()=>knowledge.ingest(req,s.actor.actorId,{name:url.searchParams.get('name'),subject:url.searchParams.get('subject'),unitId:url.searchParams.get('unitId')||undefined})));
        }
        let data;
        if(req.method==='POST'){if(req.headers.origin!==requestOrigin)fail('不接受跨來源操作。','FORBIDDEN');data=await body(req);if(!data||typeof data!=='object'||Array.isArray(data))fail('請求資料必須為物件。');}
        if(path==='/api/me'&&req.method==='GET'){const s=session(req);return send({actor:s?.actor??null,csrf:s?.csrf??null,setupRequired:store.teacherCount()===0});}
        if(req.method==='POST'&&['/api/setup','/api/login','/api/join'].includes(path)){
          if(path==='/api/setup'&&requestOrigin===publicOrigin)fail('請先在本機完成教師初始化。','FORBIDDEN');
          throttle(req);let result;
          if(path==='/api/setup'){if(store.teacherCount()||!same(data.setupToken,setupToken))fail('初始化識別無效或系統已完成設定。','FORBIDDEN');store.createTeacher(data.username,data.password,data.name??data.username);setupToken=null;result=auth.loginTeacher(data.username,data.password);}
          else result=path==='/api/login'?auth.loginTeacher(data.username,data.password):auth.loginStudent(data.code);
          auth.logout(cookie(req));return send({actor:result.actor,csrf:result.csrf},200,{'Set-Cookie':`l1_session=${result.token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${Math.floor(auth.sessionMs/1000)}${secureCookie}`});
        }
        const currentSession=requireSession(req);if(req.method==='POST'&&!same(req.headers['x-csrf-token'],currentSession.csrf))fail('操作驗證失效，請重新載入。','FORBIDDEN');
        if(path==='/api/knowledge'&&req.method==='GET'){requireSession(req,'teacher');return send(knowledge.list(currentSession.actor.actorId,url.searchParams.get('subject')??'未分類'));}
        if(path==='/api/knowledge/retrieve'&&req.method==='POST'){requireSession(req,'teacher');return send(knowledge.retrieve(currentSession.actor.actorId,data));}
        if(path==='/api/pdf'&&req.method==='POST'){requireSession(req,'teacher');return send(await parsePDF(data));}
        if(path==='/api/model'&&req.method==='GET'){requireSession(req,'teacher');return send({mode:ai.mode??'mock'});}
        if(path==='/api/logout'&&req.method==='POST'){auth.logout(cookie(req));return send({loggedOut:true},200,{'Set-Cookie':`l1_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0${secureCookie}`});}
        if(path==='/api/password'&&req.method==='POST'){requireSession(req,'teacher');return send(auth.changePassword(currentSession.actor,data.current,data.next),200,{'Set-Cookie':`l1_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0${secureCookie}`});}
        if(path==='/api/roster'&&req.method==='GET'){requireSession(req,'teacher');return send({learners:store.roster(currentSession.actor.actorId),invitations:store.invitations(currentSession.actor.actorId)});}
        if(path==='/api/invite'&&req.method==='POST'){requireSession(req,'teacher');return send(store.issueInvite(currentSession.actor.actorId,data));}
        if(path==='/api/revoke'&&req.method==='POST'){requireSession(req,'teacher');return send(store.revokeInvite(currentSession.actor.actorId,data.id));}
        if(path==='/api/audit'&&req.method==='GET'){requireSession(req,'teacher');return send(store.db.prepare('SELECT id,action,project_id,revision,at FROM audit WHERE actor=? OR project_id IN (SELECT id FROM projects WHERE owner=?) ORDER BY id DESC LIMIT 100').all(currentSession.actor.actorId,currentSession.actor.actorId));}
        const route=/^\/api\/teacher\/([a-z]+)\/([A-Za-z]+)$/.exec(path);
        if(route&&req.method==='POST'){
          requireSession(req,'teacher');const [,group,method]=route;if(!methods[group]?.includes(method))fail('不支援的操作。','NOT_FOUND');if(!Array.isArray(data.args)||data.args.length>8)fail('操作參數無效。');
          const svc=services(req,currentSession.actor,`${group}.${method}`);let value;
          const execute=async()=>{if(group==='export'&&method==='docxVersion')return exportDocx(await svc.export.printVersion(data.args[0],data.args[1]),data.args[2]);if(group==='content'&&['generate','analyze'].includes(method)){const abort=new AbortController();res.on('close',()=>{if(!res.writableEnded)abort.abort();});return method==='analyze'?svc.content.analyze(...data.args.slice(0,2),{signal:abort.signal}):svc.content.generate(...data.args.slice(0,3),{signal:abort.signal});}return svc[group][method](...data.args);};
          const projectId=group==='project'&&method==='save'?data.args[0]?.id:data.args[0];value=group==='content'&&['generate','analyze','analysisStatus','generationStatus'].includes(method)?await execute():await command(typeof projectId==='string'?projectId:'teacher:'+currentSession.actor.actorId,execute);
          return send(value);
        }
        if(path==='/api/student/list'&&req.method==='GET'){
          requireSession(req,'student');const svc=services(req,currentSession.actor,'student.list'),list=[];for(const p of await svc.repo.list())for(const a of await svc.assessment.listMine(p.id))list.push({...a,projectId:p.id});return send(list);
        }
        if(path==='/api/student/view'&&req.method==='GET'){requireSession(req,'student');return send(await services(req,currentSession.actor,'student.view').assessment.getMine(url.searchParams.get('projectId'),url.searchParams.get('allocationId')));}
        if(path==='/api/student/session'&&req.method==='GET'){requireSession(req,'student');return send(await services(req,currentSession.actor,'student.session').assessment.sessionState(url.searchParams.get('projectId'),url.searchParams.get('allocationId')));}
        const student=/^\/api\/student\/(begin|save|submit)$/.exec(path);
        if(student&&req.method==='POST'){requireSession(req,'student');const svc=services(req,currentSession.actor,'student.'+student[1]).assessment;
          const result=await command(data.projectId,()=>student[1]==='begin'?svc.begin(data.projectId,data.allocationId):student[1]==='save'?svc.saveAnswers(data.projectId,data.attemptId,data.revision,data.answers):svc.submit(data.projectId,data.attemptId,data.revision,data.answers,data.key));return send(result);
        }
        fail('找不到此 API。','NOT_FOUND');
      }
      if(req.method!=='GET'&&req.method!=='HEAD')fail('找不到此頁面。','NOT_FOUND');
      let file;if(path==='/')file=resolve(ROOT,'src/l1/login.html');else if(path==='/student'){requireSession(req,'student');file=resolve(ROOT,'src/l1/student.html');}
      else if(path==='/teacher'){requireSession(req,'teacher');let html=await readFile(resolve(ROOT,'index.html'),'utf8');html=html.replace('./src/main.js','/src/l1/teacher.js').replace('./styles/main.css','/styles/main.css').replace('本機原型</strong> · 示範教師身分（mock），沒有正式登入、真實 AI 或多人同步。','L1 開發版</strong> · 伺服器登入與隔離資料；僅用合成資料測試，AI 仍為 mock。');res.writeHead(200,{...headers,'Content-Type':'text/html; charset=utf-8'});return res.end(html);}
      else if(path.startsWith('/src/')||path.startsWith('/styles/')){file=resolve(ROOT,'.'+decodeURIComponent(path));if(!file.startsWith(resolve(ROOT,'src')+sep)&&!file.startsWith(resolve(ROOT,'styles')+sep))fail('找不到此檔案。','NOT_FOUND');}
      else fail('找不到此頁面。','NOT_FOUND');
      let content;try{content=await readFile(file);}catch{fail('找不到此檔案。','NOT_FOUND');}res.writeHead(200,{...headers,'Content-Type':{'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8'}[extname(file)]??'text/plain'});res.end(req.method==='HEAD'?undefined:content);
    }catch(e){const error=classifyError(e);try{if(error.code==='VALIDATION_FAILED'){const summary=(error.details??[]).map(d=>({path:String(d.path??'').slice(0,200),keyword:String(d.keyword??'').slice(0,40),field:String(d.field??'').slice(0,40)}));store.db.prepare('INSERT INTO request_validation VALUES(?,?)').run(requestId,JSON.stringify(summary));}store.db.prepare('INSERT INTO request_errors VALUES(?,?,?,?)').run(requestId,(req.url??'').split('?')[0],error.code,new Date().toISOString());}catch{console.error(JSON.stringify({requestId,code:error.code,event:'request_failed'}));}if(res.writableEnded||res.destroyed)return;const status={UNAUTHENTICATED:401,FORBIDDEN:403,NOT_FOUND:404,VERSION_CONFLICT:409,IDEMPOTENCY_CONFLICT:409,RATE_LIMITED:429,FILE_TOO_LARGE:413,SERVER_ERROR:500,OPERATION_FAILED:500,STORAGE_UNAVAILABLE:503,MODEL_SERVICE_UNAVAILABLE:503,UPSTREAM_TIMEOUT:504}[error.code]??400;send(errorEnvelope(error,requestId),status);}
  });
  server.requestTimeout=0;server.headersTimeout=10000;
  return {server,store,get setupToken(){return setupToken;},get origin(){return origin;},async listen(port=4180){await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});origin=`http://127.0.0.1:${server.address().port}`;return origin;},async close(){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));store.close();}};
}
