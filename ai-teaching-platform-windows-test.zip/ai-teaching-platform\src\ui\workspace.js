import {errorEnvelope} from '../contracts/errors.js';
import {capabilities,resources} from '../registries/capabilities.js';
import {parsers} from '../infrastructure/parsers.js';
import {mountWorkbench} from './workbench.js';
import {mountAssessment} from './assessment-workbench.js';
import {mountReports} from './report-workbench.js';
export async function mountWorkspace(root,service,contentService,assessmentService,learnerFactory,classroomService,exportService,{serverMode=false}={}){
  const $=selector=>root.querySelector(selector),controller=new AbortController();
  const listen=(el,event,fn)=>el?.addEventListener(event,fn,{signal:controller.signal});
  let current=null,dirty=false,busy=false,listSequence=0,importInfo=null,workbench=null,assessment=null,reports=null;
  const anyDirty=()=>dirty||workbench?.hasChanges()||assessment?.hasChanges()||reports?.hasChanges();
  const anyBusy=()=>busy||workbench?.isBusy()||assessment?.isBusy()||reports?.isBusy();
  const setSourceBusy=value=>{for(const node of root.querySelectorAll('#project-form input,#project-form textarea,#project-form select,#project-form button,#input-mode,#txt-file,#new-project,#reload'))node.disabled=value;workbench?.setExternalBusy(value);assessment?.setExternalBusy(value||dirty);reports?.setExternalBusy(value||dirty);};
  function error(e){const value=errorEnvelope(e);$('#error-state').hidden=false;$('#error-state').textContent=`${value.error.message}（${value.error.code}；追蹤碼 ${value.requestId}）`;$('#save-state').textContent='未儲存；輸入已保留。';if(value.error.code==='VERSION_CONFLICT'){$('#save-copy').hidden=false;$('#reload').hidden=false;}}
  function load(record){
    current=record;dirty=false;importInfo=null;$('#title').value=record?.title??'';$('#source-text').value=record?.source.text??'';
    if($('#input-mode'))$('#input-mode').value=record?.source.inputMode??'source';
    $('#editor-title').textContent=record?'編輯專案':'新增專案';$('#record-meta').textContent=record?`修訂 ${record.revision} · ${record.status==='archived'?'已封存':'使用中'}`:'保存後會建立固定識別碼。';
    $('#save-state').textContent=record?'已載入最近確認的儲存資料。':'尚未儲存';$('#error-state').hidden=true;$('#save-copy').hidden=true;$('#reload').hidden=!record;$('#archive').hidden=!record;$('#archive').textContent=record?.status==='archived'?'恢復專案':'封存專案';
    if($('#import-state'))$('#import-state').textContent=record?.source.originalName?`來源檔案：${record.source.originalName}`:'';
    workbench?.setSourceDirty(false);workbench?.setProject(record);assessment?.setProject(record);assessment?.setExternalBusy(false);reports?.setProject(record);reports?.setExternalBusy(false);
    if(serverMode)root.dispatchEvent(new CustomEvent('teaching:project',{detail:{id:record?.id??null}}));
  }
  async function refresh(){
    const seq=++listSequence;$('#list-state').textContent='載入中…';
    try{const list=await service.list($('#search').value);if(seq!==listSequence)return;$('#project-list').replaceChildren();$('#list-state').textContent=list.length?`${list.length} 個專案（含已封存）`:'尚無符合的專案。可以新增一份教材。';
      for(const record of list){const li=document.createElement('li'),button=document.createElement('button'),meta=document.createElement('small');button.type='button';button.textContent=record.title;meta.textContent=`${record.status==='archived'?'已封存':'使用中'} · 修訂 ${record.revision}`;button.append(meta);
        listen(button,'click',async()=>{if(anyBusy())return;if(anyDirty()&&!confirm('有尚未儲存的修改。要放棄修改並切換嗎？'))return;try{load(await service.get(record.id));}catch(e){error(e);}});li.append(button);$('#project-list').append(li);}
    }catch(e){if(seq===listSequence){$('#list-state').textContent='專案庫載入失敗。';error(e);}}
  }
  if(contentService&&$('#workbench'))workbench=mountWorkbench($('#workbench'),contentService,p=>{load(p);void refresh();},value=>{setSourceBusy(value);assessment?.setExternalBusy(value);},()=>{if(assessment?.isBusy())return false;if(assessment?.hasChanges()){alert('請先保存指派、作答或批改區的修改，再操作教材工作台。');return false;}return true;});
  if(assessmentService&&$('#assessment'))assessment=mountAssessment($('#assessment'),assessmentService,learnerFactory,p=>{load(p);void refresh();},async()=>{load(await service.get(current.id));await refresh();},setSourceBusy,()=>{if(dirty||workbench?.isBusy()||workbench?.hasChanges()){alert('請先保存上方來源或教材工作台的修改，再操作指派與作答。');return false;}return true;},{serverMode});
  if(classroomService&&exportService&&$('#reports'))reports=mountReports($('#reports'),classroomService,exportService,p=>{load(p);void refresh();},setSourceBusy,()=>{if(dirty||workbench?.hasChanges()||assessment?.hasChanges()){alert('請先保存來源、教材或作答批改區的修改，再操作課堂與輸出。');return false;}return true;},{serverMode});
  async function save(asCopy=false,status=current?.status??'active'){
    if(anyBusy())return;
    if((workbench?.hasChanges()||assessment?.hasChanges()||reports?.hasChanges())&&!confirm('其他工作區有未保存修改。保存來源會重新載入，要放棄這些修改嗎？'))return;
    busy=true;setSourceBusy(true);$('#error-state').hidden=true;$('#save-state').textContent='儲存中…';
    try{const saved=await service.save({id:asCopy?undefined:current?.id,revision:asCopy?0:current?.revision??0,title:$('#title').value,sourceText:$('#source-text').value,status,inputMode:$('#input-mode')?.value??'source',importInfo});load(saved);$('#save-state').textContent=serverMode?'已儲存至伺服器資料庫。':'已儲存至本機資料庫。';await refresh();}
    catch(e){error(e);}finally{busy=false;setSourceBusy(false);}
  }
  listen($('#project-form'),'submit',event=>{event.preventDefault();void save();});
  listen($('#save-copy'),'click',()=>void save(true));listen($('#archive'),'click',()=>void save(false,current.status==='archived'?'active':'archived'));
  listen($('#reload'),'click',async()=>{if(anyDirty()&&!confirm('重新載入會放棄目前尚未儲存的輸入，是否繼續？'))return;try{load(await service.get(current.id));}catch(e){error(e);}});
  listen($('#new-project'),'click',()=>{if(anyBusy())return;if(anyDirty()&&!confirm('有尚未儲存的修改。要放棄修改並新增專案嗎？'))return;load(null);$('#title').focus();});
  listen($('#search'),'input',()=>void refresh());
  const markDirty=()=>{dirty=true;$('#save-state').textContent='有尚未儲存的修改。';workbench?.setSourceDirty(true);assessment?.setExternalBusy(true);reports?.setExternalBusy(true);};
  for(const node of [$('#title'),$('#source-text'),$('#input-mode')])listen(node,'input',markDirty);
  listen($('#txt-file'),'change',async()=>{
    const file=$('#txt-file').files[0];if(!file||anyBusy())return;busy=true;setSourceBusy(true);$('#import-state').textContent='正在讀取 TXT…';
    try{let parsed;
      if(/\.pdf$/i.test(file.name)&&service.importPDF){
        if(file.size>4*1024*1024)throw new Error('PDF 上限 4 MiB。');
        $('#import-state').textContent='正在逐頁擷取 PDF…';const pdf=await service.importPDF(file);
        const report=pdf.pages.map(p=>`PDF 第 ${p.pdfPage} 頁：${p.status}`).join('\n');
        const selection=prompt(`${report}\n${pdf.warnings.join('\n')}\n請填 PDF 檔案頁碼（不是印刷頁碼），例如 12-16 對應這份教材的印刷 13-17：`, `1-${pdf.pages.length}`);
        if(selection===null)return;
        const chosen=new Set();for(const range of selection.split(',')){const match=/^\s*(\d+)(?:\s*-\s*(\d+))?\s*$/.exec(range);if(!match)throw new Error('頁碼格式錯誤');const first=Number(match[1]),last=Number(match[2]??match[1]);if(first<1||last>pdf.pages.length||last<first)throw new Error('頁碼範圍錯誤');for(let n=first;n<=last;n++)chosen.add(n);}
        const pages=pdf.pages.filter(p=>chosen.has(p.pdfPage));if(pages.some(p=>p.status!=='text_extracted'))throw new Error('選取範圍有掃描或失敗頁，需先補正，不能生成。');
        const text=pages.map(p=>`[PDF頁 ${p.pdfPage}]\n${p.text}`).join('\n');
        parsed={text,originalText:pages.map(p=>`[PDF頁 ${p.pdfPage}]\n${p.rawText}`).join('\n'),originalName:file.name,parseStatus:'partial',coverage:{unit:'page',total:pdf.pages.length,processed:pages.length,missing:pdf.pages.filter(p=>!chosen.has(p.pdfPage)).map(p=>p.pdfPage)},pdfAudit:{sha256:pdf.sha256,pages:pdf.pages.map(({pdfPage,status})=>({pdfPage,status})),warnings:pdf.warnings}};
      }else parsed=await parsers.parse('text/plain',file);
      importInfo=parsed;$('#source-text').value=parsed.text;$('#input-mode').value='source';$('#import-state').textContent=`已讀取 ${parsed.originalName}，採用 ${parsed.coverage.processed} ${parsed.coverage.unit}；請核對文字、範圍及缺漏後儲存。`;$('#error-state').hidden=true;markDirty();}
    catch(e){$('#import-state').textContent='匯入失敗，既有文字保持不變。';error(e);}finally{busy=false;setSourceBusy(false);$('#txt-file').value='';}
  });
  listen(window,'beforeunload',event=>{if(anyDirty()){event.preventDefault();event.returnValue='';}});
  $('#capability-list').replaceChildren();for(const cap of capabilities){const li=document.createElement('li'),strong=document.createElement('strong'),badge=document.createElement('span'),detail=document.createElement('div');strong.textContent=cap.label;badge.className='badge';badge.textContent=cap.state;detail.textContent=cap.detail;li.append(strong,badge,detail);$('#capability-list').append(li);}
  $('#resource-list').replaceChildren();for(const r of resources.list()){const li=document.createElement('li');li.textContent=`${r.label}：${r.state}`;$('#resource-list').append(li);}
  await refresh();const dispose=()=>{controller.abort();workbench?.dispose();assessment?.dispose();reports?.dispose();};
  dispose.openProject=async id=>{if((current?.id??null)===id)return;load(id?await service.get(id):null);};
  dispose.hasChanges=anyDirty;dispose.isBusy=anyBusy;dispose.selectResource=id=>workbench?.selectResource(id);dispose.currentProject=()=>current;
  return dispose;
}
