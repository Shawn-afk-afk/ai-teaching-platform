import {answerLabel} from '../domain/extended-questions.js';
import {renderRichBlock} from './expanded-content.js';
import {el} from './content-editor.js';
import {project_student} from '../domain/rules.js';
export function renderPrint(root,version,teacher=false){
  const content=teacher?version:project_student(version,'print','print');root.replaceChildren(el('h1',content.title),el('p',`${teacher?'教師版（含答案與規準）':'學生版（無答案）'} · v${version.versionNo}`));
  for(const block of content.blocks){if(['vocabularyList','organizer'].includes(block.type)){root.append(renderRichBlock(block));continue;}if(block.type!=='questionSet'){root.append(el(block.type==='heading'?'h2':'p',block.data.text,{class:block.type==='teacherNote'?'teacher-answer':'print-paragraph'}));continue;}
    for(const id of block.data.questionIds){const q=content.questions.find(q=>q.id===id),card=el('article','',{class:'print-question'});card.append(el('h3',q.prompt),el('p',`配分 ${q.maxScore}`));
      if(['singleChoice','multipleChoice','ordering'].includes(q.type)){const list=el('ol');for(const o of q.options??q.items)list.append(el('li',o.text));card.append(list);}else if(q.type==='trueFalse')card.append(el('p','□ 是　□ 否'));else if(q.type==='fillBlank')for(const b of q.blanks)card.append(el('p',`${b.label}：________`));else if(q.type==='matching'){for(const l of q.left)card.append(el('p',`${l.text} → ______`));card.append(el('p',q.right.map(r=>r.text).join('／')));}else card.append(el('div',q.type==='upload'?'請依教師指示提交作品。':'作答：\n\n\n',{class:'answer-space'}));
      if(teacher)card.append(el('p',`${['shortAnswer','upload'].includes(q.type)?'評分規準':'答案'}：${answerLabel(q)}`,{class:'teacher-answer'}));root.append(card);
    }
  }
  root.hidden=false;document.body.classList.add('print-ready');
}
