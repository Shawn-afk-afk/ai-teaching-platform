import {randomUUID} from 'node:crypto';
import {AppError} from '../src/contracts/errors.js';
const fail=(message,code='VALIDATION_FAILED')=>{throw new AppError(code,message);};
export const MAX_WORK_BYTES=20*1024*1024;
const types={pdf:'application/pdf',docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',txt:'text/plain',png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg'};
export async function readWork(req,name){
 if(typeof name!=='string'||!name.trim()||name.length>200||/[\x00-\x1f\\/]/.test(name))fail('作品檔名無效。');
 const ext=name.split('.').at(-1).toLowerCase(),mime=types[ext];if(!mime)fail('作品只接受 PDF／DOCX／TXT／PNG／JPG。','UNSUPPORTED_FORMAT');
 if(Number(req.headers['content-length'])>MAX_WORK_BYTES)fail('作品每檔上限 20 MiB。','FILE_TOO_LARGE');
 const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>MAX_WORK_BYTES)fail('作品每檔上限 20 MiB。','FILE_TOO_LARGE');chunks.push(chunk);}const bytes=Buffer.concat(chunks);if(!size)fail('不能上傳空檔案。');
 const signature=ext==='pdf'?bytes.subarray(0,5).toString()==='%PDF-':ext==='docx'?bytes[0]===80&&bytes[1]===75:ext==='png'?bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])):['jpg','jpeg'].includes(ext)?bytes[0]===255&&bytes[1]===216&&bytes[2]===255:!bytes.includes(0);
 if(!signature)fail('作品內容與副檔名不符。','UNSUPPORTED_FORMAT');return {bytes,size,mime,name};
}
export function saveWork(store,p,actor,attempt,q,current,file){
 if(!Array.isArray(current)||current.length>=5||new Set(current).size!==current.length||current.some(id=>typeof id!=='string'||!/^[a-f0-9-]{36}$/i.test(id)))fail('每題最多五檔，作品清單須為有效且不同的檔案識別碼。');
 for(const id of current){const row=store.db.prepare('SELECT student_id,attempt_id,question_id FROM work_files WHERE id=?').get(id);if(!row||row.student_id!==actor.actorId||row.attempt_id!==attempt.id||row.question_id!==q.id)fail('作品參照無效。','FORBIDDEN');}
 const id=randomUUID();return store.transaction(()=>{
  // Remove abandoned, unsaved uploads only. Saved answers and submitted work remain intact.
  const saved=new Set((p.responses??[]).filter(r=>r.attemptId===attempt.id&&r.questionId===q.id).flatMap(r=>Array.isArray(r.answer)?r.answer:[]));
  for(const row of store.db.prepare('SELECT id FROM work_files WHERE attempt_id=? AND question_id=?').all(attempt.id,q.id))if(!current.includes(row.id)&&!saved.has(row.id))store.db.prepare('DELETE FROM work_files WHERE id=?').run(row.id);
  store.db.prepare('INSERT INTO work_files VALUES(?,?,?,?,?,?,?,?,?)').run(id,p.id,actor.actorId,attempt.id,q.id,file.name,file.mime,file.size,file.bytes);store.audit(actor.actorId,'work.uploaded',p.id,p.revision);return {id,name:file.name,size:file.size,attemptId:attempt.id,questionId:q.id};
 });
}
