& (Join-Path $PSScriptRoot 'manage-p7.ps1') -Action start
