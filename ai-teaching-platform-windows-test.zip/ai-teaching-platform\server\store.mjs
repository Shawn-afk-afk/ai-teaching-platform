import {DatabaseSync} from 'node:sqlite';
import {randomBytes,randomUUID,createHash,scryptSync,timingSafeEqual} from 'node:crypto';
import {AppError} from '../src/contracts/errors.js';
import {timestamp} from '../src/domain/rules.js';
const fail=(message,code='VALIDATION_FAILED')=>{throw new AppError(code,message);};
export const token=()=>randomBytes(32).toString('base64url'),hash=value=>createHash('sha256').update(value).digest('hex');
function passwordHash(password,salt=randomBytes(16).toString('hex')){if(typeof password!=='string'||password.length<12||password.length>256)fail('密碼須為 12～256 個字元。');return {salt,digest:scryptSync(password,salt,64,{N:16384,r:8,p:1,maxmem:64*1024*1024}).toString('hex')};}
function verifyPassword(password,user){if(typeof password!=='string'||password.length>256)return false;const value=scryptSync(password,user?.salt??'missing-account',64,{N:16384,r:8,p:1,maxmem:64*1024*1024});return Boolean(user&&timingSafeEqual(value,Buffer.from(user.digest,'hex')));}
export class Store {
  constructor(path,{clock=()=>Date.now(),sessionMs=8*60*60*1000}={}){
    this.clock=clock;this.sessionMs=sessionMs;this.db=new DatabaseSync(path);this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
      CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,username TEXT UNIQUE,name TEXT NOT NULL,role TEXT NOT NULL,tenant TEXT NOT NULL,salt TEXT,digest TEXT);
      CREATE TABLE IF NOT EXISTS invites(id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),digest TEXT UNIQUE NOT NULL,expires INTEGER NOT NULL,revoked INTEGER);
      CREATE TABLE IF NOT EXISTS auth_sessions(digest TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),csrf TEXT NOT NULL,expires INTEGER NOT NULL,invite_id TEXT REFERENCES invites(id));
      CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY,owner TEXT NOT NULL REFERENCES users(id),revision INTEGER NOT NULL,body TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,actor TEXT NOT NULL,action TEXT NOT NULL,project_id TEXT,revision INTEGER,at TEXT NOT NULL);
      CREATE INDEX IF NOT EXISTS project_owner ON projects(owner);`);
    this.db.exec('CREATE TABLE IF NOT EXISTS work_files(id TEXT PRIMARY KEY,project_id TEXT NOT NULL,student_id TEXT NOT NULL,attempt_id TEXT NOT NULL,question_id TEXT NOT NULL,name TEXT NOT NULL,mime TEXT NOT NULL,size INTEGER NOT NULL,body BLOB NOT NULL)');
  }
  transaction(fn){this.db.exec('BEGIN IMMEDIATE');try{const result=fn();this.db.exec('COMMIT');return result;}catch(e){this.db.exec('ROLLBACK');throw e;}}
  audit(actor,action,projectId=null,revision=null){this.db.prepare('INSERT INTO audit(actor,action,project_id,revision,at) VALUES(?,?,?,?,?)').run(actor,action,projectId,revision,new Date(this.clock()).toISOString());}
  createTeacher(username,password,name=username){if(typeof username!=='string'||! /^[a-zA-Z0-9_.-]{3,60}$/.test(username))fail('教師帳號須為 3～60 個英數字、底線、點或連字號。');if(typeof name!=='string'||!name.trim()||name.length>80)fail('教師名稱無效。');const id=randomUUID(),p=passwordHash(password);return this.transaction(()=>{if(this.db.prepare('SELECT id FROM users WHERE username=?').get(username))fail('帳號已存在。');this.db.prepare('INSERT INTO users VALUES(?,?,?,?,?,?,?)').run(id,username,name.trim(),'teacher',id,p.salt,p.digest);this.audit(id,'teacher.created');return id;});}
  teacherCount(){return this.db.prepare("SELECT count(*) AS n FROM users WHERE role='teacher'").get().n;}
  loginTeacher(username,password){const user=typeof username==='string'?this.db.prepare("SELECT * FROM users WHERE username=? AND role='teacher'").get(username):null;if(!verifyPassword(password,user))fail('帳號或密碼無效。','UNAUTHENTICATED');return this.newSession(user,null);}
  newSession(user,inviteId){return this.transaction(()=>{const value=token(),csrf=token(),expires=this.clock()+this.sessionMs;this.db.prepare('INSERT INTO auth_sessions VALUES(?,?,?,?,?)').run(hash(value),user.id,csrf,expires,inviteId);this.audit(user.id,'session.created');return {token:value,csrf,expires,actor:this.actor(user)};});}
  actor(u){return {actorId:u.id,tenantId:u.tenant,role:u.role,name:u.name,mode:'server'};}
  authenticate(value){if(typeof value!=='string'||value.length>200)return null;const s=this.db.prepare('SELECT * FROM auth_sessions WHERE digest=?').get(hash(value));if(!s)return null;const invite=s.invite_id?this.db.prepare('SELECT * FROM invites WHERE id=?').get(s.invite_id):null;
    if(s.expires<=this.clock()||(s.invite_id&&(!invite||invite.revoked!==null||invite.expires<=this.clock()))){this.db.prepare('DELETE FROM auth_sessions WHERE digest=?').run(hash(value));return null;}const u=this.db.prepare('SELECT * FROM users WHERE id=?').get(s.user_id);return {actor:this.actor(u),csrf:s.csrf,expires:s.expires};}
  logout(value){if(value){const s=this.authenticate(value);this.db.prepare('DELETE FROM auth_sessions WHERE digest=?').run(hash(value));if(s)this.audit(s.actor.actorId,'session.logout');}}
  roster(teacherId){return this.db.prepare("SELECT id,name FROM users WHERE tenant=? AND role='student' ORDER BY rowid").all(teacherId);}
  invitations(teacherId){return this.db.prepare("SELECT i.id,i.user_id AS learnerId,u.name,i.expires,i.revoked FROM invites i JOIN users u ON u.id=i.user_id WHERE u.tenant=? ORDER BY i.rowid DESC").all(teacherId);}
  issueInvite(teacherId,{name,learnerId,expiresAt}){
    try{timestamp(expiresAt);}catch{fail('邀請有效期限必須包含合法日期、時間與時區。');}
    const expires=Date.parse(expiresAt);if(!Number.isFinite(expires)||expires<=this.clock()||expires>this.clock()+30*86400000)fail('邀請有效期限須在未來 30 天內。');
    if(!learnerId&&(typeof name!=='string'||!name.trim()||name.length>80))fail('請填寫 1～80 字的合成學生暱稱。');
    const id=randomUUID(),raw=token();return this.transaction(()=>{let uid=learnerId;
      if(uid){if(!this.db.prepare("SELECT id FROM users WHERE id=? AND tenant=? AND role='student'").get(uid,teacherId))fail('無此班級學生。','FORBIDDEN');this.revokeLearnerInvites(uid);}
      else{uid=randomUUID();this.db.prepare('INSERT INTO users VALUES(?,?,?,?,?,?,?)').run(uid,null,name.trim(),'student',teacherId,null,null);}
      this.db.prepare('INSERT INTO invites VALUES(?,?,?,?,NULL)').run(id,uid,hash(raw),expires);this.audit(teacherId,'invite.issued');return {id,learnerId:uid,code:raw,expires};});
  }
  revokeLearnerInvites(uid){this.db.prepare('DELETE FROM auth_sessions WHERE user_id=?').run(uid);this.db.prepare('UPDATE invites SET revoked=? WHERE user_id=? AND revoked IS NULL').run(this.clock(),uid);}
  revokeInvite(teacherId,id){return this.transaction(()=>{const i=this.db.prepare('SELECT i.* FROM invites i JOIN users u ON i.user_id=u.id WHERE i.id=? AND u.tenant=?').get(id,teacherId);if(!i)fail('找不到可管理的邀請。','FORBIDDEN');this.db.prepare('UPDATE invites SET revoked=? WHERE id=?').run(this.clock(),id);this.db.prepare('DELETE FROM auth_sessions WHERE invite_id=?').run(id);this.audit(teacherId,'invite.revoked');return {revoked:true};});}
  loginStudent(code){if(typeof code!=='string'||code.length>200)fail('邀請碼無效或已失效。','UNAUTHENTICATED');const i=this.db.prepare('SELECT * FROM invites WHERE digest=?').get(hash(code));if(!i||i.revoked!==null||i.expires<=this.clock())fail('邀請碼無效或已失效。','UNAUTHENTICATED');return this.newSession(this.db.prepare('SELECT * FROM users WHERE id=?').get(i.user_id),i.id);}
  changePassword(actor,current,next){const u=this.db.prepare("SELECT * FROM users WHERE id=? AND role='teacher'").get(actor.actorId);if(!verifyPassword(current,u))fail('目前密碼不正確。');const p=passwordHash(next);return this.transaction(()=>{this.db.prepare('UPDATE users SET salt=?,digest=? WHERE id=?').run(p.salt,p.digest,u.id);this.db.prepare('DELETE FROM auth_sessions WHERE user_id=?').run(u.id);this.audit(u.id,'password.changed');return {changed:true};});}
  close(){this.db.close();}
}
export class ScopedRepository {
  constructor(store,actor,action='project.update'){this.store=store;this.actor=actor;this.action=action;}
  allowed(row){return row&&row.owner===this.actor.tenantId&&(this.actor.role==='teacher'?row.owner===this.actor.actorId:JSON.parse(row.body).allocations?.some(a=>a.learnerId===this.actor.actorId));}
  hydrate(row){const p=JSON.parse(row.body);p.learners=this.store.roster(row.owner);p.runtime='server';p.workFiles=this.store.db.prepare('SELECT id,name,size,attempt_id AS attemptId,question_id AS questionId FROM work_files WHERE project_id=?'+(this.actor.role==='student'?' AND student_id=?':'')).all(p.id,...(this.actor.role==='student'?[this.actor.actorId]:[]));return p;}
  validateUploads(p,attempt,version,answers){for(const q of version.questions.filter(q=>q.type==='upload'))for(const id of answers[q.id]??[]){const file=this.store.db.prepare('SELECT project_id,student_id,attempt_id,question_id FROM work_files WHERE id=?').get(id);if(!file||file.project_id!==p.id||file.student_id!==this.actor.actorId||file.attempt_id!==attempt.id||file.question_id!==q.id)fail('作品檔案不屬於本次學生、作答或題目。','FORBIDDEN');}}
  async get(id){const row=this.store.db.prepare('SELECT * FROM projects WHERE id=?').get(id);if(!row)return null;if(!this.allowed(row))fail('無法存取這份專案。','FORBIDDEN');return this.hydrate(row);}
  async list(){return this.store.db.prepare('SELECT * FROM projects WHERE owner=? ORDER BY rowid').all(this.actor.tenantId).filter(r=>this.allowed(r)).map(r=>this.hydrate(r));}
  async save(record,expected,{signal}={}){
    if(signal?.aborted)fail('工作已取消。','JOB_CANCELLED');return this.store.transaction(()=>{
      const db=this.store.db,row=db.prepare('SELECT * FROM projects WHERE id=?').get(record.id);
      if(row&&!this.allowed(row)||!row&&this.actor.role!=='teacher'||record.ownerId!==this.actor.tenantId||record.tenantId!==this.actor.tenantId)fail('不能寫入這份專案。','FORBIDDEN');
      if((row?.revision??0)!==expected)fail('資料已更新，請重新載入後重試。','VERSION_CONFLICT');
      const saved={...structuredClone(record),revision:expected+1};delete saved.learners;delete saved.runtime;delete saved.workFiles;
      db.prepare('INSERT INTO projects(id,owner,revision,body) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET revision=excluded.revision,body=excluded.body').run(saved.id,saved.ownerId,saved.revision,JSON.stringify(saved));this.store.audit(this.actor.actorId,this.action,saved.id,saved.revision);return this.hydrate({owner:saved.ownerId,body:JSON.stringify(saved)});
    });
  }
}
