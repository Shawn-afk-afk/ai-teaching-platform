import {mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {AppError} from '../src/contracts/errors.js';
const run=promisify(execFile);
export async function parsePDF(data){
 if(typeof data.base64!=='string'||!data.name?.toLowerCase().endsWith('.pdf'))throw new AppError('UNSUPPORTED_FORMAT','請選擇 PDF。');
 const bytes=Buffer.from(data.base64,'base64');
 if(bytes.length>4*1024*1024)throw new AppError('FILE_TOO_LARGE','PDF 上限為 4 MiB。');
 if(bytes.subarray(0,5).toString()!=='%PDF-')throw new AppError('UNSUPPORTED_FORMAT','檔案不是 PDF。');
 const dir=await mkdtemp(join(tmpdir(),'teaching-pdf-'));
 try{
  const file=join(dir,'source.pdf');await writeFile(file,bytes);
  const python=process.env.PDF_PYTHON??'C:\\Program Files\\WindowsApps\\OpenAI.CodexPrimaryRuntime.v26-1119-907-0_26.1119.907.0_x64__3k8sg7r9htsxt\\dependencies\\python\\python.exe';
  const {stdout}=await run(python,[resolve('tools/parse-pdf.py'),file],{timeout:60000,maxBuffer:8*1024*1024,windowsHide:true});
  return {...JSON.parse(stdout),originalName:data.name};
 }catch(e){throw new AppError('PDF_PARSE_FAILED','PDF 解析失敗；請確認文件未加密及 Python／pdfplumber 可用。');}
 finally{await rm(dir,{recursive:true,force:true});}
}
