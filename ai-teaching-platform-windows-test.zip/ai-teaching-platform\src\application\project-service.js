import {AppError} from '../contracts/errors.js';
import {checkText,readyCoverage} from '../domain/materials.js';
export class ProjectService {
  constructor(repository,identity){this.repository=repository;this.identity=identity;}
  async list(query=''){return (await this.repository.list()).filter(p=>p.title.toLocaleLowerCase().includes(query.toLocaleLowerCase()));}
  async get(id){return this.repository.get(id);}
  async save({id,title,sourceText,revision=0,status='active',sourceId,inputMode,importInfo}){
    if(typeof title!=='string'||!title.trim()) throw new AppError('VALIDATION_FAILED','請輸入專案名稱。');
    if(typeof sourceText!=='string'||!sourceText.trim()) throw new AppError('VALIDATION_FAILED','請貼上要保存的教材文字。');
    checkText(sourceText);
    if(!['active','archived'].includes(status)) throw new AppError('VALIDATION_FAILED','不支援的專案狀態。');
    const actor=await this.identity.getContext();
    // A local workspace envelope keeps source text outside the v2 Resource schema.
    const existing=id?await this.repository.get(id):null;
    if(id&&!existing) throw new AppError('VERSION_CONFLICT','原專案不存在，請另存副本。');
    const mode=inputMode??existing?.source.inputMode??'source';
    if(!['source','topic'].includes(mode))throw new AppError('VALIDATION_FAILED','不支援的輸入模式。');
    const changed=!existing||sourceText!==existing.source.text||mode!==existing.source.inputMode||Boolean(importInfo);
    const projectId=id??crypto.randomUUID();
    const history=structuredClone(existing?.sourceHistory??[]);
    if(existing&&changed&&!history.some(s=>s.id===existing.source.id&&s.revision===existing.source.revision))history.push(structuredClone(existing.source));
    const originalText=importInfo?.originalText??(existing?.source.inputMode===mode?(existing.source.originalText??existing.source.text):sourceText);
    const partial=existing?.source.parseStatus==='partial';
    const coverage=importInfo?.coverage??(partial?existing.source.coverage:changed?readyCoverage(sourceText):existing?.source.coverage??readyCoverage(sourceText));
    const source={id:existing?.source.id??sourceId??crypto.randomUUID(),projectId,inputMode:mode,sourceType:mode==='topic'?'topic':importInfo?'file':existing?.source.inputMode===mode?existing.source.sourceType:'text',text:sourceText,originalText,
      originalName:importInfo?.originalName??existing?.source.originalName??null,mimeType:mode==='topic'?null:'text/plain',revision:existing?existing.source.revision+(changed?1:0):1,
      parseStatus:importInfo?.parseStatus??(partial?'partial':changed?'ready':existing?.source.parseStatus??'ready'),coverage:mode==='topic'?{unit:'topic',total:null,processed:0,missing:[]}:coverage};
    if(importInfo?.pdfAudit)source.pdfAudit=structuredClone(importInfo.pdfAudit);
    else if(!changed&&existing?.source.pdfAudit)source.pdfAudit=structuredClone(existing.source.pdfAudit);
    return this.repository.save({...existing,id:projectId,title:title.trim(),status,tenantId:actor.tenantId,ownerId:actor.actorId,source,sourceHistory:history,
      preparation:changed?null:existing?.preparation??null,
      analysisCandidate:changed?null:existing?.analysisCandidate??null,
      updatedAt:new Date().toISOString()},revision);
  }
}
