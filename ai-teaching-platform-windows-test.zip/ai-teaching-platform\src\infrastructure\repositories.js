import {AppError} from '../contracts/errors.js';
const copy=structuredClone;
function versionCheck(current,expected) {
  if((current?.revision??0)!==expected) throw new AppError('VERSION_CONFLICT','資料已被其他頁面更新。請重新載入，或將目前輸入另存副本。');
}
export class MemoryRepository {
  mode='mock'; records=new Map();
  async list(){return copy([...this.records.values()]);}
  async get(id){return copy(this.records.get(id)??null);}
  async save(record,expectedRevision,{signal}={}){
    if(signal?.aborted)throw new AppError('JOB_CANCELLED','工作已取消。');
    versionCheck(this.records.get(record.id),expectedRevision);
    const saved={...copy(record),revision:expectedRevision+1};this.records.set(record.id,saved);return copy(saved);
  }
  async close(){}
}
export class IndexedDBRepository {
  mode='local';
  constructor(name='ai-teaching-p1',factory=globalThis.indexedDB){this.name=name;this.factory=factory;this.pending=null;}
  async open(){
    if(!this.factory) throw new AppError('STORAGE_UNAVAILABLE','此瀏覽器無法使用 IndexedDB。資料尚未儲存。',{retryable:true});
    if(!this.pending) this.pending=new Promise((resolve,reject)=>{
      let blocked=false;
      const req=this.factory.open(this.name,1);
      req.onupgradeneeded=()=>req.result.createObjectStore('projects',{keyPath:'id'});
      req.onerror=()=>reject(new AppError('STORAGE_UNAVAILABLE','無法開啟本機資料庫。',{retryable:true}));
      req.onblocked=()=>{blocked=true;reject(new AppError('STORAGE_UNAVAILABLE','資料庫更新被其他頁面阻擋，請關閉其他分頁後重試。',{retryable:true}));};
      req.onsuccess=()=>{const db=req.result;if(blocked){db.close();return;}db.onversionchange=()=>{db.close();this.pending=null;};resolve(db);};
    }).catch(e=>{this.pending=null;throw e;});
    return this.pending;
  }
  async transact(mode,operation,signal){
    const db=await this.open();
    if(signal?.aborted)throw new AppError('JOB_CANCELLED','工作已取消。');
    return new Promise((resolve,reject)=>{
      let result, failure;
      const tx=db.transaction('projects',mode);
      const abort=()=>{failure=new AppError('JOB_CANCELLED','工作已取消。');try{tx.abort();}catch{}};
      signal?.addEventListener('abort',abort,{once:true});
      const cleanup=()=>signal?.removeEventListener('abort',abort);
      tx.oncomplete=()=>{cleanup();resolve(copy(result));};
      tx.onerror=()=>{};
      tx.onabort=()=>{cleanup();reject(failure??new AppError('STORAGE_UNAVAILABLE','儲存未完成；輸入仍保留，請重試。',{retryable:true}));};
      try {operation(tx.objectStore('projects'),value=>{result=value;},error=>{failure=error;tx.abort();});}
      catch(error){failure=error;tx.abort();}
    });
  }
  async list(){return this.transact('readonly',(store,done)=>{store.getAll().onsuccess=e=>done(e.target.result);});}
  async get(id){return this.transact('readonly',(store,done)=>{store.get(id).onsuccess=e=>done(e.target.result??null);});}
  async save(record,expectedRevision,{signal}={}){
    return this.transact('readwrite',(store,done,fail)=>{
      store.get(record.id).onsuccess=e=>{
        try {versionCheck(e.target.result,expectedRevision);const saved={...copy(record),revision:expectedRevision+1};store.put(saved);done(saved);}
        catch(error){fail(error);}
      };
    },signal);
  }
  async close(){if(this.pending){(await this.pending).close();this.pending=null;}}
}
