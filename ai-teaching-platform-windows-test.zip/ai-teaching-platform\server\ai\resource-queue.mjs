import {AppError} from '../../src/contracts/errors.js';
const cancelled=()=>new AppError('JOB_CANCELLED','生成已取消；既有內容保持不變。');
const timeout=()=>new AppError('UPSTREAM_TIMEOUT','整份資源生成逾時；已完成的批次保留供教師處理，沒有發布。',{retryable:true});

// Exactly one execution, including retries and validation. A cancelled provider
// must settle before the next job starts; a late result can never be returned.
export class ResourceQueue {
  #tail=Promise.resolve();
  constructor({timeoutMs=180000}={}) {this.timeoutMs=timeoutMs;}
  async run(work,{signal,onState=()=>{}}={}) {
    const queuedAt=performance.now();
    const prior=this.#tail;
    let release;
    this.#tail=new Promise(resolve=>{release=resolve;});
    const controller=new AbortController();
    const relay=()=>controller.abort(cancelled());
    signal?.addEventListener('abort',relay,{once:true});
    if(signal?.aborted)relay();
    onState('queued');
    // A cancelled queued job returns immediately but retains its FIFO slot.
    let cancelReject;
    const aborted=new Promise((_,reject)=>{cancelReject=()=>reject(controller.signal.reason);controller.signal.addEventListener('abort',cancelReject,{once:true});if(controller.signal.aborted)cancelReject();});
    let timer,task,startedAt;
    try {
      await Promise.race([prior,aborted]);
      controller.signal.throwIfAborted();
      startedAt=performance.now();
      const timing={queueMs:startedAt-queuedAt,executionMs:null};
      const deadline=startedAt+this.timeoutMs;
      const remainingMs=()=>Math.max(0,deadline-performance.now());
      const check=()=>{controller.signal.throwIfAborted();if(remainingMs()<=0){controller.abort(timeout());controller.signal.throwIfAborted();}};
      timer=setTimeout(()=>controller.abort(timeout()),this.timeoutMs);
      onState('running');
      task=Promise.resolve().then(()=>work({signal:controller.signal,remainingMs,check,timing}));
      const value=await Promise.race([task,aborted]);
      check(); timing.executionMs=performance.now()-startedAt;
      return {value,timing};
    } catch(error) {
      if(error&&typeof error==='object')error.timing={queueMs:(startedAt??performance.now())-queuedAt,executionMs:startedAt===undefined?0:performance.now()-startedAt};
      throw error;
    } finally {
      clearTimeout(timer); signal?.removeEventListener('abort',relay);
      controller.signal.removeEventListener('abort',cancelReject);
      // Keep execution serialized even if a provider ignores cancellation.
      Promise.allSettled([prior,task]).then(release);
    }
  }
}
