"""Create an editable resource document from already-authorized projected content."""
import sys,json,io
from docx import Document
from docx.shared import Inches,Pt,RGBColor,Mm
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
sys.stdin.reconfigure(encoding='utf-8')
data=json.load(sys.stdin); content=data['content']; teacher=data['teacher']; doc=Document()
section=doc.sections[0];section.page_width=Mm(210);section.page_height=Mm(297)
section.top_margin=section.bottom_margin=Mm(18);section.left_margin=section.right_margin=Mm(20)
for name in ['Normal','Title','Heading 1','Heading 2']:
 style=doc.styles[name];style.font.name='Calibri';style.font.color.rgb=RGBColor(0,0,0);style.font.size=Pt(11 if name=='Normal' else 20 if name=='Title' else 14)
 style.element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Microsoft JhengHei')
 style.paragraph_format.line_spacing=1.15
for border in list(doc.styles.element.xpath('.//w:pBdr')):
 border.getparent().remove(border)
doc.add_paragraph(content['title'],style='Title');doc.add_paragraph(('教師版 含答案與規準' if teacher else '學生版 無答案與規準')+f" 版本 {data['versionNo']}")
questions={q['id']:q for q in content['questions']}
def table(headers,rows):
 t=doc.add_table(rows=1,cols=len(headers));t.style='Table Grid'
 for cell,text in zip(t.rows[0].cells,headers):cell.text=text
 for row in rows:
  for cell,text in zip(t.add_row().cells,row):cell.text=str(text)
 for row in t.rows:
  for cell in row.cells:
   props=cell._tc.get_or_add_tcPr();borders=OxmlElement('w:tcBorders')
   for side in ['top','left','bottom','right']:
    edge=OxmlElement('w:'+side);edge.set(qn('w:val'),'single');edge.set(qn('w:sz'),'4');edge.set(qn('w:color'),'D9D9D9');borders.append(edge)
   props.append(borders)
 doc.add_paragraph('')
for block in content['blocks']:
 kind=block['type'];b=block['data']
 if kind=='heading':doc.add_paragraph(b['text'],style='Heading 1')
 elif kind in ['paragraph','teacherNote']:doc.add_paragraph(b['text'])
 elif kind=='vocabularyList':table(['詞彙','詞義','例句'],[[e['term'],e['definition'],e['example']] for e in b['entries']])
 elif kind=='organizer':
  doc.add_paragraph(b['title'],style='Heading 1');nodes={n['id']:n['label'] for n in b['nodes']};table(['概念節點'],[[n['label']] for n in b['nodes']]);table(['起點','關係','終點'],[[nodes[e['from']],e['label'],nodes[e['to']]] for e in b['edges']])
 elif kind=='questionSet':
  for ident in b['questionIds']:
   q=questions[ident];doc.add_paragraph(q['prompt'],style='Heading 2');doc.add_paragraph(f"配分 {q['maxScore']}")
   if q['type'] in ['singleChoice','multipleChoice','ordering']:
    for i,item in enumerate(q.get('options',q.get('items',[]))):doc.add_paragraph(f"{i+1}. {item['text']}")
   elif q['type']=='trueFalse':doc.add_paragraph('□ 是　□ 否')
   elif q['type']=='fillBlank':
    for blank in q['blanks']:doc.add_paragraph(blank['label']+' ____________________')
   elif q['type']=='matching':table(['待配對項目','選項'],[[l['text'],q['right'][i]['text'] if i<len(q['right']) else ''] for i,l in enumerate(q['left'])])
   elif q['type']=='upload':doc.add_paragraph('請依教師指示上傳作品 PDF DOCX TXT PNG JPG 每題最多五檔 每檔 20 MiB')
   else:doc.add_paragraph('作答 ______________________________\n\n')
   if teacher:doc.add_paragraph('答案或評分規準 '+data['answers'].get(ident,''))
out=io.BytesIO();doc.save(out);sys.stdout.buffer.write(out.getvalue())
