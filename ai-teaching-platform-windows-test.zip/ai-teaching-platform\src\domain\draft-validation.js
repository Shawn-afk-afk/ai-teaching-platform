import {AppError} from '../contracts/errors.js';
export function draftIssues(content,context){
 const issues=[];const add=(path,field,message,targetId)=>issues.push({path,field,message,targetId,keyword:'businessRule'});
 if(!content.title?.trim())add('/title','資源標題','請填寫資源標題。');
 const objectives=new Set(context.objectives.map(o=>o.id)),chunks=new Set(context.chunks.map(c=>c.id));
 for(const [i,q] of content.questions.entries()){
  const base=`/questions/${i}`,label=`第 ${i+1} 題`;
  if(!q.prompt?.trim())add(base+'/prompt','題目',`${label}：題目不可空白。`,q.id);
  if(!Number.isFinite(q.maxScore)||q.maxScore<=0)add(base+'/maxScore','配分',`${label}：配分須大於 0。`,q.id);
  if(!q.objectiveIds?.length||q.objectiveIds.some(id=>!objectives.has(id)))add(base+'/objectiveIds','學習目標與來源',`${label}：請選擇有效學習目標。`,q.id);
  if(context.inputMode==='source'&&(!q.sourceRefs?.length||q.sourceRefs.some(r=>!chunks.has(r.chunkId))))add(base+'/sourceRefs','學習目標與來源',`${label}：請選擇有效來源。`,q.id);
  const placed=content.blocks.filter(b=>b.type==='questionSet').flatMap(b=>b.data.questionIds).filter(id=>id===q.id).length;
  if(placed!==1)add(base+'/layout','題組',`${label}：須出現在一個且僅一個題組，目前為 ${placed} 個。`,q.id);
  if(q.type==='singleChoice'){
   if(q.options.length<2)add(base+'/options','選項',`${label}：至少需要兩個選項。`,q.id);
   q.options.forEach((o,j)=>{if(!o.text?.trim())add(base+`/options/${j}/text`,`選項 ${j+1}`,`${label}：選項 ${j+1} 不可空白。`,q.id);});
   if(!q.options.some(o=>o.id===q.answerKey))add(base+'/answerKey','正確選項',`${label}：請重新選擇有效正解。`,q.id);
  }
  if(q.type==='shortAnswer'&&!q.rubric?.trim())add(base+'/rubric','評分規準',`${label}：請填寫評分規準。`,q.id);
 }
 for(const [i,b] of content.blocks.entries()){
  if(b.type==='questionSet'&&!b.data.questionIds.length)add(`/blocks/${i}/data/questionIds`,'題組',`區塊 ${i+1}：空題組須加入題目或移除。`,b.id);
  if(['paragraph','heading','teacherNote'].includes(b.type)&&!b.data.text?.trim())add(`/blocks/${i}/data/text`,'區塊文字',`區塊 ${i+1}：文字不可空白，或請移除區塊。`,b.id);
 }
 return issues;
}
export function requireValidDraft(content,context){const issues=draftIssues(content,context);if(issues.length)throw new AppError('VALIDATION_FAILED',`草稿有 ${issues.length} 個問題，請修正標示欄位。`,{details:issues});}
