import {AppError} from '../contracts/errors.js';
import {ALL_TYPES,RESOURCE_LABELS} from './extended-questions.js';
export function validateGenerationSettings(spec,model){
 if(!spec.title?.trim())throw new AppError('VALIDATION_FAILED','請填寫資源名稱。');
 if(!Number.isInteger(spec.questionCount)||spec.questionCount<0||spec.questionCount>100)throw new AppError('VALIDATION_FAILED','題數需為 0～100 的整數。');
 if(!model)return;
 if(!Object.hasOwn(RESOURCE_LABELS,spec.resourceType))throw new AppError('VALIDATION_FAILED','資源類型未啟用。');
 if(['reading','handout','vocabulary','organizer'].includes(spec.resourceType)){
  if(spec.questionCount!==0)throw new AppError('VALIDATION_FAILED','閱讀／講義／字彙／概念圖請設 0 題。');
 }else if(spec.questionCount!==5||!spec.questionTypes?.length||spec.questionTypes.length>5||new Set(spec.questionTypes).size!==spec.questionTypes.length||spec.questionTypes.some(t=>!ALL_TYPES.includes(t)))throw new AppError('VALIDATION_FAILED','評量資源固定 5 題，請選擇 1～5 種題型，依勾選順序輪流分配。');
}
