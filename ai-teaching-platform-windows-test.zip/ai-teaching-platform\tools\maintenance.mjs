import {DatabaseSync} from 'node:sqlite';
import {mkdir,readFile,writeFile,copyFile,stat} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {createReadStream} from 'node:fs';
const digest=async path=>{const hash=createHash('sha256');for await(const chunk of createReadStream(path))hash.update(chunk);return hash.digest('hex');};
function integrity(db){
 if(db.prepare('PRAGMA integrity_check').all().some(x=>x.integrity_check!=='ok')||db.prepare('PRAGMA foreign_key_check').all().length)throw Error('Database integrity check failed');
 for(const table of ['users','projects','audit'])db.prepare(`SELECT count(*) FROM ${table}`).get();
}
async function newDirectory(path){await mkdir(resolve(path));return resolve(path);}
export async function backupDatabase(source,destination){
 source=resolve(source);await stat(source);const dir=await newDirectory(destination),file=join(dir,'database.sqlite');
 const db=new DatabaseSync(source,{readOnly:true});
 try{integrity(db);db.exec(`VACUUM INTO '${file.replaceAll("'","''")}'`);}finally{db.close();}
 const check=new DatabaseSync(file,{readOnly:true});try{integrity(check);}finally{check.close();}
 const manifest={format:'teaching-db-backup-1',createdAt:new Date().toISOString(),node:process.version,database:'database.sqlite',sha256:await digest(file),scope:'SQLite: accounts, invitations, saved projects, submissions, student work file blobs, knowledge index and audit; excludes original source files, model weights and AI checkpoint directories'};
 await writeFile(join(dir,'manifest.json'),JSON.stringify(manifest,null,2),{flag:'wx'});return manifest;
}
export async function restoreDatabase(backup,destination){
 const manifest=JSON.parse(await readFile(join(resolve(backup),'manifest.json'),'utf8'));
 if(manifest.format!=='teaching-db-backup-1'||manifest.database!=='database.sqlite')throw Error('Unsupported backup format');
 const source=join(resolve(backup),'database.sqlite');
 if(await digest(source)!==manifest.sha256)throw Error('Backup checksum mismatch');
 const check=new DatabaseSync(source,{readOnly:true});try{integrity(check);}finally{check.close();}
 const dir=await newDirectory(destination),file=join(dir,'l1.sqlite');await copyFile(source,file);
 const db=new DatabaseSync(file);try{db.exec('DELETE FROM auth_sessions');integrity(db);}finally{db.close();}
 await writeFile(join(dir,'restore.json'),JSON.stringify({restoredAt:new Date().toISOString(),sourceSha256:manifest.sha256,sessionsRevoked:true},null,2),{flag:'wx'});
 return {database:file,sessionsRevoked:true};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){
 const [command,source,destination]=process.argv.slice(2);
 try{if(!source||!destination||!['backup','restore'].includes(command))throw Error('Usage: node tools/maintenance.mjs backup <database> <NEW backup directory> | restore <backup directory> <NEW restore directory>');
 console.log(JSON.stringify(await (command==='backup'?backupDatabase:restoreDatabase)(source,destination),null,2));}catch(error){console.error(error.message);process.exitCode=1;}
}
