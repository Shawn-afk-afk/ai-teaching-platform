var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// node_modules/.pnpm/ajv-formats@3.0.1_ajv@8.17.1/node_modules/ajv-formats/dist/formats.js
var require_formats = __commonJS({
  "node_modules/.pnpm/ajv-formats@3.0.1_ajv@8.17.1/node_modules/ajv-formats/dist/formats.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.formatNames = exports.fastFormats = exports.fullFormats = void 0;
    function fmtDef(validate, compare) {
      return { validate, compare };
    }
    exports.fullFormats = {
      // date: http://tools.ietf.org/html/rfc3339#section-5.6
      date: fmtDef(date, compareDate),
      // date-time: http://tools.ietf.org/html/rfc3339#section-5.6
      time: fmtDef(getTime(true), compareTime),
      "date-time": fmtDef(getDateTime(true), compareDateTime),
      "iso-time": fmtDef(getTime(), compareIsoTime),
      "iso-date-time": fmtDef(getDateTime(), compareIsoDateTime),
      // duration: https://tools.ietf.org/html/rfc3339#appendix-A
      duration: /^P(?!$)((\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+S)?)?|(\d+W)?)$/,
      uri,
      "uri-reference": /^(?:[a-z][a-z0-9+\-.]*:)?(?:\/?\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:(?:[0-9a-f]{1,4}:){6}|::(?:[0-9a-f]{1,4}:){5}|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}|(?:(?:[0-9a-f]{1,4}:){0,1}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::)(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?))|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)|[Vv][0-9a-f]+\.[a-z0-9\-._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)|(?:[a-z0-9\-._~!$&'"()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*)?(?:\?(?:[a-z0-9\-._~!$&'"()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[a-z0-9\-._~!$&'"()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i,
      // uri-template: https://tools.ietf.org/html/rfc6570
      "uri-template": /^(?:(?:[^\x00-\x20"'<>%\\^`{|}]|%[0-9a-f]{2})|\{[+#./;?&=,!@|]?(?:[a-z0-9_]|%[0-9a-f]{2})+(?::[1-9][0-9]{0,3}|\*)?(?:,(?:[a-z0-9_]|%[0-9a-f]{2})+(?::[1-9][0-9]{0,3}|\*)?)*\})*$/i,
      // For the source: https://gist.github.com/dperini/729294
      // For test cases: https://mathiasbynens.be/demo/url-regex
      url: /^(?:https?|ftp):\/\/(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z0-9\u{00a1}-\u{ffff}]+-)*[a-z0-9\u{00a1}-\u{ffff}]+)(?:\.(?:[a-z0-9\u{00a1}-\u{ffff}]+-)*[a-z0-9\u{00a1}-\u{ffff}]+)*(?:\.(?:[a-z\u{00a1}-\u{ffff}]{2,})))(?::\d{2,5})?(?:\/[^\s]*)?$/iu,
      email: /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i,
      hostname: /^(?=.{1,253}\.?$)[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[-0-9a-z]{0,61}[0-9a-z])?)*\.?$/i,
      // optimized https://www.safaribooksonline.com/library/view/regular-expressions-cookbook/9780596802837/ch07s16.html
      ipv4: /^(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/,
      ipv6: /^((([0-9a-f]{1,4}:){7}([0-9a-f]{1,4}|:))|(([0-9a-f]{1,4}:){6}(:[0-9a-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){5}(((:[0-9a-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){4}(((:[0-9a-f]{1,4}){1,3})|((:[0-9a-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){3}(((:[0-9a-f]{1,4}){1,4})|((:[0-9a-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){2}(((:[0-9a-f]{1,4}){1,5})|((:[0-9a-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){1}(((:[0-9a-f]{1,4}){1,6})|((:[0-9a-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9a-f]{1,4}){1,7})|((:[0-9a-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))$/i,
      regex,
      // uuid: http://tools.ietf.org/html/rfc4122
      uuid: /^(?:urn:uuid:)?[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i,
      // JSON-pointer: https://tools.ietf.org/html/rfc6901
      // uri fragment: https://tools.ietf.org/html/rfc3986#appendix-A
      "json-pointer": /^(?:\/(?:[^~/]|~0|~1)*)*$/,
      "json-pointer-uri-fragment": /^#(?:\/(?:[a-z0-9_\-.!$&'()*+,;:=@]|%[0-9a-f]{2}|~0|~1)*)*$/i,
      // relative JSON-pointer: http://tools.ietf.org/html/draft-luff-relative-json-pointer-00
      "relative-json-pointer": /^(?:0|[1-9][0-9]*)(?:#|(?:\/(?:[^~/]|~0|~1)*)*)$/,
      // the following formats are used by the openapi specification: https://spec.openapis.org/oas/v3.0.0#data-types
      // byte: https://github.com/miguelmota/is-base64
      byte,
      // signed 32 bit integer
      int32: { type: "number", validate: validateInt32 },
      // signed 64 bit integer
      int64: { type: "number", validate: validateInt64 },
      // C-type float
      float: { type: "number", validate: validateNumber },
      // C-type double
      double: { type: "number", validate: validateNumber },
      // hint to the UI to hide input strings
      password: true,
      // unchecked string payload
      binary: true
    };
    exports.fastFormats = {
      ...exports.fullFormats,
      date: fmtDef(/^\d\d\d\d-[0-1]\d-[0-3]\d$/, compareDate),
      time: fmtDef(/^(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)$/i, compareTime),
      "date-time": fmtDef(/^\d\d\d\d-[0-1]\d-[0-3]\dt(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)$/i, compareDateTime),
      "iso-time": fmtDef(/^(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)?$/i, compareIsoTime),
      "iso-date-time": fmtDef(/^\d\d\d\d-[0-1]\d-[0-3]\d[t\s](?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)?$/i, compareIsoDateTime),
      // uri: https://github.com/mafintosh/is-my-json-valid/blob/master/formats.js
      uri: /^(?:[a-z][a-z0-9+\-.]*:)(?:\/?\/)?[^\s]*$/i,
      "uri-reference": /^(?:(?:[a-z][a-z0-9+\-.]*:)?\/?\/)?(?:[^\\\s#][^\s#]*)?(?:#[^\\\s]*)?$/i,
      // email (sources from jsen validator):
      // http://stackoverflow.com/questions/201323/using-a-regular-expression-to-validate-an-email-address#answer-8829363
      // http://www.w3.org/TR/html5/forms.html#valid-e-mail-address (search for 'wilful violation')
      email: /^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*$/i
    };
    exports.formatNames = Object.keys(exports.fullFormats);
    function isLeapYear(year) {
      return year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
    }
    var DATE = /^(\d\d\d\d)-(\d\d)-(\d\d)$/;
    var DAYS = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    function date(str) {
      const matches = DATE.exec(str);
      if (!matches)
        return false;
      const year = +matches[1];
      const month = +matches[2];
      const day = +matches[3];
      return month >= 1 && month <= 12 && day >= 1 && day <= (month === 2 && isLeapYear(year) ? 29 : DAYS[month]);
    }
    function compareDate(d1, d2) {
      if (!(d1 && d2))
        return void 0;
      if (d1 > d2)
        return 1;
      if (d1 < d2)
        return -1;
      return 0;
    }
    var TIME = /^(\d\d):(\d\d):(\d\d(?:\.\d+)?)(z|([+-])(\d\d)(?::?(\d\d))?)?$/i;
    function getTime(strictTimeZone) {
      return function time(str) {
        const matches = TIME.exec(str);
        if (!matches)
          return false;
        const hr = +matches[1];
        const min = +matches[2];
        const sec = +matches[3];
        const tz = matches[4];
        const tzSign = matches[5] === "-" ? -1 : 1;
        const tzH = +(matches[6] || 0);
        const tzM = +(matches[7] || 0);
        if (tzH > 23 || tzM > 59 || strictTimeZone && !tz)
          return false;
        if (hr <= 23 && min <= 59 && sec < 60)
          return true;
        const utcMin = min - tzM * tzSign;
        const utcHr = hr - tzH * tzSign - (utcMin < 0 ? 1 : 0);
        return (utcHr === 23 || utcHr === -1) && (utcMin === 59 || utcMin === -1) && sec < 61;
      };
    }
    function compareTime(s1, s2) {
      if (!(s1 && s2))
        return void 0;
      const t1 = (/* @__PURE__ */ new Date("2020-01-01T" + s1)).valueOf();
      const t2 = (/* @__PURE__ */ new Date("2020-01-01T" + s2)).valueOf();
      if (!(t1 && t2))
        return void 0;
      return t1 - t2;
    }
    function compareIsoTime(t1, t2) {
      if (!(t1 && t2))
        return void 0;
      const a1 = TIME.exec(t1);
      const a2 = TIME.exec(t2);
      if (!(a1 && a2))
        return void 0;
      t1 = a1[1] + a1[2] + a1[3];
      t2 = a2[1] + a2[2] + a2[3];
      if (t1 > t2)
        return 1;
      if (t1 < t2)
        return -1;
      return 0;
    }
    var DATE_TIME_SEPARATOR = /t|\s/i;
    function getDateTime(strictTimeZone) {
      const time = getTime(strictTimeZone);
      return function date_time(str) {
        const dateTime = str.split(DATE_TIME_SEPARATOR);
        return dateTime.length === 2 && date(dateTime[0]) && time(dateTime[1]);
      };
    }
    function compareDateTime(dt1, dt2) {
      if (!(dt1 && dt2))
        return void 0;
      const d1 = new Date(dt1).valueOf();
      const d2 = new Date(dt2).valueOf();
      if (!(d1 && d2))
        return void 0;
      return d1 - d2;
    }
    function compareIsoDateTime(dt1, dt2) {
      if (!(dt1 && dt2))
        return void 0;
      const [d1, t1] = dt1.split(DATE_TIME_SEPARATOR);
      const [d2, t2] = dt2.split(DATE_TIME_SEPARATOR);
      const res = compareDate(d1, d2);
      if (res === void 0)
        return void 0;
      return res || compareTime(t1, t2);
    }
    var NOT_URI_FRAGMENT = /\/|:/;
    var URI = /^(?:[a-z][a-z0-9+\-.]*:)(?:\/?\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:(?:[0-9a-f]{1,4}:){6}|::(?:[0-9a-f]{1,4}:){5}|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}|(?:(?:[0-9a-f]{1,4}:){0,1}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::)(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?))|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)|[Vv][0-9a-f]+\.[a-z0-9\-._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)|(?:[a-z0-9\-._~!$&'()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)(?:\?(?:[a-z0-9\-._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[a-z0-9\-._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i;
    function uri(str) {
      return NOT_URI_FRAGMENT.test(str) && URI.test(str);
    }
    var BYTE = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/gm;
    function byte(str) {
      BYTE.lastIndex = 0;
      return BYTE.test(str);
    }
    var MIN_INT32 = -(2 ** 31);
    var MAX_INT32 = 2 ** 31 - 1;
    function validateInt32(value) {
      return Number.isInteger(value) && value <= MAX_INT32 && value >= MIN_INT32;
    }
    function validateInt64(value) {
      return Number.isInteger(value);
    }
    function validateNumber() {
      return true;
    }
    var Z_ANCHOR = /[^\\]\\Z/;
    function regex(str) {
      if (Z_ANCHOR.test(str))
        return false;
      try {
        new RegExp(str);
        return true;
      } catch (e) {
        return false;
      }
    }
  }
});

// node_modules/.pnpm/ajv@8.17.1/node_modules/ajv/dist/runtime/ucs2length.js
var require_ucs2length = __commonJS({
  "node_modules/.pnpm/ajv@8.17.1/node_modules/ajv/dist/runtime/ucs2length.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function ucs2length(str) {
      const len = str.length;
      let length = 0;
      let pos = 0;
      let value;
      while (pos < len) {
        length++;
        value = str.charCodeAt(pos++);
        if (value >= 55296 && value <= 56319 && pos < len) {
          value = str.charCodeAt(pos);
          if ((value & 64512) === 56320)
            pos++;
        }
      }
      return length;
    }
    exports.default = ucs2length;
    ucs2length.code = 'require("ajv/dist/runtime/ucs2length").default';
  }
});

// node_modules/.pnpm/fast-deep-equal@3.1.3/node_modules/fast-deep-equal/index.js
var require_fast_deep_equal = __commonJS({
  "node_modules/.pnpm/fast-deep-equal@3.1.3/node_modules/fast-deep-equal/index.js"(exports, module) {
    "use strict";
    module.exports = function equal(a, b) {
      if (a === b) return true;
      if (a && b && typeof a == "object" && typeof b == "object") {
        if (a.constructor !== b.constructor) return false;
        var length, i, keys;
        if (Array.isArray(a)) {
          length = a.length;
          if (length != b.length) return false;
          for (i = length; i-- !== 0; )
            if (!equal(a[i], b[i])) return false;
          return true;
        }
        if (a.constructor === RegExp) return a.source === b.source && a.flags === b.flags;
        if (a.valueOf !== Object.prototype.valueOf) return a.valueOf() === b.valueOf();
        if (a.toString !== Object.prototype.toString) return a.toString() === b.toString();
        keys = Object.keys(a);
        length = keys.length;
        if (length !== Object.keys(b).length) return false;
        for (i = length; i-- !== 0; )
          if (!Object.prototype.hasOwnProperty.call(b, keys[i])) return false;
        for (i = length; i-- !== 0; ) {
          var key = keys[i];
          if (!equal(a[key], b[key])) return false;
        }
        return true;
      }
      return a !== a && b !== b;
    };
  }
});

// node_modules/.pnpm/ajv@8.17.1/node_modules/ajv/dist/runtime/equal.js
var require_equal = __commonJS({
  "node_modules/.pnpm/ajv@8.17.1/node_modules/ajv/dist/runtime/equal.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var equal = require_fast_deep_equal();
    equal.code = 'require("ajv/dist/runtime/equal").default';
    exports.default = equal;
  }
});

// compiled-contracts.js
var attempt = validate20;
var schema31 = { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "allocationId": { "type": "string", "minLength": 1 }, "attemptNo": { "type": "integer", "minimum": 1 }, "status": { "enum": ["in_progress", "submitted", "closed"] }, "gradingStatus": { "enum": ["not_started", "partial", "complete"] }, "startedAt": { "type": "string", "format": "date-time" }, "submittedAt": { "type": ["string", "null"], "format": "date-time" }, "invalidatedAt": { "type": ["string", "null"], "format": "date-time" }, "revision": { "type": "integer", "minimum": 1 } }, "required": ["id", "allocationId", "attemptNo", "status", "gradingStatus", "startedAt", "submittedAt", "invalidatedAt", "revision"], "additionalProperties": false, "allOf": [{ "if": { "properties": { "status": { "const": "in_progress" } } }, "then": { "properties": { "submittedAt": { "type": "null" }, "gradingStatus": { "const": "not_started" } } }, "else": { "properties": { "submittedAt": { "type": "string", "format": "date-time" } } } }], "$schema": "https://json-schema.org/draft/2020-12/schema", "title": "attempt" };
var formats0 = require_formats().fullFormats["date-time"];
var func1 = Object.prototype.hasOwnProperty;
var func2 = require_ucs2length().default;
function validate20(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate20.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs2 = errors;
  let valid1 = true;
  const _errs3 = errors;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.status !== void 0) {
      if ("in_progress" !== data.status) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors++;
      }
    }
  }
  var _valid0 = _errs3 === errors;
  errors = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  let ifClause0;
  if (_valid0) {
    const _errs5 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.submittedAt !== void 0) {
        if (data.submittedAt !== null) {
          const err1 = { instancePath: instancePath + "/submittedAt", schemaPath: "#/allOf/0/then/properties/submittedAt/type", keyword: "type", params: { type: "null" }, message: "must be null" };
          if (vErrors === null) {
            vErrors = [err1];
          } else {
            vErrors.push(err1);
          }
          errors++;
        }
      }
      if (data.gradingStatus !== void 0) {
        if ("not_started" !== data.gradingStatus) {
          const err2 = { instancePath: instancePath + "/gradingStatus", schemaPath: "#/allOf/0/then/properties/gradingStatus/const", keyword: "const", params: { allowedValue: "not_started" }, message: "must be equal to constant" };
          if (vErrors === null) {
            vErrors = [err2];
          } else {
            vErrors.push(err2);
          }
          errors++;
        }
      }
    }
    var _valid0 = _errs5 === errors;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.submittedAt = true;
      props0.gradingStatus = true;
      props0.status = true;
    }
    ifClause0 = "then";
  } else {
    const _errs9 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.submittedAt !== void 0) {
        let data3 = data.submittedAt;
        if (typeof data3 === "string") {
          if (!formats0.validate(data3)) {
            const err3 = { instancePath: instancePath + "/submittedAt", schemaPath: "#/allOf/0/else/properties/submittedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
            if (vErrors === null) {
              vErrors = [err3];
            } else {
              vErrors.push(err3);
            }
            errors++;
          }
        } else {
          const err4 = { instancePath: instancePath + "/submittedAt", schemaPath: "#/allOf/0/else/properties/submittedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
          if (vErrors === null) {
            vErrors = [err4];
          } else {
            vErrors.push(err4);
          }
          errors++;
        }
      }
    }
    var _valid0 = _errs9 === errors;
    valid1 = _valid0;
    if (valid1) {
      if (props0 !== true) {
        props0 = props0 || {};
        props0.submittedAt = true;
      }
    }
    ifClause0 = "else";
  }
  if (!valid1) {
    const err5 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: ifClause0 }, message: 'must match "' + ifClause0 + '" schema' };
    if (vErrors === null) {
      vErrors = [err5];
    } else {
      vErrors.push(err5);
    }
    errors++;
  }
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.id === void 0) {
      const err6 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
      if (vErrors === null) {
        vErrors = [err6];
      } else {
        vErrors.push(err6);
      }
      errors++;
    }
    if (data.allocationId === void 0) {
      const err7 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "allocationId" }, message: "must have required property 'allocationId'" };
      if (vErrors === null) {
        vErrors = [err7];
      } else {
        vErrors.push(err7);
      }
      errors++;
    }
    if (data.attemptNo === void 0) {
      const err8 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "attemptNo" }, message: "must have required property 'attemptNo'" };
      if (vErrors === null) {
        vErrors = [err8];
      } else {
        vErrors.push(err8);
      }
      errors++;
    }
    if (data.status === void 0) {
      const err9 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "status" }, message: "must have required property 'status'" };
      if (vErrors === null) {
        vErrors = [err9];
      } else {
        vErrors.push(err9);
      }
      errors++;
    }
    if (data.gradingStatus === void 0) {
      const err10 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "gradingStatus" }, message: "must have required property 'gradingStatus'" };
      if (vErrors === null) {
        vErrors = [err10];
      } else {
        vErrors.push(err10);
      }
      errors++;
    }
    if (data.startedAt === void 0) {
      const err11 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "startedAt" }, message: "must have required property 'startedAt'" };
      if (vErrors === null) {
        vErrors = [err11];
      } else {
        vErrors.push(err11);
      }
      errors++;
    }
    if (data.submittedAt === void 0) {
      const err12 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "submittedAt" }, message: "must have required property 'submittedAt'" };
      if (vErrors === null) {
        vErrors = [err12];
      } else {
        vErrors.push(err12);
      }
      errors++;
    }
    if (data.invalidatedAt === void 0) {
      const err13 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "invalidatedAt" }, message: "must have required property 'invalidatedAt'" };
      if (vErrors === null) {
        vErrors = [err13];
      } else {
        vErrors.push(err13);
      }
      errors++;
    }
    if (data.revision === void 0) {
      const err14 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "revision" }, message: "must have required property 'revision'" };
      if (vErrors === null) {
        vErrors = [err14];
      } else {
        vErrors.push(err14);
      }
      errors++;
    }
    for (const key0 in data) {
      if (!func1.call(schema31.properties, key0)) {
        const err15 = { instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" };
        if (vErrors === null) {
          vErrors = [err15];
        } else {
          vErrors.push(err15);
        }
        errors++;
      }
    }
    if (data.id !== void 0) {
      let data4 = data.id;
      if (typeof data4 === "string") {
        if (func2(data4) < 1) {
          const err16 = { instancePath: instancePath + "/id", schemaPath: "#/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err16];
          } else {
            vErrors.push(err16);
          }
          errors++;
        }
      } else {
        const err17 = { instancePath: instancePath + "/id", schemaPath: "#/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err17];
        } else {
          vErrors.push(err17);
        }
        errors++;
      }
    }
    if (data.allocationId !== void 0) {
      let data5 = data.allocationId;
      if (typeof data5 === "string") {
        if (func2(data5) < 1) {
          const err18 = { instancePath: instancePath + "/allocationId", schemaPath: "#/properties/allocationId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err18];
          } else {
            vErrors.push(err18);
          }
          errors++;
        }
      } else {
        const err19 = { instancePath: instancePath + "/allocationId", schemaPath: "#/properties/allocationId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err19];
        } else {
          vErrors.push(err19);
        }
        errors++;
      }
    }
    if (data.attemptNo !== void 0) {
      let data6 = data.attemptNo;
      if (!(typeof data6 == "number" && (!(data6 % 1) && !isNaN(data6)))) {
        const err20 = { instancePath: instancePath + "/attemptNo", schemaPath: "#/properties/attemptNo/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
        if (vErrors === null) {
          vErrors = [err20];
        } else {
          vErrors.push(err20);
        }
        errors++;
      }
      if (typeof data6 == "number") {
        if (data6 < 1 || isNaN(data6)) {
          const err21 = { instancePath: instancePath + "/attemptNo", schemaPath: "#/properties/attemptNo/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
          if (vErrors === null) {
            vErrors = [err21];
          } else {
            vErrors.push(err21);
          }
          errors++;
        }
      }
    }
    if (data.status !== void 0) {
      let data7 = data.status;
      if (!(data7 === "in_progress" || data7 === "submitted" || data7 === "closed")) {
        const err22 = { instancePath: instancePath + "/status", schemaPath: "#/properties/status/enum", keyword: "enum", params: { allowedValues: schema31.properties.status.enum }, message: "must be equal to one of the allowed values" };
        if (vErrors === null) {
          vErrors = [err22];
        } else {
          vErrors.push(err22);
        }
        errors++;
      }
    }
    if (data.gradingStatus !== void 0) {
      let data8 = data.gradingStatus;
      if (!(data8 === "not_started" || data8 === "partial" || data8 === "complete")) {
        const err23 = { instancePath: instancePath + "/gradingStatus", schemaPath: "#/properties/gradingStatus/enum", keyword: "enum", params: { allowedValues: schema31.properties.gradingStatus.enum }, message: "must be equal to one of the allowed values" };
        if (vErrors === null) {
          vErrors = [err23];
        } else {
          vErrors.push(err23);
        }
        errors++;
      }
    }
    if (data.startedAt !== void 0) {
      let data9 = data.startedAt;
      if (typeof data9 === "string") {
        if (!formats0.validate(data9)) {
          const err24 = { instancePath: instancePath + "/startedAt", schemaPath: "#/properties/startedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
          if (vErrors === null) {
            vErrors = [err24];
          } else {
            vErrors.push(err24);
          }
          errors++;
        }
      } else {
        const err25 = { instancePath: instancePath + "/startedAt", schemaPath: "#/properties/startedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err25];
        } else {
          vErrors.push(err25);
        }
        errors++;
      }
    }
    if (data.submittedAt !== void 0) {
      let data10 = data.submittedAt;
      if (typeof data10 !== "string" && data10 !== null) {
        const err26 = { instancePath: instancePath + "/submittedAt", schemaPath: "#/properties/submittedAt/type", keyword: "type", params: { type: schema31.properties.submittedAt.type }, message: "must be string,null" };
        if (vErrors === null) {
          vErrors = [err26];
        } else {
          vErrors.push(err26);
        }
        errors++;
      }
      if (typeof data10 === "string") {
        if (!formats0.validate(data10)) {
          const err27 = { instancePath: instancePath + "/submittedAt", schemaPath: "#/properties/submittedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
          if (vErrors === null) {
            vErrors = [err27];
          } else {
            vErrors.push(err27);
          }
          errors++;
        }
      }
    }
    if (data.invalidatedAt !== void 0) {
      let data11 = data.invalidatedAt;
      if (typeof data11 !== "string" && data11 !== null) {
        const err28 = { instancePath: instancePath + "/invalidatedAt", schemaPath: "#/properties/invalidatedAt/type", keyword: "type", params: { type: schema31.properties.invalidatedAt.type }, message: "must be string,null" };
        if (vErrors === null) {
          vErrors = [err28];
        } else {
          vErrors.push(err28);
        }
        errors++;
      }
      if (typeof data11 === "string") {
        if (!formats0.validate(data11)) {
          const err29 = { instancePath: instancePath + "/invalidatedAt", schemaPath: "#/properties/invalidatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
          if (vErrors === null) {
            vErrors = [err29];
          } else {
            vErrors.push(err29);
          }
          errors++;
        }
      }
    }
    if (data.revision !== void 0) {
      let data12 = data.revision;
      if (!(typeof data12 == "number" && (!(data12 % 1) && !isNaN(data12)))) {
        const err30 = { instancePath: instancePath + "/revision", schemaPath: "#/properties/revision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
        if (vErrors === null) {
          vErrors = [err30];
        } else {
          vErrors.push(err30);
        }
        errors++;
      }
      if (typeof data12 == "number") {
        if (data12 < 1 || isNaN(data12)) {
          const err31 = { instancePath: instancePath + "/revision", schemaPath: "#/properties/revision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
          if (vErrors === null) {
            vErrors = [err31];
          } else {
            vErrors.push(err31);
          }
          errors++;
        }
      }
    }
  } else {
    const err32 = { instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" };
    if (vErrors === null) {
      vErrors = [err32];
    } else {
      vErrors.push(err32);
    }
    errors++;
  }
  validate20.errors = vErrors;
  return errors === 0;
}
validate20.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var resource = validate21;
var schema32 = { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "projectId": { "type": "string", "minLength": 1 }, "sourceMaterialIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "uniqueItems": true }, "profileId": { "type": "string", "minLength": 1 }, "type": { "enum": ["handout", "reading", "comprehension", "quiz", "vocabulary", "stations", "exitTicket", "organizer", "tieredPractice"] }, "currentDraftId": { "type": ["string", "null"] }, "latestPublishedVersionId": { "type": ["string", "null"] } }, "required": ["id", "projectId", "sourceMaterialIds", "profileId", "type", "currentDraftId", "latestPublishedVersionId"], "additionalProperties": false, "$schema": "https://json-schema.org/draft/2020-12/schema", "title": "resource" };
function validate21(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate21.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.id === void 0) {
      const err0 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
      if (vErrors === null) {
        vErrors = [err0];
      } else {
        vErrors.push(err0);
      }
      errors++;
    }
    if (data.projectId === void 0) {
      const err1 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "projectId" }, message: "must have required property 'projectId'" };
      if (vErrors === null) {
        vErrors = [err1];
      } else {
        vErrors.push(err1);
      }
      errors++;
    }
    if (data.sourceMaterialIds === void 0) {
      const err2 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "sourceMaterialIds" }, message: "must have required property 'sourceMaterialIds'" };
      if (vErrors === null) {
        vErrors = [err2];
      } else {
        vErrors.push(err2);
      }
      errors++;
    }
    if (data.profileId === void 0) {
      const err3 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "profileId" }, message: "must have required property 'profileId'" };
      if (vErrors === null) {
        vErrors = [err3];
      } else {
        vErrors.push(err3);
      }
      errors++;
    }
    if (data.type === void 0) {
      const err4 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
      if (vErrors === null) {
        vErrors = [err4];
      } else {
        vErrors.push(err4);
      }
      errors++;
    }
    if (data.currentDraftId === void 0) {
      const err5 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "currentDraftId" }, message: "must have required property 'currentDraftId'" };
      if (vErrors === null) {
        vErrors = [err5];
      } else {
        vErrors.push(err5);
      }
      errors++;
    }
    if (data.latestPublishedVersionId === void 0) {
      const err6 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "latestPublishedVersionId" }, message: "must have required property 'latestPublishedVersionId'" };
      if (vErrors === null) {
        vErrors = [err6];
      } else {
        vErrors.push(err6);
      }
      errors++;
    }
    for (const key0 in data) {
      if (!(key0 === "id" || key0 === "projectId" || key0 === "sourceMaterialIds" || key0 === "profileId" || key0 === "type" || key0 === "currentDraftId" || key0 === "latestPublishedVersionId")) {
        const err7 = { instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" };
        if (vErrors === null) {
          vErrors = [err7];
        } else {
          vErrors.push(err7);
        }
        errors++;
      }
    }
    if (data.id !== void 0) {
      let data0 = data.id;
      if (typeof data0 === "string") {
        if (func2(data0) < 1) {
          const err8 = { instancePath: instancePath + "/id", schemaPath: "#/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err8];
          } else {
            vErrors.push(err8);
          }
          errors++;
        }
      } else {
        const err9 = { instancePath: instancePath + "/id", schemaPath: "#/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err9];
        } else {
          vErrors.push(err9);
        }
        errors++;
      }
    }
    if (data.projectId !== void 0) {
      let data1 = data.projectId;
      if (typeof data1 === "string") {
        if (func2(data1) < 1) {
          const err10 = { instancePath: instancePath + "/projectId", schemaPath: "#/properties/projectId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err10];
          } else {
            vErrors.push(err10);
          }
          errors++;
        }
      } else {
        const err11 = { instancePath: instancePath + "/projectId", schemaPath: "#/properties/projectId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err11];
        } else {
          vErrors.push(err11);
        }
        errors++;
      }
    }
    if (data.sourceMaterialIds !== void 0) {
      let data2 = data.sourceMaterialIds;
      if (Array.isArray(data2)) {
        const len0 = data2.length;
        for (let i0 = 0; i0 < len0; i0++) {
          let data3 = data2[i0];
          if (typeof data3 === "string") {
            if (func2(data3) < 1) {
              const err12 = { instancePath: instancePath + "/sourceMaterialIds/" + i0, schemaPath: "#/properties/sourceMaterialIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
              if (vErrors === null) {
                vErrors = [err12];
              } else {
                vErrors.push(err12);
              }
              errors++;
            }
          } else {
            const err13 = { instancePath: instancePath + "/sourceMaterialIds/" + i0, schemaPath: "#/properties/sourceMaterialIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
            if (vErrors === null) {
              vErrors = [err13];
            } else {
              vErrors.push(err13);
            }
            errors++;
          }
        }
        let i1 = data2.length;
        let j0;
        if (i1 > 1) {
          const indices0 = {};
          for (; i1--; ) {
            let item0 = data2[i1];
            if (typeof item0 !== "string") {
              continue;
            }
            if (typeof indices0[item0] == "number") {
              j0 = indices0[item0];
              const err14 = { instancePath: instancePath + "/sourceMaterialIds", schemaPath: "#/properties/sourceMaterialIds/uniqueItems", keyword: "uniqueItems", params: { i: i1, j: j0 }, message: "must NOT have duplicate items (items ## " + j0 + " and " + i1 + " are identical)" };
              if (vErrors === null) {
                vErrors = [err14];
              } else {
                vErrors.push(err14);
              }
              errors++;
              break;
            }
            indices0[item0] = i1;
          }
        }
      } else {
        const err15 = { instancePath: instancePath + "/sourceMaterialIds", schemaPath: "#/properties/sourceMaterialIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
        if (vErrors === null) {
          vErrors = [err15];
        } else {
          vErrors.push(err15);
        }
        errors++;
      }
    }
    if (data.profileId !== void 0) {
      let data4 = data.profileId;
      if (typeof data4 === "string") {
        if (func2(data4) < 1) {
          const err16 = { instancePath: instancePath + "/profileId", schemaPath: "#/properties/profileId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err16];
          } else {
            vErrors.push(err16);
          }
          errors++;
        }
      } else {
        const err17 = { instancePath: instancePath + "/profileId", schemaPath: "#/properties/profileId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err17];
        } else {
          vErrors.push(err17);
        }
        errors++;
      }
    }
    if (data.type !== void 0) {
      let data5 = data.type;
      if (!(data5 === "handout" || data5 === "reading" || data5 === "comprehension" || data5 === "quiz" || data5 === "vocabulary" || data5 === "stations" || data5 === "exitTicket" || data5 === "organizer" || data5 === "tieredPractice")) {
        const err18 = { instancePath: instancePath + "/type", schemaPath: "#/properties/type/enum", keyword: "enum", params: { allowedValues: schema32.properties.type.enum }, message: "must be equal to one of the allowed values" };
        if (vErrors === null) {
          vErrors = [err18];
        } else {
          vErrors.push(err18);
        }
        errors++;
      }
    }
    if (data.currentDraftId !== void 0) {
      let data6 = data.currentDraftId;
      if (typeof data6 !== "string" && data6 !== null) {
        const err19 = { instancePath: instancePath + "/currentDraftId", schemaPath: "#/properties/currentDraftId/type", keyword: "type", params: { type: schema32.properties.currentDraftId.type }, message: "must be string,null" };
        if (vErrors === null) {
          vErrors = [err19];
        } else {
          vErrors.push(err19);
        }
        errors++;
      }
    }
    if (data.latestPublishedVersionId !== void 0) {
      let data7 = data.latestPublishedVersionId;
      if (typeof data7 !== "string" && data7 !== null) {
        const err20 = { instancePath: instancePath + "/latestPublishedVersionId", schemaPath: "#/properties/latestPublishedVersionId/type", keyword: "type", params: { type: schema32.properties.latestPublishedVersionId.type }, message: "must be string,null" };
        if (vErrors === null) {
          vErrors = [err20];
        } else {
          vErrors.push(err20);
        }
        errors++;
      }
    }
  } else {
    const err21 = { instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" };
    if (vErrors === null) {
      vErrors = [err21];
    } else {
      vErrors.push(err21);
    }
    errors++;
  }
  validate21.errors = vErrors;
  return errors === 0;
}
validate21.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var generate_request = validate22;
var schema33 = { "type": "object", "properties": { "schemaVersion": { "const": "2.0.0" }, "requestId": { "type": "string", "minLength": 1 }, "task": { "const": "generateResources" }, "inputMode": { "enum": ["source", "topic"] }, "projectId": { "type": "string", "minLength": 1 }, "topicDescription": { "type": "string", "minLength": 1 }, "sourceChunks": { "type": "array", "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "text": { "type": "string", "minLength": 1 }, "locator": { "type": "object", "properties": { "kind": { "enum": ["page", "paragraph", "section"] }, "index": { "type": "integer", "minimum": 1 } }, "required": ["kind", "index"], "additionalProperties": false } }, "required": ["id", "sourceId", "sourceRevision", "text", "locator"], "additionalProperties": false } }, "objectives": { "type": "array", "minItems": 1, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "description": { "type": "string", "minLength": 1 } }, "required": ["id", "description"], "additionalProperties": false } }, "profile": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "language": { "type": "string", "minLength": 1 }, "readingLoad": { "type": "object", "properties": { "teacherLabel": { "type": "string", "minLength": 1 }, "sentenceGuidance": { "type": "string", "minLength": 1 }, "vocabularySupport": { "type": "boolean" } }, "required": ["teacherLabel", "sentenceGuidance", "vocabularySupport"], "additionalProperties": false }, "cognitiveChallenge": { "type": "string", "minLength": 1 }, "scaffolds": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "supportTier": { "type": ["string", "null"] } }, "required": ["id", "language", "readingLoad", "cognitiveChallenge", "scaffolds", "supportTier"], "additionalProperties": false }, "outputSpec": { "type": "object", "properties": { "resourceType": { "enum": ["handout", "reading", "comprehension", "quiz", "vocabulary", "stations", "exitTicket", "organizer", "tieredPractice"] }, "title": { "type": "string", "minLength": 1 }, "questionTypes": { "type": "array", "uniqueItems": true, "items": { "enum": ["singleChoice", "trueFalse", "shortAnswer"] } }, "questionCount": { "type": "integer", "minimum": 0, "maximum": 100 } }, "required": ["resourceType", "title", "questionTypes", "questionCount"], "additionalProperties": false } }, "required": ["schemaVersion", "requestId", "task", "inputMode", "projectId", "topicDescription", "sourceChunks", "objectives", "profile", "outputSpec"], "additionalProperties": false, "allOf": [{ "if": { "properties": { "inputMode": { "const": "source" } } }, "then": { "properties": { "sourceChunks": { "minItems": 1 } } } }], "$schema": "https://json-schema.org/draft/2020-12/schema", "title": "generate-request" };
var func0 = require_equal().default;
function validate22(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate22.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  const _errs2 = errors;
  let valid1 = true;
  const _errs3 = errors;
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.inputMode !== void 0) {
      if ("source" !== data.inputMode) {
        const err0 = {};
        if (vErrors === null) {
          vErrors = [err0];
        } else {
          vErrors.push(err0);
        }
        errors++;
      }
    }
  }
  var _valid0 = _errs3 === errors;
  errors = _errs2;
  if (vErrors !== null) {
    if (_errs2) {
      vErrors.length = _errs2;
    } else {
      vErrors = null;
    }
  }
  if (_valid0) {
    const _errs5 = errors;
    if (data && typeof data == "object" && !Array.isArray(data)) {
      if (data.sourceChunks !== void 0) {
        let data1 = data.sourceChunks;
        if (Array.isArray(data1)) {
          if (data1.length < 1) {
            const err1 = { instancePath: instancePath + "/sourceChunks", schemaPath: "#/allOf/0/then/properties/sourceChunks/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
            if (vErrors === null) {
              vErrors = [err1];
            } else {
              vErrors.push(err1);
            }
            errors++;
          }
        }
      }
    }
    var _valid0 = _errs5 === errors;
    valid1 = _valid0;
    if (valid1) {
      var props0 = {};
      props0.sourceChunks = true;
      props0.inputMode = true;
    }
  }
  if (!valid1) {
    const err2 = { instancePath, schemaPath: "#/allOf/0/if", keyword: "if", params: { failingKeyword: "then" }, message: 'must match "then" schema' };
    if (vErrors === null) {
      vErrors = [err2];
    } else {
      vErrors.push(err2);
    }
    errors++;
  }
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.schemaVersion === void 0) {
      const err3 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "schemaVersion" }, message: "must have required property 'schemaVersion'" };
      if (vErrors === null) {
        vErrors = [err3];
      } else {
        vErrors.push(err3);
      }
      errors++;
    }
    if (data.requestId === void 0) {
      const err4 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "requestId" }, message: "must have required property 'requestId'" };
      if (vErrors === null) {
        vErrors = [err4];
      } else {
        vErrors.push(err4);
      }
      errors++;
    }
    if (data.task === void 0) {
      const err5 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "task" }, message: "must have required property 'task'" };
      if (vErrors === null) {
        vErrors = [err5];
      } else {
        vErrors.push(err5);
      }
      errors++;
    }
    if (data.inputMode === void 0) {
      const err6 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "inputMode" }, message: "must have required property 'inputMode'" };
      if (vErrors === null) {
        vErrors = [err6];
      } else {
        vErrors.push(err6);
      }
      errors++;
    }
    if (data.projectId === void 0) {
      const err7 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "projectId" }, message: "must have required property 'projectId'" };
      if (vErrors === null) {
        vErrors = [err7];
      } else {
        vErrors.push(err7);
      }
      errors++;
    }
    if (data.topicDescription === void 0) {
      const err8 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "topicDescription" }, message: "must have required property 'topicDescription'" };
      if (vErrors === null) {
        vErrors = [err8];
      } else {
        vErrors.push(err8);
      }
      errors++;
    }
    if (data.sourceChunks === void 0) {
      const err9 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "sourceChunks" }, message: "must have required property 'sourceChunks'" };
      if (vErrors === null) {
        vErrors = [err9];
      } else {
        vErrors.push(err9);
      }
      errors++;
    }
    if (data.objectives === void 0) {
      const err10 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "objectives" }, message: "must have required property 'objectives'" };
      if (vErrors === null) {
        vErrors = [err10];
      } else {
        vErrors.push(err10);
      }
      errors++;
    }
    if (data.profile === void 0) {
      const err11 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "profile" }, message: "must have required property 'profile'" };
      if (vErrors === null) {
        vErrors = [err11];
      } else {
        vErrors.push(err11);
      }
      errors++;
    }
    if (data.outputSpec === void 0) {
      const err12 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "outputSpec" }, message: "must have required property 'outputSpec'" };
      if (vErrors === null) {
        vErrors = [err12];
      } else {
        vErrors.push(err12);
      }
      errors++;
    }
    for (const key0 in data) {
      if (!func1.call(schema33.properties, key0)) {
        const err13 = { instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" };
        if (vErrors === null) {
          vErrors = [err13];
        } else {
          vErrors.push(err13);
        }
        errors++;
      }
    }
    if (data.schemaVersion !== void 0) {
      if ("2.0.0" !== data.schemaVersion) {
        const err14 = { instancePath: instancePath + "/schemaVersion", schemaPath: "#/properties/schemaVersion/const", keyword: "const", params: { allowedValue: "2.0.0" }, message: "must be equal to constant" };
        if (vErrors === null) {
          vErrors = [err14];
        } else {
          vErrors.push(err14);
        }
        errors++;
      }
    }
    if (data.requestId !== void 0) {
      let data3 = data.requestId;
      if (typeof data3 === "string") {
        if (func2(data3) < 1) {
          const err15 = { instancePath: instancePath + "/requestId", schemaPath: "#/properties/requestId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err15];
          } else {
            vErrors.push(err15);
          }
          errors++;
        }
      } else {
        const err16 = { instancePath: instancePath + "/requestId", schemaPath: "#/properties/requestId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err16];
        } else {
          vErrors.push(err16);
        }
        errors++;
      }
    }
    if (data.task !== void 0) {
      if ("generateResources" !== data.task) {
        const err17 = { instancePath: instancePath + "/task", schemaPath: "#/properties/task/const", keyword: "const", params: { allowedValue: "generateResources" }, message: "must be equal to constant" };
        if (vErrors === null) {
          vErrors = [err17];
        } else {
          vErrors.push(err17);
        }
        errors++;
      }
    }
    if (data.inputMode !== void 0) {
      let data5 = data.inputMode;
      if (!(data5 === "source" || data5 === "topic")) {
        const err18 = { instancePath: instancePath + "/inputMode", schemaPath: "#/properties/inputMode/enum", keyword: "enum", params: { allowedValues: schema33.properties.inputMode.enum }, message: "must be equal to one of the allowed values" };
        if (vErrors === null) {
          vErrors = [err18];
        } else {
          vErrors.push(err18);
        }
        errors++;
      }
    }
    if (data.projectId !== void 0) {
      let data6 = data.projectId;
      if (typeof data6 === "string") {
        if (func2(data6) < 1) {
          const err19 = { instancePath: instancePath + "/projectId", schemaPath: "#/properties/projectId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err19];
          } else {
            vErrors.push(err19);
          }
          errors++;
        }
      } else {
        const err20 = { instancePath: instancePath + "/projectId", schemaPath: "#/properties/projectId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err20];
        } else {
          vErrors.push(err20);
        }
        errors++;
      }
    }
    if (data.topicDescription !== void 0) {
      let data7 = data.topicDescription;
      if (typeof data7 === "string") {
        if (func2(data7) < 1) {
          const err21 = { instancePath: instancePath + "/topicDescription", schemaPath: "#/properties/topicDescription/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err21];
          } else {
            vErrors.push(err21);
          }
          errors++;
        }
      } else {
        const err22 = { instancePath: instancePath + "/topicDescription", schemaPath: "#/properties/topicDescription/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err22];
        } else {
          vErrors.push(err22);
        }
        errors++;
      }
    }
    if (data.sourceChunks !== void 0) {
      let data8 = data.sourceChunks;
      if (Array.isArray(data8)) {
        const len0 = data8.length;
        for (let i0 = 0; i0 < len0; i0++) {
          let data9 = data8[i0];
          if (data9 && typeof data9 == "object" && !Array.isArray(data9)) {
            if (data9.id === void 0) {
              const err23 = { instancePath: instancePath + "/sourceChunks/" + i0, schemaPath: "#/properties/sourceChunks/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
              if (vErrors === null) {
                vErrors = [err23];
              } else {
                vErrors.push(err23);
              }
              errors++;
            }
            if (data9.sourceId === void 0) {
              const err24 = { instancePath: instancePath + "/sourceChunks/" + i0, schemaPath: "#/properties/sourceChunks/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
              if (vErrors === null) {
                vErrors = [err24];
              } else {
                vErrors.push(err24);
              }
              errors++;
            }
            if (data9.sourceRevision === void 0) {
              const err25 = { instancePath: instancePath + "/sourceChunks/" + i0, schemaPath: "#/properties/sourceChunks/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
              if (vErrors === null) {
                vErrors = [err25];
              } else {
                vErrors.push(err25);
              }
              errors++;
            }
            if (data9.text === void 0) {
              const err26 = { instancePath: instancePath + "/sourceChunks/" + i0, schemaPath: "#/properties/sourceChunks/items/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
              if (vErrors === null) {
                vErrors = [err26];
              } else {
                vErrors.push(err26);
              }
              errors++;
            }
            if (data9.locator === void 0) {
              const err27 = { instancePath: instancePath + "/sourceChunks/" + i0, schemaPath: "#/properties/sourceChunks/items/required", keyword: "required", params: { missingProperty: "locator" }, message: "must have required property 'locator'" };
              if (vErrors === null) {
                vErrors = [err27];
              } else {
                vErrors.push(err27);
              }
              errors++;
            }
            for (const key1 in data9) {
              if (!(key1 === "id" || key1 === "sourceId" || key1 === "sourceRevision" || key1 === "text" || key1 === "locator")) {
                const err28 = { instancePath: instancePath + "/sourceChunks/" + i0, schemaPath: "#/properties/sourceChunks/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" };
                if (vErrors === null) {
                  vErrors = [err28];
                } else {
                  vErrors.push(err28);
                }
                errors++;
              }
            }
            if (data9.id !== void 0) {
              let data10 = data9.id;
              if (typeof data10 === "string") {
                if (func2(data10) < 1) {
                  const err29 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/id", schemaPath: "#/properties/sourceChunks/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err29];
                  } else {
                    vErrors.push(err29);
                  }
                  errors++;
                }
              } else {
                const err30 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/id", schemaPath: "#/properties/sourceChunks/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err30];
                } else {
                  vErrors.push(err30);
                }
                errors++;
              }
            }
            if (data9.sourceId !== void 0) {
              let data11 = data9.sourceId;
              if (typeof data11 === "string") {
                if (func2(data11) < 1) {
                  const err31 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/sourceId", schemaPath: "#/properties/sourceChunks/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err31];
                  } else {
                    vErrors.push(err31);
                  }
                  errors++;
                }
              } else {
                const err32 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/sourceId", schemaPath: "#/properties/sourceChunks/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err32];
                } else {
                  vErrors.push(err32);
                }
                errors++;
              }
            }
            if (data9.sourceRevision !== void 0) {
              let data12 = data9.sourceRevision;
              if (!(typeof data12 == "number" && (!(data12 % 1) && !isNaN(data12)))) {
                const err33 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/sourceRevision", schemaPath: "#/properties/sourceChunks/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                if (vErrors === null) {
                  vErrors = [err33];
                } else {
                  vErrors.push(err33);
                }
                errors++;
              }
              if (typeof data12 == "number") {
                if (data12 < 1 || isNaN(data12)) {
                  const err34 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/sourceRevision", schemaPath: "#/properties/sourceChunks/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                  if (vErrors === null) {
                    vErrors = [err34];
                  } else {
                    vErrors.push(err34);
                  }
                  errors++;
                }
              }
            }
            if (data9.text !== void 0) {
              let data13 = data9.text;
              if (typeof data13 === "string") {
                if (func2(data13) < 1) {
                  const err35 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/text", schemaPath: "#/properties/sourceChunks/items/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err35];
                  } else {
                    vErrors.push(err35);
                  }
                  errors++;
                }
              } else {
                const err36 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/text", schemaPath: "#/properties/sourceChunks/items/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err36];
                } else {
                  vErrors.push(err36);
                }
                errors++;
              }
            }
            if (data9.locator !== void 0) {
              let data14 = data9.locator;
              if (data14 && typeof data14 == "object" && !Array.isArray(data14)) {
                if (data14.kind === void 0) {
                  const err37 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/locator", schemaPath: "#/properties/sourceChunks/items/properties/locator/required", keyword: "required", params: { missingProperty: "kind" }, message: "must have required property 'kind'" };
                  if (vErrors === null) {
                    vErrors = [err37];
                  } else {
                    vErrors.push(err37);
                  }
                  errors++;
                }
                if (data14.index === void 0) {
                  const err38 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/locator", schemaPath: "#/properties/sourceChunks/items/properties/locator/required", keyword: "required", params: { missingProperty: "index" }, message: "must have required property 'index'" };
                  if (vErrors === null) {
                    vErrors = [err38];
                  } else {
                    vErrors.push(err38);
                  }
                  errors++;
                }
                for (const key2 in data14) {
                  if (!(key2 === "kind" || key2 === "index")) {
                    const err39 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/locator", schemaPath: "#/properties/sourceChunks/items/properties/locator/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" };
                    if (vErrors === null) {
                      vErrors = [err39];
                    } else {
                      vErrors.push(err39);
                    }
                    errors++;
                  }
                }
                if (data14.kind !== void 0) {
                  let data15 = data14.kind;
                  if (!(data15 === "page" || data15 === "paragraph" || data15 === "section")) {
                    const err40 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/locator/kind", schemaPath: "#/properties/sourceChunks/items/properties/locator/properties/kind/enum", keyword: "enum", params: { allowedValues: schema33.properties.sourceChunks.items.properties.locator.properties.kind.enum }, message: "must be equal to one of the allowed values" };
                    if (vErrors === null) {
                      vErrors = [err40];
                    } else {
                      vErrors.push(err40);
                    }
                    errors++;
                  }
                }
                if (data14.index !== void 0) {
                  let data16 = data14.index;
                  if (!(typeof data16 == "number" && (!(data16 % 1) && !isNaN(data16)))) {
                    const err41 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/locator/index", schemaPath: "#/properties/sourceChunks/items/properties/locator/properties/index/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                    if (vErrors === null) {
                      vErrors = [err41];
                    } else {
                      vErrors.push(err41);
                    }
                    errors++;
                  }
                  if (typeof data16 == "number") {
                    if (data16 < 1 || isNaN(data16)) {
                      const err42 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/locator/index", schemaPath: "#/properties/sourceChunks/items/properties/locator/properties/index/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                      if (vErrors === null) {
                        vErrors = [err42];
                      } else {
                        vErrors.push(err42);
                      }
                      errors++;
                    }
                  }
                }
              } else {
                const err43 = { instancePath: instancePath + "/sourceChunks/" + i0 + "/locator", schemaPath: "#/properties/sourceChunks/items/properties/locator/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                if (vErrors === null) {
                  vErrors = [err43];
                } else {
                  vErrors.push(err43);
                }
                errors++;
              }
            }
          } else {
            const err44 = { instancePath: instancePath + "/sourceChunks/" + i0, schemaPath: "#/properties/sourceChunks/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
            if (vErrors === null) {
              vErrors = [err44];
            } else {
              vErrors.push(err44);
            }
            errors++;
          }
        }
      } else {
        const err45 = { instancePath: instancePath + "/sourceChunks", schemaPath: "#/properties/sourceChunks/type", keyword: "type", params: { type: "array" }, message: "must be array" };
        if (vErrors === null) {
          vErrors = [err45];
        } else {
          vErrors.push(err45);
        }
        errors++;
      }
    }
    if (data.objectives !== void 0) {
      let data17 = data.objectives;
      if (Array.isArray(data17)) {
        if (data17.length < 1) {
          const err46 = { instancePath: instancePath + "/objectives", schemaPath: "#/properties/objectives/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
          if (vErrors === null) {
            vErrors = [err46];
          } else {
            vErrors.push(err46);
          }
          errors++;
        }
        const len1 = data17.length;
        for (let i1 = 0; i1 < len1; i1++) {
          let data18 = data17[i1];
          if (data18 && typeof data18 == "object" && !Array.isArray(data18)) {
            if (data18.id === void 0) {
              const err47 = { instancePath: instancePath + "/objectives/" + i1, schemaPath: "#/properties/objectives/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
              if (vErrors === null) {
                vErrors = [err47];
              } else {
                vErrors.push(err47);
              }
              errors++;
            }
            if (data18.description === void 0) {
              const err48 = { instancePath: instancePath + "/objectives/" + i1, schemaPath: "#/properties/objectives/items/required", keyword: "required", params: { missingProperty: "description" }, message: "must have required property 'description'" };
              if (vErrors === null) {
                vErrors = [err48];
              } else {
                vErrors.push(err48);
              }
              errors++;
            }
            for (const key3 in data18) {
              if (!(key3 === "id" || key3 === "description")) {
                const err49 = { instancePath: instancePath + "/objectives/" + i1, schemaPath: "#/properties/objectives/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" };
                if (vErrors === null) {
                  vErrors = [err49];
                } else {
                  vErrors.push(err49);
                }
                errors++;
              }
            }
            if (data18.id !== void 0) {
              let data19 = data18.id;
              if (typeof data19 === "string") {
                if (func2(data19) < 1) {
                  const err50 = { instancePath: instancePath + "/objectives/" + i1 + "/id", schemaPath: "#/properties/objectives/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err50];
                  } else {
                    vErrors.push(err50);
                  }
                  errors++;
                }
              } else {
                const err51 = { instancePath: instancePath + "/objectives/" + i1 + "/id", schemaPath: "#/properties/objectives/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err51];
                } else {
                  vErrors.push(err51);
                }
                errors++;
              }
            }
            if (data18.description !== void 0) {
              let data20 = data18.description;
              if (typeof data20 === "string") {
                if (func2(data20) < 1) {
                  const err52 = { instancePath: instancePath + "/objectives/" + i1 + "/description", schemaPath: "#/properties/objectives/items/properties/description/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err52];
                  } else {
                    vErrors.push(err52);
                  }
                  errors++;
                }
              } else {
                const err53 = { instancePath: instancePath + "/objectives/" + i1 + "/description", schemaPath: "#/properties/objectives/items/properties/description/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err53];
                } else {
                  vErrors.push(err53);
                }
                errors++;
              }
            }
          } else {
            const err54 = { instancePath: instancePath + "/objectives/" + i1, schemaPath: "#/properties/objectives/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
            if (vErrors === null) {
              vErrors = [err54];
            } else {
              vErrors.push(err54);
            }
            errors++;
          }
        }
      } else {
        const err55 = { instancePath: instancePath + "/objectives", schemaPath: "#/properties/objectives/type", keyword: "type", params: { type: "array" }, message: "must be array" };
        if (vErrors === null) {
          vErrors = [err55];
        } else {
          vErrors.push(err55);
        }
        errors++;
      }
    }
    if (data.profile !== void 0) {
      let data21 = data.profile;
      if (data21 && typeof data21 == "object" && !Array.isArray(data21)) {
        if (data21.id === void 0) {
          const err56 = { instancePath: instancePath + "/profile", schemaPath: "#/properties/profile/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
          if (vErrors === null) {
            vErrors = [err56];
          } else {
            vErrors.push(err56);
          }
          errors++;
        }
        if (data21.language === void 0) {
          const err57 = { instancePath: instancePath + "/profile", schemaPath: "#/properties/profile/required", keyword: "required", params: { missingProperty: "language" }, message: "must have required property 'language'" };
          if (vErrors === null) {
            vErrors = [err57];
          } else {
            vErrors.push(err57);
          }
          errors++;
        }
        if (data21.readingLoad === void 0) {
          const err58 = { instancePath: instancePath + "/profile", schemaPath: "#/properties/profile/required", keyword: "required", params: { missingProperty: "readingLoad" }, message: "must have required property 'readingLoad'" };
          if (vErrors === null) {
            vErrors = [err58];
          } else {
            vErrors.push(err58);
          }
          errors++;
        }
        if (data21.cognitiveChallenge === void 0) {
          const err59 = { instancePath: instancePath + "/profile", schemaPath: "#/properties/profile/required", keyword: "required", params: { missingProperty: "cognitiveChallenge" }, message: "must have required property 'cognitiveChallenge'" };
          if (vErrors === null) {
            vErrors = [err59];
          } else {
            vErrors.push(err59);
          }
          errors++;
        }
        if (data21.scaffolds === void 0) {
          const err60 = { instancePath: instancePath + "/profile", schemaPath: "#/properties/profile/required", keyword: "required", params: { missingProperty: "scaffolds" }, message: "must have required property 'scaffolds'" };
          if (vErrors === null) {
            vErrors = [err60];
          } else {
            vErrors.push(err60);
          }
          errors++;
        }
        if (data21.supportTier === void 0) {
          const err61 = { instancePath: instancePath + "/profile", schemaPath: "#/properties/profile/required", keyword: "required", params: { missingProperty: "supportTier" }, message: "must have required property 'supportTier'" };
          if (vErrors === null) {
            vErrors = [err61];
          } else {
            vErrors.push(err61);
          }
          errors++;
        }
        for (const key4 in data21) {
          if (!(key4 === "id" || key4 === "language" || key4 === "readingLoad" || key4 === "cognitiveChallenge" || key4 === "scaffolds" || key4 === "supportTier")) {
            const err62 = { instancePath: instancePath + "/profile", schemaPath: "#/properties/profile/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key4 }, message: "must NOT have additional properties" };
            if (vErrors === null) {
              vErrors = [err62];
            } else {
              vErrors.push(err62);
            }
            errors++;
          }
        }
        if (data21.id !== void 0) {
          let data22 = data21.id;
          if (typeof data22 === "string") {
            if (func2(data22) < 1) {
              const err63 = { instancePath: instancePath + "/profile/id", schemaPath: "#/properties/profile/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
              if (vErrors === null) {
                vErrors = [err63];
              } else {
                vErrors.push(err63);
              }
              errors++;
            }
          } else {
            const err64 = { instancePath: instancePath + "/profile/id", schemaPath: "#/properties/profile/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
            if (vErrors === null) {
              vErrors = [err64];
            } else {
              vErrors.push(err64);
            }
            errors++;
          }
        }
        if (data21.language !== void 0) {
          let data23 = data21.language;
          if (typeof data23 === "string") {
            if (func2(data23) < 1) {
              const err65 = { instancePath: instancePath + "/profile/language", schemaPath: "#/properties/profile/properties/language/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
              if (vErrors === null) {
                vErrors = [err65];
              } else {
                vErrors.push(err65);
              }
              errors++;
            }
          } else {
            const err66 = { instancePath: instancePath + "/profile/language", schemaPath: "#/properties/profile/properties/language/type", keyword: "type", params: { type: "string" }, message: "must be string" };
            if (vErrors === null) {
              vErrors = [err66];
            } else {
              vErrors.push(err66);
            }
            errors++;
          }
        }
        if (data21.readingLoad !== void 0) {
          let data24 = data21.readingLoad;
          if (data24 && typeof data24 == "object" && !Array.isArray(data24)) {
            if (data24.teacherLabel === void 0) {
              const err67 = { instancePath: instancePath + "/profile/readingLoad", schemaPath: "#/properties/profile/properties/readingLoad/required", keyword: "required", params: { missingProperty: "teacherLabel" }, message: "must have required property 'teacherLabel'" };
              if (vErrors === null) {
                vErrors = [err67];
              } else {
                vErrors.push(err67);
              }
              errors++;
            }
            if (data24.sentenceGuidance === void 0) {
              const err68 = { instancePath: instancePath + "/profile/readingLoad", schemaPath: "#/properties/profile/properties/readingLoad/required", keyword: "required", params: { missingProperty: "sentenceGuidance" }, message: "must have required property 'sentenceGuidance'" };
              if (vErrors === null) {
                vErrors = [err68];
              } else {
                vErrors.push(err68);
              }
              errors++;
            }
            if (data24.vocabularySupport === void 0) {
              const err69 = { instancePath: instancePath + "/profile/readingLoad", schemaPath: "#/properties/profile/properties/readingLoad/required", keyword: "required", params: { missingProperty: "vocabularySupport" }, message: "must have required property 'vocabularySupport'" };
              if (vErrors === null) {
                vErrors = [err69];
              } else {
                vErrors.push(err69);
              }
              errors++;
            }
            for (const key5 in data24) {
              if (!(key5 === "teacherLabel" || key5 === "sentenceGuidance" || key5 === "vocabularySupport")) {
                const err70 = { instancePath: instancePath + "/profile/readingLoad", schemaPath: "#/properties/profile/properties/readingLoad/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key5 }, message: "must NOT have additional properties" };
                if (vErrors === null) {
                  vErrors = [err70];
                } else {
                  vErrors.push(err70);
                }
                errors++;
              }
            }
            if (data24.teacherLabel !== void 0) {
              let data25 = data24.teacherLabel;
              if (typeof data25 === "string") {
                if (func2(data25) < 1) {
                  const err71 = { instancePath: instancePath + "/profile/readingLoad/teacherLabel", schemaPath: "#/properties/profile/properties/readingLoad/properties/teacherLabel/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err71];
                  } else {
                    vErrors.push(err71);
                  }
                  errors++;
                }
              } else {
                const err72 = { instancePath: instancePath + "/profile/readingLoad/teacherLabel", schemaPath: "#/properties/profile/properties/readingLoad/properties/teacherLabel/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err72];
                } else {
                  vErrors.push(err72);
                }
                errors++;
              }
            }
            if (data24.sentenceGuidance !== void 0) {
              let data26 = data24.sentenceGuidance;
              if (typeof data26 === "string") {
                if (func2(data26) < 1) {
                  const err73 = { instancePath: instancePath + "/profile/readingLoad/sentenceGuidance", schemaPath: "#/properties/profile/properties/readingLoad/properties/sentenceGuidance/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err73];
                  } else {
                    vErrors.push(err73);
                  }
                  errors++;
                }
              } else {
                const err74 = { instancePath: instancePath + "/profile/readingLoad/sentenceGuidance", schemaPath: "#/properties/profile/properties/readingLoad/properties/sentenceGuidance/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err74];
                } else {
                  vErrors.push(err74);
                }
                errors++;
              }
            }
            if (data24.vocabularySupport !== void 0) {
              if (typeof data24.vocabularySupport !== "boolean") {
                const err75 = { instancePath: instancePath + "/profile/readingLoad/vocabularySupport", schemaPath: "#/properties/profile/properties/readingLoad/properties/vocabularySupport/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" };
                if (vErrors === null) {
                  vErrors = [err75];
                } else {
                  vErrors.push(err75);
                }
                errors++;
              }
            }
          } else {
            const err76 = { instancePath: instancePath + "/profile/readingLoad", schemaPath: "#/properties/profile/properties/readingLoad/type", keyword: "type", params: { type: "object" }, message: "must be object" };
            if (vErrors === null) {
              vErrors = [err76];
            } else {
              vErrors.push(err76);
            }
            errors++;
          }
        }
        if (data21.cognitiveChallenge !== void 0) {
          let data28 = data21.cognitiveChallenge;
          if (typeof data28 === "string") {
            if (func2(data28) < 1) {
              const err77 = { instancePath: instancePath + "/profile/cognitiveChallenge", schemaPath: "#/properties/profile/properties/cognitiveChallenge/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
              if (vErrors === null) {
                vErrors = [err77];
              } else {
                vErrors.push(err77);
              }
              errors++;
            }
          } else {
            const err78 = { instancePath: instancePath + "/profile/cognitiveChallenge", schemaPath: "#/properties/profile/properties/cognitiveChallenge/type", keyword: "type", params: { type: "string" }, message: "must be string" };
            if (vErrors === null) {
              vErrors = [err78];
            } else {
              vErrors.push(err78);
            }
            errors++;
          }
        }
        if (data21.scaffolds !== void 0) {
          let data29 = data21.scaffolds;
          if (Array.isArray(data29)) {
            const len2 = data29.length;
            for (let i2 = 0; i2 < len2; i2++) {
              let data30 = data29[i2];
              if (typeof data30 === "string") {
                if (func2(data30) < 1) {
                  const err79 = { instancePath: instancePath + "/profile/scaffolds/" + i2, schemaPath: "#/properties/profile/properties/scaffolds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err79];
                  } else {
                    vErrors.push(err79);
                  }
                  errors++;
                }
              } else {
                const err80 = { instancePath: instancePath + "/profile/scaffolds/" + i2, schemaPath: "#/properties/profile/properties/scaffolds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err80];
                } else {
                  vErrors.push(err80);
                }
                errors++;
              }
            }
          } else {
            const err81 = { instancePath: instancePath + "/profile/scaffolds", schemaPath: "#/properties/profile/properties/scaffolds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
            if (vErrors === null) {
              vErrors = [err81];
            } else {
              vErrors.push(err81);
            }
            errors++;
          }
        }
        if (data21.supportTier !== void 0) {
          let data31 = data21.supportTier;
          if (typeof data31 !== "string" && data31 !== null) {
            const err82 = { instancePath: instancePath + "/profile/supportTier", schemaPath: "#/properties/profile/properties/supportTier/type", keyword: "type", params: { type: schema33.properties.profile.properties.supportTier.type }, message: "must be string,null" };
            if (vErrors === null) {
              vErrors = [err82];
            } else {
              vErrors.push(err82);
            }
            errors++;
          }
        }
      } else {
        const err83 = { instancePath: instancePath + "/profile", schemaPath: "#/properties/profile/type", keyword: "type", params: { type: "object" }, message: "must be object" };
        if (vErrors === null) {
          vErrors = [err83];
        } else {
          vErrors.push(err83);
        }
        errors++;
      }
    }
    if (data.outputSpec !== void 0) {
      let data32 = data.outputSpec;
      if (data32 && typeof data32 == "object" && !Array.isArray(data32)) {
        if (data32.resourceType === void 0) {
          const err84 = { instancePath: instancePath + "/outputSpec", schemaPath: "#/properties/outputSpec/required", keyword: "required", params: { missingProperty: "resourceType" }, message: "must have required property 'resourceType'" };
          if (vErrors === null) {
            vErrors = [err84];
          } else {
            vErrors.push(err84);
          }
          errors++;
        }
        if (data32.title === void 0) {
          const err85 = { instancePath: instancePath + "/outputSpec", schemaPath: "#/properties/outputSpec/required", keyword: "required", params: { missingProperty: "title" }, message: "must have required property 'title'" };
          if (vErrors === null) {
            vErrors = [err85];
          } else {
            vErrors.push(err85);
          }
          errors++;
        }
        if (data32.questionTypes === void 0) {
          const err86 = { instancePath: instancePath + "/outputSpec", schemaPath: "#/properties/outputSpec/required", keyword: "required", params: { missingProperty: "questionTypes" }, message: "must have required property 'questionTypes'" };
          if (vErrors === null) {
            vErrors = [err86];
          } else {
            vErrors.push(err86);
          }
          errors++;
        }
        if (data32.questionCount === void 0) {
          const err87 = { instancePath: instancePath + "/outputSpec", schemaPath: "#/properties/outputSpec/required", keyword: "required", params: { missingProperty: "questionCount" }, message: "must have required property 'questionCount'" };
          if (vErrors === null) {
            vErrors = [err87];
          } else {
            vErrors.push(err87);
          }
          errors++;
        }
        for (const key6 in data32) {
          if (!(key6 === "resourceType" || key6 === "title" || key6 === "questionTypes" || key6 === "questionCount")) {
            const err88 = { instancePath: instancePath + "/outputSpec", schemaPath: "#/properties/outputSpec/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key6 }, message: "must NOT have additional properties" };
            if (vErrors === null) {
              vErrors = [err88];
            } else {
              vErrors.push(err88);
            }
            errors++;
          }
        }
        if (data32.resourceType !== void 0) {
          let data33 = data32.resourceType;
          if (!(data33 === "handout" || data33 === "reading" || data33 === "comprehension" || data33 === "quiz" || data33 === "vocabulary" || data33 === "stations" || data33 === "exitTicket" || data33 === "organizer" || data33 === "tieredPractice")) {
            const err89 = { instancePath: instancePath + "/outputSpec/resourceType", schemaPath: "#/properties/outputSpec/properties/resourceType/enum", keyword: "enum", params: { allowedValues: schema33.properties.outputSpec.properties.resourceType.enum }, message: "must be equal to one of the allowed values" };
            if (vErrors === null) {
              vErrors = [err89];
            } else {
              vErrors.push(err89);
            }
            errors++;
          }
        }
        if (data32.title !== void 0) {
          let data34 = data32.title;
          if (typeof data34 === "string") {
            if (func2(data34) < 1) {
              const err90 = { instancePath: instancePath + "/outputSpec/title", schemaPath: "#/properties/outputSpec/properties/title/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
              if (vErrors === null) {
                vErrors = [err90];
              } else {
                vErrors.push(err90);
              }
              errors++;
            }
          } else {
            const err91 = { instancePath: instancePath + "/outputSpec/title", schemaPath: "#/properties/outputSpec/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" };
            if (vErrors === null) {
              vErrors = [err91];
            } else {
              vErrors.push(err91);
            }
            errors++;
          }
        }
        if (data32.questionTypes !== void 0) {
          let data35 = data32.questionTypes;
          if (Array.isArray(data35)) {
            const len3 = data35.length;
            for (let i3 = 0; i3 < len3; i3++) {
              let data36 = data35[i3];
              if (!(data36 === "singleChoice" || data36 === "trueFalse" || data36 === "shortAnswer")) {
                const err92 = { instancePath: instancePath + "/outputSpec/questionTypes/" + i3, schemaPath: "#/properties/outputSpec/properties/questionTypes/items/enum", keyword: "enum", params: { allowedValues: schema33.properties.outputSpec.properties.questionTypes.items.enum }, message: "must be equal to one of the allowed values" };
                if (vErrors === null) {
                  vErrors = [err92];
                } else {
                  vErrors.push(err92);
                }
                errors++;
              }
            }
            let i4 = data35.length;
            let j0;
            if (i4 > 1) {
              outer0: for (; i4--; ) {
                for (j0 = i4; j0--; ) {
                  if (func0(data35[i4], data35[j0])) {
                    const err93 = { instancePath: instancePath + "/outputSpec/questionTypes", schemaPath: "#/properties/outputSpec/properties/questionTypes/uniqueItems", keyword: "uniqueItems", params: { i: i4, j: j0 }, message: "must NOT have duplicate items (items ## " + j0 + " and " + i4 + " are identical)" };
                    if (vErrors === null) {
                      vErrors = [err93];
                    } else {
                      vErrors.push(err93);
                    }
                    errors++;
                    break outer0;
                  }
                }
              }
            }
          } else {
            const err94 = { instancePath: instancePath + "/outputSpec/questionTypes", schemaPath: "#/properties/outputSpec/properties/questionTypes/type", keyword: "type", params: { type: "array" }, message: "must be array" };
            if (vErrors === null) {
              vErrors = [err94];
            } else {
              vErrors.push(err94);
            }
            errors++;
          }
        }
        if (data32.questionCount !== void 0) {
          let data37 = data32.questionCount;
          if (!(typeof data37 == "number" && (!(data37 % 1) && !isNaN(data37)))) {
            const err95 = { instancePath: instancePath + "/outputSpec/questionCount", schemaPath: "#/properties/outputSpec/properties/questionCount/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
            if (vErrors === null) {
              vErrors = [err95];
            } else {
              vErrors.push(err95);
            }
            errors++;
          }
          if (typeof data37 == "number") {
            if (data37 > 100 || isNaN(data37)) {
              const err96 = { instancePath: instancePath + "/outputSpec/questionCount", schemaPath: "#/properties/outputSpec/properties/questionCount/maximum", keyword: "maximum", params: { comparison: "<=", limit: 100 }, message: "must be <= 100" };
              if (vErrors === null) {
                vErrors = [err96];
              } else {
                vErrors.push(err96);
              }
              errors++;
            }
            if (data37 < 0 || isNaN(data37)) {
              const err97 = { instancePath: instancePath + "/outputSpec/questionCount", schemaPath: "#/properties/outputSpec/properties/questionCount/minimum", keyword: "minimum", params: { comparison: ">=", limit: 0 }, message: "must be >= 0" };
              if (vErrors === null) {
                vErrors = [err97];
              } else {
                vErrors.push(err97);
              }
              errors++;
            }
          }
        }
      } else {
        const err98 = { instancePath: instancePath + "/outputSpec", schemaPath: "#/properties/outputSpec/type", keyword: "type", params: { type: "object" }, message: "must be object" };
        if (vErrors === null) {
          vErrors = [err98];
        } else {
          vErrors.push(err98);
        }
        errors++;
      }
    }
  } else {
    const err99 = { instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" };
    if (vErrors === null) {
      vErrors = [err99];
    } else {
      vErrors.push(err99);
    }
    errors++;
  }
  validate22.errors = vErrors;
  return errors === 0;
}
validate22.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var generate_result = validate23;
var schema34 = { "type": "object", "properties": { "schemaVersion": { "const": "2.0.0" }, "requestId": { "type": "string", "minLength": 1 }, "jobId": { "type": "string", "minLength": 1 }, "state": { "const": "succeeded" }, "origin": { "enum": ["mock", "model"] }, "providerInfo": { "type": "object", "properties": { "provider": { "type": "string", "minLength": 1 }, "modelId": { "type": ["string", "null"] } }, "required": ["provider", "modelId"], "additionalProperties": false }, "generatedAt": { "type": "string", "format": "date-time" }, "resources": { "type": "array", "minItems": 1, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "resourceId": { "type": "string", "minLength": 1 }, "resourceType": { "enum": ["handout", "reading", "comprehension", "quiz", "vocabulary", "stations", "exitTicket", "organizer", "tieredPractice"] }, "title": { "type": "string", "minLength": 1 }, "profileId": { "type": "string", "minLength": 1 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "blocks": { "type": "array", "items": { "oneOf": [{ "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "type": { "enum": ["heading", "paragraph"] }, "data": { "type": "object", "properties": { "text": { "type": "string", "minLength": 1 } }, "required": ["text"], "additionalProperties": false }, "visibility": { "enum": ["student", "teacher", "both"] }, "sourceRefs": { "type": "array", "items": { "type": "object", "properties": { "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "chunkId": { "type": "string", "minLength": 1 } }, "required": ["sourceId", "sourceRevision", "chunkId"], "additionalProperties": false } } }, "required": ["id", "type", "data", "visibility", "sourceRefs"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "type": { "const": "teacherNote" }, "data": { "type": "object", "properties": { "text": { "type": "string", "minLength": 1 } }, "required": ["text"], "additionalProperties": false }, "visibility": { "const": "teacher" }, "sourceRefs": { "type": "array", "items": { "type": "object", "properties": { "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "chunkId": { "type": "string", "minLength": 1 } }, "required": ["sourceId", "sourceRevision", "chunkId"], "additionalProperties": false } } }, "required": ["id", "type", "data", "visibility", "sourceRefs"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "type": { "const": "questionSet" }, "data": { "type": "object", "properties": { "questionIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true } }, "required": ["questionIds"], "additionalProperties": false }, "visibility": { "enum": ["student", "both"] }, "sourceRefs": { "type": "array", "items": { "type": "object", "properties": { "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "chunkId": { "type": "string", "minLength": 1 } }, "required": ["sourceId", "sourceRevision", "chunkId"], "additionalProperties": false } } }, "required": ["id", "type", "data", "visibility", "sourceRefs"], "additionalProperties": false }] } }, "questions": { "type": "array", "items": { "oneOf": [{ "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "sourceRefs": { "type": "array", "items": { "type": "object", "properties": { "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "chunkId": { "type": "string", "minLength": 1 } }, "required": ["sourceId", "sourceRevision", "chunkId"], "additionalProperties": false } }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "singleChoice" }, "options": { "type": "array", "minItems": 2, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "text": { "type": "string", "minLength": 1 } }, "required": ["id", "text"], "additionalProperties": false } }, "answerKey": { "type": "string", "minLength": 1 }, "scoring": { "const": "exactMatch" } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "sourceRefs", "hints", "type", "options", "answerKey", "scoring"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "sourceRefs": { "type": "array", "items": { "type": "object", "properties": { "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "chunkId": { "type": "string", "minLength": 1 } }, "required": ["sourceId", "sourceRevision", "chunkId"], "additionalProperties": false } }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "trueFalse" }, "answerKey": { "type": "boolean" }, "scoring": { "const": "exactMatch" } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "sourceRefs", "hints", "type", "answerKey", "scoring"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "sourceRefs": { "type": "array", "items": { "type": "object", "properties": { "sourceId": { "type": "string", "minLength": 1 }, "sourceRevision": { "type": "integer", "minimum": 1 }, "chunkId": { "type": "string", "minLength": 1 } }, "required": ["sourceId", "sourceRevision", "chunkId"], "additionalProperties": false } }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "shortAnswer" }, "rubric": { "type": "string", "minLength": 1 }, "scoring": { "const": "manual" } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "sourceRefs", "hints", "type", "rubric", "scoring"], "additionalProperties": false }] } } }, "required": ["id", "resourceId", "resourceType", "title", "profileId", "objectiveIds", "blocks", "questions"], "additionalProperties": false } }, "warnings": { "type": "array", "items": { "type": "string", "minLength": 1 } } }, "required": ["schemaVersion", "requestId", "jobId", "state", "origin", "providerInfo", "generatedAt", "resources", "warnings"], "additionalProperties": false, "$schema": "https://json-schema.org/draft/2020-12/schema", "title": "generate-result" };
function validate23(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate23.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.schemaVersion === void 0) {
      const err0 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "schemaVersion" }, message: "must have required property 'schemaVersion'" };
      if (vErrors === null) {
        vErrors = [err0];
      } else {
        vErrors.push(err0);
      }
      errors++;
    }
    if (data.requestId === void 0) {
      const err1 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "requestId" }, message: "must have required property 'requestId'" };
      if (vErrors === null) {
        vErrors = [err1];
      } else {
        vErrors.push(err1);
      }
      errors++;
    }
    if (data.jobId === void 0) {
      const err2 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "jobId" }, message: "must have required property 'jobId'" };
      if (vErrors === null) {
        vErrors = [err2];
      } else {
        vErrors.push(err2);
      }
      errors++;
    }
    if (data.state === void 0) {
      const err3 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "state" }, message: "must have required property 'state'" };
      if (vErrors === null) {
        vErrors = [err3];
      } else {
        vErrors.push(err3);
      }
      errors++;
    }
    if (data.origin === void 0) {
      const err4 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "origin" }, message: "must have required property 'origin'" };
      if (vErrors === null) {
        vErrors = [err4];
      } else {
        vErrors.push(err4);
      }
      errors++;
    }
    if (data.providerInfo === void 0) {
      const err5 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "providerInfo" }, message: "must have required property 'providerInfo'" };
      if (vErrors === null) {
        vErrors = [err5];
      } else {
        vErrors.push(err5);
      }
      errors++;
    }
    if (data.generatedAt === void 0) {
      const err6 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "generatedAt" }, message: "must have required property 'generatedAt'" };
      if (vErrors === null) {
        vErrors = [err6];
      } else {
        vErrors.push(err6);
      }
      errors++;
    }
    if (data.resources === void 0) {
      const err7 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "resources" }, message: "must have required property 'resources'" };
      if (vErrors === null) {
        vErrors = [err7];
      } else {
        vErrors.push(err7);
      }
      errors++;
    }
    if (data.warnings === void 0) {
      const err8 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "warnings" }, message: "must have required property 'warnings'" };
      if (vErrors === null) {
        vErrors = [err8];
      } else {
        vErrors.push(err8);
      }
      errors++;
    }
    for (const key0 in data) {
      if (!func1.call(schema34.properties, key0)) {
        const err9 = { instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" };
        if (vErrors === null) {
          vErrors = [err9];
        } else {
          vErrors.push(err9);
        }
        errors++;
      }
    }
    if (data.schemaVersion !== void 0) {
      if ("2.0.0" !== data.schemaVersion) {
        const err10 = { instancePath: instancePath + "/schemaVersion", schemaPath: "#/properties/schemaVersion/const", keyword: "const", params: { allowedValue: "2.0.0" }, message: "must be equal to constant" };
        if (vErrors === null) {
          vErrors = [err10];
        } else {
          vErrors.push(err10);
        }
        errors++;
      }
    }
    if (data.requestId !== void 0) {
      let data1 = data.requestId;
      if (typeof data1 === "string") {
        if (func2(data1) < 1) {
          const err11 = { instancePath: instancePath + "/requestId", schemaPath: "#/properties/requestId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err11];
          } else {
            vErrors.push(err11);
          }
          errors++;
        }
      } else {
        const err12 = { instancePath: instancePath + "/requestId", schemaPath: "#/properties/requestId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err12];
        } else {
          vErrors.push(err12);
        }
        errors++;
      }
    }
    if (data.jobId !== void 0) {
      let data2 = data.jobId;
      if (typeof data2 === "string") {
        if (func2(data2) < 1) {
          const err13 = { instancePath: instancePath + "/jobId", schemaPath: "#/properties/jobId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err13];
          } else {
            vErrors.push(err13);
          }
          errors++;
        }
      } else {
        const err14 = { instancePath: instancePath + "/jobId", schemaPath: "#/properties/jobId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err14];
        } else {
          vErrors.push(err14);
        }
        errors++;
      }
    }
    if (data.state !== void 0) {
      if ("succeeded" !== data.state) {
        const err15 = { instancePath: instancePath + "/state", schemaPath: "#/properties/state/const", keyword: "const", params: { allowedValue: "succeeded" }, message: "must be equal to constant" };
        if (vErrors === null) {
          vErrors = [err15];
        } else {
          vErrors.push(err15);
        }
        errors++;
      }
    }
    if (data.origin !== void 0) {
      let data4 = data.origin;
      if (!(data4 === "mock" || data4 === "model")) {
        const err16 = { instancePath: instancePath + "/origin", schemaPath: "#/properties/origin/enum", keyword: "enum", params: { allowedValues: schema34.properties.origin.enum }, message: "must be equal to one of the allowed values" };
        if (vErrors === null) {
          vErrors = [err16];
        } else {
          vErrors.push(err16);
        }
        errors++;
      }
    }
    if (data.providerInfo !== void 0) {
      let data5 = data.providerInfo;
      if (data5 && typeof data5 == "object" && !Array.isArray(data5)) {
        if (data5.provider === void 0) {
          const err17 = { instancePath: instancePath + "/providerInfo", schemaPath: "#/properties/providerInfo/required", keyword: "required", params: { missingProperty: "provider" }, message: "must have required property 'provider'" };
          if (vErrors === null) {
            vErrors = [err17];
          } else {
            vErrors.push(err17);
          }
          errors++;
        }
        if (data5.modelId === void 0) {
          const err18 = { instancePath: instancePath + "/providerInfo", schemaPath: "#/properties/providerInfo/required", keyword: "required", params: { missingProperty: "modelId" }, message: "must have required property 'modelId'" };
          if (vErrors === null) {
            vErrors = [err18];
          } else {
            vErrors.push(err18);
          }
          errors++;
        }
        for (const key1 in data5) {
          if (!(key1 === "provider" || key1 === "modelId")) {
            const err19 = { instancePath: instancePath + "/providerInfo", schemaPath: "#/properties/providerInfo/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" };
            if (vErrors === null) {
              vErrors = [err19];
            } else {
              vErrors.push(err19);
            }
            errors++;
          }
        }
        if (data5.provider !== void 0) {
          let data6 = data5.provider;
          if (typeof data6 === "string") {
            if (func2(data6) < 1) {
              const err20 = { instancePath: instancePath + "/providerInfo/provider", schemaPath: "#/properties/providerInfo/properties/provider/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
              if (vErrors === null) {
                vErrors = [err20];
              } else {
                vErrors.push(err20);
              }
              errors++;
            }
          } else {
            const err21 = { instancePath: instancePath + "/providerInfo/provider", schemaPath: "#/properties/providerInfo/properties/provider/type", keyword: "type", params: { type: "string" }, message: "must be string" };
            if (vErrors === null) {
              vErrors = [err21];
            } else {
              vErrors.push(err21);
            }
            errors++;
          }
        }
        if (data5.modelId !== void 0) {
          let data7 = data5.modelId;
          if (typeof data7 !== "string" && data7 !== null) {
            const err22 = { instancePath: instancePath + "/providerInfo/modelId", schemaPath: "#/properties/providerInfo/properties/modelId/type", keyword: "type", params: { type: schema34.properties.providerInfo.properties.modelId.type }, message: "must be string,null" };
            if (vErrors === null) {
              vErrors = [err22];
            } else {
              vErrors.push(err22);
            }
            errors++;
          }
        }
      } else {
        const err23 = { instancePath: instancePath + "/providerInfo", schemaPath: "#/properties/providerInfo/type", keyword: "type", params: { type: "object" }, message: "must be object" };
        if (vErrors === null) {
          vErrors = [err23];
        } else {
          vErrors.push(err23);
        }
        errors++;
      }
    }
    if (data.generatedAt !== void 0) {
      let data8 = data.generatedAt;
      if (typeof data8 === "string") {
        if (!formats0.validate(data8)) {
          const err24 = { instancePath: instancePath + "/generatedAt", schemaPath: "#/properties/generatedAt/format", keyword: "format", params: { format: "date-time" }, message: 'must match format "date-time"' };
          if (vErrors === null) {
            vErrors = [err24];
          } else {
            vErrors.push(err24);
          }
          errors++;
        }
      } else {
        const err25 = { instancePath: instancePath + "/generatedAt", schemaPath: "#/properties/generatedAt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err25];
        } else {
          vErrors.push(err25);
        }
        errors++;
      }
    }
    if (data.resources !== void 0) {
      let data9 = data.resources;
      if (Array.isArray(data9)) {
        if (data9.length < 1) {
          const err26 = { instancePath: instancePath + "/resources", schemaPath: "#/properties/resources/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
          if (vErrors === null) {
            vErrors = [err26];
          } else {
            vErrors.push(err26);
          }
          errors++;
        }
        const len0 = data9.length;
        for (let i0 = 0; i0 < len0; i0++) {
          let data10 = data9[i0];
          if (data10 && typeof data10 == "object" && !Array.isArray(data10)) {
            if (data10.id === void 0) {
              const err27 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
              if (vErrors === null) {
                vErrors = [err27];
              } else {
                vErrors.push(err27);
              }
              errors++;
            }
            if (data10.resourceId === void 0) {
              const err28 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/required", keyword: "required", params: { missingProperty: "resourceId" }, message: "must have required property 'resourceId'" };
              if (vErrors === null) {
                vErrors = [err28];
              } else {
                vErrors.push(err28);
              }
              errors++;
            }
            if (data10.resourceType === void 0) {
              const err29 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/required", keyword: "required", params: { missingProperty: "resourceType" }, message: "must have required property 'resourceType'" };
              if (vErrors === null) {
                vErrors = [err29];
              } else {
                vErrors.push(err29);
              }
              errors++;
            }
            if (data10.title === void 0) {
              const err30 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/required", keyword: "required", params: { missingProperty: "title" }, message: "must have required property 'title'" };
              if (vErrors === null) {
                vErrors = [err30];
              } else {
                vErrors.push(err30);
              }
              errors++;
            }
            if (data10.profileId === void 0) {
              const err31 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/required", keyword: "required", params: { missingProperty: "profileId" }, message: "must have required property 'profileId'" };
              if (vErrors === null) {
                vErrors = [err31];
              } else {
                vErrors.push(err31);
              }
              errors++;
            }
            if (data10.objectiveIds === void 0) {
              const err32 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
              if (vErrors === null) {
                vErrors = [err32];
              } else {
                vErrors.push(err32);
              }
              errors++;
            }
            if (data10.blocks === void 0) {
              const err33 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/required", keyword: "required", params: { missingProperty: "blocks" }, message: "must have required property 'blocks'" };
              if (vErrors === null) {
                vErrors = [err33];
              } else {
                vErrors.push(err33);
              }
              errors++;
            }
            if (data10.questions === void 0) {
              const err34 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/required", keyword: "required", params: { missingProperty: "questions" }, message: "must have required property 'questions'" };
              if (vErrors === null) {
                vErrors = [err34];
              } else {
                vErrors.push(err34);
              }
              errors++;
            }
            for (const key2 in data10) {
              if (!(key2 === "id" || key2 === "resourceId" || key2 === "resourceType" || key2 === "title" || key2 === "profileId" || key2 === "objectiveIds" || key2 === "blocks" || key2 === "questions")) {
                const err35 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" };
                if (vErrors === null) {
                  vErrors = [err35];
                } else {
                  vErrors.push(err35);
                }
                errors++;
              }
            }
            if (data10.id !== void 0) {
              let data11 = data10.id;
              if (typeof data11 === "string") {
                if (func2(data11) < 1) {
                  const err36 = { instancePath: instancePath + "/resources/" + i0 + "/id", schemaPath: "#/properties/resources/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err36];
                  } else {
                    vErrors.push(err36);
                  }
                  errors++;
                }
              } else {
                const err37 = { instancePath: instancePath + "/resources/" + i0 + "/id", schemaPath: "#/properties/resources/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err37];
                } else {
                  vErrors.push(err37);
                }
                errors++;
              }
            }
            if (data10.resourceId !== void 0) {
              let data12 = data10.resourceId;
              if (typeof data12 === "string") {
                if (func2(data12) < 1) {
                  const err38 = { instancePath: instancePath + "/resources/" + i0 + "/resourceId", schemaPath: "#/properties/resources/items/properties/resourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err38];
                  } else {
                    vErrors.push(err38);
                  }
                  errors++;
                }
              } else {
                const err39 = { instancePath: instancePath + "/resources/" + i0 + "/resourceId", schemaPath: "#/properties/resources/items/properties/resourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err39];
                } else {
                  vErrors.push(err39);
                }
                errors++;
              }
            }
            if (data10.resourceType !== void 0) {
              let data13 = data10.resourceType;
              if (!(data13 === "handout" || data13 === "reading" || data13 === "comprehension" || data13 === "quiz" || data13 === "vocabulary" || data13 === "stations" || data13 === "exitTicket" || data13 === "organizer" || data13 === "tieredPractice")) {
                const err40 = { instancePath: instancePath + "/resources/" + i0 + "/resourceType", schemaPath: "#/properties/resources/items/properties/resourceType/enum", keyword: "enum", params: { allowedValues: schema34.properties.resources.items.properties.resourceType.enum }, message: "must be equal to one of the allowed values" };
                if (vErrors === null) {
                  vErrors = [err40];
                } else {
                  vErrors.push(err40);
                }
                errors++;
              }
            }
            if (data10.title !== void 0) {
              let data14 = data10.title;
              if (typeof data14 === "string") {
                if (func2(data14) < 1) {
                  const err41 = { instancePath: instancePath + "/resources/" + i0 + "/title", schemaPath: "#/properties/resources/items/properties/title/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err41];
                  } else {
                    vErrors.push(err41);
                  }
                  errors++;
                }
              } else {
                const err42 = { instancePath: instancePath + "/resources/" + i0 + "/title", schemaPath: "#/properties/resources/items/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err42];
                } else {
                  vErrors.push(err42);
                }
                errors++;
              }
            }
            if (data10.profileId !== void 0) {
              let data15 = data10.profileId;
              if (typeof data15 === "string") {
                if (func2(data15) < 1) {
                  const err43 = { instancePath: instancePath + "/resources/" + i0 + "/profileId", schemaPath: "#/properties/resources/items/properties/profileId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err43];
                  } else {
                    vErrors.push(err43);
                  }
                  errors++;
                }
              } else {
                const err44 = { instancePath: instancePath + "/resources/" + i0 + "/profileId", schemaPath: "#/properties/resources/items/properties/profileId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err44];
                } else {
                  vErrors.push(err44);
                }
                errors++;
              }
            }
            if (data10.objectiveIds !== void 0) {
              let data16 = data10.objectiveIds;
              if (Array.isArray(data16)) {
                if (data16.length < 1) {
                  const err45 = { instancePath: instancePath + "/resources/" + i0 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                  if (vErrors === null) {
                    vErrors = [err45];
                  } else {
                    vErrors.push(err45);
                  }
                  errors++;
                }
                const len1 = data16.length;
                for (let i1 = 0; i1 < len1; i1++) {
                  let data17 = data16[i1];
                  if (typeof data17 === "string") {
                    if (func2(data17) < 1) {
                      const err46 = { instancePath: instancePath + "/resources/" + i0 + "/objectiveIds/" + i1, schemaPath: "#/properties/resources/items/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err46];
                      } else {
                        vErrors.push(err46);
                      }
                      errors++;
                    }
                  } else {
                    const err47 = { instancePath: instancePath + "/resources/" + i0 + "/objectiveIds/" + i1, schemaPath: "#/properties/resources/items/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err47];
                    } else {
                      vErrors.push(err47);
                    }
                    errors++;
                  }
                }
                let i2 = data16.length;
                let j0;
                if (i2 > 1) {
                  const indices0 = {};
                  for (; i2--; ) {
                    let item0 = data16[i2];
                    if (typeof item0 !== "string") {
                      continue;
                    }
                    if (typeof indices0[item0] == "number") {
                      j0 = indices0[item0];
                      const err48 = { instancePath: instancePath + "/resources/" + i0 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i2, j: j0 }, message: "must NOT have duplicate items (items ## " + j0 + " and " + i2 + " are identical)" };
                      if (vErrors === null) {
                        vErrors = [err48];
                      } else {
                        vErrors.push(err48);
                      }
                      errors++;
                      break;
                    }
                    indices0[item0] = i2;
                  }
                }
              } else {
                const err49 = { instancePath: instancePath + "/resources/" + i0 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                if (vErrors === null) {
                  vErrors = [err49];
                } else {
                  vErrors.push(err49);
                }
                errors++;
              }
            }
            if (data10.blocks !== void 0) {
              let data18 = data10.blocks;
              if (Array.isArray(data18)) {
                const len2 = data18.length;
                for (let i3 = 0; i3 < len2; i3++) {
                  let data19 = data18[i3];
                  const _errs39 = errors;
                  let valid10 = false;
                  let passing0 = null;
                  const _errs40 = errors;
                  if (data19 && typeof data19 == "object" && !Array.isArray(data19)) {
                    if (data19.id === void 0) {
                      const err50 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                      if (vErrors === null) {
                        vErrors = [err50];
                      } else {
                        vErrors.push(err50);
                      }
                      errors++;
                    }
                    if (data19.type === void 0) {
                      const err51 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                      if (vErrors === null) {
                        vErrors = [err51];
                      } else {
                        vErrors.push(err51);
                      }
                      errors++;
                    }
                    if (data19.data === void 0) {
                      const err52 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/required", keyword: "required", params: { missingProperty: "data" }, message: "must have required property 'data'" };
                      if (vErrors === null) {
                        vErrors = [err52];
                      } else {
                        vErrors.push(err52);
                      }
                      errors++;
                    }
                    if (data19.visibility === void 0) {
                      const err53 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/required", keyword: "required", params: { missingProperty: "visibility" }, message: "must have required property 'visibility'" };
                      if (vErrors === null) {
                        vErrors = [err53];
                      } else {
                        vErrors.push(err53);
                      }
                      errors++;
                    }
                    if (data19.sourceRefs === void 0) {
                      const err54 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/required", keyword: "required", params: { missingProperty: "sourceRefs" }, message: "must have required property 'sourceRefs'" };
                      if (vErrors === null) {
                        vErrors = [err54];
                      } else {
                        vErrors.push(err54);
                      }
                      errors++;
                    }
                    for (const key3 in data19) {
                      if (!(key3 === "id" || key3 === "type" || key3 === "data" || key3 === "visibility" || key3 === "sourceRefs")) {
                        const err55 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" };
                        if (vErrors === null) {
                          vErrors = [err55];
                        } else {
                          vErrors.push(err55);
                        }
                        errors++;
                      }
                    }
                    if (data19.id !== void 0) {
                      let data20 = data19.id;
                      if (typeof data20 === "string") {
                        if (func2(data20) < 1) {
                          const err56 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err56];
                          } else {
                            vErrors.push(err56);
                          }
                          errors++;
                        }
                      } else {
                        const err57 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err57];
                        } else {
                          vErrors.push(err57);
                        }
                        errors++;
                      }
                    }
                    if (data19.type !== void 0) {
                      let data21 = data19.type;
                      if (!(data21 === "heading" || data21 === "paragraph")) {
                        const err58 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/type", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/type/enum", keyword: "enum", params: { allowedValues: schema34.properties.resources.items.properties.blocks.items.oneOf[0].properties.type.enum }, message: "must be equal to one of the allowed values" };
                        if (vErrors === null) {
                          vErrors = [err58];
                        } else {
                          vErrors.push(err58);
                        }
                        errors++;
                      }
                    }
                    if (data19.data !== void 0) {
                      let data22 = data19.data;
                      if (data22 && typeof data22 == "object" && !Array.isArray(data22)) {
                        if (data22.text === void 0) {
                          const err59 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/data/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
                          if (vErrors === null) {
                            vErrors = [err59];
                          } else {
                            vErrors.push(err59);
                          }
                          errors++;
                        }
                        for (const key4 in data22) {
                          if (!(key4 === "text")) {
                            const err60 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/data/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key4 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err60];
                            } else {
                              vErrors.push(err60);
                            }
                            errors++;
                          }
                        }
                        if (data22.text !== void 0) {
                          let data23 = data22.text;
                          if (typeof data23 === "string") {
                            if (func2(data23) < 1) {
                              const err61 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/text", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/data/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err61];
                              } else {
                                vErrors.push(err61);
                              }
                              errors++;
                            }
                          } else {
                            const err62 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/text", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/data/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err62];
                            } else {
                              vErrors.push(err62);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err63 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/data/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                        if (vErrors === null) {
                          vErrors = [err63];
                        } else {
                          vErrors.push(err63);
                        }
                        errors++;
                      }
                    }
                    if (data19.visibility !== void 0) {
                      let data24 = data19.visibility;
                      if (!(data24 === "student" || data24 === "teacher" || data24 === "both")) {
                        const err64 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/visibility", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/visibility/enum", keyword: "enum", params: { allowedValues: schema34.properties.resources.items.properties.blocks.items.oneOf[0].properties.visibility.enum }, message: "must be equal to one of the allowed values" };
                        if (vErrors === null) {
                          vErrors = [err64];
                        } else {
                          vErrors.push(err64);
                        }
                        errors++;
                      }
                    }
                    if (data19.sourceRefs !== void 0) {
                      let data25 = data19.sourceRefs;
                      if (Array.isArray(data25)) {
                        const len3 = data25.length;
                        for (let i4 = 0; i4 < len3; i4++) {
                          let data26 = data25[i4];
                          if (data26 && typeof data26 == "object" && !Array.isArray(data26)) {
                            if (data26.sourceId === void 0) {
                              const err65 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
                              if (vErrors === null) {
                                vErrors = [err65];
                              } else {
                                vErrors.push(err65);
                              }
                              errors++;
                            }
                            if (data26.sourceRevision === void 0) {
                              const err66 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
                              if (vErrors === null) {
                                vErrors = [err66];
                              } else {
                                vErrors.push(err66);
                              }
                              errors++;
                            }
                            if (data26.chunkId === void 0) {
                              const err67 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "chunkId" }, message: "must have required property 'chunkId'" };
                              if (vErrors === null) {
                                vErrors = [err67];
                              } else {
                                vErrors.push(err67);
                              }
                              errors++;
                            }
                            for (const key5 in data26) {
                              if (!(key5 === "sourceId" || key5 === "sourceRevision" || key5 === "chunkId")) {
                                const err68 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key5 }, message: "must NOT have additional properties" };
                                if (vErrors === null) {
                                  vErrors = [err68];
                                } else {
                                  vErrors.push(err68);
                                }
                                errors++;
                              }
                            }
                            if (data26.sourceId !== void 0) {
                              let data27 = data26.sourceId;
                              if (typeof data27 === "string") {
                                if (func2(data27) < 1) {
                                  const err69 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4 + "/sourceId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err69];
                                  } else {
                                    vErrors.push(err69);
                                  }
                                  errors++;
                                }
                              } else {
                                const err70 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4 + "/sourceId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err70];
                                } else {
                                  vErrors.push(err70);
                                }
                                errors++;
                              }
                            }
                            if (data26.sourceRevision !== void 0) {
                              let data28 = data26.sourceRevision;
                              if (!(typeof data28 == "number" && (!(data28 % 1) && !isNaN(data28)))) {
                                const err71 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                if (vErrors === null) {
                                  vErrors = [err71];
                                } else {
                                  vErrors.push(err71);
                                }
                                errors++;
                              }
                              if (typeof data28 == "number") {
                                if (data28 < 1 || isNaN(data28)) {
                                  const err72 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                                  if (vErrors === null) {
                                    vErrors = [err72];
                                  } else {
                                    vErrors.push(err72);
                                  }
                                  errors++;
                                }
                              }
                            }
                            if (data26.chunkId !== void 0) {
                              let data29 = data26.chunkId;
                              if (typeof data29 === "string") {
                                if (func2(data29) < 1) {
                                  const err73 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4 + "/chunkId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/properties/chunkId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err73];
                                  } else {
                                    vErrors.push(err73);
                                  }
                                  errors++;
                                }
                              } else {
                                const err74 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4 + "/chunkId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/properties/chunkId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err74];
                                } else {
                                  vErrors.push(err74);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err75 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i4, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                            if (vErrors === null) {
                              vErrors = [err75];
                            } else {
                              vErrors.push(err75);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err76 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/properties/sourceRefs/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err76];
                        } else {
                          vErrors.push(err76);
                        }
                        errors++;
                      }
                    }
                  } else {
                    const err77 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/0/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                    if (vErrors === null) {
                      vErrors = [err77];
                    } else {
                      vErrors.push(err77);
                    }
                    errors++;
                  }
                  var _valid0 = _errs40 === errors;
                  if (_valid0) {
                    valid10 = true;
                    passing0 = 0;
                    var props0 = true;
                  }
                  const _errs63 = errors;
                  if (data19 && typeof data19 == "object" && !Array.isArray(data19)) {
                    if (data19.id === void 0) {
                      const err78 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                      if (vErrors === null) {
                        vErrors = [err78];
                      } else {
                        vErrors.push(err78);
                      }
                      errors++;
                    }
                    if (data19.type === void 0) {
                      const err79 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                      if (vErrors === null) {
                        vErrors = [err79];
                      } else {
                        vErrors.push(err79);
                      }
                      errors++;
                    }
                    if (data19.data === void 0) {
                      const err80 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/required", keyword: "required", params: { missingProperty: "data" }, message: "must have required property 'data'" };
                      if (vErrors === null) {
                        vErrors = [err80];
                      } else {
                        vErrors.push(err80);
                      }
                      errors++;
                    }
                    if (data19.visibility === void 0) {
                      const err81 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/required", keyword: "required", params: { missingProperty: "visibility" }, message: "must have required property 'visibility'" };
                      if (vErrors === null) {
                        vErrors = [err81];
                      } else {
                        vErrors.push(err81);
                      }
                      errors++;
                    }
                    if (data19.sourceRefs === void 0) {
                      const err82 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/required", keyword: "required", params: { missingProperty: "sourceRefs" }, message: "must have required property 'sourceRefs'" };
                      if (vErrors === null) {
                        vErrors = [err82];
                      } else {
                        vErrors.push(err82);
                      }
                      errors++;
                    }
                    for (const key6 in data19) {
                      if (!(key6 === "id" || key6 === "type" || key6 === "data" || key6 === "visibility" || key6 === "sourceRefs")) {
                        const err83 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key6 }, message: "must NOT have additional properties" };
                        if (vErrors === null) {
                          vErrors = [err83];
                        } else {
                          vErrors.push(err83);
                        }
                        errors++;
                      }
                    }
                    if (data19.id !== void 0) {
                      let data30 = data19.id;
                      if (typeof data30 === "string") {
                        if (func2(data30) < 1) {
                          const err84 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err84];
                          } else {
                            vErrors.push(err84);
                          }
                          errors++;
                        }
                      } else {
                        const err85 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err85];
                        } else {
                          vErrors.push(err85);
                        }
                        errors++;
                      }
                    }
                    if (data19.type !== void 0) {
                      if ("teacherNote" !== data19.type) {
                        const err86 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/type", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/type/const", keyword: "const", params: { allowedValue: "teacherNote" }, message: "must be equal to constant" };
                        if (vErrors === null) {
                          vErrors = [err86];
                        } else {
                          vErrors.push(err86);
                        }
                        errors++;
                      }
                    }
                    if (data19.data !== void 0) {
                      let data32 = data19.data;
                      if (data32 && typeof data32 == "object" && !Array.isArray(data32)) {
                        if (data32.text === void 0) {
                          const err87 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/data/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
                          if (vErrors === null) {
                            vErrors = [err87];
                          } else {
                            vErrors.push(err87);
                          }
                          errors++;
                        }
                        for (const key7 in data32) {
                          if (!(key7 === "text")) {
                            const err88 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/data/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key7 }, message: "must NOT have additional properties" };
                            if (vErrors === null) {
                              vErrors = [err88];
                            } else {
                              vErrors.push(err88);
                            }
                            errors++;
                          }
                        }
                        if (data32.text !== void 0) {
                          let data33 = data32.text;
                          if (typeof data33 === "string") {
                            if (func2(data33) < 1) {
                              const err89 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/text", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/data/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err89];
                              } else {
                                vErrors.push(err89);
                              }
                              errors++;
                            }
                          } else {
                            const err90 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/text", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/data/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err90];
                            } else {
                              vErrors.push(err90);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err91 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/data/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                        if (vErrors === null) {
                          vErrors = [err91];
                        } else {
                          vErrors.push(err91);
                        }
                        errors++;
                      }
                    }
                    if (data19.visibility !== void 0) {
                      if ("teacher" !== data19.visibility) {
                        const err92 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/visibility", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/visibility/const", keyword: "const", params: { allowedValue: "teacher" }, message: "must be equal to constant" };
                        if (vErrors === null) {
                          vErrors = [err92];
                        } else {
                          vErrors.push(err92);
                        }
                        errors++;
                      }
                    }
                    if (data19.sourceRefs !== void 0) {
                      let data35 = data19.sourceRefs;
                      if (Array.isArray(data35)) {
                        const len4 = data35.length;
                        for (let i5 = 0; i5 < len4; i5++) {
                          let data36 = data35[i5];
                          if (data36 && typeof data36 == "object" && !Array.isArray(data36)) {
                            if (data36.sourceId === void 0) {
                              const err93 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
                              if (vErrors === null) {
                                vErrors = [err93];
                              } else {
                                vErrors.push(err93);
                              }
                              errors++;
                            }
                            if (data36.sourceRevision === void 0) {
                              const err94 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
                              if (vErrors === null) {
                                vErrors = [err94];
                              } else {
                                vErrors.push(err94);
                              }
                              errors++;
                            }
                            if (data36.chunkId === void 0) {
                              const err95 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "chunkId" }, message: "must have required property 'chunkId'" };
                              if (vErrors === null) {
                                vErrors = [err95];
                              } else {
                                vErrors.push(err95);
                              }
                              errors++;
                            }
                            for (const key8 in data36) {
                              if (!(key8 === "sourceId" || key8 === "sourceRevision" || key8 === "chunkId")) {
                                const err96 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key8 }, message: "must NOT have additional properties" };
                                if (vErrors === null) {
                                  vErrors = [err96];
                                } else {
                                  vErrors.push(err96);
                                }
                                errors++;
                              }
                            }
                            if (data36.sourceId !== void 0) {
                              let data37 = data36.sourceId;
                              if (typeof data37 === "string") {
                                if (func2(data37) < 1) {
                                  const err97 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5 + "/sourceId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err97];
                                  } else {
                                    vErrors.push(err97);
                                  }
                                  errors++;
                                }
                              } else {
                                const err98 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5 + "/sourceId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err98];
                                } else {
                                  vErrors.push(err98);
                                }
                                errors++;
                              }
                            }
                            if (data36.sourceRevision !== void 0) {
                              let data38 = data36.sourceRevision;
                              if (!(typeof data38 == "number" && (!(data38 % 1) && !isNaN(data38)))) {
                                const err99 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                if (vErrors === null) {
                                  vErrors = [err99];
                                } else {
                                  vErrors.push(err99);
                                }
                                errors++;
                              }
                              if (typeof data38 == "number") {
                                if (data38 < 1 || isNaN(data38)) {
                                  const err100 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                                  if (vErrors === null) {
                                    vErrors = [err100];
                                  } else {
                                    vErrors.push(err100);
                                  }
                                  errors++;
                                }
                              }
                            }
                            if (data36.chunkId !== void 0) {
                              let data39 = data36.chunkId;
                              if (typeof data39 === "string") {
                                if (func2(data39) < 1) {
                                  const err101 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5 + "/chunkId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/properties/chunkId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err101];
                                  } else {
                                    vErrors.push(err101);
                                  }
                                  errors++;
                                }
                              } else {
                                const err102 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5 + "/chunkId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/properties/chunkId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err102];
                                } else {
                                  vErrors.push(err102);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err103 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i5, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                            if (vErrors === null) {
                              vErrors = [err103];
                            } else {
                              vErrors.push(err103);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err104 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/properties/sourceRefs/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err104];
                        } else {
                          vErrors.push(err104);
                        }
                        errors++;
                      }
                    }
                  } else {
                    const err105 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/1/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                    if (vErrors === null) {
                      vErrors = [err105];
                    } else {
                      vErrors.push(err105);
                    }
                    errors++;
                  }
                  var _valid0 = _errs63 === errors;
                  if (_valid0 && valid10) {
                    valid10 = false;
                    passing0 = [passing0, 1];
                  } else {
                    if (_valid0) {
                      valid10 = true;
                      passing0 = 1;
                      if (props0 !== true) {
                        props0 = true;
                      }
                    }
                    const _errs86 = errors;
                    if (data19 && typeof data19 == "object" && !Array.isArray(data19)) {
                      if (data19.id === void 0) {
                        const err106 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                        if (vErrors === null) {
                          vErrors = [err106];
                        } else {
                          vErrors.push(err106);
                        }
                        errors++;
                      }
                      if (data19.type === void 0) {
                        const err107 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                        if (vErrors === null) {
                          vErrors = [err107];
                        } else {
                          vErrors.push(err107);
                        }
                        errors++;
                      }
                      if (data19.data === void 0) {
                        const err108 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/required", keyword: "required", params: { missingProperty: "data" }, message: "must have required property 'data'" };
                        if (vErrors === null) {
                          vErrors = [err108];
                        } else {
                          vErrors.push(err108);
                        }
                        errors++;
                      }
                      if (data19.visibility === void 0) {
                        const err109 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/required", keyword: "required", params: { missingProperty: "visibility" }, message: "must have required property 'visibility'" };
                        if (vErrors === null) {
                          vErrors = [err109];
                        } else {
                          vErrors.push(err109);
                        }
                        errors++;
                      }
                      if (data19.sourceRefs === void 0) {
                        const err110 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/required", keyword: "required", params: { missingProperty: "sourceRefs" }, message: "must have required property 'sourceRefs'" };
                        if (vErrors === null) {
                          vErrors = [err110];
                        } else {
                          vErrors.push(err110);
                        }
                        errors++;
                      }
                      for (const key9 in data19) {
                        if (!(key9 === "id" || key9 === "type" || key9 === "data" || key9 === "visibility" || key9 === "sourceRefs")) {
                          const err111 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key9 }, message: "must NOT have additional properties" };
                          if (vErrors === null) {
                            vErrors = [err111];
                          } else {
                            vErrors.push(err111);
                          }
                          errors++;
                        }
                      }
                      if (data19.id !== void 0) {
                        let data40 = data19.id;
                        if (typeof data40 === "string") {
                          if (func2(data40) < 1) {
                            const err112 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                            if (vErrors === null) {
                              vErrors = [err112];
                            } else {
                              vErrors.push(err112);
                            }
                            errors++;
                          }
                        } else {
                          const err113 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/id", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                          if (vErrors === null) {
                            vErrors = [err113];
                          } else {
                            vErrors.push(err113);
                          }
                          errors++;
                        }
                      }
                      if (data19.type !== void 0) {
                        if ("questionSet" !== data19.type) {
                          const err114 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/type", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/type/const", keyword: "const", params: { allowedValue: "questionSet" }, message: "must be equal to constant" };
                          if (vErrors === null) {
                            vErrors = [err114];
                          } else {
                            vErrors.push(err114);
                          }
                          errors++;
                        }
                      }
                      if (data19.data !== void 0) {
                        let data42 = data19.data;
                        if (data42 && typeof data42 == "object" && !Array.isArray(data42)) {
                          if (data42.questionIds === void 0) {
                            const err115 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/data/required", keyword: "required", params: { missingProperty: "questionIds" }, message: "must have required property 'questionIds'" };
                            if (vErrors === null) {
                              vErrors = [err115];
                            } else {
                              vErrors.push(err115);
                            }
                            errors++;
                          }
                          for (const key10 in data42) {
                            if (!(key10 === "questionIds")) {
                              const err116 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/data/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key10 }, message: "must NOT have additional properties" };
                              if (vErrors === null) {
                                vErrors = [err116];
                              } else {
                                vErrors.push(err116);
                              }
                              errors++;
                            }
                          }
                          if (data42.questionIds !== void 0) {
                            let data43 = data42.questionIds;
                            if (Array.isArray(data43)) {
                              if (data43.length < 1) {
                                const err117 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/questionIds", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/data/properties/questionIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                                if (vErrors === null) {
                                  vErrors = [err117];
                                } else {
                                  vErrors.push(err117);
                                }
                                errors++;
                              }
                              const len5 = data43.length;
                              for (let i6 = 0; i6 < len5; i6++) {
                                let data44 = data43[i6];
                                if (typeof data44 === "string") {
                                  if (func2(data44) < 1) {
                                    const err118 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/questionIds/" + i6, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/data/properties/questionIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err118];
                                    } else {
                                      vErrors.push(err118);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err119 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/questionIds/" + i6, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/data/properties/questionIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err119];
                                  } else {
                                    vErrors.push(err119);
                                  }
                                  errors++;
                                }
                              }
                              let i7 = data43.length;
                              let j1;
                              if (i7 > 1) {
                                const indices1 = {};
                                for (; i7--; ) {
                                  let item1 = data43[i7];
                                  if (typeof item1 !== "string") {
                                    continue;
                                  }
                                  if (typeof indices1[item1] == "number") {
                                    j1 = indices1[item1];
                                    const err120 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/questionIds", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/data/properties/questionIds/uniqueItems", keyword: "uniqueItems", params: { i: i7, j: j1 }, message: "must NOT have duplicate items (items ## " + j1 + " and " + i7 + " are identical)" };
                                    if (vErrors === null) {
                                      vErrors = [err120];
                                    } else {
                                      vErrors.push(err120);
                                    }
                                    errors++;
                                    break;
                                  }
                                  indices1[item1] = i7;
                                }
                              }
                            } else {
                              const err121 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data/questionIds", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/data/properties/questionIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                              if (vErrors === null) {
                                vErrors = [err121];
                              } else {
                                vErrors.push(err121);
                              }
                              errors++;
                            }
                          }
                        } else {
                          const err122 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/data", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/data/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                          if (vErrors === null) {
                            vErrors = [err122];
                          } else {
                            vErrors.push(err122);
                          }
                          errors++;
                        }
                      }
                      if (data19.visibility !== void 0) {
                        let data45 = data19.visibility;
                        if (!(data45 === "student" || data45 === "both")) {
                          const err123 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/visibility", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/visibility/enum", keyword: "enum", params: { allowedValues: schema34.properties.resources.items.properties.blocks.items.oneOf[2].properties.visibility.enum }, message: "must be equal to one of the allowed values" };
                          if (vErrors === null) {
                            vErrors = [err123];
                          } else {
                            vErrors.push(err123);
                          }
                          errors++;
                        }
                      }
                      if (data19.sourceRefs !== void 0) {
                        let data46 = data19.sourceRefs;
                        if (Array.isArray(data46)) {
                          const len6 = data46.length;
                          for (let i8 = 0; i8 < len6; i8++) {
                            let data47 = data46[i8];
                            if (data47 && typeof data47 == "object" && !Array.isArray(data47)) {
                              if (data47.sourceId === void 0) {
                                const err124 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
                                if (vErrors === null) {
                                  vErrors = [err124];
                                } else {
                                  vErrors.push(err124);
                                }
                                errors++;
                              }
                              if (data47.sourceRevision === void 0) {
                                const err125 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
                                if (vErrors === null) {
                                  vErrors = [err125];
                                } else {
                                  vErrors.push(err125);
                                }
                                errors++;
                              }
                              if (data47.chunkId === void 0) {
                                const err126 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "chunkId" }, message: "must have required property 'chunkId'" };
                                if (vErrors === null) {
                                  vErrors = [err126];
                                } else {
                                  vErrors.push(err126);
                                }
                                errors++;
                              }
                              for (const key11 in data47) {
                                if (!(key11 === "sourceId" || key11 === "sourceRevision" || key11 === "chunkId")) {
                                  const err127 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key11 }, message: "must NOT have additional properties" };
                                  if (vErrors === null) {
                                    vErrors = [err127];
                                  } else {
                                    vErrors.push(err127);
                                  }
                                  errors++;
                                }
                              }
                              if (data47.sourceId !== void 0) {
                                let data48 = data47.sourceId;
                                if (typeof data48 === "string") {
                                  if (func2(data48) < 1) {
                                    const err128 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8 + "/sourceId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err128];
                                    } else {
                                      vErrors.push(err128);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err129 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8 + "/sourceId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err129];
                                  } else {
                                    vErrors.push(err129);
                                  }
                                  errors++;
                                }
                              }
                              if (data47.sourceRevision !== void 0) {
                                let data49 = data47.sourceRevision;
                                if (!(typeof data49 == "number" && (!(data49 % 1) && !isNaN(data49)))) {
                                  const err130 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                  if (vErrors === null) {
                                    vErrors = [err130];
                                  } else {
                                    vErrors.push(err130);
                                  }
                                  errors++;
                                }
                                if (typeof data49 == "number") {
                                  if (data49 < 1 || isNaN(data49)) {
                                    const err131 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                                    if (vErrors === null) {
                                      vErrors = [err131];
                                    } else {
                                      vErrors.push(err131);
                                    }
                                    errors++;
                                  }
                                }
                              }
                              if (data47.chunkId !== void 0) {
                                let data50 = data47.chunkId;
                                if (typeof data50 === "string") {
                                  if (func2(data50) < 1) {
                                    const err132 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8 + "/chunkId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/properties/chunkId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err132];
                                    } else {
                                      vErrors.push(err132);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err133 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8 + "/chunkId", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/properties/chunkId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err133];
                                  } else {
                                    vErrors.push(err133);
                                  }
                                  errors++;
                                }
                              }
                            } else {
                              const err134 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs/" + i8, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                              if (vErrors === null) {
                                vErrors = [err134];
                              } else {
                                vErrors.push(err134);
                              }
                              errors++;
                            }
                          }
                        } else {
                          const err135 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3 + "/sourceRefs", schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/properties/sourceRefs/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                          if (vErrors === null) {
                            vErrors = [err135];
                          } else {
                            vErrors.push(err135);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err136 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf/2/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err136];
                      } else {
                        vErrors.push(err136);
                      }
                      errors++;
                    }
                    var _valid0 = _errs86 === errors;
                    if (_valid0 && valid10) {
                      valid10 = false;
                      passing0 = [passing0, 2];
                    } else {
                      if (_valid0) {
                        valid10 = true;
                        passing0 = 2;
                        if (props0 !== true) {
                          props0 = true;
                        }
                      }
                    }
                  }
                  if (!valid10) {
                    const err137 = { instancePath: instancePath + "/resources/" + i0 + "/blocks/" + i3, schemaPath: "#/properties/resources/items/properties/blocks/items/oneOf", keyword: "oneOf", params: { passingSchemas: passing0 }, message: "must match exactly one schema in oneOf" };
                    if (vErrors === null) {
                      vErrors = [err137];
                    } else {
                      vErrors.push(err137);
                    }
                    errors++;
                  } else {
                    errors = _errs39;
                    if (vErrors !== null) {
                      if (_errs39) {
                        vErrors.length = _errs39;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                }
              } else {
                const err138 = { instancePath: instancePath + "/resources/" + i0 + "/blocks", schemaPath: "#/properties/resources/items/properties/blocks/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                if (vErrors === null) {
                  vErrors = [err138];
                } else {
                  vErrors.push(err138);
                }
                errors++;
              }
            }
            if (data10.questions !== void 0) {
              let data51 = data10.questions;
              if (Array.isArray(data51)) {
                const len7 = data51.length;
                for (let i9 = 0; i9 < len7; i9++) {
                  let data52 = data51[i9];
                  const _errs114 = errors;
                  let valid31 = false;
                  let passing1 = null;
                  const _errs115 = errors;
                  if (data52 && typeof data52 == "object" && !Array.isArray(data52)) {
                    if (data52.id === void 0) {
                      const err139 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                      if (vErrors === null) {
                        vErrors = [err139];
                      } else {
                        vErrors.push(err139);
                      }
                      errors++;
                    }
                    if (data52.prompt === void 0) {
                      const err140 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
                      if (vErrors === null) {
                        vErrors = [err140];
                      } else {
                        vErrors.push(err140);
                      }
                      errors++;
                    }
                    if (data52.maxScore === void 0) {
                      const err141 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
                      if (vErrors === null) {
                        vErrors = [err141];
                      } else {
                        vErrors.push(err141);
                      }
                      errors++;
                    }
                    if (data52.objectiveIds === void 0) {
                      const err142 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
                      if (vErrors === null) {
                        vErrors = [err142];
                      } else {
                        vErrors.push(err142);
                      }
                      errors++;
                    }
                    if (data52.sourceRefs === void 0) {
                      const err143 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "sourceRefs" }, message: "must have required property 'sourceRefs'" };
                      if (vErrors === null) {
                        vErrors = [err143];
                      } else {
                        vErrors.push(err143);
                      }
                      errors++;
                    }
                    if (data52.hints === void 0) {
                      const err144 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
                      if (vErrors === null) {
                        vErrors = [err144];
                      } else {
                        vErrors.push(err144);
                      }
                      errors++;
                    }
                    if (data52.type === void 0) {
                      const err145 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                      if (vErrors === null) {
                        vErrors = [err145];
                      } else {
                        vErrors.push(err145);
                      }
                      errors++;
                    }
                    if (data52.options === void 0) {
                      const err146 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "options" }, message: "must have required property 'options'" };
                      if (vErrors === null) {
                        vErrors = [err146];
                      } else {
                        vErrors.push(err146);
                      }
                      errors++;
                    }
                    if (data52.answerKey === void 0) {
                      const err147 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "answerKey" }, message: "must have required property 'answerKey'" };
                      if (vErrors === null) {
                        vErrors = [err147];
                      } else {
                        vErrors.push(err147);
                      }
                      errors++;
                    }
                    if (data52.scoring === void 0) {
                      const err148 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "scoring" }, message: "must have required property 'scoring'" };
                      if (vErrors === null) {
                        vErrors = [err148];
                      } else {
                        vErrors.push(err148);
                      }
                      errors++;
                    }
                    for (const key12 in data52) {
                      if (!func1.call(schema34.properties.resources.items.properties.questions.items.oneOf[0].properties, key12)) {
                        const err149 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key12 }, message: "must NOT have additional properties" };
                        if (vErrors === null) {
                          vErrors = [err149];
                        } else {
                          vErrors.push(err149);
                        }
                        errors++;
                      }
                    }
                    if (data52.id !== void 0) {
                      let data53 = data52.id;
                      if (typeof data53 === "string") {
                        if (func2(data53) < 1) {
                          const err150 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err150];
                          } else {
                            vErrors.push(err150);
                          }
                          errors++;
                        }
                      } else {
                        const err151 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err151];
                        } else {
                          vErrors.push(err151);
                        }
                        errors++;
                      }
                    }
                    if (data52.prompt !== void 0) {
                      let data54 = data52.prompt;
                      if (typeof data54 === "string") {
                        if (func2(data54) < 1) {
                          const err152 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err152];
                          } else {
                            vErrors.push(err152);
                          }
                          errors++;
                        }
                      } else {
                        const err153 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err153];
                        } else {
                          vErrors.push(err153);
                        }
                        errors++;
                      }
                    }
                    if (data52.maxScore !== void 0) {
                      let data55 = data52.maxScore;
                      if (typeof data55 == "number") {
                        if (data55 <= 0 || isNaN(data55)) {
                          const err154 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                          if (vErrors === null) {
                            vErrors = [err154];
                          } else {
                            vErrors.push(err154);
                          }
                          errors++;
                        }
                      } else {
                        const err155 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                        if (vErrors === null) {
                          vErrors = [err155];
                        } else {
                          vErrors.push(err155);
                        }
                        errors++;
                      }
                    }
                    if (data52.objectiveIds !== void 0) {
                      let data56 = data52.objectiveIds;
                      if (Array.isArray(data56)) {
                        if (data56.length < 1) {
                          const err156 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                          if (vErrors === null) {
                            vErrors = [err156];
                          } else {
                            vErrors.push(err156);
                          }
                          errors++;
                        }
                        const len8 = data56.length;
                        for (let i10 = 0; i10 < len8; i10++) {
                          let data57 = data56[i10];
                          if (typeof data57 === "string") {
                            if (func2(data57) < 1) {
                              const err157 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/objectiveIds/" + i10, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err157];
                              } else {
                                vErrors.push(err157);
                              }
                              errors++;
                            }
                          } else {
                            const err158 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/objectiveIds/" + i10, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err158];
                            } else {
                              vErrors.push(err158);
                            }
                            errors++;
                          }
                        }
                        let i11 = data56.length;
                        let j2;
                        if (i11 > 1) {
                          const indices2 = {};
                          for (; i11--; ) {
                            let item2 = data56[i11];
                            if (typeof item2 !== "string") {
                              continue;
                            }
                            if (typeof indices2[item2] == "number") {
                              j2 = indices2[item2];
                              const err159 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i11, j: j2 }, message: "must NOT have duplicate items (items ## " + j2 + " and " + i11 + " are identical)" };
                              if (vErrors === null) {
                                vErrors = [err159];
                              } else {
                                vErrors.push(err159);
                              }
                              errors++;
                              break;
                            }
                            indices2[item2] = i11;
                          }
                        }
                      } else {
                        const err160 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err160];
                        } else {
                          vErrors.push(err160);
                        }
                        errors++;
                      }
                    }
                    if (data52.sourceRefs !== void 0) {
                      let data58 = data52.sourceRefs;
                      if (Array.isArray(data58)) {
                        const len9 = data58.length;
                        for (let i12 = 0; i12 < len9; i12++) {
                          let data59 = data58[i12];
                          if (data59 && typeof data59 == "object" && !Array.isArray(data59)) {
                            if (data59.sourceId === void 0) {
                              const err161 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i12, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
                              if (vErrors === null) {
                                vErrors = [err161];
                              } else {
                                vErrors.push(err161);
                              }
                              errors++;
                            }
                            if (data59.sourceRevision === void 0) {
                              const err162 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i12, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
                              if (vErrors === null) {
                                vErrors = [err162];
                              } else {
                                vErrors.push(err162);
                              }
                              errors++;
                            }
                            if (data59.chunkId === void 0) {
                              const err163 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i12, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "chunkId" }, message: "must have required property 'chunkId'" };
                              if (vErrors === null) {
                                vErrors = [err163];
                              } else {
                                vErrors.push(err163);
                              }
                              errors++;
                            }
                            for (const key13 in data59) {
                              if (!(key13 === "sourceId" || key13 === "sourceRevision" || key13 === "chunkId")) {
                                const err164 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i12, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key13 }, message: "must NOT have additional properties" };
                                if (vErrors === null) {
                                  vErrors = [err164];
                                } else {
                                  vErrors.push(err164);
                                }
                                errors++;
                              }
                            }
                            if (data59.sourceId !== void 0) {
                              let data60 = data59.sourceId;
                              if (typeof data60 === "string") {
                                if (func2(data60) < 1) {
                                  const err165 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i12 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err165];
                                  } else {
                                    vErrors.push(err165);
                                  }
                                  errors++;
                                }
                              } else {
                                const err166 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i12 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err166];
                                } else {
                                  vErrors.push(err166);
                                }
                                errors++;
                              }
                            }
                            if (data59.sourceRevision !== void 0) {
                              let data61 = data59.sourceRevision;
                              if (!(typeof data61 == "number" && (!(data61 % 1) && !isNaN(data61)))) {
                                const err167 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i12 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                if (vErrors === null) {
                                  vErrors = [err167];
                                } else {
                                  vErrors.push(err167);
                                }
                                errors++;
                              }
                              if (typeof data61 == "number") {
                                if (data61 < 1 || isNaN(data61)) {
                                  const err168 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i12 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                                  if (vErrors === null) {
                                    vErrors = [err168];
                                  } else {
                                    vErrors.push(err168);
                                  }
                                  errors++;
                                }
                              }
                            }
                            if (data59.chunkId !== void 0) {
                              let data62 = data59.chunkId;
                              if (typeof data62 === "string") {
                                if (func2(data62) < 1) {
                                  const err169 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i12 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/properties/chunkId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err169];
                                  } else {
                                    vErrors.push(err169);
                                  }
                                  errors++;
                                }
                              } else {
                                const err170 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i12 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/properties/chunkId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err170];
                                } else {
                                  vErrors.push(err170);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err171 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i12, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                            if (vErrors === null) {
                              vErrors = [err171];
                            } else {
                              vErrors.push(err171);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err172 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/sourceRefs/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err172];
                        } else {
                          vErrors.push(err172);
                        }
                        errors++;
                      }
                    }
                    if (data52.hints !== void 0) {
                      let data63 = data52.hints;
                      if (Array.isArray(data63)) {
                        const len10 = data63.length;
                        for (let i13 = 0; i13 < len10; i13++) {
                          let data64 = data63[i13];
                          if (typeof data64 === "string") {
                            if (func2(data64) < 1) {
                              const err173 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/hints/" + i13, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err173];
                              } else {
                                vErrors.push(err173);
                              }
                              errors++;
                            }
                          } else {
                            const err174 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/hints/" + i13, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err174];
                            } else {
                              vErrors.push(err174);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err175 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/hints", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err175];
                        } else {
                          vErrors.push(err175);
                        }
                        errors++;
                      }
                    }
                    if (data52.type !== void 0) {
                      if ("singleChoice" !== data52.type) {
                        const err176 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/type", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/type/const", keyword: "const", params: { allowedValue: "singleChoice" }, message: "must be equal to constant" };
                        if (vErrors === null) {
                          vErrors = [err176];
                        } else {
                          vErrors.push(err176);
                        }
                        errors++;
                      }
                    }
                    if (data52.options !== void 0) {
                      let data66 = data52.options;
                      if (Array.isArray(data66)) {
                        if (data66.length < 2) {
                          const err177 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/options", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/minItems", keyword: "minItems", params: { limit: 2 }, message: "must NOT have fewer than 2 items" };
                          if (vErrors === null) {
                            vErrors = [err177];
                          } else {
                            vErrors.push(err177);
                          }
                          errors++;
                        }
                        const len11 = data66.length;
                        for (let i14 = 0; i14 < len11; i14++) {
                          let data67 = data66[i14];
                          if (data67 && typeof data67 == "object" && !Array.isArray(data67)) {
                            if (data67.id === void 0) {
                              const err178 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/options/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                              if (vErrors === null) {
                                vErrors = [err178];
                              } else {
                                vErrors.push(err178);
                              }
                              errors++;
                            }
                            if (data67.text === void 0) {
                              const err179 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/options/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/items/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
                              if (vErrors === null) {
                                vErrors = [err179];
                              } else {
                                vErrors.push(err179);
                              }
                              errors++;
                            }
                            for (const key14 in data67) {
                              if (!(key14 === "id" || key14 === "text")) {
                                const err180 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/options/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key14 }, message: "must NOT have additional properties" };
                                if (vErrors === null) {
                                  vErrors = [err180];
                                } else {
                                  vErrors.push(err180);
                                }
                                errors++;
                              }
                            }
                            if (data67.id !== void 0) {
                              let data68 = data67.id;
                              if (typeof data68 === "string") {
                                if (func2(data68) < 1) {
                                  const err181 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/options/" + i14 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err181];
                                  } else {
                                    vErrors.push(err181);
                                  }
                                  errors++;
                                }
                              } else {
                                const err182 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/options/" + i14 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err182];
                                } else {
                                  vErrors.push(err182);
                                }
                                errors++;
                              }
                            }
                            if (data67.text !== void 0) {
                              let data69 = data67.text;
                              if (typeof data69 === "string") {
                                if (func2(data69) < 1) {
                                  const err183 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/options/" + i14 + "/text", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/items/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err183];
                                  } else {
                                    vErrors.push(err183);
                                  }
                                  errors++;
                                }
                              } else {
                                const err184 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/options/" + i14 + "/text", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/items/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err184];
                                } else {
                                  vErrors.push(err184);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err185 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/options/" + i14, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                            if (vErrors === null) {
                              vErrors = [err185];
                            } else {
                              vErrors.push(err185);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err186 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/options", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/options/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err186];
                        } else {
                          vErrors.push(err186);
                        }
                        errors++;
                      }
                    }
                    if (data52.answerKey !== void 0) {
                      let data70 = data52.answerKey;
                      if (typeof data70 === "string") {
                        if (func2(data70) < 1) {
                          const err187 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/answerKey", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/answerKey/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err187];
                          } else {
                            vErrors.push(err187);
                          }
                          errors++;
                        }
                      } else {
                        const err188 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/answerKey", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/answerKey/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err188];
                        } else {
                          vErrors.push(err188);
                        }
                        errors++;
                      }
                    }
                    if (data52.scoring !== void 0) {
                      if ("exactMatch" !== data52.scoring) {
                        const err189 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/scoring", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/properties/scoring/const", keyword: "const", params: { allowedValue: "exactMatch" }, message: "must be equal to constant" };
                        if (vErrors === null) {
                          vErrors = [err189];
                        } else {
                          vErrors.push(err189);
                        }
                        errors++;
                      }
                    }
                  } else {
                    const err190 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/0/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                    if (vErrors === null) {
                      vErrors = [err190];
                    } else {
                      vErrors.push(err190);
                    }
                    errors++;
                  }
                  var _valid1 = _errs115 === errors;
                  if (_valid1) {
                    valid31 = true;
                    passing1 = 0;
                    var props1 = true;
                  }
                  const _errs156 = errors;
                  if (data52 && typeof data52 == "object" && !Array.isArray(data52)) {
                    if (data52.id === void 0) {
                      const err191 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                      if (vErrors === null) {
                        vErrors = [err191];
                      } else {
                        vErrors.push(err191);
                      }
                      errors++;
                    }
                    if (data52.prompt === void 0) {
                      const err192 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
                      if (vErrors === null) {
                        vErrors = [err192];
                      } else {
                        vErrors.push(err192);
                      }
                      errors++;
                    }
                    if (data52.maxScore === void 0) {
                      const err193 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
                      if (vErrors === null) {
                        vErrors = [err193];
                      } else {
                        vErrors.push(err193);
                      }
                      errors++;
                    }
                    if (data52.objectiveIds === void 0) {
                      const err194 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
                      if (vErrors === null) {
                        vErrors = [err194];
                      } else {
                        vErrors.push(err194);
                      }
                      errors++;
                    }
                    if (data52.sourceRefs === void 0) {
                      const err195 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "sourceRefs" }, message: "must have required property 'sourceRefs'" };
                      if (vErrors === null) {
                        vErrors = [err195];
                      } else {
                        vErrors.push(err195);
                      }
                      errors++;
                    }
                    if (data52.hints === void 0) {
                      const err196 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
                      if (vErrors === null) {
                        vErrors = [err196];
                      } else {
                        vErrors.push(err196);
                      }
                      errors++;
                    }
                    if (data52.type === void 0) {
                      const err197 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                      if (vErrors === null) {
                        vErrors = [err197];
                      } else {
                        vErrors.push(err197);
                      }
                      errors++;
                    }
                    if (data52.answerKey === void 0) {
                      const err198 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "answerKey" }, message: "must have required property 'answerKey'" };
                      if (vErrors === null) {
                        vErrors = [err198];
                      } else {
                        vErrors.push(err198);
                      }
                      errors++;
                    }
                    if (data52.scoring === void 0) {
                      const err199 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "scoring" }, message: "must have required property 'scoring'" };
                      if (vErrors === null) {
                        vErrors = [err199];
                      } else {
                        vErrors.push(err199);
                      }
                      errors++;
                    }
                    for (const key15 in data52) {
                      if (!func1.call(schema34.properties.resources.items.properties.questions.items.oneOf[1].properties, key15)) {
                        const err200 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key15 }, message: "must NOT have additional properties" };
                        if (vErrors === null) {
                          vErrors = [err200];
                        } else {
                          vErrors.push(err200);
                        }
                        errors++;
                      }
                    }
                    if (data52.id !== void 0) {
                      let data72 = data52.id;
                      if (typeof data72 === "string") {
                        if (func2(data72) < 1) {
                          const err201 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err201];
                          } else {
                            vErrors.push(err201);
                          }
                          errors++;
                        }
                      } else {
                        const err202 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err202];
                        } else {
                          vErrors.push(err202);
                        }
                        errors++;
                      }
                    }
                    if (data52.prompt !== void 0) {
                      let data73 = data52.prompt;
                      if (typeof data73 === "string") {
                        if (func2(data73) < 1) {
                          const err203 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err203];
                          } else {
                            vErrors.push(err203);
                          }
                          errors++;
                        }
                      } else {
                        const err204 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err204];
                        } else {
                          vErrors.push(err204);
                        }
                        errors++;
                      }
                    }
                    if (data52.maxScore !== void 0) {
                      let data74 = data52.maxScore;
                      if (typeof data74 == "number") {
                        if (data74 <= 0 || isNaN(data74)) {
                          const err205 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                          if (vErrors === null) {
                            vErrors = [err205];
                          } else {
                            vErrors.push(err205);
                          }
                          errors++;
                        }
                      } else {
                        const err206 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                        if (vErrors === null) {
                          vErrors = [err206];
                        } else {
                          vErrors.push(err206);
                        }
                        errors++;
                      }
                    }
                    if (data52.objectiveIds !== void 0) {
                      let data75 = data52.objectiveIds;
                      if (Array.isArray(data75)) {
                        if (data75.length < 1) {
                          const err207 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                          if (vErrors === null) {
                            vErrors = [err207];
                          } else {
                            vErrors.push(err207);
                          }
                          errors++;
                        }
                        const len12 = data75.length;
                        for (let i15 = 0; i15 < len12; i15++) {
                          let data76 = data75[i15];
                          if (typeof data76 === "string") {
                            if (func2(data76) < 1) {
                              const err208 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/objectiveIds/" + i15, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err208];
                              } else {
                                vErrors.push(err208);
                              }
                              errors++;
                            }
                          } else {
                            const err209 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/objectiveIds/" + i15, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err209];
                            } else {
                              vErrors.push(err209);
                            }
                            errors++;
                          }
                        }
                        let i16 = data75.length;
                        let j3;
                        if (i16 > 1) {
                          const indices3 = {};
                          for (; i16--; ) {
                            let item3 = data75[i16];
                            if (typeof item3 !== "string") {
                              continue;
                            }
                            if (typeof indices3[item3] == "number") {
                              j3 = indices3[item3];
                              const err210 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i16, j: j3 }, message: "must NOT have duplicate items (items ## " + j3 + " and " + i16 + " are identical)" };
                              if (vErrors === null) {
                                vErrors = [err210];
                              } else {
                                vErrors.push(err210);
                              }
                              errors++;
                              break;
                            }
                            indices3[item3] = i16;
                          }
                        }
                      } else {
                        const err211 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err211];
                        } else {
                          vErrors.push(err211);
                        }
                        errors++;
                      }
                    }
                    if (data52.sourceRefs !== void 0) {
                      let data77 = data52.sourceRefs;
                      if (Array.isArray(data77)) {
                        const len13 = data77.length;
                        for (let i17 = 0; i17 < len13; i17++) {
                          let data78 = data77[i17];
                          if (data78 && typeof data78 == "object" && !Array.isArray(data78)) {
                            if (data78.sourceId === void 0) {
                              const err212 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i17, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
                              if (vErrors === null) {
                                vErrors = [err212];
                              } else {
                                vErrors.push(err212);
                              }
                              errors++;
                            }
                            if (data78.sourceRevision === void 0) {
                              const err213 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i17, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
                              if (vErrors === null) {
                                vErrors = [err213];
                              } else {
                                vErrors.push(err213);
                              }
                              errors++;
                            }
                            if (data78.chunkId === void 0) {
                              const err214 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i17, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "chunkId" }, message: "must have required property 'chunkId'" };
                              if (vErrors === null) {
                                vErrors = [err214];
                              } else {
                                vErrors.push(err214);
                              }
                              errors++;
                            }
                            for (const key16 in data78) {
                              if (!(key16 === "sourceId" || key16 === "sourceRevision" || key16 === "chunkId")) {
                                const err215 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i17, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key16 }, message: "must NOT have additional properties" };
                                if (vErrors === null) {
                                  vErrors = [err215];
                                } else {
                                  vErrors.push(err215);
                                }
                                errors++;
                              }
                            }
                            if (data78.sourceId !== void 0) {
                              let data79 = data78.sourceId;
                              if (typeof data79 === "string") {
                                if (func2(data79) < 1) {
                                  const err216 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i17 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err216];
                                  } else {
                                    vErrors.push(err216);
                                  }
                                  errors++;
                                }
                              } else {
                                const err217 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i17 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err217];
                                } else {
                                  vErrors.push(err217);
                                }
                                errors++;
                              }
                            }
                            if (data78.sourceRevision !== void 0) {
                              let data80 = data78.sourceRevision;
                              if (!(typeof data80 == "number" && (!(data80 % 1) && !isNaN(data80)))) {
                                const err218 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i17 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                if (vErrors === null) {
                                  vErrors = [err218];
                                } else {
                                  vErrors.push(err218);
                                }
                                errors++;
                              }
                              if (typeof data80 == "number") {
                                if (data80 < 1 || isNaN(data80)) {
                                  const err219 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i17 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                                  if (vErrors === null) {
                                    vErrors = [err219];
                                  } else {
                                    vErrors.push(err219);
                                  }
                                  errors++;
                                }
                              }
                            }
                            if (data78.chunkId !== void 0) {
                              let data81 = data78.chunkId;
                              if (typeof data81 === "string") {
                                if (func2(data81) < 1) {
                                  const err220 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i17 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/properties/chunkId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                  if (vErrors === null) {
                                    vErrors = [err220];
                                  } else {
                                    vErrors.push(err220);
                                  }
                                  errors++;
                                }
                              } else {
                                const err221 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i17 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/properties/chunkId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                if (vErrors === null) {
                                  vErrors = [err221];
                                } else {
                                  vErrors.push(err221);
                                }
                                errors++;
                              }
                            }
                          } else {
                            const err222 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i17, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                            if (vErrors === null) {
                              vErrors = [err222];
                            } else {
                              vErrors.push(err222);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err223 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/sourceRefs/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err223];
                        } else {
                          vErrors.push(err223);
                        }
                        errors++;
                      }
                    }
                    if (data52.hints !== void 0) {
                      let data82 = data52.hints;
                      if (Array.isArray(data82)) {
                        const len14 = data82.length;
                        for (let i18 = 0; i18 < len14; i18++) {
                          let data83 = data82[i18];
                          if (typeof data83 === "string") {
                            if (func2(data83) < 1) {
                              const err224 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/hints/" + i18, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                              if (vErrors === null) {
                                vErrors = [err224];
                              } else {
                                vErrors.push(err224);
                              }
                              errors++;
                            }
                          } else {
                            const err225 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/hints/" + i18, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                            if (vErrors === null) {
                              vErrors = [err225];
                            } else {
                              vErrors.push(err225);
                            }
                            errors++;
                          }
                        }
                      } else {
                        const err226 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/hints", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                        if (vErrors === null) {
                          vErrors = [err226];
                        } else {
                          vErrors.push(err226);
                        }
                        errors++;
                      }
                    }
                    if (data52.type !== void 0) {
                      if ("trueFalse" !== data52.type) {
                        const err227 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/type", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/type/const", keyword: "const", params: { allowedValue: "trueFalse" }, message: "must be equal to constant" };
                        if (vErrors === null) {
                          vErrors = [err227];
                        } else {
                          vErrors.push(err227);
                        }
                        errors++;
                      }
                    }
                    if (data52.answerKey !== void 0) {
                      if (typeof data52.answerKey !== "boolean") {
                        const err228 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/answerKey", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/answerKey/type", keyword: "type", params: { type: "boolean" }, message: "must be boolean" };
                        if (vErrors === null) {
                          vErrors = [err228];
                        } else {
                          vErrors.push(err228);
                        }
                        errors++;
                      }
                    }
                    if (data52.scoring !== void 0) {
                      if ("exactMatch" !== data52.scoring) {
                        const err229 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/scoring", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/properties/scoring/const", keyword: "const", params: { allowedValue: "exactMatch" }, message: "must be equal to constant" };
                        if (vErrors === null) {
                          vErrors = [err229];
                        } else {
                          vErrors.push(err229);
                        }
                        errors++;
                      }
                    }
                  } else {
                    const err230 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/1/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                    if (vErrors === null) {
                      vErrors = [err230];
                    } else {
                      vErrors.push(err230);
                    }
                    errors++;
                  }
                  var _valid1 = _errs156 === errors;
                  if (_valid1 && valid31) {
                    valid31 = false;
                    passing1 = [passing1, 1];
                  } else {
                    if (_valid1) {
                      valid31 = true;
                      passing1 = 1;
                      if (props1 !== true) {
                        props1 = true;
                      }
                    }
                    const _errs188 = errors;
                    if (data52 && typeof data52 == "object" && !Array.isArray(data52)) {
                      if (data52.id === void 0) {
                        const err231 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                        if (vErrors === null) {
                          vErrors = [err231];
                        } else {
                          vErrors.push(err231);
                        }
                        errors++;
                      }
                      if (data52.prompt === void 0) {
                        const err232 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
                        if (vErrors === null) {
                          vErrors = [err232];
                        } else {
                          vErrors.push(err232);
                        }
                        errors++;
                      }
                      if (data52.maxScore === void 0) {
                        const err233 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
                        if (vErrors === null) {
                          vErrors = [err233];
                        } else {
                          vErrors.push(err233);
                        }
                        errors++;
                      }
                      if (data52.objectiveIds === void 0) {
                        const err234 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
                        if (vErrors === null) {
                          vErrors = [err234];
                        } else {
                          vErrors.push(err234);
                        }
                        errors++;
                      }
                      if (data52.sourceRefs === void 0) {
                        const err235 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "sourceRefs" }, message: "must have required property 'sourceRefs'" };
                        if (vErrors === null) {
                          vErrors = [err235];
                        } else {
                          vErrors.push(err235);
                        }
                        errors++;
                      }
                      if (data52.hints === void 0) {
                        const err236 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
                        if (vErrors === null) {
                          vErrors = [err236];
                        } else {
                          vErrors.push(err236);
                        }
                        errors++;
                      }
                      if (data52.type === void 0) {
                        const err237 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                        if (vErrors === null) {
                          vErrors = [err237];
                        } else {
                          vErrors.push(err237);
                        }
                        errors++;
                      }
                      if (data52.rubric === void 0) {
                        const err238 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "rubric" }, message: "must have required property 'rubric'" };
                        if (vErrors === null) {
                          vErrors = [err238];
                        } else {
                          vErrors.push(err238);
                        }
                        errors++;
                      }
                      if (data52.scoring === void 0) {
                        const err239 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "scoring" }, message: "must have required property 'scoring'" };
                        if (vErrors === null) {
                          vErrors = [err239];
                        } else {
                          vErrors.push(err239);
                        }
                        errors++;
                      }
                      for (const key17 in data52) {
                        if (!func1.call(schema34.properties.resources.items.properties.questions.items.oneOf[2].properties, key17)) {
                          const err240 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key17 }, message: "must NOT have additional properties" };
                          if (vErrors === null) {
                            vErrors = [err240];
                          } else {
                            vErrors.push(err240);
                          }
                          errors++;
                        }
                      }
                      if (data52.id !== void 0) {
                        let data87 = data52.id;
                        if (typeof data87 === "string") {
                          if (func2(data87) < 1) {
                            const err241 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                            if (vErrors === null) {
                              vErrors = [err241];
                            } else {
                              vErrors.push(err241);
                            }
                            errors++;
                          }
                        } else {
                          const err242 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/id", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                          if (vErrors === null) {
                            vErrors = [err242];
                          } else {
                            vErrors.push(err242);
                          }
                          errors++;
                        }
                      }
                      if (data52.prompt !== void 0) {
                        let data88 = data52.prompt;
                        if (typeof data88 === "string") {
                          if (func2(data88) < 1) {
                            const err243 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                            if (vErrors === null) {
                              vErrors = [err243];
                            } else {
                              vErrors.push(err243);
                            }
                            errors++;
                          }
                        } else {
                          const err244 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/prompt", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                          if (vErrors === null) {
                            vErrors = [err244];
                          } else {
                            vErrors.push(err244);
                          }
                          errors++;
                        }
                      }
                      if (data52.maxScore !== void 0) {
                        let data89 = data52.maxScore;
                        if (typeof data89 == "number") {
                          if (data89 <= 0 || isNaN(data89)) {
                            const err245 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                            if (vErrors === null) {
                              vErrors = [err245];
                            } else {
                              vErrors.push(err245);
                            }
                            errors++;
                          }
                        } else {
                          const err246 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/maxScore", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                          if (vErrors === null) {
                            vErrors = [err246];
                          } else {
                            vErrors.push(err246);
                          }
                          errors++;
                        }
                      }
                      if (data52.objectiveIds !== void 0) {
                        let data90 = data52.objectiveIds;
                        if (Array.isArray(data90)) {
                          if (data90.length < 1) {
                            const err247 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                            if (vErrors === null) {
                              vErrors = [err247];
                            } else {
                              vErrors.push(err247);
                            }
                            errors++;
                          }
                          const len15 = data90.length;
                          for (let i19 = 0; i19 < len15; i19++) {
                            let data91 = data90[i19];
                            if (typeof data91 === "string") {
                              if (func2(data91) < 1) {
                                const err248 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/objectiveIds/" + i19, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                if (vErrors === null) {
                                  vErrors = [err248];
                                } else {
                                  vErrors.push(err248);
                                }
                                errors++;
                              }
                            } else {
                              const err249 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/objectiveIds/" + i19, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err249];
                              } else {
                                vErrors.push(err249);
                              }
                              errors++;
                            }
                          }
                          let i20 = data90.length;
                          let j4;
                          if (i20 > 1) {
                            const indices4 = {};
                            for (; i20--; ) {
                              let item4 = data90[i20];
                              if (typeof item4 !== "string") {
                                continue;
                              }
                              if (typeof indices4[item4] == "number") {
                                j4 = indices4[item4];
                                const err250 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i20, j: j4 }, message: "must NOT have duplicate items (items ## " + j4 + " and " + i20 + " are identical)" };
                                if (vErrors === null) {
                                  vErrors = [err250];
                                } else {
                                  vErrors.push(err250);
                                }
                                errors++;
                                break;
                              }
                              indices4[item4] = i20;
                            }
                          }
                        } else {
                          const err251 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/objectiveIds", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                          if (vErrors === null) {
                            vErrors = [err251];
                          } else {
                            vErrors.push(err251);
                          }
                          errors++;
                        }
                      }
                      if (data52.sourceRefs !== void 0) {
                        let data92 = data52.sourceRefs;
                        if (Array.isArray(data92)) {
                          const len16 = data92.length;
                          for (let i21 = 0; i21 < len16; i21++) {
                            let data93 = data92[i21];
                            if (data93 && typeof data93 == "object" && !Array.isArray(data93)) {
                              if (data93.sourceId === void 0) {
                                const err252 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i21, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceId" }, message: "must have required property 'sourceId'" };
                                if (vErrors === null) {
                                  vErrors = [err252];
                                } else {
                                  vErrors.push(err252);
                                }
                                errors++;
                              }
                              if (data93.sourceRevision === void 0) {
                                const err253 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i21, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "sourceRevision" }, message: "must have required property 'sourceRevision'" };
                                if (vErrors === null) {
                                  vErrors = [err253];
                                } else {
                                  vErrors.push(err253);
                                }
                                errors++;
                              }
                              if (data93.chunkId === void 0) {
                                const err254 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i21, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/required", keyword: "required", params: { missingProperty: "chunkId" }, message: "must have required property 'chunkId'" };
                                if (vErrors === null) {
                                  vErrors = [err254];
                                } else {
                                  vErrors.push(err254);
                                }
                                errors++;
                              }
                              for (const key18 in data93) {
                                if (!(key18 === "sourceId" || key18 === "sourceRevision" || key18 === "chunkId")) {
                                  const err255 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i21, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key18 }, message: "must NOT have additional properties" };
                                  if (vErrors === null) {
                                    vErrors = [err255];
                                  } else {
                                    vErrors.push(err255);
                                  }
                                  errors++;
                                }
                              }
                              if (data93.sourceId !== void 0) {
                                let data94 = data93.sourceId;
                                if (typeof data94 === "string") {
                                  if (func2(data94) < 1) {
                                    const err256 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i21 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/properties/sourceId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err256];
                                    } else {
                                      vErrors.push(err256);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err257 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i21 + "/sourceId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/properties/sourceId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err257];
                                  } else {
                                    vErrors.push(err257);
                                  }
                                  errors++;
                                }
                              }
                              if (data93.sourceRevision !== void 0) {
                                let data95 = data93.sourceRevision;
                                if (!(typeof data95 == "number" && (!(data95 % 1) && !isNaN(data95)))) {
                                  const err258 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i21 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/properties/sourceRevision/type", keyword: "type", params: { type: "integer" }, message: "must be integer" };
                                  if (vErrors === null) {
                                    vErrors = [err258];
                                  } else {
                                    vErrors.push(err258);
                                  }
                                  errors++;
                                }
                                if (typeof data95 == "number") {
                                  if (data95 < 1 || isNaN(data95)) {
                                    const err259 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i21 + "/sourceRevision", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/properties/sourceRevision/minimum", keyword: "minimum", params: { comparison: ">=", limit: 1 }, message: "must be >= 1" };
                                    if (vErrors === null) {
                                      vErrors = [err259];
                                    } else {
                                      vErrors.push(err259);
                                    }
                                    errors++;
                                  }
                                }
                              }
                              if (data93.chunkId !== void 0) {
                                let data96 = data93.chunkId;
                                if (typeof data96 === "string") {
                                  if (func2(data96) < 1) {
                                    const err260 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i21 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/properties/chunkId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                    if (vErrors === null) {
                                      vErrors = [err260];
                                    } else {
                                      vErrors.push(err260);
                                    }
                                    errors++;
                                  }
                                } else {
                                  const err261 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i21 + "/chunkId", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/properties/chunkId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                                  if (vErrors === null) {
                                    vErrors = [err261];
                                  } else {
                                    vErrors.push(err261);
                                  }
                                  errors++;
                                }
                              }
                            } else {
                              const err262 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs/" + i21, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                              if (vErrors === null) {
                                vErrors = [err262];
                              } else {
                                vErrors.push(err262);
                              }
                              errors++;
                            }
                          }
                        } else {
                          const err263 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/sourceRefs", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/sourceRefs/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                          if (vErrors === null) {
                            vErrors = [err263];
                          } else {
                            vErrors.push(err263);
                          }
                          errors++;
                        }
                      }
                      if (data52.hints !== void 0) {
                        let data97 = data52.hints;
                        if (Array.isArray(data97)) {
                          const len17 = data97.length;
                          for (let i22 = 0; i22 < len17; i22++) {
                            let data98 = data97[i22];
                            if (typeof data98 === "string") {
                              if (func2(data98) < 1) {
                                const err264 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/hints/" + i22, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                                if (vErrors === null) {
                                  vErrors = [err264];
                                } else {
                                  vErrors.push(err264);
                                }
                                errors++;
                              }
                            } else {
                              const err265 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/hints/" + i22, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                              if (vErrors === null) {
                                vErrors = [err265];
                              } else {
                                vErrors.push(err265);
                              }
                              errors++;
                            }
                          }
                        } else {
                          const err266 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/hints", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                          if (vErrors === null) {
                            vErrors = [err266];
                          } else {
                            vErrors.push(err266);
                          }
                          errors++;
                        }
                      }
                      if (data52.type !== void 0) {
                        if ("shortAnswer" !== data52.type) {
                          const err267 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/type", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/type/const", keyword: "const", params: { allowedValue: "shortAnswer" }, message: "must be equal to constant" };
                          if (vErrors === null) {
                            vErrors = [err267];
                          } else {
                            vErrors.push(err267);
                          }
                          errors++;
                        }
                      }
                      if (data52.rubric !== void 0) {
                        let data100 = data52.rubric;
                        if (typeof data100 === "string") {
                          if (func2(data100) < 1) {
                            const err268 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/rubric", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/rubric/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                            if (vErrors === null) {
                              vErrors = [err268];
                            } else {
                              vErrors.push(err268);
                            }
                            errors++;
                          }
                        } else {
                          const err269 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/rubric", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/rubric/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                          if (vErrors === null) {
                            vErrors = [err269];
                          } else {
                            vErrors.push(err269);
                          }
                          errors++;
                        }
                      }
                      if (data52.scoring !== void 0) {
                        if ("manual" !== data52.scoring) {
                          const err270 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9 + "/scoring", schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/properties/scoring/const", keyword: "const", params: { allowedValue: "manual" }, message: "must be equal to constant" };
                          if (vErrors === null) {
                            vErrors = [err270];
                          } else {
                            vErrors.push(err270);
                          }
                          errors++;
                        }
                      }
                    } else {
                      const err271 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf/2/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                      if (vErrors === null) {
                        vErrors = [err271];
                      } else {
                        vErrors.push(err271);
                      }
                      errors++;
                    }
                    var _valid1 = _errs188 === errors;
                    if (_valid1 && valid31) {
                      valid31 = false;
                      passing1 = [passing1, 2];
                    } else {
                      if (_valid1) {
                        valid31 = true;
                        passing1 = 2;
                        if (props1 !== true) {
                          props1 = true;
                        }
                      }
                    }
                  }
                  if (!valid31) {
                    const err272 = { instancePath: instancePath + "/resources/" + i0 + "/questions/" + i9, schemaPath: "#/properties/resources/items/properties/questions/items/oneOf", keyword: "oneOf", params: { passingSchemas: passing1 }, message: "must match exactly one schema in oneOf" };
                    if (vErrors === null) {
                      vErrors = [err272];
                    } else {
                      vErrors.push(err272);
                    }
                    errors++;
                  } else {
                    errors = _errs114;
                    if (vErrors !== null) {
                      if (_errs114) {
                        vErrors.length = _errs114;
                      } else {
                        vErrors = null;
                      }
                    }
                  }
                }
              } else {
                const err273 = { instancePath: instancePath + "/resources/" + i0 + "/questions", schemaPath: "#/properties/resources/items/properties/questions/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                if (vErrors === null) {
                  vErrors = [err273];
                } else {
                  vErrors.push(err273);
                }
                errors++;
              }
            }
          } else {
            const err274 = { instancePath: instancePath + "/resources/" + i0, schemaPath: "#/properties/resources/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
            if (vErrors === null) {
              vErrors = [err274];
            } else {
              vErrors.push(err274);
            }
            errors++;
          }
        }
      } else {
        const err275 = { instancePath: instancePath + "/resources", schemaPath: "#/properties/resources/type", keyword: "type", params: { type: "array" }, message: "must be array" };
        if (vErrors === null) {
          vErrors = [err275];
        } else {
          vErrors.push(err275);
        }
        errors++;
      }
    }
    if (data.warnings !== void 0) {
      let data102 = data.warnings;
      if (Array.isArray(data102)) {
        const len18 = data102.length;
        for (let i23 = 0; i23 < len18; i23++) {
          let data103 = data102[i23];
          if (typeof data103 === "string") {
            if (func2(data103) < 1) {
              const err276 = { instancePath: instancePath + "/warnings/" + i23, schemaPath: "#/properties/warnings/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
              if (vErrors === null) {
                vErrors = [err276];
              } else {
                vErrors.push(err276);
              }
              errors++;
            }
          } else {
            const err277 = { instancePath: instancePath + "/warnings/" + i23, schemaPath: "#/properties/warnings/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
            if (vErrors === null) {
              vErrors = [err277];
            } else {
              vErrors.push(err277);
            }
            errors++;
          }
        }
      } else {
        const err278 = { instancePath: instancePath + "/warnings", schemaPath: "#/properties/warnings/type", keyword: "type", params: { type: "array" }, message: "must be array" };
        if (vErrors === null) {
          vErrors = [err278];
        } else {
          vErrors.push(err278);
        }
        errors++;
      }
    }
  } else {
    const err279 = { instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" };
    if (vErrors === null) {
      vErrors = [err279];
    } else {
      vErrors.push(err279);
    }
    errors++;
  }
  validate23.errors = vErrors;
  return errors === 0;
}
validate23.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
var student_content = validate24;
var schema35 = { "type": "object", "properties": { "schemaVersion": { "const": "2.0.0" }, "assignmentId": { "type": "string", "minLength": 1 }, "allocationId": { "type": "string", "minLength": 1 }, "resourceVersionId": { "type": "string", "minLength": 1 }, "title": { "type": "string", "minLength": 1 }, "blocks": { "type": "array", "items": { "oneOf": [{ "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "type": { "enum": ["heading", "paragraph"] }, "data": { "type": "object", "properties": { "text": { "type": "string", "minLength": 1 } }, "required": ["text"], "additionalProperties": false }, "visibility": { "enum": ["student", "both"] } }, "required": ["id", "type", "data", "visibility"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "type": { "const": "questionSet" }, "data": { "type": "object", "properties": { "questionIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true } }, "required": ["questionIds"], "additionalProperties": false }, "visibility": { "enum": ["student", "both"] } }, "required": ["id", "type", "data", "visibility"], "additionalProperties": false }] } }, "questions": { "type": "array", "items": { "oneOf": [{ "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "singleChoice" }, "options": { "type": "array", "minItems": 2, "items": { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "text": { "type": "string", "minLength": 1 } }, "required": ["id", "text"], "additionalProperties": false } } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "hints", "type", "options"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "trueFalse" } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "hints", "type"], "additionalProperties": false }, { "type": "object", "properties": { "id": { "type": "string", "minLength": 1 }, "prompt": { "type": "string", "minLength": 1 }, "maxScore": { "type": "number", "exclusiveMinimum": 0 }, "objectiveIds": { "type": "array", "items": { "type": "string", "minLength": 1 }, "minItems": 1, "uniqueItems": true }, "hints": { "type": "array", "items": { "type": "string", "minLength": 1 } }, "type": { "const": "shortAnswer" } }, "required": ["id", "prompt", "maxScore", "objectiveIds", "hints", "type"], "additionalProperties": false }] } }, "releaseState": { "type": "object", "properties": { "score": { "const": false }, "answers": { "const": false }, "feedback": { "const": false } }, "required": ["score", "answers", "feedback"], "additionalProperties": false } }, "required": ["schemaVersion", "assignmentId", "allocationId", "resourceVersionId", "title", "blocks", "questions", "releaseState"], "additionalProperties": false, "$schema": "https://json-schema.org/draft/2020-12/schema", "title": "student-content" };
function validate24(data, { instancePath = "", parentData, parentDataProperty, rootData = data, dynamicAnchors = {} } = {}) {
  let vErrors = null;
  let errors = 0;
  const evaluated0 = validate24.evaluated;
  if (evaluated0.dynamicProps) {
    evaluated0.props = void 0;
  }
  if (evaluated0.dynamicItems) {
    evaluated0.items = void 0;
  }
  if (data && typeof data == "object" && !Array.isArray(data)) {
    if (data.schemaVersion === void 0) {
      const err0 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "schemaVersion" }, message: "must have required property 'schemaVersion'" };
      if (vErrors === null) {
        vErrors = [err0];
      } else {
        vErrors.push(err0);
      }
      errors++;
    }
    if (data.assignmentId === void 0) {
      const err1 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "assignmentId" }, message: "must have required property 'assignmentId'" };
      if (vErrors === null) {
        vErrors = [err1];
      } else {
        vErrors.push(err1);
      }
      errors++;
    }
    if (data.allocationId === void 0) {
      const err2 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "allocationId" }, message: "must have required property 'allocationId'" };
      if (vErrors === null) {
        vErrors = [err2];
      } else {
        vErrors.push(err2);
      }
      errors++;
    }
    if (data.resourceVersionId === void 0) {
      const err3 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "resourceVersionId" }, message: "must have required property 'resourceVersionId'" };
      if (vErrors === null) {
        vErrors = [err3];
      } else {
        vErrors.push(err3);
      }
      errors++;
    }
    if (data.title === void 0) {
      const err4 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "title" }, message: "must have required property 'title'" };
      if (vErrors === null) {
        vErrors = [err4];
      } else {
        vErrors.push(err4);
      }
      errors++;
    }
    if (data.blocks === void 0) {
      const err5 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "blocks" }, message: "must have required property 'blocks'" };
      if (vErrors === null) {
        vErrors = [err5];
      } else {
        vErrors.push(err5);
      }
      errors++;
    }
    if (data.questions === void 0) {
      const err6 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "questions" }, message: "must have required property 'questions'" };
      if (vErrors === null) {
        vErrors = [err6];
      } else {
        vErrors.push(err6);
      }
      errors++;
    }
    if (data.releaseState === void 0) {
      const err7 = { instancePath, schemaPath: "#/required", keyword: "required", params: { missingProperty: "releaseState" }, message: "must have required property 'releaseState'" };
      if (vErrors === null) {
        vErrors = [err7];
      } else {
        vErrors.push(err7);
      }
      errors++;
    }
    for (const key0 in data) {
      if (!(key0 === "schemaVersion" || key0 === "assignmentId" || key0 === "allocationId" || key0 === "resourceVersionId" || key0 === "title" || key0 === "blocks" || key0 === "questions" || key0 === "releaseState")) {
        const err8 = { instancePath, schemaPath: "#/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key0 }, message: "must NOT have additional properties" };
        if (vErrors === null) {
          vErrors = [err8];
        } else {
          vErrors.push(err8);
        }
        errors++;
      }
    }
    if (data.schemaVersion !== void 0) {
      if ("2.0.0" !== data.schemaVersion) {
        const err9 = { instancePath: instancePath + "/schemaVersion", schemaPath: "#/properties/schemaVersion/const", keyword: "const", params: { allowedValue: "2.0.0" }, message: "must be equal to constant" };
        if (vErrors === null) {
          vErrors = [err9];
        } else {
          vErrors.push(err9);
        }
        errors++;
      }
    }
    if (data.assignmentId !== void 0) {
      let data1 = data.assignmentId;
      if (typeof data1 === "string") {
        if (func2(data1) < 1) {
          const err10 = { instancePath: instancePath + "/assignmentId", schemaPath: "#/properties/assignmentId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err10];
          } else {
            vErrors.push(err10);
          }
          errors++;
        }
      } else {
        const err11 = { instancePath: instancePath + "/assignmentId", schemaPath: "#/properties/assignmentId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err11];
        } else {
          vErrors.push(err11);
        }
        errors++;
      }
    }
    if (data.allocationId !== void 0) {
      let data2 = data.allocationId;
      if (typeof data2 === "string") {
        if (func2(data2) < 1) {
          const err12 = { instancePath: instancePath + "/allocationId", schemaPath: "#/properties/allocationId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err12];
          } else {
            vErrors.push(err12);
          }
          errors++;
        }
      } else {
        const err13 = { instancePath: instancePath + "/allocationId", schemaPath: "#/properties/allocationId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err13];
        } else {
          vErrors.push(err13);
        }
        errors++;
      }
    }
    if (data.resourceVersionId !== void 0) {
      let data3 = data.resourceVersionId;
      if (typeof data3 === "string") {
        if (func2(data3) < 1) {
          const err14 = { instancePath: instancePath + "/resourceVersionId", schemaPath: "#/properties/resourceVersionId/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err14];
          } else {
            vErrors.push(err14);
          }
          errors++;
        }
      } else {
        const err15 = { instancePath: instancePath + "/resourceVersionId", schemaPath: "#/properties/resourceVersionId/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err15];
        } else {
          vErrors.push(err15);
        }
        errors++;
      }
    }
    if (data.title !== void 0) {
      let data4 = data.title;
      if (typeof data4 === "string") {
        if (func2(data4) < 1) {
          const err16 = { instancePath: instancePath + "/title", schemaPath: "#/properties/title/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
          if (vErrors === null) {
            vErrors = [err16];
          } else {
            vErrors.push(err16);
          }
          errors++;
        }
      } else {
        const err17 = { instancePath: instancePath + "/title", schemaPath: "#/properties/title/type", keyword: "type", params: { type: "string" }, message: "must be string" };
        if (vErrors === null) {
          vErrors = [err17];
        } else {
          vErrors.push(err17);
        }
        errors++;
      }
    }
    if (data.blocks !== void 0) {
      let data5 = data.blocks;
      if (Array.isArray(data5)) {
        const len0 = data5.length;
        for (let i0 = 0; i0 < len0; i0++) {
          let data6 = data5[i0];
          const _errs14 = errors;
          let valid3 = false;
          let passing0 = null;
          const _errs15 = errors;
          if (data6 && typeof data6 == "object" && !Array.isArray(data6)) {
            if (data6.id === void 0) {
              const err18 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/0/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
              if (vErrors === null) {
                vErrors = [err18];
              } else {
                vErrors.push(err18);
              }
              errors++;
            }
            if (data6.type === void 0) {
              const err19 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/0/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
              if (vErrors === null) {
                vErrors = [err19];
              } else {
                vErrors.push(err19);
              }
              errors++;
            }
            if (data6.data === void 0) {
              const err20 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/0/required", keyword: "required", params: { missingProperty: "data" }, message: "must have required property 'data'" };
              if (vErrors === null) {
                vErrors = [err20];
              } else {
                vErrors.push(err20);
              }
              errors++;
            }
            if (data6.visibility === void 0) {
              const err21 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/0/required", keyword: "required", params: { missingProperty: "visibility" }, message: "must have required property 'visibility'" };
              if (vErrors === null) {
                vErrors = [err21];
              } else {
                vErrors.push(err21);
              }
              errors++;
            }
            for (const key1 in data6) {
              if (!(key1 === "id" || key1 === "type" || key1 === "data" || key1 === "visibility")) {
                const err22 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/0/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key1 }, message: "must NOT have additional properties" };
                if (vErrors === null) {
                  vErrors = [err22];
                } else {
                  vErrors.push(err22);
                }
                errors++;
              }
            }
            if (data6.id !== void 0) {
              let data7 = data6.id;
              if (typeof data7 === "string") {
                if (func2(data7) < 1) {
                  const err23 = { instancePath: instancePath + "/blocks/" + i0 + "/id", schemaPath: "#/properties/blocks/items/oneOf/0/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err23];
                  } else {
                    vErrors.push(err23);
                  }
                  errors++;
                }
              } else {
                const err24 = { instancePath: instancePath + "/blocks/" + i0 + "/id", schemaPath: "#/properties/blocks/items/oneOf/0/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err24];
                } else {
                  vErrors.push(err24);
                }
                errors++;
              }
            }
            if (data6.type !== void 0) {
              let data8 = data6.type;
              if (!(data8 === "heading" || data8 === "paragraph")) {
                const err25 = { instancePath: instancePath + "/blocks/" + i0 + "/type", schemaPath: "#/properties/blocks/items/oneOf/0/properties/type/enum", keyword: "enum", params: { allowedValues: schema35.properties.blocks.items.oneOf[0].properties.type.enum }, message: "must be equal to one of the allowed values" };
                if (vErrors === null) {
                  vErrors = [err25];
                } else {
                  vErrors.push(err25);
                }
                errors++;
              }
            }
            if (data6.data !== void 0) {
              let data9 = data6.data;
              if (data9 && typeof data9 == "object" && !Array.isArray(data9)) {
                if (data9.text === void 0) {
                  const err26 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/0/properties/data/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
                  if (vErrors === null) {
                    vErrors = [err26];
                  } else {
                    vErrors.push(err26);
                  }
                  errors++;
                }
                for (const key2 in data9) {
                  if (!(key2 === "text")) {
                    const err27 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/0/properties/data/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key2 }, message: "must NOT have additional properties" };
                    if (vErrors === null) {
                      vErrors = [err27];
                    } else {
                      vErrors.push(err27);
                    }
                    errors++;
                  }
                }
                if (data9.text !== void 0) {
                  let data10 = data9.text;
                  if (typeof data10 === "string") {
                    if (func2(data10) < 1) {
                      const err28 = { instancePath: instancePath + "/blocks/" + i0 + "/data/text", schemaPath: "#/properties/blocks/items/oneOf/0/properties/data/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err28];
                      } else {
                        vErrors.push(err28);
                      }
                      errors++;
                    }
                  } else {
                    const err29 = { instancePath: instancePath + "/blocks/" + i0 + "/data/text", schemaPath: "#/properties/blocks/items/oneOf/0/properties/data/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err29];
                    } else {
                      vErrors.push(err29);
                    }
                    errors++;
                  }
                }
              } else {
                const err30 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/0/properties/data/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                if (vErrors === null) {
                  vErrors = [err30];
                } else {
                  vErrors.push(err30);
                }
                errors++;
              }
            }
            if (data6.visibility !== void 0) {
              let data11 = data6.visibility;
              if (!(data11 === "student" || data11 === "both")) {
                const err31 = { instancePath: instancePath + "/blocks/" + i0 + "/visibility", schemaPath: "#/properties/blocks/items/oneOf/0/properties/visibility/enum", keyword: "enum", params: { allowedValues: schema35.properties.blocks.items.oneOf[0].properties.visibility.enum }, message: "must be equal to one of the allowed values" };
                if (vErrors === null) {
                  vErrors = [err31];
                } else {
                  vErrors.push(err31);
                }
                errors++;
              }
            }
          } else {
            const err32 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/0/type", keyword: "type", params: { type: "object" }, message: "must be object" };
            if (vErrors === null) {
              vErrors = [err32];
            } else {
              vErrors.push(err32);
            }
            errors++;
          }
          var _valid0 = _errs15 === errors;
          if (_valid0) {
            valid3 = true;
            passing0 = 0;
            var props0 = true;
          }
          const _errs27 = errors;
          if (data6 && typeof data6 == "object" && !Array.isArray(data6)) {
            if (data6.id === void 0) {
              const err33 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/1/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
              if (vErrors === null) {
                vErrors = [err33];
              } else {
                vErrors.push(err33);
              }
              errors++;
            }
            if (data6.type === void 0) {
              const err34 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/1/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
              if (vErrors === null) {
                vErrors = [err34];
              } else {
                vErrors.push(err34);
              }
              errors++;
            }
            if (data6.data === void 0) {
              const err35 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/1/required", keyword: "required", params: { missingProperty: "data" }, message: "must have required property 'data'" };
              if (vErrors === null) {
                vErrors = [err35];
              } else {
                vErrors.push(err35);
              }
              errors++;
            }
            if (data6.visibility === void 0) {
              const err36 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/1/required", keyword: "required", params: { missingProperty: "visibility" }, message: "must have required property 'visibility'" };
              if (vErrors === null) {
                vErrors = [err36];
              } else {
                vErrors.push(err36);
              }
              errors++;
            }
            for (const key3 in data6) {
              if (!(key3 === "id" || key3 === "type" || key3 === "data" || key3 === "visibility")) {
                const err37 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/1/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key3 }, message: "must NOT have additional properties" };
                if (vErrors === null) {
                  vErrors = [err37];
                } else {
                  vErrors.push(err37);
                }
                errors++;
              }
            }
            if (data6.id !== void 0) {
              let data12 = data6.id;
              if (typeof data12 === "string") {
                if (func2(data12) < 1) {
                  const err38 = { instancePath: instancePath + "/blocks/" + i0 + "/id", schemaPath: "#/properties/blocks/items/oneOf/1/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err38];
                  } else {
                    vErrors.push(err38);
                  }
                  errors++;
                }
              } else {
                const err39 = { instancePath: instancePath + "/blocks/" + i0 + "/id", schemaPath: "#/properties/blocks/items/oneOf/1/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err39];
                } else {
                  vErrors.push(err39);
                }
                errors++;
              }
            }
            if (data6.type !== void 0) {
              if ("questionSet" !== data6.type) {
                const err40 = { instancePath: instancePath + "/blocks/" + i0 + "/type", schemaPath: "#/properties/blocks/items/oneOf/1/properties/type/const", keyword: "const", params: { allowedValue: "questionSet" }, message: "must be equal to constant" };
                if (vErrors === null) {
                  vErrors = [err40];
                } else {
                  vErrors.push(err40);
                }
                errors++;
              }
            }
            if (data6.data !== void 0) {
              let data14 = data6.data;
              if (data14 && typeof data14 == "object" && !Array.isArray(data14)) {
                if (data14.questionIds === void 0) {
                  const err41 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/1/properties/data/required", keyword: "required", params: { missingProperty: "questionIds" }, message: "must have required property 'questionIds'" };
                  if (vErrors === null) {
                    vErrors = [err41];
                  } else {
                    vErrors.push(err41);
                  }
                  errors++;
                }
                for (const key4 in data14) {
                  if (!(key4 === "questionIds")) {
                    const err42 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/1/properties/data/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key4 }, message: "must NOT have additional properties" };
                    if (vErrors === null) {
                      vErrors = [err42];
                    } else {
                      vErrors.push(err42);
                    }
                    errors++;
                  }
                }
                if (data14.questionIds !== void 0) {
                  let data15 = data14.questionIds;
                  if (Array.isArray(data15)) {
                    if (data15.length < 1) {
                      const err43 = { instancePath: instancePath + "/blocks/" + i0 + "/data/questionIds", schemaPath: "#/properties/blocks/items/oneOf/1/properties/data/properties/questionIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                      if (vErrors === null) {
                        vErrors = [err43];
                      } else {
                        vErrors.push(err43);
                      }
                      errors++;
                    }
                    const len1 = data15.length;
                    for (let i1 = 0; i1 < len1; i1++) {
                      let data16 = data15[i1];
                      if (typeof data16 === "string") {
                        if (func2(data16) < 1) {
                          const err44 = { instancePath: instancePath + "/blocks/" + i0 + "/data/questionIds/" + i1, schemaPath: "#/properties/blocks/items/oneOf/1/properties/data/properties/questionIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err44];
                          } else {
                            vErrors.push(err44);
                          }
                          errors++;
                        }
                      } else {
                        const err45 = { instancePath: instancePath + "/blocks/" + i0 + "/data/questionIds/" + i1, schemaPath: "#/properties/blocks/items/oneOf/1/properties/data/properties/questionIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err45];
                        } else {
                          vErrors.push(err45);
                        }
                        errors++;
                      }
                    }
                    let i2 = data15.length;
                    let j0;
                    if (i2 > 1) {
                      const indices0 = {};
                      for (; i2--; ) {
                        let item0 = data15[i2];
                        if (typeof item0 !== "string") {
                          continue;
                        }
                        if (typeof indices0[item0] == "number") {
                          j0 = indices0[item0];
                          const err46 = { instancePath: instancePath + "/blocks/" + i0 + "/data/questionIds", schemaPath: "#/properties/blocks/items/oneOf/1/properties/data/properties/questionIds/uniqueItems", keyword: "uniqueItems", params: { i: i2, j: j0 }, message: "must NOT have duplicate items (items ## " + j0 + " and " + i2 + " are identical)" };
                          if (vErrors === null) {
                            vErrors = [err46];
                          } else {
                            vErrors.push(err46);
                          }
                          errors++;
                          break;
                        }
                        indices0[item0] = i2;
                      }
                    }
                  } else {
                    const err47 = { instancePath: instancePath + "/blocks/" + i0 + "/data/questionIds", schemaPath: "#/properties/blocks/items/oneOf/1/properties/data/properties/questionIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                    if (vErrors === null) {
                      vErrors = [err47];
                    } else {
                      vErrors.push(err47);
                    }
                    errors++;
                  }
                }
              } else {
                const err48 = { instancePath: instancePath + "/blocks/" + i0 + "/data", schemaPath: "#/properties/blocks/items/oneOf/1/properties/data/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                if (vErrors === null) {
                  vErrors = [err48];
                } else {
                  vErrors.push(err48);
                }
                errors++;
              }
            }
            if (data6.visibility !== void 0) {
              let data17 = data6.visibility;
              if (!(data17 === "student" || data17 === "both")) {
                const err49 = { instancePath: instancePath + "/blocks/" + i0 + "/visibility", schemaPath: "#/properties/blocks/items/oneOf/1/properties/visibility/enum", keyword: "enum", params: { allowedValues: schema35.properties.blocks.items.oneOf[1].properties.visibility.enum }, message: "must be equal to one of the allowed values" };
                if (vErrors === null) {
                  vErrors = [err49];
                } else {
                  vErrors.push(err49);
                }
                errors++;
              }
            }
          } else {
            const err50 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf/1/type", keyword: "type", params: { type: "object" }, message: "must be object" };
            if (vErrors === null) {
              vErrors = [err50];
            } else {
              vErrors.push(err50);
            }
            errors++;
          }
          var _valid0 = _errs27 === errors;
          if (_valid0 && valid3) {
            valid3 = false;
            passing0 = [passing0, 1];
          } else {
            if (_valid0) {
              valid3 = true;
              passing0 = 1;
              if (props0 !== true) {
                props0 = true;
              }
            }
          }
          if (!valid3) {
            const err51 = { instancePath: instancePath + "/blocks/" + i0, schemaPath: "#/properties/blocks/items/oneOf", keyword: "oneOf", params: { passingSchemas: passing0 }, message: "must match exactly one schema in oneOf" };
            if (vErrors === null) {
              vErrors = [err51];
            } else {
              vErrors.push(err51);
            }
            errors++;
          } else {
            errors = _errs14;
            if (vErrors !== null) {
              if (_errs14) {
                vErrors.length = _errs14;
              } else {
                vErrors = null;
              }
            }
          }
        }
      } else {
        const err52 = { instancePath: instancePath + "/blocks", schemaPath: "#/properties/blocks/type", keyword: "type", params: { type: "array" }, message: "must be array" };
        if (vErrors === null) {
          vErrors = [err52];
        } else {
          vErrors.push(err52);
        }
        errors++;
      }
    }
    if (data.questions !== void 0) {
      let data18 = data.questions;
      if (Array.isArray(data18)) {
        const len2 = data18.length;
        for (let i3 = 0; i3 < len2; i3++) {
          let data19 = data18[i3];
          const _errs44 = errors;
          let valid13 = false;
          let passing1 = null;
          const _errs45 = errors;
          if (data19 && typeof data19 == "object" && !Array.isArray(data19)) {
            if (data19.id === void 0) {
              const err53 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
              if (vErrors === null) {
                vErrors = [err53];
              } else {
                vErrors.push(err53);
              }
              errors++;
            }
            if (data19.prompt === void 0) {
              const err54 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
              if (vErrors === null) {
                vErrors = [err54];
              } else {
                vErrors.push(err54);
              }
              errors++;
            }
            if (data19.maxScore === void 0) {
              const err55 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
              if (vErrors === null) {
                vErrors = [err55];
              } else {
                vErrors.push(err55);
              }
              errors++;
            }
            if (data19.objectiveIds === void 0) {
              const err56 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
              if (vErrors === null) {
                vErrors = [err56];
              } else {
                vErrors.push(err56);
              }
              errors++;
            }
            if (data19.hints === void 0) {
              const err57 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
              if (vErrors === null) {
                vErrors = [err57];
              } else {
                vErrors.push(err57);
              }
              errors++;
            }
            if (data19.type === void 0) {
              const err58 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
              if (vErrors === null) {
                vErrors = [err58];
              } else {
                vErrors.push(err58);
              }
              errors++;
            }
            if (data19.options === void 0) {
              const err59 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/0/required", keyword: "required", params: { missingProperty: "options" }, message: "must have required property 'options'" };
              if (vErrors === null) {
                vErrors = [err59];
              } else {
                vErrors.push(err59);
              }
              errors++;
            }
            for (const key5 in data19) {
              if (!(key5 === "id" || key5 === "prompt" || key5 === "maxScore" || key5 === "objectiveIds" || key5 === "hints" || key5 === "type" || key5 === "options")) {
                const err60 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/0/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key5 }, message: "must NOT have additional properties" };
                if (vErrors === null) {
                  vErrors = [err60];
                } else {
                  vErrors.push(err60);
                }
                errors++;
              }
            }
            if (data19.id !== void 0) {
              let data20 = data19.id;
              if (typeof data20 === "string") {
                if (func2(data20) < 1) {
                  const err61 = { instancePath: instancePath + "/questions/" + i3 + "/id", schemaPath: "#/properties/questions/items/oneOf/0/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err61];
                  } else {
                    vErrors.push(err61);
                  }
                  errors++;
                }
              } else {
                const err62 = { instancePath: instancePath + "/questions/" + i3 + "/id", schemaPath: "#/properties/questions/items/oneOf/0/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err62];
                } else {
                  vErrors.push(err62);
                }
                errors++;
              }
            }
            if (data19.prompt !== void 0) {
              let data21 = data19.prompt;
              if (typeof data21 === "string") {
                if (func2(data21) < 1) {
                  const err63 = { instancePath: instancePath + "/questions/" + i3 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/0/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err63];
                  } else {
                    vErrors.push(err63);
                  }
                  errors++;
                }
              } else {
                const err64 = { instancePath: instancePath + "/questions/" + i3 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/0/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err64];
                } else {
                  vErrors.push(err64);
                }
                errors++;
              }
            }
            if (data19.maxScore !== void 0) {
              let data22 = data19.maxScore;
              if (typeof data22 == "number") {
                if (data22 <= 0 || isNaN(data22)) {
                  const err65 = { instancePath: instancePath + "/questions/" + i3 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/0/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                  if (vErrors === null) {
                    vErrors = [err65];
                  } else {
                    vErrors.push(err65);
                  }
                  errors++;
                }
              } else {
                const err66 = { instancePath: instancePath + "/questions/" + i3 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/0/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                if (vErrors === null) {
                  vErrors = [err66];
                } else {
                  vErrors.push(err66);
                }
                errors++;
              }
            }
            if (data19.objectiveIds !== void 0) {
              let data23 = data19.objectiveIds;
              if (Array.isArray(data23)) {
                if (data23.length < 1) {
                  const err67 = { instancePath: instancePath + "/questions/" + i3 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/0/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                  if (vErrors === null) {
                    vErrors = [err67];
                  } else {
                    vErrors.push(err67);
                  }
                  errors++;
                }
                const len3 = data23.length;
                for (let i4 = 0; i4 < len3; i4++) {
                  let data24 = data23[i4];
                  if (typeof data24 === "string") {
                    if (func2(data24) < 1) {
                      const err68 = { instancePath: instancePath + "/questions/" + i3 + "/objectiveIds/" + i4, schemaPath: "#/properties/questions/items/oneOf/0/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err68];
                      } else {
                        vErrors.push(err68);
                      }
                      errors++;
                    }
                  } else {
                    const err69 = { instancePath: instancePath + "/questions/" + i3 + "/objectiveIds/" + i4, schemaPath: "#/properties/questions/items/oneOf/0/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err69];
                    } else {
                      vErrors.push(err69);
                    }
                    errors++;
                  }
                }
                let i5 = data23.length;
                let j1;
                if (i5 > 1) {
                  const indices1 = {};
                  for (; i5--; ) {
                    let item1 = data23[i5];
                    if (typeof item1 !== "string") {
                      continue;
                    }
                    if (typeof indices1[item1] == "number") {
                      j1 = indices1[item1];
                      const err70 = { instancePath: instancePath + "/questions/" + i3 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/0/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i5, j: j1 }, message: "must NOT have duplicate items (items ## " + j1 + " and " + i5 + " are identical)" };
                      if (vErrors === null) {
                        vErrors = [err70];
                      } else {
                        vErrors.push(err70);
                      }
                      errors++;
                      break;
                    }
                    indices1[item1] = i5;
                  }
                }
              } else {
                const err71 = { instancePath: instancePath + "/questions/" + i3 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/0/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                if (vErrors === null) {
                  vErrors = [err71];
                } else {
                  vErrors.push(err71);
                }
                errors++;
              }
            }
            if (data19.hints !== void 0) {
              let data25 = data19.hints;
              if (Array.isArray(data25)) {
                const len4 = data25.length;
                for (let i6 = 0; i6 < len4; i6++) {
                  let data26 = data25[i6];
                  if (typeof data26 === "string") {
                    if (func2(data26) < 1) {
                      const err72 = { instancePath: instancePath + "/questions/" + i3 + "/hints/" + i6, schemaPath: "#/properties/questions/items/oneOf/0/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err72];
                      } else {
                        vErrors.push(err72);
                      }
                      errors++;
                    }
                  } else {
                    const err73 = { instancePath: instancePath + "/questions/" + i3 + "/hints/" + i6, schemaPath: "#/properties/questions/items/oneOf/0/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err73];
                    } else {
                      vErrors.push(err73);
                    }
                    errors++;
                  }
                }
              } else {
                const err74 = { instancePath: instancePath + "/questions/" + i3 + "/hints", schemaPath: "#/properties/questions/items/oneOf/0/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                if (vErrors === null) {
                  vErrors = [err74];
                } else {
                  vErrors.push(err74);
                }
                errors++;
              }
            }
            if (data19.type !== void 0) {
              if ("singleChoice" !== data19.type) {
                const err75 = { instancePath: instancePath + "/questions/" + i3 + "/type", schemaPath: "#/properties/questions/items/oneOf/0/properties/type/const", keyword: "const", params: { allowedValue: "singleChoice" }, message: "must be equal to constant" };
                if (vErrors === null) {
                  vErrors = [err75];
                } else {
                  vErrors.push(err75);
                }
                errors++;
              }
            }
            if (data19.options !== void 0) {
              let data28 = data19.options;
              if (Array.isArray(data28)) {
                if (data28.length < 2) {
                  const err76 = { instancePath: instancePath + "/questions/" + i3 + "/options", schemaPath: "#/properties/questions/items/oneOf/0/properties/options/minItems", keyword: "minItems", params: { limit: 2 }, message: "must NOT have fewer than 2 items" };
                  if (vErrors === null) {
                    vErrors = [err76];
                  } else {
                    vErrors.push(err76);
                  }
                  errors++;
                }
                const len5 = data28.length;
                for (let i7 = 0; i7 < len5; i7++) {
                  let data29 = data28[i7];
                  if (data29 && typeof data29 == "object" && !Array.isArray(data29)) {
                    if (data29.id === void 0) {
                      const err77 = { instancePath: instancePath + "/questions/" + i3 + "/options/" + i7, schemaPath: "#/properties/questions/items/oneOf/0/properties/options/items/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                      if (vErrors === null) {
                        vErrors = [err77];
                      } else {
                        vErrors.push(err77);
                      }
                      errors++;
                    }
                    if (data29.text === void 0) {
                      const err78 = { instancePath: instancePath + "/questions/" + i3 + "/options/" + i7, schemaPath: "#/properties/questions/items/oneOf/0/properties/options/items/required", keyword: "required", params: { missingProperty: "text" }, message: "must have required property 'text'" };
                      if (vErrors === null) {
                        vErrors = [err78];
                      } else {
                        vErrors.push(err78);
                      }
                      errors++;
                    }
                    for (const key6 in data29) {
                      if (!(key6 === "id" || key6 === "text")) {
                        const err79 = { instancePath: instancePath + "/questions/" + i3 + "/options/" + i7, schemaPath: "#/properties/questions/items/oneOf/0/properties/options/items/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key6 }, message: "must NOT have additional properties" };
                        if (vErrors === null) {
                          vErrors = [err79];
                        } else {
                          vErrors.push(err79);
                        }
                        errors++;
                      }
                    }
                    if (data29.id !== void 0) {
                      let data30 = data29.id;
                      if (typeof data30 === "string") {
                        if (func2(data30) < 1) {
                          const err80 = { instancePath: instancePath + "/questions/" + i3 + "/options/" + i7 + "/id", schemaPath: "#/properties/questions/items/oneOf/0/properties/options/items/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err80];
                          } else {
                            vErrors.push(err80);
                          }
                          errors++;
                        }
                      } else {
                        const err81 = { instancePath: instancePath + "/questions/" + i3 + "/options/" + i7 + "/id", schemaPath: "#/properties/questions/items/oneOf/0/properties/options/items/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err81];
                        } else {
                          vErrors.push(err81);
                        }
                        errors++;
                      }
                    }
                    if (data29.text !== void 0) {
                      let data31 = data29.text;
                      if (typeof data31 === "string") {
                        if (func2(data31) < 1) {
                          const err82 = { instancePath: instancePath + "/questions/" + i3 + "/options/" + i7 + "/text", schemaPath: "#/properties/questions/items/oneOf/0/properties/options/items/properties/text/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                          if (vErrors === null) {
                            vErrors = [err82];
                          } else {
                            vErrors.push(err82);
                          }
                          errors++;
                        }
                      } else {
                        const err83 = { instancePath: instancePath + "/questions/" + i3 + "/options/" + i7 + "/text", schemaPath: "#/properties/questions/items/oneOf/0/properties/options/items/properties/text/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                        if (vErrors === null) {
                          vErrors = [err83];
                        } else {
                          vErrors.push(err83);
                        }
                        errors++;
                      }
                    }
                  } else {
                    const err84 = { instancePath: instancePath + "/questions/" + i3 + "/options/" + i7, schemaPath: "#/properties/questions/items/oneOf/0/properties/options/items/type", keyword: "type", params: { type: "object" }, message: "must be object" };
                    if (vErrors === null) {
                      vErrors = [err84];
                    } else {
                      vErrors.push(err84);
                    }
                    errors++;
                  }
                }
              } else {
                const err85 = { instancePath: instancePath + "/questions/" + i3 + "/options", schemaPath: "#/properties/questions/items/oneOf/0/properties/options/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                if (vErrors === null) {
                  vErrors = [err85];
                } else {
                  vErrors.push(err85);
                }
                errors++;
              }
            }
          } else {
            const err86 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/0/type", keyword: "type", params: { type: "object" }, message: "must be object" };
            if (vErrors === null) {
              vErrors = [err86];
            } else {
              vErrors.push(err86);
            }
            errors++;
          }
          var _valid1 = _errs45 === errors;
          if (_valid1) {
            valid13 = true;
            passing1 = 0;
            var props1 = true;
          }
          const _errs72 = errors;
          if (data19 && typeof data19 == "object" && !Array.isArray(data19)) {
            if (data19.id === void 0) {
              const err87 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
              if (vErrors === null) {
                vErrors = [err87];
              } else {
                vErrors.push(err87);
              }
              errors++;
            }
            if (data19.prompt === void 0) {
              const err88 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
              if (vErrors === null) {
                vErrors = [err88];
              } else {
                vErrors.push(err88);
              }
              errors++;
            }
            if (data19.maxScore === void 0) {
              const err89 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
              if (vErrors === null) {
                vErrors = [err89];
              } else {
                vErrors.push(err89);
              }
              errors++;
            }
            if (data19.objectiveIds === void 0) {
              const err90 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
              if (vErrors === null) {
                vErrors = [err90];
              } else {
                vErrors.push(err90);
              }
              errors++;
            }
            if (data19.hints === void 0) {
              const err91 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
              if (vErrors === null) {
                vErrors = [err91];
              } else {
                vErrors.push(err91);
              }
              errors++;
            }
            if (data19.type === void 0) {
              const err92 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/1/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
              if (vErrors === null) {
                vErrors = [err92];
              } else {
                vErrors.push(err92);
              }
              errors++;
            }
            for (const key7 in data19) {
              if (!(key7 === "id" || key7 === "prompt" || key7 === "maxScore" || key7 === "objectiveIds" || key7 === "hints" || key7 === "type")) {
                const err93 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/1/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key7 }, message: "must NOT have additional properties" };
                if (vErrors === null) {
                  vErrors = [err93];
                } else {
                  vErrors.push(err93);
                }
                errors++;
              }
            }
            if (data19.id !== void 0) {
              let data32 = data19.id;
              if (typeof data32 === "string") {
                if (func2(data32) < 1) {
                  const err94 = { instancePath: instancePath + "/questions/" + i3 + "/id", schemaPath: "#/properties/questions/items/oneOf/1/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err94];
                  } else {
                    vErrors.push(err94);
                  }
                  errors++;
                }
              } else {
                const err95 = { instancePath: instancePath + "/questions/" + i3 + "/id", schemaPath: "#/properties/questions/items/oneOf/1/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err95];
                } else {
                  vErrors.push(err95);
                }
                errors++;
              }
            }
            if (data19.prompt !== void 0) {
              let data33 = data19.prompt;
              if (typeof data33 === "string") {
                if (func2(data33) < 1) {
                  const err96 = { instancePath: instancePath + "/questions/" + i3 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/1/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                  if (vErrors === null) {
                    vErrors = [err96];
                  } else {
                    vErrors.push(err96);
                  }
                  errors++;
                }
              } else {
                const err97 = { instancePath: instancePath + "/questions/" + i3 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/1/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                if (vErrors === null) {
                  vErrors = [err97];
                } else {
                  vErrors.push(err97);
                }
                errors++;
              }
            }
            if (data19.maxScore !== void 0) {
              let data34 = data19.maxScore;
              if (typeof data34 == "number") {
                if (data34 <= 0 || isNaN(data34)) {
                  const err98 = { instancePath: instancePath + "/questions/" + i3 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/1/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                  if (vErrors === null) {
                    vErrors = [err98];
                  } else {
                    vErrors.push(err98);
                  }
                  errors++;
                }
              } else {
                const err99 = { instancePath: instancePath + "/questions/" + i3 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/1/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                if (vErrors === null) {
                  vErrors = [err99];
                } else {
                  vErrors.push(err99);
                }
                errors++;
              }
            }
            if (data19.objectiveIds !== void 0) {
              let data35 = data19.objectiveIds;
              if (Array.isArray(data35)) {
                if (data35.length < 1) {
                  const err100 = { instancePath: instancePath + "/questions/" + i3 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/1/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                  if (vErrors === null) {
                    vErrors = [err100];
                  } else {
                    vErrors.push(err100);
                  }
                  errors++;
                }
                const len6 = data35.length;
                for (let i8 = 0; i8 < len6; i8++) {
                  let data36 = data35[i8];
                  if (typeof data36 === "string") {
                    if (func2(data36) < 1) {
                      const err101 = { instancePath: instancePath + "/questions/" + i3 + "/objectiveIds/" + i8, schemaPath: "#/properties/questions/items/oneOf/1/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err101];
                      } else {
                        vErrors.push(err101);
                      }
                      errors++;
                    }
                  } else {
                    const err102 = { instancePath: instancePath + "/questions/" + i3 + "/objectiveIds/" + i8, schemaPath: "#/properties/questions/items/oneOf/1/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err102];
                    } else {
                      vErrors.push(err102);
                    }
                    errors++;
                  }
                }
                let i9 = data35.length;
                let j2;
                if (i9 > 1) {
                  const indices2 = {};
                  for (; i9--; ) {
                    let item2 = data35[i9];
                    if (typeof item2 !== "string") {
                      continue;
                    }
                    if (typeof indices2[item2] == "number") {
                      j2 = indices2[item2];
                      const err103 = { instancePath: instancePath + "/questions/" + i3 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/1/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i9, j: j2 }, message: "must NOT have duplicate items (items ## " + j2 + " and " + i9 + " are identical)" };
                      if (vErrors === null) {
                        vErrors = [err103];
                      } else {
                        vErrors.push(err103);
                      }
                      errors++;
                      break;
                    }
                    indices2[item2] = i9;
                  }
                }
              } else {
                const err104 = { instancePath: instancePath + "/questions/" + i3 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/1/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                if (vErrors === null) {
                  vErrors = [err104];
                } else {
                  vErrors.push(err104);
                }
                errors++;
              }
            }
            if (data19.hints !== void 0) {
              let data37 = data19.hints;
              if (Array.isArray(data37)) {
                const len7 = data37.length;
                for (let i10 = 0; i10 < len7; i10++) {
                  let data38 = data37[i10];
                  if (typeof data38 === "string") {
                    if (func2(data38) < 1) {
                      const err105 = { instancePath: instancePath + "/questions/" + i3 + "/hints/" + i10, schemaPath: "#/properties/questions/items/oneOf/1/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                      if (vErrors === null) {
                        vErrors = [err105];
                      } else {
                        vErrors.push(err105);
                      }
                      errors++;
                    }
                  } else {
                    const err106 = { instancePath: instancePath + "/questions/" + i3 + "/hints/" + i10, schemaPath: "#/properties/questions/items/oneOf/1/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                    if (vErrors === null) {
                      vErrors = [err106];
                    } else {
                      vErrors.push(err106);
                    }
                    errors++;
                  }
                }
              } else {
                const err107 = { instancePath: instancePath + "/questions/" + i3 + "/hints", schemaPath: "#/properties/questions/items/oneOf/1/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                if (vErrors === null) {
                  vErrors = [err107];
                } else {
                  vErrors.push(err107);
                }
                errors++;
              }
            }
            if (data19.type !== void 0) {
              if ("trueFalse" !== data19.type) {
                const err108 = { instancePath: instancePath + "/questions/" + i3 + "/type", schemaPath: "#/properties/questions/items/oneOf/1/properties/type/const", keyword: "const", params: { allowedValue: "trueFalse" }, message: "must be equal to constant" };
                if (vErrors === null) {
                  vErrors = [err108];
                } else {
                  vErrors.push(err108);
                }
                errors++;
              }
            }
          } else {
            const err109 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/1/type", keyword: "type", params: { type: "object" }, message: "must be object" };
            if (vErrors === null) {
              vErrors = [err109];
            } else {
              vErrors.push(err109);
            }
            errors++;
          }
          var _valid1 = _errs72 === errors;
          if (_valid1 && valid13) {
            valid13 = false;
            passing1 = [passing1, 1];
          } else {
            if (_valid1) {
              valid13 = true;
              passing1 = 1;
              if (props1 !== true) {
                props1 = true;
              }
            }
            const _errs90 = errors;
            if (data19 && typeof data19 == "object" && !Array.isArray(data19)) {
              if (data19.id === void 0) {
                const err110 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "id" }, message: "must have required property 'id'" };
                if (vErrors === null) {
                  vErrors = [err110];
                } else {
                  vErrors.push(err110);
                }
                errors++;
              }
              if (data19.prompt === void 0) {
                const err111 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "prompt" }, message: "must have required property 'prompt'" };
                if (vErrors === null) {
                  vErrors = [err111];
                } else {
                  vErrors.push(err111);
                }
                errors++;
              }
              if (data19.maxScore === void 0) {
                const err112 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "maxScore" }, message: "must have required property 'maxScore'" };
                if (vErrors === null) {
                  vErrors = [err112];
                } else {
                  vErrors.push(err112);
                }
                errors++;
              }
              if (data19.objectiveIds === void 0) {
                const err113 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "objectiveIds" }, message: "must have required property 'objectiveIds'" };
                if (vErrors === null) {
                  vErrors = [err113];
                } else {
                  vErrors.push(err113);
                }
                errors++;
              }
              if (data19.hints === void 0) {
                const err114 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "hints" }, message: "must have required property 'hints'" };
                if (vErrors === null) {
                  vErrors = [err114];
                } else {
                  vErrors.push(err114);
                }
                errors++;
              }
              if (data19.type === void 0) {
                const err115 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/2/required", keyword: "required", params: { missingProperty: "type" }, message: "must have required property 'type'" };
                if (vErrors === null) {
                  vErrors = [err115];
                } else {
                  vErrors.push(err115);
                }
                errors++;
              }
              for (const key8 in data19) {
                if (!(key8 === "id" || key8 === "prompt" || key8 === "maxScore" || key8 === "objectiveIds" || key8 === "hints" || key8 === "type")) {
                  const err116 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/2/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key8 }, message: "must NOT have additional properties" };
                  if (vErrors === null) {
                    vErrors = [err116];
                  } else {
                    vErrors.push(err116);
                  }
                  errors++;
                }
              }
              if (data19.id !== void 0) {
                let data40 = data19.id;
                if (typeof data40 === "string") {
                  if (func2(data40) < 1) {
                    const err117 = { instancePath: instancePath + "/questions/" + i3 + "/id", schemaPath: "#/properties/questions/items/oneOf/2/properties/id/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                    if (vErrors === null) {
                      vErrors = [err117];
                    } else {
                      vErrors.push(err117);
                    }
                    errors++;
                  }
                } else {
                  const err118 = { instancePath: instancePath + "/questions/" + i3 + "/id", schemaPath: "#/properties/questions/items/oneOf/2/properties/id/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err118];
                  } else {
                    vErrors.push(err118);
                  }
                  errors++;
                }
              }
              if (data19.prompt !== void 0) {
                let data41 = data19.prompt;
                if (typeof data41 === "string") {
                  if (func2(data41) < 1) {
                    const err119 = { instancePath: instancePath + "/questions/" + i3 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/2/properties/prompt/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                    if (vErrors === null) {
                      vErrors = [err119];
                    } else {
                      vErrors.push(err119);
                    }
                    errors++;
                  }
                } else {
                  const err120 = { instancePath: instancePath + "/questions/" + i3 + "/prompt", schemaPath: "#/properties/questions/items/oneOf/2/properties/prompt/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                  if (vErrors === null) {
                    vErrors = [err120];
                  } else {
                    vErrors.push(err120);
                  }
                  errors++;
                }
              }
              if (data19.maxScore !== void 0) {
                let data42 = data19.maxScore;
                if (typeof data42 == "number") {
                  if (data42 <= 0 || isNaN(data42)) {
                    const err121 = { instancePath: instancePath + "/questions/" + i3 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/2/properties/maxScore/exclusiveMinimum", keyword: "exclusiveMinimum", params: { comparison: ">", limit: 0 }, message: "must be > 0" };
                    if (vErrors === null) {
                      vErrors = [err121];
                    } else {
                      vErrors.push(err121);
                    }
                    errors++;
                  }
                } else {
                  const err122 = { instancePath: instancePath + "/questions/" + i3 + "/maxScore", schemaPath: "#/properties/questions/items/oneOf/2/properties/maxScore/type", keyword: "type", params: { type: "number" }, message: "must be number" };
                  if (vErrors === null) {
                    vErrors = [err122];
                  } else {
                    vErrors.push(err122);
                  }
                  errors++;
                }
              }
              if (data19.objectiveIds !== void 0) {
                let data43 = data19.objectiveIds;
                if (Array.isArray(data43)) {
                  if (data43.length < 1) {
                    const err123 = { instancePath: instancePath + "/questions/" + i3 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/2/properties/objectiveIds/minItems", keyword: "minItems", params: { limit: 1 }, message: "must NOT have fewer than 1 items" };
                    if (vErrors === null) {
                      vErrors = [err123];
                    } else {
                      vErrors.push(err123);
                    }
                    errors++;
                  }
                  const len8 = data43.length;
                  for (let i11 = 0; i11 < len8; i11++) {
                    let data44 = data43[i11];
                    if (typeof data44 === "string") {
                      if (func2(data44) < 1) {
                        const err124 = { instancePath: instancePath + "/questions/" + i3 + "/objectiveIds/" + i11, schemaPath: "#/properties/questions/items/oneOf/2/properties/objectiveIds/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                        if (vErrors === null) {
                          vErrors = [err124];
                        } else {
                          vErrors.push(err124);
                        }
                        errors++;
                      }
                    } else {
                      const err125 = { instancePath: instancePath + "/questions/" + i3 + "/objectiveIds/" + i11, schemaPath: "#/properties/questions/items/oneOf/2/properties/objectiveIds/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err125];
                      } else {
                        vErrors.push(err125);
                      }
                      errors++;
                    }
                  }
                  let i12 = data43.length;
                  let j3;
                  if (i12 > 1) {
                    const indices3 = {};
                    for (; i12--; ) {
                      let item3 = data43[i12];
                      if (typeof item3 !== "string") {
                        continue;
                      }
                      if (typeof indices3[item3] == "number") {
                        j3 = indices3[item3];
                        const err126 = { instancePath: instancePath + "/questions/" + i3 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/2/properties/objectiveIds/uniqueItems", keyword: "uniqueItems", params: { i: i12, j: j3 }, message: "must NOT have duplicate items (items ## " + j3 + " and " + i12 + " are identical)" };
                        if (vErrors === null) {
                          vErrors = [err126];
                        } else {
                          vErrors.push(err126);
                        }
                        errors++;
                        break;
                      }
                      indices3[item3] = i12;
                    }
                  }
                } else {
                  const err127 = { instancePath: instancePath + "/questions/" + i3 + "/objectiveIds", schemaPath: "#/properties/questions/items/oneOf/2/properties/objectiveIds/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                  if (vErrors === null) {
                    vErrors = [err127];
                  } else {
                    vErrors.push(err127);
                  }
                  errors++;
                }
              }
              if (data19.hints !== void 0) {
                let data45 = data19.hints;
                if (Array.isArray(data45)) {
                  const len9 = data45.length;
                  for (let i13 = 0; i13 < len9; i13++) {
                    let data46 = data45[i13];
                    if (typeof data46 === "string") {
                      if (func2(data46) < 1) {
                        const err128 = { instancePath: instancePath + "/questions/" + i3 + "/hints/" + i13, schemaPath: "#/properties/questions/items/oneOf/2/properties/hints/items/minLength", keyword: "minLength", params: { limit: 1 }, message: "must NOT have fewer than 1 characters" };
                        if (vErrors === null) {
                          vErrors = [err128];
                        } else {
                          vErrors.push(err128);
                        }
                        errors++;
                      }
                    } else {
                      const err129 = { instancePath: instancePath + "/questions/" + i3 + "/hints/" + i13, schemaPath: "#/properties/questions/items/oneOf/2/properties/hints/items/type", keyword: "type", params: { type: "string" }, message: "must be string" };
                      if (vErrors === null) {
                        vErrors = [err129];
                      } else {
                        vErrors.push(err129);
                      }
                      errors++;
                    }
                  }
                } else {
                  const err130 = { instancePath: instancePath + "/questions/" + i3 + "/hints", schemaPath: "#/properties/questions/items/oneOf/2/properties/hints/type", keyword: "type", params: { type: "array" }, message: "must be array" };
                  if (vErrors === null) {
                    vErrors = [err130];
                  } else {
                    vErrors.push(err130);
                  }
                  errors++;
                }
              }
              if (data19.type !== void 0) {
                if ("shortAnswer" !== data19.type) {
                  const err131 = { instancePath: instancePath + "/questions/" + i3 + "/type", schemaPath: "#/properties/questions/items/oneOf/2/properties/type/const", keyword: "const", params: { allowedValue: "shortAnswer" }, message: "must be equal to constant" };
                  if (vErrors === null) {
                    vErrors = [err131];
                  } else {
                    vErrors.push(err131);
                  }
                  errors++;
                }
              }
            } else {
              const err132 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf/2/type", keyword: "type", params: { type: "object" }, message: "must be object" };
              if (vErrors === null) {
                vErrors = [err132];
              } else {
                vErrors.push(err132);
              }
              errors++;
            }
            var _valid1 = _errs90 === errors;
            if (_valid1 && valid13) {
              valid13 = false;
              passing1 = [passing1, 2];
            } else {
              if (_valid1) {
                valid13 = true;
                passing1 = 2;
                if (props1 !== true) {
                  props1 = true;
                }
              }
            }
          }
          if (!valid13) {
            const err133 = { instancePath: instancePath + "/questions/" + i3, schemaPath: "#/properties/questions/items/oneOf", keyword: "oneOf", params: { passingSchemas: passing1 }, message: "must match exactly one schema in oneOf" };
            if (vErrors === null) {
              vErrors = [err133];
            } else {
              vErrors.push(err133);
            }
            errors++;
          } else {
            errors = _errs44;
            if (vErrors !== null) {
              if (_errs44) {
                vErrors.length = _errs44;
              } else {
                vErrors = null;
              }
            }
          }
        }
      } else {
        const err134 = { instancePath: instancePath + "/questions", schemaPath: "#/properties/questions/type", keyword: "type", params: { type: "array" }, message: "must be array" };
        if (vErrors === null) {
          vErrors = [err134];
        } else {
          vErrors.push(err134);
        }
        errors++;
      }
    }
    if (data.releaseState !== void 0) {
      let data48 = data.releaseState;
      if (data48 && typeof data48 == "object" && !Array.isArray(data48)) {
        if (data48.score === void 0) {
          const err135 = { instancePath: instancePath + "/releaseState", schemaPath: "#/properties/releaseState/required", keyword: "required", params: { missingProperty: "score" }, message: "must have required property 'score'" };
          if (vErrors === null) {
            vErrors = [err135];
          } else {
            vErrors.push(err135);
          }
          errors++;
        }
        if (data48.answers === void 0) {
          const err136 = { instancePath: instancePath + "/releaseState", schemaPath: "#/properties/releaseState/required", keyword: "required", params: { missingProperty: "answers" }, message: "must have required property 'answers'" };
          if (vErrors === null) {
            vErrors = [err136];
          } else {
            vErrors.push(err136);
          }
          errors++;
        }
        if (data48.feedback === void 0) {
          const err137 = { instancePath: instancePath + "/releaseState", schemaPath: "#/properties/releaseState/required", keyword: "required", params: { missingProperty: "feedback" }, message: "must have required property 'feedback'" };
          if (vErrors === null) {
            vErrors = [err137];
          } else {
            vErrors.push(err137);
          }
          errors++;
        }
        for (const key9 in data48) {
          if (!(key9 === "score" || key9 === "answers" || key9 === "feedback")) {
            const err138 = { instancePath: instancePath + "/releaseState", schemaPath: "#/properties/releaseState/additionalProperties", keyword: "additionalProperties", params: { additionalProperty: key9 }, message: "must NOT have additional properties" };
            if (vErrors === null) {
              vErrors = [err138];
            } else {
              vErrors.push(err138);
            }
            errors++;
          }
        }
        if (data48.score !== void 0) {
          if (false !== data48.score) {
            const err139 = { instancePath: instancePath + "/releaseState/score", schemaPath: "#/properties/releaseState/properties/score/const", keyword: "const", params: { allowedValue: false }, message: "must be equal to constant" };
            if (vErrors === null) {
              vErrors = [err139];
            } else {
              vErrors.push(err139);
            }
            errors++;
          }
        }
        if (data48.answers !== void 0) {
          if (false !== data48.answers) {
            const err140 = { instancePath: instancePath + "/releaseState/answers", schemaPath: "#/properties/releaseState/properties/answers/const", keyword: "const", params: { allowedValue: false }, message: "must be equal to constant" };
            if (vErrors === null) {
              vErrors = [err140];
            } else {
              vErrors.push(err140);
            }
            errors++;
          }
        }
        if (data48.feedback !== void 0) {
          if (false !== data48.feedback) {
            const err141 = { instancePath: instancePath + "/releaseState/feedback", schemaPath: "#/properties/releaseState/properties/feedback/const", keyword: "const", params: { allowedValue: false }, message: "must be equal to constant" };
            if (vErrors === null) {
              vErrors = [err141];
            } else {
              vErrors.push(err141);
            }
            errors++;
          }
        }
      } else {
        const err142 = { instancePath: instancePath + "/releaseState", schemaPath: "#/properties/releaseState/type", keyword: "type", params: { type: "object" }, message: "must be object" };
        if (vErrors === null) {
          vErrors = [err142];
        } else {
          vErrors.push(err142);
        }
        errors++;
      }
    }
  } else {
    const err143 = { instancePath, schemaPath: "#/type", keyword: "type", params: { type: "object" }, message: "must be object" };
    if (vErrors === null) {
      vErrors = [err143];
    } else {
      vErrors.push(err143);
    }
    errors++;
  }
  validate24.errors = vErrors;
  return errors === 0;
}
validate24.evaluated = { "props": true, "dynamicProps": false, "dynamicItems": false };
export {
  attempt,
  generate_request,
  generate_result,
  resource,
  student_content
};
