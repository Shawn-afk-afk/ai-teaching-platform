// Port of the unmodified v0.3 Python contract. Domain functions use no I/O.
import {ALL_TYPES,publicExtra,versionFor} from './extended-questions.js';
export const SCHEMA_VERSION='2.0.0';
export const PRIVATE_KEYS=new Set(['sourceRefs','provenance','answerKey','rubric','scoring','providerInfo','scoreRevisions','correctAnswer','chunkId','locator']);
const clone=structuredClone;
export function compareIds(a,b) {
  const x=Array.from(a, c=>c.codePointAt(0)), y=Array.from(b,c=>c.codePointAt(0));
  for(let i=0;i<Math.min(x.length,y.length);i++) if(x[i]!==y[i]) return x[i]<y[i]?-1:1;
  return Math.sign(x.length-y.length);
}
export function timestamp(value) {
  // Contract date-time values carry a timezone. Preserve Python microseconds.
  const m=typeof value==='string' && /^(\d{4})-(\d{2})-(\d{2})[Tt ](\d{2}):(\d{2}):(\d{2})(?:[.,](\d+))?([Zz]|[+-]\d{2}:\d{2})$/.exec(value);
  if(!m) throw new Error('Timestamp must include timezone');
  const [year,month,day,hour,minute,second]=m.slice(1,7).map(Number);
  const d=new Date(0);d.setUTCFullYear(year,month-1,day);d.setUTCHours(hour,minute,second,0);
  if(year<1||d.getUTCFullYear()!==year||d.getUTCMonth()!==month-1||d.getUTCDate()!==day||hour>23||minute>59||second>59) throw new Error('Invalid timestamp');
  let offset=0;
  if(!/z/i.test(m[8])) {
    const oh=Number(m[8].slice(1,3)),om=Number(m[8].slice(4));
    if(oh>23||om>59) throw new Error('Invalid timezone');
    offset=(oh*60+om)*(m[8][0]==='-'?-1:1);
  }
  return BigInt(d.getTime()-offset*60000)*1000n+BigInt((m[7]??'').padEnd(6,'0').slice(0,6));
}
const cmp=(a,b)=>a<b?-1:a>b?1:0;
function newer(a,b,field) {return cmp(timestamp(a[field]),timestamp(b[field])) || (field==='submittedAt'?cmp(a.attemptNo,b.attemptNo):0) || compareIds(a.id,b.id);}
export function effective_scores(revisions) {
  const byId=new Map(revisions.map(x=>[x.id,x]));
  if(byId.size!==revisions.length) throw new Error('Duplicate score revision id');
  for(const item of revisions) {
    timestamp(item.createdAt);
    let cursor=item.supersedesId;
    if(cursor!=null) {
      const target=byId.get(cursor);
      if(!target||target.responseId!==item.responseId) throw new Error('Supersedes must reference the same response');
      if(target.origin!==item.origin) throw new Error('Each scoring origin maintains its own revision chain');
      if(timestamp(item.createdAt)<timestamp(target.createdAt)) throw new Error('Successor predates predecessor');
    }
    const seen=new Set([item.id]);
    while(cursor!=null) {
      if(seen.has(cursor)||!byId.has(cursor)) throw new Error('Invalid score revision chain');
      seen.add(cursor);cursor=byId.get(cursor).supersedesId;
    }
  }
  const valid=revisions.filter(x=>x.invalidatedAt==null&&['teacher','rule'].includes(x.origin));
  const retired=new Set(valid.filter(x=>x.supersedesId).map(x=>x.supersedesId));
  const selected=new Map();
  for(const item of valid.filter(x=>!retired.has(x.id))) {
    const previous=selected.get(item.responseId);
    if(!previous||(item.origin==='teacher'&&previous.origin!=='teacher')||
      (item.origin===previous.origin&&newer(item,previous,'createdAt')>0)) selected.set(item.responseId,item);
  }
  return Object.fromEntries(selected);
}
export function latest_submitted_attempt(attempts,allocationId) {
  const valid=attempts.filter(a=>a.allocationId===allocationId&&['submitted','closed'].includes(a.status)&&a.submittedAt!=null&&a.invalidatedAt==null);
  let selected=null;
  for(const a of valid) { timestamp(a.submittedAt);if(!selected||newer(a,selected,'submittedAt')>0) selected=a; }
  return selected;
}
export function validate_layout(resource) {
  const ids=resource.questions.map(q=>q.id), blocks=resource.blocks;
  if(new Set(ids).size!==ids.length) throw new Error('Duplicate question id');
  if(new Set(blocks.map(b=>b.id)).size!==blocks.length) throw new Error('Duplicate block id');
  const placed=[];
  for(const block of blocks) if(block.type==='questionSet') {
    const refs=block.data.questionIds;
    if(!Array.isArray(refs)||!refs.length) throw new Error('questionSet requires questionIds');
    if(!['student','both'].includes(block.visibility)) throw new Error('questionSet must be visible to students');
    placed.push(...refs);
  }
  if(new Set(placed).size!==placed.length||placed.length!==ids.length||placed.some(x=>!ids.includes(x))) throw new Error('Every question must be placed exactly once, without dangling refs');
  return null;
}
export function strip_private(value) {
  if(Array.isArray(value)) return value.filter(v=>!(v&&typeof v==='object'&&v.type==='teacherNote')).map(strip_private);
  if(value&&typeof value==='object') return Object.fromEntries(Object.entries(value).filter(([k])=>!PRIVATE_KEYS.has(k)).map(([k,v])=>[k,strip_private(v)]));
  return clone(value);
}
export function project_student(version,assignmentId,allocationId) {
  validate_layout(version);
  const blocks=version.blocks.filter(b=>b.type!=='teacherNote'&&b.visibility!=='teacher').map(b=>{
    if(!['heading','paragraph','questionSet','vocabularyList','organizer'].includes(b.type)) throw new Error('Unsupported public block type');
    if(['vocabularyList','organizer'].includes(b.type)){const data=b.type==='vocabularyList'?{entries:b.data.entries.map(({id,term,definition,example})=>({id,term,definition,example}))}:{title:b.data.title,nodes:b.data.nodes.map(({id,label})=>({id,label})),edges:b.data.edges.map(({from,to,label})=>({from,to,label}))};return {id:b.id,type:b.type,data,visibility:b.visibility};}
    const key=b.type==='questionSet'?'questionIds':'text';
    return {id:b.id,type:b.type,data:{[key]:clone(b.data[key])},visibility:b.visibility};
  });
  const questions=version.questions.map(q=>{
    if(!ALL_TYPES.includes(q.type)) throw new Error('Unsupported public question type');
    const publicQuestion=Object.fromEntries(['id','type','prompt','maxScore','objectiveIds','hints'].map(k=>[k,clone(q[k])]));
    if(q.type==='singleChoice') publicQuestion.options=q.options.map(o=>({id:o.id,text:o.text}));
    Object.assign(publicQuestion,publicExtra(q));
    return publicQuestion;
  });
  const projected=strip_private({schemaVersion:versionFor(version),assignmentId,allocationId,resourceVersionId:version.id,title:version.title,blocks,questions,releaseState:{score:false,answers:false,feedback:false}});
  validate_layout(projected);return projected;
}
export function csv_safe_text(value) {
  if(typeof value!=='string') throw new TypeError('CSV text sanitizer expects str');
  return /^[=+\-@\t\r]/.test(value)?"'"+value:value;
}
