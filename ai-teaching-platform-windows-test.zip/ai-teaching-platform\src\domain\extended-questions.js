export const EXTRA_TYPES=['multipleChoice','fillBlank','matching','ordering','upload'];
export const TYPE_LABELS={singleChoice:'單選',trueFalse:'是非',shortAnswer:'簡答',multipleChoice:'多選',fillBlank:'填空',matching:'配對',ordering:'排序',upload:'作品上傳'};
export const ALL_TYPES=Object.keys(TYPE_LABELS);
export const RESOURCE_LABELS={handout:'講義',reading:'閱讀文章',comprehension:'理解題',quiz:'測驗',vocabulary:'字彙活動',stations:'學習站',exitTicket:'退出單',organizer:'圖像組織工具',tieredPractice:'分層練習'};
export const versionFor=c=>(c.questions??[]).some(q=>EXTRA_TYPES.includes(q.type))||(c.blocks??[]).some(b=>['vocabularyList','organizer'].includes(b.type))?'3.0.0':'2.0.0';
export const requestVersion=spec=>spec.questionTypes?.some(t=>EXTRA_TYPES.includes(t))||['vocabulary','organizer'].includes(spec.resourceType)?'3.0.0':'2.0.0';
const norm=s=>s.trim().toLowerCase();
export function validateExtra(q){
 const ids=items=>items.map(x=>x.id),unique=a=>new Set(a).size===a.length;
 if(q.type==='multipleChoice'&&(!unique(ids(q.options))||!q.answerKey.length||!unique(q.answerKey)||q.answerKey.some(id=>!ids(q.options).includes(id))))throw Error('多選答案必須是不同的有效選項。');
 if(q.type==='fillBlank'&&(!q.blanks.length||!unique(ids(q.blanks))||q.blanks.some(b=>!b.label.trim()||!b.answers.length||b.answers.some(s=>!s.trim()))))throw Error('每一空格必須有名稱及可接受答案。');
 if(q.type==='matching'&&(!unique(ids(q.left))||!unique(ids(q.right))||Object.keys(q.answerKey).length!==q.left.length||q.left.some(l=>!ids(q.right).includes(q.answerKey[l.id]))||!unique(Object.values(q.answerKey))))throw Error('配對答案須完整且一對一。');
 if(q.type==='ordering'&&(!unique(ids(q.items))||q.answerKey.length!==q.items.length||!unique(q.answerKey)||q.answerKey.some(id=>!ids(q.items).includes(id))))throw Error('排序答案必須包含每個項目且只出現一次。');
 if(q.type==='upload'&&!q.rubric.trim())throw Error('作品上傳必須有人工評分規準。');
}
export function normalizeExtra(q,value){
 if(value===null||value==='')return null;
 if(['multipleChoice','ordering','upload'].includes(q.type)){
  if(!Array.isArray(value)||value.some(x=>typeof x!=='string')||new Set(value).size!==value.length)throw Error('作答清單格式或識別碼重複。');
  const allowed=q.type==='multipleChoice'?q.options.map(o=>o.id):q.type==='ordering'?q.items.map(o=>o.id):null;
  if(allowed&&value.some(id=>!allowed.includes(id)))throw Error('作答含有不屬於本題的項目。');
  if(q.type==='ordering'&&value.length&&value.length!==q.items.length)throw Error('排序作答必須完整。');
  if(q.type==='upload'&&(value.length>5||value.some(id=>!/^[a-f0-9-]{36}$/i.test(id))))throw Error('作品最多五檔，檔案識別碼必須有效。');
  return q.type==='multipleChoice'||q.type==='upload'?[...value].sort():[...value];
 }
 if(!value||typeof value!=='object'||Array.isArray(value))throw Error('逐格作答格式無效。');
 const keys=q.type==='fillBlank'?q.blanks.map(b=>b.id):q.left.map(b=>b.id);
 if(Object.keys(value).some(k=>!keys.includes(k)))throw Error('作答含不存在的空格或配對。');
 const result=Object.fromEntries(keys.map(k=>[k,value[k]??'']));
 if(Object.values(result).some(v=>typeof v!=='string'||v.length>20000))throw Error('作答值格式無效。');
 if(q.type==='matching'&&Object.values(result).some(v=>v&&!q.right.some(r=>r.id===v)))throw Error('配對項目不存在。');
 if(q.type==='matching'&&new Set(Object.values(result).filter(Boolean)).size!==Object.values(result).filter(Boolean).length)throw Error('同一配對選項不能重複使用。');
 return result;
}
export function objectiveScore(q,value){
 if(value===null)return 0;
 if(q.type==='multipleChoice')return value.length===q.answerKey.length&&value.every(id=>q.answerKey.includes(id))?q.maxScore:0;
 if(q.type==='ordering')return value.length===q.answerKey.length&&value.every((id,i)=>id===q.answerKey[i])?q.maxScore:0;
 if(q.type==='fillBlank')return q.maxScore*q.blanks.filter(b=>b.answers.some(a=>norm(a)===norm(value[b.id]??''))).length/q.blanks.length;
 if(q.type==='matching')return q.maxScore*q.left.filter(l=>value[l.id]===q.answerKey[l.id]).length/q.left.length;
 return value===q.answerKey?q.maxScore:0;
}
export function publicExtra(q){
 if(q.type==='multipleChoice')return {options:q.options.map(({id,text})=>({id,text}))};
 if(q.type==='fillBlank')return {blanks:q.blanks.map(({id,label})=>({id,label}))};
 if(q.type==='matching')return {left:q.left.map(({id,text})=>({id,text})),right:q.right.map(({id,text})=>({id,text}))};
 if(q.type==='ordering')return {items:q.items.map(({id,text})=>({id,text}))};
 return {};
}
export function answerLabel(q){
 if(['shortAnswer','upload'].includes(q.type))return q.rubric;
 if(q.type==='singleChoice')return q.options.find(o=>o.id===q.answerKey)?.text??'';
 if(q.type==='trueFalse')return q.answerKey?'是':'否';
 if(q.type==='multipleChoice')return q.answerKey.map(id=>q.options.find(o=>o.id===id)?.text).join('；');
 if(q.type==='fillBlank')return q.blanks.map(b=>`${b.label}：${b.answers.join('／')}`).join('；');
 if(q.type==='matching')return q.left.map(l=>`${l.text} → ${q.right.find(r=>r.id===q.answerKey[l.id])?.text}`).join('；');
 return q.answerKey.map(id=>q.items.find(o=>o.id===id)?.text).join(' → ');
}
export function responseLabel(q,value){
 if(value===null||value===undefined)return '未作答';
 if(['singleChoice','trueFalse','shortAnswer'].includes(q.type))return q.type==='singleChoice'?q.options.find(o=>o.id===value)?.text??'':q.type==='trueFalse'?(value?'是':'否'):value;
 if(q.type==='upload')return `${value.length} 個作品檔案`;
 if(q.type==='multipleChoice')return value.map(id=>q.options.find(o=>o.id===id)?.text).join('；');
 if(q.type==='fillBlank')return q.blanks.map(b=>`${b.label}：${value[b.id]??''}`).join('；');
 if(q.type==='matching')return q.left.map(l=>`${l.text} → ${q.right.find(r=>r.id===value[l.id])?.text??'未配對'}`).join('；');
 return value.map(id=>q.items.find(o=>o.id===id)?.text).join(' → ');
}
