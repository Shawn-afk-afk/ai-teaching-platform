import {AppError} from '../../src/contracts/errors.js';
import {P6_CONFIG} from './config.mjs';
const invalid=message=>new AppError('MODEL_OUTPUT_INVALID',message);
const transient=status=>[429,502,503,504].includes(status);
const resourceError=/out of memory|insufficient.*memory|requires more.*memory|context.*(length|limit)|input.*(long|limit)|cuda.*alloc/i;

export class OllamaClient {
  constructor({config=P6_CONFIG,fetchImpl=fetch}={}) {this.config=config;this.fetch=fetchImpl;}
  async chat({messages,schema,signal,remainingMs,check=()=>{},validate,onAttempt=()=>{},retryBudget={remaining:1}}) {
    const request={model:this.config.model,messages,format:schema,stream:false,think:false,options:{...this.config.options}};
    for(let attempt=0;;attempt++) {
      check(); signal?.throwIfAborted();
      const started=performance.now();
      const budget=Math.min(this.config.requestTimeoutMs,remainingMs());
      if(budget<=0)throw new AppError('UPSTREAM_TIMEOUT','整份資源已超過期限。');
      const requestSignal=AbortSignal.any([...(signal?[signal]:[]),AbortSignal.timeout(Math.max(1,Math.ceil(budget)))]);
      let entry={attempt,request,startedAt:new Date().toISOString()},phase='transport';
      try {
        const response=await this.fetch(this.config.baseUrl+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(request),signal:requestSignal});
        const raw=await response.text(); check();
        entry.httpStatus=response.status;entry.raw=raw;
        if(!response.ok){
          const message=(()=>{try{return JSON.parse(raw).error??raw;}catch{return raw;}})();
          const error=new AppError(resourceError.test(message)?'MODEL_RESOURCE_LIMIT':'MODEL_SERVICE_UNAVAILABLE',`Ollama HTTP ${response.status}：${message}`,{retryable:transient(response.status)&&!resourceError.test(message)});
          throw error;
        }
        phase='validation';
        let body;try{body=JSON.parse(raw);}catch{throw invalid('模型 HTTP 回應不是有效 JSON。');}
        if(body.error)throw invalid(`模型服務錯誤：${body.error}`);
        if(body.done!==true||body.done_reason!=='stop')throw invalid(`輸出未完整結束（${body.done_reason??'unknown'}），不接受截斷結果。`);
        if(!Number.isInteger(body.eval_count)||body.eval_count<0||!Number.isInteger(body.prompt_eval_count)||body.prompt_eval_count<0)throw invalid('模型缺少有效 token 用量，無法檢查上下文與截斷。');
        if(body.eval_count>=this.config.options.num_predict)throw invalid('模型用盡單次輸出額度；需重新規劃批次。');
        if(body.prompt_eval_count+this.config.options.num_predict>this.config.options.num_ctx)throw invalid('輸入未保留指定輸出額度；需縮小教材批次。');
        let data;try{data=JSON.parse(body.message?.content);}catch{throw invalid('模型內容不是有效 JSON；未建立可發布草稿。');}
        const validationStarted=performance.now();
        try{validate(data);}catch(error){throw invalid(`生成資料驗證失敗：${error.message}`);}check();
        entry.validationMs=performance.now()-validationStarted;
        entry.metrics=Object.fromEntries(['total_duration','load_duration','prompt_eval_count','prompt_eval_duration','eval_count','eval_duration','done_reason'].map(k=>[k,body[k]]));
        entry.state='succeeded';entry.elapsedMs=performance.now()-started;await onAttempt(entry);
        return {data,metrics:entry.metrics};
      } catch(error) {
        entry.state='failed';entry.elapsedMs=performance.now()-started;entry.error=String(error.message);
        await onAttempt(entry);
        if(signal?.aborted)throw signal.reason;
        if(requestSignal.aborted)throw new AppError('UPSTREAM_TIMEOUT','整份資源或本次模型請求已逾時。',{retryable:true});
        // Only transport errors and explicit transient HTTP statuses qualify.
        const retryable=(phase==='transport'&&error instanceof TypeError) || error.retryable===true;
        if(retryable&&retryBudget.remaining>0){retryBudget.remaining--;check();continue;}
        if(error instanceof AppError)throw error;
        throw new AppError('MODEL_SERVICE_UNAVAILABLE','無法連線至本機模型服務。',{retryable:true});
      }
    }
  }
}
