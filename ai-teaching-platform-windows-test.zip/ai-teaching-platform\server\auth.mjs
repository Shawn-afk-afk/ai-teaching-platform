// Replaceable authentication port. The HTTP layer owns cookies/Origin/CSRF;
// this provider resolves opaque credentials to stable, server-trusted actors.
// An alternative provider must provision/map its users to local users/tenants
// and preserve immediate revocation and expiration checks on every call.
export class LocalAuthProvider {
  constructor(store){this.store=store;}
  get sessionMs(){return this.store.sessionMs;}
  authenticate(raw){return this.store.authenticate(raw);}
  loginTeacher(username,password){return this.store.loginTeacher(username,password);}
  loginStudent(code){return this.store.loginStudent(code);}
  logout(raw){return this.store.logout(raw);}
  changePassword(actor,current,next){return this.store.changePassword(actor,current,next);}
}
