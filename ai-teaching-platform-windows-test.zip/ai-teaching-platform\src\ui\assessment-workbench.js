import {el,button,field} from './content-editor.js';
import {errorEnvelope} from '../contracts/errors.js';
import {AppError} from '../contracts/errors.js';
import {DEMO_LEARNERS,learnersFor,attemptResult} from '../domain/assessment.js';
import {latest_submitted_attempt} from '../domain/rules.js';
import {renderStudentWork,updateStudentSession} from './student-work.js';
import {answerLabel,responseLabel} from '../domain/extended-questions.js';
const gradingLabel={not_started:'待批改',partial:'部分已評',complete:'評分完整'},statusLabel={submitted:'已提交',closed:'已關閉'};
export function mountAssessment(root,teacher,learnerFactory,onUpdated,onStudentUpdated,onBusy=()=>{},canAct=()=>true,{serverMode=false}={}){
  let project=null,busy=false,dirty=false,externalBusy=false,disposed=false,learnerId=DEMO_LEARNERS[0].id,allocationId=null,attemptId=null,gradeAttemptId=null,sequence=0,submitKey=crypto.randomUUID();
  const dirtySections=new Set();let actionScope=null;
  const scope=target=>target.closest('[data-grade-id]')?.dataset.gradeId??(target.closest('#student-work')?'student':target.closest('#assignment-form')?'assignment':target.id==='feedback-body'||target.id==='save-feedback'?'feedback':'other');
  const track=event=>dirtySections.add(scope(event.target)),trackClick=event=>{actionScope=scope(event.target);};root.addEventListener('input',track,true);root.addEventListener('click',trackClick,true);
  const status=el('p','',{id:'assessment-state',role:'status'}),error=el('p','',{id:'assessment-error',role:'alert'}),controls=el('fieldset','',{id:'assessment-controls'});
  root.replaceChildren(el('h2','指派、作答與教師批改'),el('p',serverMode?'L1 合成資料班級：學生使用個別邀請碼登入獨立學生頁；指派、計分與發布由後端執行。':'教師用本機示範：A／B 是模擬身分，同一瀏覽器保有完整資料。此處不代表正式登入或跨裝置授權。',{class:'notice'}),status,error,controls);
  function showError(e){const value=errorEnvelope(e);error.textContent=`${value.error.message}（${value.error.code}；追蹤碼 ${value.requestId}）` ;status.textContent='操作未完成，未保存的輸入保留在畫面。';}
  function sync(){controls.disabled=busy||externalBusy||!project;}
  function changed(){dirty=true;status.textContent='有尚未保存的修改。';}
  function discard(){return !dirty||confirm('有未保存的作答或批改輸入。要放棄並切換嗎？');}
  async function action(fn){if(busy||externalBusy||!canAct())return;if(dirty&&[...dirtySections].some(s=>s!==actionScope)&&!confirm('其他表單也有未保存修改。這次操作完成後會重新載入，要放棄其他修改嗎？'))return;busy=true;onBusy(true);sync();error.textContent='';try{await fn();}catch(e){showError(e);}finally{busy=false;onBusy(false);sync();}}
  function accept(p,message){dirty=false;project=p;onUpdated(p);status.textContent=message;}
  async function acceptStudent(message){dirty=false;await onStudentUpdated();status.textContent=message;}
  function addField(parent,label,value,fn,options={},id){const wrap=field(label,value,fn,options);if(id)wrap.querySelector('input,select,textarea').id=id;parent.append(wrap);return wrap;}
  async function renderLearner(container){
    const ticket=++sequence;container.replaceChildren(el('p','讀取指定作業…'));if(!project)return;
    try{const service=learnerFactory(learnerId),mine=await service.listMine(project.id);if(disposed||ticket!==sequence)return;
      if(!mine.some(a=>a.allocationId===allocationId)){allocationId=mine[0]?.allocationId??null;attemptId=null;}
      container.replaceChildren();if(!mine.length){container.append(el('p','這位示範學生尚未獲得指派。'));return;}
      addField(container,'指派給我的作業',allocationId,v=>{if(!discard()){container.querySelector('#learner-allocation').value=allocationId;return;}dirty=false;allocationId=v;attemptId=null;submitKey=crypto.randomUUID();void renderLearner(container);},{options:mine.map(a=>[a.allocationId,`${a.title} · ${a.resourceTitle} v${a.versionNo}`])},'learner-allocation');
      const view=await service.getMine(project.id,allocationId);if(disposed||ticket!==sequence)return;const work=el('div','',{id:'student-work'});container.append(work);
      renderStudentWork(work,view,{changed,selectAttempt(id){if(!discard())return;dirty=false;attemptId=id;void renderLearner(container);},
        begin:()=>action(async()=>{const next=await service.begin(project.id,allocationId);attemptId=next.attempts.find(a=>a.status==='in_progress'&&!a.invalidatedAt)?.id;submitKey=crypto.randomUUID();await acceptStudent('已開始新作答，可暫存後恢復。');}),
        save:(a,answers)=>action(async()=>{await service.saveAnswers(project.id,a.id,a.revision,answers);await acceptStudent('作答已暫存至本機資料庫。');}),
        submit:(a,answers)=>action(async()=>{await service.submit(project.id,a.id,a.revision,answers,submitKey);await acceptStudent('提交成功；簡答待教師批改，結果由教師發布。');})},attemptId);
    }catch(e){if(ticket===sequence)showError(e);}
  }
  function render(){
    sequence++;controls.replaceChildren();sync();if(!project){controls.append(el('p','請先選擇一個專案。'));return;}
    const DEMO_LEARNERS=learnersFor(project);
    const create=el('details');create.open=!(project.assignments?.length);create.append(el('summary','發布自主學習作業'));
    const values={title:`${project.title}自主學習`,opensAt:null,closesAt:null,maxAttempts:1,allocations:[]};let assignKey=crypto.randomUUID();
    const form=el('fieldset','',{id:'assignment-form'});form.disabled=project.status==='archived';addField(form,'作業名稱',values.title,v=>{values.title=v;changed();},{},'assignment-title');
    addField(form,'教學模式','selfPaced',v=>{values.mode=v;changed();},{options:[['selfPaced','自主學習'],['synchronous',serverMode?'同步課堂':'同步課堂（本機模擬）']]},'assignment-mode');
    const dateValue=value=>value?new Date(value).toISOString():null;
    for(const [name,label] of [['opensAt','開放時間（留白立即開放）'],['closesAt','截止時間（留白不限時）']])addField(form,label,'',v=>{values[name]=v;changed();},{type:'datetime-local'},'assignment-'+name);
    addField(form,'最多作答次數',1,v=>{values.maxAttempts=v;changed();},{type:'number'},'assignment-attempts');
    const versions=(project.versions??[]).map(v=>[v.id,`${v.title} · v${v.versionNo} · ${project.profiles.find(p=>p.id===v.profileId)?.readingLoad.teacherLabel??''}`]),choices={};
    for(const learner of DEMO_LEARNERS)addField(form,`${learner.name} 的固定教材版本`,'',v=>{choices[learner.id]=v;changed();},{options:[['','不指派'],...versions]},'assign-'+learner.id);
    const publish=button('發布作業與指派',()=>action(async()=>{const p=await teacher.assign(project.id,project.revision,{...values,opensAt:dateValue(values.opensAt),closesAt:dateValue(values.closesAt),allocations:Object.entries(choices).filter(([,id])=>id).map(([learnerId,resourceVersionId])=>({learnerId,resourceVersionId}))},assignKey);assignKey=crypto.randomUUID();accept(p,'作業已發布；每位學生固定使用所選版本。');}));publish.id='publish-assignment';publish.disabled=!versions.length;form.append(el('p','留白題目可提交；空白客觀題計 0 分，簡答待批改。截止後拒絕提交；每次重做另建紀錄。'),publish);if(!versions.length)form.append(el('p','請先在教材工作台發布至少一個版本。'));create.append(form);controls.append(create);
    const teacherPanel=el('details');teacherPanel.open=Boolean(project.attempts?.some(a=>a.status!=='in_progress'));teacherPanel.append(el('summary','教師：提交概況、批改與結果發布'));
    const overview=el('div','',{id:'submission-overview'});
    for(const a of project.allocations??[]){const assignment=project.assignments.find(x=>x.id===a.assignmentId),latest=latest_submitted_attempt(project.attempts??[],a.id),name=DEMO_LEARNERS.find(l=>l.id===a.learnerId)?.name,v=project.versions.find(v=>v.id===a.resourceVersionId);overview.append(el('p',`${assignment.title} · ${name} · ${latest?`最新有效提交：第 ${latest.attemptNo} 次；${gradingLabel[latest.gradingStatus]}`:'尚未提交'} · ${v.title} v${v.versionNo}`));}teacherPanel.append(overview);
    const submitted=(project.attempts??[]).filter(a=>a.status!=='in_progress'&&!a.invalidatedAt);
    if(!submitted.some(a=>a.id===gradeAttemptId))gradeAttemptId=submitted.at(-1)?.id;
    if(submitted.length){addField(teacherPanel,'選擇要批改的提交',gradeAttemptId,v=>{if(!discard())return;dirty=false;gradeAttemptId=v;render();},{options:submitted.map(a=>{const allocation=project.allocations.find(x=>x.id===a.allocationId);return [a.id,`${DEMO_LEARNERS.find(l=>l.id===allocation.learnerId)?.name} · 第 ${a.attemptNo} 次 · ${project.assignments.find(s=>s.id===allocation.assignmentId).title}`];})},'grade-attempt');renderGrading(teacherPanel,submitted.find(a=>a.id===gradeAttemptId));}
    else teacherPanel.append(el('p','尚無有效提交，草稿不會進入批改與報告。'));controls.append(teacherPanel);
    if(serverMode)return;
    const learnerPanel=el('details');learnerPanel.open=Boolean(project.allocations?.length);learnerPanel.append(el('summary','學生流程模擬（本機）'));
    const learnerContent=el('div','',{id:'learner-panel'});addField(learnerPanel,'模擬學生',learnerId,v=>{if(!discard()){root.querySelector('#demo-learner').value=learnerId;return;}dirty=false;learnerId=v;allocationId=null;attemptId=null;submitKey=crypto.randomUUID();void renderLearner(learnerContent);},{options:DEMO_LEARNERS.map(l=>[l.id,l.name])},'demo-learner');learnerPanel.append(learnerContent);controls.append(learnerPanel);void renderLearner(learnerContent);
  }
  function renderGrading(panel,attempt){
    const allocation=project.allocations.find(a=>a.id===attempt.allocationId),version=project.versions.find(v=>v.id===allocation.resourceVersionId),result=attemptResult(project,attempt);
    panel.append(el('p',`${statusLabel[attempt.status]} · ${gradingLabel[attempt.gradingStatus]} · 得分 ${result.score}／已評配分 ${result.scoredMax}；總配分 ${result.totalMax} · ${result.scoreComplete?'完整':'不完整，待批改不補零'}`,{id:'grade-summary'}));
    for(const item of result.questions){const q=version.questions.find(q=>q.id===item.questionId),r=project.responses.find(r=>r.id===item.responseId),card=el('div','',{class:'edit-card','data-grade-id':q.id});let score=item.score,reason='';
      const answer=responseLabel(q,r.answer);
      card.append(el('h4',q.prompt),el('p',`學生回答：${answer}`),el('p',`答案／規準：${answerLabel(q)}`),el('p',`目前有效分數：${item.score===null?'待批改':item.score+'／'+item.maxScore} · ${item.origin??'無'}`));
      if(q.type==='upload')for(const id of r.answer??[])card.append(el('a',project.workFiles?.find(f=>f.id===id)?.name??'下載學生作品',{href:`/api/works/${id}`,download:''}));
      // Keep an empty grading input distinct from an explicit zero.
      addField(card,`教師分數（0～${q.maxScore}）`,score??'',v=>{score=v;changed();},{type:'text'}).querySelector('input').inputMode='decimal';
      addField(card,'評分原因（教師內部）','',v=>{reason=v;changed();},{type:'textarea'});
      card.append(button('保存教師評分',()=>action(async()=>{if(score===null||String(score).trim()==='')throw new AppError('VALIDATION_FAILED','請填寫分數；留白不代表零分。');accept(await teacher.grade(project.id,project.revision,r.id,Number(score),reason),'教師評分已保存；學生仍只見先前發布的快照。');})));
      const history=el('details');history.append(el('summary','評分修訂歷史'));
      for(const s of (project.scoreRevisions??[]).filter(s=>s.responseId===r.id)){const row=el('p',`${s.origin} · ${s.score}／${s.maxScore} · ${s.invalidatedAt?'已撤銷':'歷史保留'} · ${s.reason}`);if(s.origin==='teacher'&&!s.invalidatedAt)row.append(button('撤銷此教師修訂',()=>action(async()=>accept(await teacher.revokeGrade(project.id,project.revision,s.id),'已撤銷修訂並重新選取有效分數；需另行發布更新。'))));history.append(row);}card.append(history);panel.append(card);
    }
    let body=project.feedbackDrafts?.find(f=>f.attemptId===attempt.id)?.body??'';
    addField(panel,'教師回饋草稿',body,v=>{body=v;changed();},{type:'textarea'},'feedback-body');const save=button('保存回饋草稿',()=>action(async()=>accept(await teacher.saveFeedback(project.id,project.revision,attempt.id,body),'回饋草稿已保存，尚未對學生發布。')));save.id='save-feedback';panel.append(save);
    const releases=el('div','',{class:'actions'});
    for(const [kind,name] of [['score','分數'],['answers','答案與規準'],['feedback','回饋']]){const releaseKey=crypto.randomUUID(),btn=button(`發布${name}`,()=>action(async()=>{if(dirty){status.textContent='請先保存修改，再發布已保存的結果。';return;}accept(await teacher.release(project.id,project.revision,attempt.id,kind,releaseKey),`${name}已明確發布給此筆作答的學生。`);}));btn.id='release-'+kind;releases.append(btn);}panel.append(el('p','三項各自發布。之後修改分數或回饋，需再次發布才會更新學生看到的內容。'),releases);
  }
  let polling=false;
  const poll=setInterval(async()=>{if(serverMode||polling||busy||disposed||!project||!allocationId)return;const pid=project.id,aid=allocationId,lid=learnerId,ticket=sequence;polling=true;try{const session=await learnerFactory(lid).sessionState(pid,aid);if(!disposed&&ticket===sequence&&lid===learnerId&&aid===allocationId){const work=root.querySelector('#student-work');if(work)updateStudentSession(work,session);}}catch{if(!disposed&&ticket===sequence){const work=root.querySelector('#student-work');if(work)updateStudentSession(work,null,true);}}finally{polling=false;}},1000);
  return {setProject(p){if(p?.id!==project?.id){allocationId=null;attemptId=null;gradeAttemptId=null;}project=p;dirty=false;dirtySections.clear();error.textContent='';render();},setExternalBusy(value){externalBusy=value;sync();},hasChanges:()=>dirty,isBusy:()=>busy,dispose(){disposed=true;sequence++;clearInterval(poll);root.removeEventListener('input',track,true);root.removeEventListener('click',trackClick,true);root.replaceChildren();}};
}
