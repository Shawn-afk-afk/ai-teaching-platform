"""Extract page text in geometric reading order; preserve raw lines and status."""
import sys, json, re, hashlib
import pdfplumber
sys.stdout.reconfigure(encoding='utf-8')
path=sys.argv[1]
pages=[]
with pdfplumber.open(path) as doc:
    if len(doc.pages)>100: raise ValueError('PDF 上限為 100 頁，請拆分。')
    for i,page in enumerate(doc.pages,1):
        try:
            raw=page.dedupe_chars().extract_text(x_tolerance=2,y_tolerance=3) or ''
            # Resolve duplicate overprints and keep each original line available.
            # Do not concatenate Chinese translations into English continuation.
            lines=[s.strip() for s in raw.splitlines() if s.strip()]
            normalized=[]
            for line in lines:
                if normalized and re.search(r'[A-Za-z,;]$',normalized[-1]) and re.match(r'^[a-z]',line) and not re.search(r'[\u3400-\u9fff]',line+normalized[-1]):
                    normalized[-1]+=' '+line
                else: normalized.append(line)
            pages.append({'pdfPage':i,'status':'text_extracted' if raw.strip() else 'needs_ocr',
                          'rawText':raw,'text':'\n'.join(normalized),'images':len(page.images)})
        except Exception as e: pages.append({'pdfPage':i,'status':'failed','text':'','rawText':'','error':str(e)})
print(json.dumps({'sha256':hashlib.sha256(open(path,'rb').read()).hexdigest(),'pages':pages,
                  'warnings':['文字擷取不代表圖片、音訊或圖表已解析。掃描頁須 OCR；請核對教師註記、欄位順序與跨頁句子。']},ensure_ascii=False))
